package com.sunline.sbp.model;

public class ComItex {
	private int stacid;
	private String assimp;
	private String acexcd;
	private String acexna;
	private String valide;
	private String fromdt;
	private String pscope;
	private int ordeid;
	private String desctx;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getAssimp() {
		return assimp;
	}
	public void setAssimp(String assimp) {
		this.assimp = assimp;
	}
	public String getAcexcd() {
		return acexcd;
	}
	public void setAcexcd(String acexcd) {
		this.acexcd = acexcd;
	}
	public String getAcexna() {
		return acexna;
	}
	public void setAcexna(String acexna) {
		this.acexna = acexna;
	}
	public String getValide() {
		return valide;
	}
	public void setValide(String valide) {
		this.valide = valide;
	}
	public String getFromdt() {
		return fromdt;
	}
	public void setFromdt(String fromdt) {
		this.fromdt = fromdt;
	}
	public String getPscope() {
		return pscope;
	}
	public void setPscope(String pscope) {
		this.pscope = pscope;
	}
	public int getOrdeid() {
		return ordeid;
	}
	public void setOrdeid(int ordeid) {
		this.ordeid = ordeid;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
}
