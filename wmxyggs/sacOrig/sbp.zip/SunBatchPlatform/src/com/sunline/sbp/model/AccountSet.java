package com.sunline.sbp.model;

/**
 * ���ױ���com_stac��
 * @author Zhangjin
 *
 */
public class AccountSet {
	private int stacid;
	private int linkid;
	private String stacna;
	private String brchna;
	private String crcycd;
	private String starmh;
	private int mesglt;
	private String autoup;
	private int stacst;
	private String curtmh;
	private String closmh;
	private String glisdt;
	private String realbl;
	private String blncck;
	private String rstrvc;
	private String stacmt;
	private String keepac;
	private String vlidtg;
	private String acctdt;
	private String bsnsdt;
	private String musctg;
	private int muscid;
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public int getLinkid() {
		return linkid;
	}
	public void setLinkid(int linkid) {
		this.linkid = linkid;
	}
	public String getStacna() {
		return stacna;
	}
	public void setStacna(String stacna) {
		this.stacna = stacna;
	}
	public String getBrchna() {
		return brchna;
	}
	public void setBrchna(String brchna) {
		this.brchna = brchna;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getStarmh() {
		return starmh;
	}
	public void setStarmh(String starmh) {
		this.starmh = starmh;
	}
	public int getMesglt() {
		return mesglt;
	}
	public void setMesglt(int mesglt) {
		this.mesglt = mesglt;
	}
	public String getAutoup() {
		return autoup;
	}
	public void setAutoup(String autoup) {
		this.autoup = autoup;
	}
	public int getStacst() {
		return stacst;
	}
	public void setStacst(int stacst) {
		this.stacst = stacst;
	}
	public String getCurtmh() {
		return curtmh;
	}
	public void setCurtmh(String curtmh) {
		this.curtmh = curtmh;
	}
	public String getClosmh() {
		return closmh;
	}
	public void setClosmh(String closmh) {
		this.closmh = closmh;
	}
	public String getGlisdt() {
		return glisdt;
	}
	public void setGlisdt(String glisdt) {
		this.glisdt = glisdt;
	}
	public String getRealbl() {
		return realbl;
	}
	public void setRealbl(String realbl) {
		this.realbl = realbl;
	}
	public String getBlncck() {
		return blncck;
	}
	public void setBlncck(String blncck) {
		this.blncck = blncck;
	}
	public String getRstrvc() {
		return rstrvc;
	}
	public void setRstrvc(String rstrvc) {
		this.rstrvc = rstrvc;
	}
	public String getStacmt() {
		return stacmt;
	}
	public void setStacmt(String stacmt) {
		this.stacmt = stacmt;
	}
	public String getKeepac() {
		return keepac;
	}
	public void setKeepac(String keepac) {
		this.keepac = keepac;
	}
	public String getVlidtg() {
		return vlidtg;
	}
	public void setVlidtg(String vlidtg) {
		this.vlidtg = vlidtg;
	}
	public String getBsnsdt() {
		return bsnsdt;
	}
	public void setBsnsdt(String bsnsdt) {
		this.bsnsdt = bsnsdt;
	}
	public String getAcctdt() {
		return acctdt;
	}
	public void setAcctdt(String acctdt) {
		this.acctdt = acctdt;
	}
	public String getMusctg() {
		return musctg;
	}
	public void setMusctg(String musctg) {
		this.musctg = musctg;
	}
	public int getMuscid() {
		return muscid;
	}
	public void setMuscid(int muscid) {
		this.muscid = muscid;
	}
}
