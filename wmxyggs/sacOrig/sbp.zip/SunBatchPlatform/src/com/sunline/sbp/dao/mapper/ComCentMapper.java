package com.sunline.sbp.dao.mapper;

import java.util.List;

import com.sunline.sbp.model.ComCent;

public interface ComCentMapper {
	public List<ComCent> getAllEntities();
}
