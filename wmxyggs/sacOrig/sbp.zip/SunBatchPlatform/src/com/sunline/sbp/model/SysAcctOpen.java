package com.sunline.sbp.model;

public class SysAcctOpen {
	private int stacid;
	private String systid;
	private String brchcd;
	private String crcycd;
	private String itemcd;
	private int aorder;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getBrchcd() {
		return brchcd;
	}
	public void setBrchcd(String brchcd) {
		this.brchcd = brchcd;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getItemcd() {
		return itemcd;
	}
	public void setItemcd(String itemcd) {
		this.itemcd = itemcd;
	}
	public int getAorder() {
		return aorder;
	}
	public void setAorder(int aorder) {
		this.aorder = aorder;
	}
	
	public String toString(){
		return "��������:".concat(String.valueOf(stacid)).concat(",������ϵͳ:").concat(systid)
				.concat(",��������:").concat(brchcd).concat(",��������:").concat(crcycd).concat(",������Ŀ:")
				.concat(itemcd).concat(",���:").concat(String.valueOf(aorder));
	}
}
