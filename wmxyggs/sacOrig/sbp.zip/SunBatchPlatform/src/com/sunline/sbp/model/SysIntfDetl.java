package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * �ӿ���ϸ����(sys_intf_detl)
 * @author Zhangjin
 *
 */
public class SysIntfDetl implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3738450984979516746L;
	String intfcd;
	String inottg;
	String fildlv;
	String fildcd;
	String fildna;
	String enname;
	String nulflg;
	String dftval;
	String tagcds;
	String desctx;
	String vermod;
	String module;
	String projcd;
	public String getIntfcd() {
		return intfcd;
	}
	public void setIntfcd(String intfcd) {
		this.intfcd = intfcd;
	}
	public String getInottg() {
		return inottg;
	}
	public void setInottg(String inottg) {
		this.inottg = inottg;
	}
	public String getFildlv() {
		return fildlv;
	}
	public void setFildlv(String fildlv) {
		this.fildlv = fildlv;
	}
	public String getFildcd() {
		return fildcd;
	}
	public void setFildcd(String fildcd) {
		this.fildcd = fildcd;
	}
	public String getFildna() {
		return fildna;
	}
	public void setFildna(String fildna) {
		this.fildna = fildna;
	}
	public String getEnname() {
		return enname;
	}
	public void setEnname(String enname) {
		this.enname = enname;
	}
	public String getNulflg() {
		return nulflg;
	}
	public void setNulflg(String nulflg) {
		this.nulflg = nulflg;
	}
	public String getDftval() {
		return dftval;
	}
	public void setDftval(String dftval) {
		this.dftval = dftval;
	}
	public String getTagcds() {
		return tagcds;
	}
	public void setTagcds(String tagcds) {
		this.tagcds = tagcds;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
}
