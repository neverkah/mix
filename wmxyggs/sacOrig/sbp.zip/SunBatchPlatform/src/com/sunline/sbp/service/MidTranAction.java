package com.sunline.sbp.service;

import com.sunline.sbp.model.MidTran;


public interface MidTranAction{
	public void insert(MidTran midtran);
	public void generateTranDetail();
}
