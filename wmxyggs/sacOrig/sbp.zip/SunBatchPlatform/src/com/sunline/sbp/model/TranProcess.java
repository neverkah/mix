package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * �����붨���(sys_prcs)
 * @author Zhangjin
 *
 */
public class TranProcess implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8871132208548657222L;
	private String prcscd;
	private String prcsna;
	private String proccd;
	private String cktrtg;
	private String lnblck;
	private String fundtg;
	private String prtrtp;
	private String usedtg;
	private String enname;
	private String desctx;
	private String strktg;
	private String chrgfg;
	private String chrgtp;
	private String bftmpl;
	private String bftmid;
	private String aftmpl;
	private String aftmid;
	private String prproc;
	private String afproc;
	private String erproc;
	private String qtgrad;
	private String vermod;
	private String module;
	private String projcd;
	
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public String getPrcsna() {
		return prcsna;
	}
	public void setPrcsna(String prcsna) {
		this.prcsna = prcsna;
	}
	public String getProccd() {
		return proccd;
	}
	public void setProccd(String proccd) {
		this.proccd = proccd;
	}
	public String getCktrtg() {
		return cktrtg;
	}
	public void setCktrtg(String cktrtg) {
		this.cktrtg = cktrtg;
	}
	public String getFundtg() {
		return fundtg;
	}
	public void setFundtg(String fundtg) {
		this.fundtg = fundtg;
	}
	public String getPrtrtp() {
		return prtrtp;
	}
	public void setPrtrtp(String prtrtp) {
		this.prtrtp = prtrtp;
	}
	public String getUsedtg() {
		return usedtg;
	}
	public void setUsedtg(String usedtg) {
		this.usedtg = usedtg;
	}
	public String getEnname() {
		return enname;
	}
	public void setEnname(String enname) {
		this.enname = enname;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getStrktg() {
		return strktg;
	}
	public void setStrktg(String strktg) {
		this.strktg = strktg;
	}
	public String getChrgfg() {
		return chrgfg;
	}
	public void setChrgfg(String chrgfg) {
		this.chrgfg = chrgfg;
	}
	public String getChrgtp() {
		return chrgtp;
	}
	public void setChrgtp(String chrgtp) {
		this.chrgtp = chrgtp;
	}
	public String getBftmpl() {
		return bftmpl;
	}
	public void setBftmpl(String bftmpl) {
		this.bftmpl = bftmpl;
	}
	public String getBftmid() {
		return bftmid;
	}
	public void setBftmid(String bftmid) {
		this.bftmid = bftmid;
	}
	public String getAftmpl() {
		return aftmpl;
	}
	public void setAftmpl(String aftmpl) {
		this.aftmpl = aftmpl;
	}
	public String getAftmid() {
		return aftmid;
	}
	public void setAftmid(String aftmid) {
		this.aftmid = aftmid;
	}
	public String getPrproc() {
		return prproc;
	}
	public void setPrproc(String prproc) {
		this.prproc = prproc;
	}
	public String getAfproc() {
		return afproc;
	}
	public void setAfproc(String afproc) {
		this.afproc = afproc;
	}
	public String getErproc() {
		return erproc;
	}
	public void setErproc(String erproc) {
		this.erproc = erproc;
	}
	public String getQtgrad() {
		return qtgrad;
	}
	public void setQtgrad(String qtgrad) {
		this.qtgrad = qtgrad;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
	public String getLnblck() {
		return lnblck;
	}
	public void setLnblck(String lnblck) {
		this.lnblck = lnblck;
	}
	
	
}
