package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.TranProcess;

public interface TranProcessMapper {
	public TranProcess getEntity(TranProcess tranProcess);
}
