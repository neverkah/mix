package com.sunline.sbp.model;

/**
 * 
 * @author Zhangjin
 *
 */

public class ProfParamer {
	private String proftp;
	private String profid;
	private String profky;
	private String profvl;
	private String vermod;
	private String module;
	private String projcd;
	
	
	public String getProftp() {
		return proftp;
	}
	public void setProftp(String proftp) {
		this.proftp = proftp;
	}
	public String getProfid() {
		return profid;
	}
	public void setProfid(String profid) {
		this.profid = profid;
	}
	public String getProfky() {
		return profky;
	}
	public void setProfky(String profky) {
		this.profky = profky;
	}
	public String getProfvl() {
		return profvl;
	}
	public void setProfvl(String profvl) {
		this.profvl = profvl;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
	
	
}
