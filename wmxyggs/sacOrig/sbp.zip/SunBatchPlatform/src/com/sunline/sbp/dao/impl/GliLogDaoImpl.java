package com.sunline.sbp.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.Enumeration;
import com.sunline.foundation.tools.StringUtil;
import com.sunline.sbp.dao.GlaVoucherDao;
import com.sunline.sbp.dao.GliLogDao;
import com.sunline.sbp.dao.mapper.GlaVoucherMapper;
import com.sunline.sbp.dao.mapper.GliLogMapper;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.GlbCler;
import com.sunline.sbp.model.GliMslg;
import com.sunline.sunbp.util.MyBatisUtil;

public class GliLogDaoImpl implements GliLogDao {

	private Logger logger = Logger.getLogger(GliLogDaoImpl.class);

	private GliLogMapper gliLogMapper;

	public GliLogMapper getGliLogMapper() {
		return gliLogMapper;
	}

	public void setGliLogMapper(GliLogMapper gliLogMapper) {
		this.gliLogMapper = gliLogMapper;
	}

	@Override
	public void insertGliMslg(String bussinessInfo, JSONObject gliMslgJSONObject, Timestamp recedt, Timestamp respdt,
			String executeMsg, String mstype) {

		GliMslg gliMslg = new GliMslg();

		if (null != gliMslgJSONObject) {
			// ����
			gliMslg.setStacid(gliMslgJSONObject.getInteger("stacid"));
			// Դϵͳ
			gliMslg.setSystid(gliMslgJSONObject.getString("systid"));

			// Դϵͳ��ˮ
			if (Enumeration.Mstype.JYLS.value.equals(mstype)) {
				gliMslg.setSoursq(gliMslgJSONObject.getString("transq"));
			} else if (Enumeration.Mstype.CPLS.value.equals(mstype)) {
				gliMslg.setSoursq(gliMslgJSONObject.getString("soursq"));
			}

		}

		// ���ձ���
		gliMslg.setRecems(bussinessInfo);

		// ���Ĵ�С
		gliMslg.setMssize(bussinessInfo.getBytes().length);

		// ���ر���
		gliMslg.setRespms(executeMsg);
		// ������־id
		gliMslg.setMessid(gliLogMapper.getMessid());
		// ���Ľ���ʱ��
		gliMslg.setRecedt(recedt);
		// ���ķ���ʱ��
		gliMslg.setRespdt(respdt);
		// ��������
		gliMslg.setMstype(mstype);

		gliLogMapper.insertGliMslg(gliMslg);
	}

}
