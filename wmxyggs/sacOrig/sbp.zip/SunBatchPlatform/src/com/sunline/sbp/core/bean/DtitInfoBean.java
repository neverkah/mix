package com.sunline.sbp.core.bean;

public class DtitInfoBean {
	private String itemcd;
	private String amntcd;
	private String ioflag;
	public String getItemcd() {
		return itemcd;
	}
	public void setItemcd(String itemcd) {
		this.itemcd = itemcd;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}
	public String getIoflag() {
		return ioflag;
	}
	public void setIoflag(String ioflag) {
		this.ioflag = ioflag;
	}
	
	
}
