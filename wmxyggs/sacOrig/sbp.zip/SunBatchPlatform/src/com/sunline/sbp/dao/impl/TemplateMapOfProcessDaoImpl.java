package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.sbp.dao.TemplateMapOfProcessDao;
import com.sunline.sbp.dao.mapper.ProcessTemplateMapMapper;
import com.sunline.sbp.model.ProcessTemplateMap;

public class TemplateMapOfProcessDaoImpl implements TemplateMapOfProcessDao{
	
	private ProcessTemplateMapMapper processTemplateMapMapper;
	private Logger logger = Logger.getLogger(TemplateMapOfProcessDaoImpl.class);
	
	public ProcessTemplateMap[] getMapOfTemplate(ProcessTemplateMap processTemplateMap){
		ProcessTemplateMap[] processTemplateMaps = processTemplateMapMapper.getTemplMapPrcs(processTemplateMap);
		if (processTemplateMaps.length == 0){
			logger.debug("��ȡ������Ŀ��"+processTemplateMap.getProjcd()+"�������루" + processTemplateMap.getPrcscd() + "����ģ�塢�����ӳ���ϵ");
			return null;
		}else{
			logger.debug("��ȡ������"+processTemplateMap.getPrcscd()+"��Ӧģ�塢����ӳ����Ϣ�ɹ�");
			return processTemplateMaps;
		}
		
	}

	public ProcessTemplateMapMapper getProcessTemplateMapMapper() {
		return processTemplateMapMapper;
	}

	public void setProcessTemplateMapMapper(
			ProcessTemplateMapMapper processTemplateMapMapper) {
		this.processTemplateMapMapper = processTemplateMapMapper;
	}
	
	
}
