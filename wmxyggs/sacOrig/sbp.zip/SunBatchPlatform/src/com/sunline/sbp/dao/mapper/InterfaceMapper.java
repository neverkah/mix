package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;

public interface InterfaceMapper {
	public SysIntfDetl[] getIntfDetl(SysIntf sysIntf);
}
