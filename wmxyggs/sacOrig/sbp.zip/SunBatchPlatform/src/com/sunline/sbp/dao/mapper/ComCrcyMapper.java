package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.ComCrcy;

public interface ComCrcyMapper {
	public ComCrcy getComCrcyByPrimKey(@Param("crcycd") String crcycd);
	public ComCrcy[] selectFullComCrcys();
}
