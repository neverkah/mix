package com.sunline.sbp.dao;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.AccountingCode;

public interface AccountingCodeDao {
	public AccountingCode getItemCode(int stacid , String dtitcd, String trprcd) throws EngineRuntimeException;
}
