package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.GlsTrcmCsmv;


public interface GlsTrcmCsmvMapper {
	public String insertEntity(GlsTrcmCsmv entity);
	public GlsTrcmCsmv selectEntity(@Param("trandt") String trandt , @Param("transq") String transq , @Param("cmmdsq") String cmmdsq , @Param("systid") String systid);
	public void postingUpdate(GlsTrcmCsmv entity);
}
