package com.sunline.sbp.dao;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.ProfParamer;

public interface SysProfParaDao {
	public ProfParamer[] getProfParamers(ProfParamer profParamer) throws EngineRuntimeException;
}
