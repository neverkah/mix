package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.GliMslg;


public interface GliLogMapper {
	

	public int insertGliMslg(GliMslg gliMslg);
	
	public Long getMessid();
}