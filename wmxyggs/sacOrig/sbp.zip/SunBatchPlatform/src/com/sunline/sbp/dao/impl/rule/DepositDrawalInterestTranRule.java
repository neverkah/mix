package com.sunline.sbp.dao.impl.rule;

import java.util.HashMap;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.DataObjectUtil;
import com.sunline.foundation.TranamInfoEntity;
import com.sunline.sbp.base.RuleBeanObject;
import com.sunline.sbp.dao.mapper.DepositDrawalInterestMapper;
import com.sunline.sbp.dao.mapper.GlsExtdMapper;
import com.sunline.sbp.model.DepositDrawalInterest;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;
import com.sunline.sbp.model.SysIomp;

/***
 * ���Ӧ����Ϣ������ϸ
 * @author Zhangjin
 *
 */
public class DepositDrawalInterestTranRule implements RuleBeanObject {
	
	private DepositDrawalInterestMapper depositDrawalInterestMapper;
	private DepositDrawalInterest command;
	private GlsExtdMapper glsExtdMapper;
	private GlsExtd extd;
	
	private HashMap<String , Object> data;
	private SysIomp[] iopms;
	private SysIntf sysIntf;
	private SysIntfDetl[] intfDetl;
	
	@Override
	public void setMapOfInIntf(final SysIntf sysIntf , final SysIomp[] iopms ,final SysIntfDetl[] detls) {
		// TODO Auto-generated method stub
		this.iopms = iopms;
		this.sysIntf = sysIntf;
		this.intfDetl = detls;
	}
	
	@Override
	public String initialize(HashMap<String , Object> data) throws AnalyseException {
		// TODO Auto-generated method stub
		command = new DepositDrawalInterest();
		command.setAcctbr(DataObjectUtil.getHashMapStr(data,"acctbr").toString());
		command.setBkfnst(DataObjectUtil.getHashMapStr(data,"bkfnst").toString());
		command.setCainsq(DataObjectUtil.getHashMapStr(data,"cainsq").toString());
		command.setCrcycd(DataObjectUtil.getHashMapStr(data,"crcycd").toString());
		command.setDtitcd(DataObjectUtil.getHashMapStr(data,"dtitcd").toString());
		command.setLastbl(DataObjectUtil.getBigDecimalValue(data,"lastbl"));
		command.setOnlnbl(DataObjectUtil.getBigDecimalValue(data,"onlnbl"));
		command.setStacid(DataObjectUtil.getIntegerValue(data, "stacid"));
		command.setSystid(DataObjectUtil.getHashMapStr(data,"systid").toString());
		command.setTranam(DataObjectUtil.getBigDecimalValue(data,"tranam"));
		command.setTranbr(DataObjectUtil.getHashMapStr(data,"tranbr").toString());
		command.setTrandt(DataObjectUtil.getHashMapStr(data,"trandt").toString());
		command.setTransq(DataObjectUtil.getHashMapStr(data,"transq").toString());
		
		return null;
	}

	@Override
	public String check() {
		// TODO Auto-generated method stub
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public GlsExtd execute(int orderCount) {
		// TODO Auto-generated method stub
		depositDrawalInterestMapper.insertEntity(command);
			
		extd = new GlsExtd();
		extd.setStacid(command.getStacid());
		extd.setSystid(command.getSystid());
		extd.setTrandt(command.getTrandt());
		extd.setTranbr(command.getTranbr());
		extd.setTransq(command.getTransq());
		extd.setSortno(orderCount);
		extd.setCmmdtg(Constants.COMMAND_IDENTITY_DI);
		extd.setAmntcd(Constants.AMNTCD_DEBIT);
		extd.setCrcycd(command.getCrcycd());
		extd.setTranam(command.getTranam());
		
		return extd;
	}

	@Override
	public TranamInfoEntity getTranamInfo() {
		// TODO Auto-generated method stub
		return new TranamInfoEntity(Constants.AMNTCD_CREDIT,command.getTranam());
	}

	public DepositDrawalInterestMapper getDepositDrawalInterestMapper() {
		return depositDrawalInterestMapper;
	}

	public void setDepositDrawalInterestMapper(
			DepositDrawalInterestMapper depositDrawalInterestMapper) {
		this.depositDrawalInterestMapper = depositDrawalInterestMapper;
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return data;
	}

	@Override
	public JSONObject getCmmd() {
		// TODO Auto-generated method stub
		return (JSONObject)JSON.toJSON(command);
	}
	
	
}
