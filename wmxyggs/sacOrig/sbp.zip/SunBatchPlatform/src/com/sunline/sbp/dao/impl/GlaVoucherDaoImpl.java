package com.sunline.sbp.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DuplicateKeyException;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.Enumeration;
import com.sunline.foundation.tools.StringUtil;
import com.sunline.sbp.dao.GlaVoucherDao;
import com.sunline.sbp.dao.mapper.GlaVoucherMapper;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.GlbCler;

public class GlaVoucherDaoImpl implements GlaVoucherDao {
	
	private Logger logger = Logger.getLogger(GlaVoucherDaoImpl.class);
	
	private GlaVoucherMapper glaVoucherMapper;
	private SequenceFactoryDaoImpl sequenceFactoryDao;
	private ComParaDaoImpl comParaDao;
	private AccountSetDaoImpl accountSetDao;

	@Override
	public String insertEntity(List<GlaVoucher> list) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		
		ArrayList<String> _transq = sequenceFactoryDao
				.generateSequence(list.get(0).getStacid(), Enumeration.SQNOCD.TRANSQ.value,
						list.get(0).getTranbr(), list.get(0).getTrandt(), 1);
		int order = 1;
		for(GlaVoucher entity : list){
			entity.setTransq(_transq.get(0));
			if(!StringUtil.isNotNull(entity.getSrvcsq())){
				//��Χϵͳ��Ʊ�п��ܲ�����Ʊ��ţ�����ϵͳ���������Ĵ�Ʊ������ŵ�
				entity.setSrvcsq(String.valueOf(order++));
			}
		}
		
		int batchCount = 1000;
		int insertRecordCount = 0;
		
		try{
			int ednIdx = 0;
			for(int beginIdx = 0 ; beginIdx < list.size() ; ){
				ednIdx = beginIdx + batchCount < list.size() ? beginIdx + batchCount : list.size();
				
				List<GlaVoucher> subVchrs = list.subList(beginIdx, ednIdx);
				beginIdx = beginIdx + batchCount;
				insertRecordCount += glaVoucherMapper.insertEntitiesBatch(subVchrs);
				logger.info("���ڣ�"+list.get(0).getTrandt()+"���׻�����"+list.get(0).getTranbr()+"��"+list.size()+"�ʴ�Ʊ���ѱ��������" + insertRecordCount);
			}
			if(insertRecordCount != list.size()){
				throw new Exception("��Ҫ����"+list.size()+"����Ʊ������ɹ���"+insertRecordCount+"������һ�£�");
			}
		}catch(DuplicateKeyException duex){
			int vchrsCount = glaVoucherMapper.countVchrsBySour(list.get(0));
			if(vchrsCount == 0){
				logger.error("���洫Ʊ��¼ʧ�ܣ�");
				throw new AnalyseException("���洫Ʊ��¼ʧ�ܣ�",duex);
			}else{
				logger.fatal("��ˮ("+list.get(0).getSoursq()+")�Ѿ������ɹ����ȴ�ͬ��״̬��");
				throw new AnalyseException(Constants.EXECUTE_DUPLICATE + ":" +"��ˮ("+list.get(0).getSoursq()+")�ظ�������");
			}
		}catch(Exception ex){
			logger.error("���洫Ʊ��Ϣʧ�ܡ�" + ex.getMessage(),ex);
			throw new AnalyseException("���洫Ʊ��¼ʧ�ܣ�",ex);
		}
		logger.debug("���洫Ʊ��Ϣ�ɹ���");
		return Constants.EXECUTE_SUCC;
	}
	
	@Override
	public int insertEntitiesBatch(List<List<GlaVoucher>> list , String trandt , String tranbr , int stacid) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		
		int insertRecordCount = 0;
		
		int accoutStacid = 0;
		
		if (null != list && list.size() > 0) {
			
			//ҵ����ˮ��ʱ����ʱ����ƱΪ��ǰ���ڣ�����ҵ������
			accoutStacid = list.get(0).get(0).getStacid();
			trandt = accountSetDao.getTrandt(accoutStacid);
			
			ArrayList<String> _transq = sequenceFactoryDao
					.generateSequence(accoutStacid, Enumeration.SQNOCD.TRANSQ.value,
							tranbr, trandt, list.size());
			
			List<GlaVoucher> vchrs = new ArrayList<GlaVoucher>();
			for (int ai = 0; ai < list.size(); ai++) {
				int order = 1;
				for (int ay = 0; ay < list.get(ai).size(); ay++) {
					list.get(ai).get(ay).setTransq(_transq.get(ai));
					list.get(ai).get(ay).setTrandt(trandt);
					//��Դ���׸�ֵ
					list.get(ai).get(ay).setSourac(stacid);
					if(!StringUtil.isNotNull(list.get(ai).get(ay).getSrvcsq())){
						//��Χϵͳ��Ʊ�п��ܲ�����Ʊ��ţ�����ϵͳ���������Ĵ�Ʊ������ŵ�
						list.get(ai).get(ay).setSrvcsq(String.valueOf(order++));
					}
				}
				vchrs.addAll(list.get(ai));
			}
			
			//�����ύ����(ԭֵΪ10000����ʱ�޸�Ϊ1000)
			int batchCount = 1000;
			
			try{
				int ednIdx = 0;
				for(int beginIdx = 0 ; beginIdx < vchrs.size() ; ){
					ednIdx = beginIdx + batchCount < vchrs.size() ? beginIdx + batchCount : vchrs.size();
					
					List<GlaVoucher> subVchrs = vchrs.subList(beginIdx, ednIdx);
					beginIdx = beginIdx + batchCount;
					insertRecordCount += glaVoucherMapper.insertEntitiesBatch(subVchrs);
					logger.info("���ڣ�"+trandt+"���׻�����"+tranbr+"��"+vchrs.size()+"�ʴ�Ʊ����ת�������" + insertRecordCount);
				}
			}catch(Exception ex){
				String message = "���ڣ�"+trandt+"���׻�����"+tranbr+"��"+vchrs.size()+"�ʴ�Ʊ����ʧ�ܡ�";
				throw new EngineRuntimeException(message,ex);
			}
			
		}
		return insertRecordCount;
	}
	

	public GlaVoucherMapper getGlaVoucherMapper() {
		return glaVoucherMapper;
	}

	public void setGlaVoucherMapper(GlaVoucherMapper glaVoucherMapper) {
		this.glaVoucherMapper = glaVoucherMapper;
	}

	public SequenceFactoryDaoImpl getSequenceFactoryDao() {
		return sequenceFactoryDao;
	}

	public void setSequenceFactoryDao(SequenceFactoryDaoImpl sequenceFactoryDao) {
		this.sequenceFactoryDao = sequenceFactoryDao;
	}

	public ComParaDaoImpl getComParaDao() {
		return comParaDao;
	}

	public void setComParaDao(ComParaDaoImpl comParaDao) {
		this.comParaDao = comParaDao;
	}

	@Override
	public int getNextSequence(GlaVoucher vchr) {
		// TODO Auto-generated method stub
		int tranno;
		//ͬһ��ҵ��Ĵ�Ʊ��Ŵ�1��ʼ
		try{
			tranno = glaVoucherMapper.getNextSequence(vchr);
		}catch(Exception ex){
			tranno = 1;
		}

		return tranno;
	}

	@Override
	public List<GlbCler> getStaticTranamByBrch(int stacid, String trandt) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		//��ȡ�����������Ļ�������
		String clerBrch_headbank = comParaDao.getParamInfoByKey(stacid, "clerBrch_headbank").getParavl();
		String [] clerBrch_headbank_Array = clerBrch_headbank.split(",");
		glaVoucherMapper.updateClertgWait(stacid, trandt);
		List<GlbCler> clerBooks =  glaVoucherMapper.selectSumTranamByBrch(stacid,trandt,clerBrch_headbank_Array);
		return clerBooks;
	}


	@Override
	public void setClearOver(int stacid, String trandt,
			String clerdt, String clerod) {
		// TODO Auto-generated method stub
		glaVoucherMapper.updateClearInfo(stacid, trandt, clerod, clerdt);
	}

	public AccountSetDaoImpl getAccountSetDao() {
		return accountSetDao;
	}

	public void setAccountSetDao(AccountSetDaoImpl accountSetDao) {
		this.accountSetDao = accountSetDao;
	}
	
	@Override
	public List<GlaVoucher> getVouchersByBsns(int stacid, String bsnssy, String bsnsdt, String bsnssq) {
		// TODO Auto-generated method stub
		List<GlaVoucher> list = glaVoucherMapper.getVchrsBySour(stacid, bsnssy, bsnsdt, bsnssq);
		return list;
	}

}
