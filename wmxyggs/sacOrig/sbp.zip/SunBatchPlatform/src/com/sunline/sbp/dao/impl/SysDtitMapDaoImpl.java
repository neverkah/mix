package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.dao.SysDtitMapDao;
import com.sunline.sbp.dao.mapper.SysDtitMapMapper;
import com.sunline.sbp.model.SysDtitMapBean;

public class SysDtitMapDaoImpl implements SysDtitMapDao {
	
	private SysDtitMapMapper sysDtitMapMapper;
	private Logger logger = Logger.getLogger(SysDtitMapDaoImpl.class);


	@Override
	public SysDtitMapBean getDtitInfo(SysDtitMapBean param)
			throws EngineRuntimeException {
		// TODO Auto-generated method stub
		String message = "��Ʒ��"+param.getProdcd()+"���ԣ�"+param.getProdp1()+","+param.getProdp2()+","+param.getProdp3()+","+param.getProdp4()+","+param.getProdp5()+","+param.getProdp6()+","+param.getProdp7()+","+param.getProdp8()+","+param.getProdp9()+","+param.getProdpa();
		logger.debug(message);
		SysDtitMapBean[] results = sysDtitMapMapper.selectDtit(param);
		if(null == results 
				|| (null != results && results.length == 0)){
			message = message+",δ�ҵ���Ʒ�������ã�";
			logger.error(message);
			throw new EngineRuntimeException(message);
		}else if(results.length > 1){
			message = message + ",��ȡ"+results.length+"����Ʒ�������á����ݴ���ֻ��������һ��";
			logger.error(message);
			throw new EngineRuntimeException(message);
		}else{
			logger.debug("��ȡ�������ɹ� ��" + results[0].getDtitcd());
			if(null == results[0].getDtitcd() || results[0].getDtitcd().length() == 0){
				throw new EngineRuntimeException(message + ",���������ã����������Ϊ�գ�");
			}
		}
		return results[0];
	}

	public SysDtitMapMapper getSysDtitMapMapper() {
		return sysDtitMapMapper;
	}


	public void setSysDtitMapMapper(SysDtitMapMapper sysDtitMapMapper) {
		this.sysDtitMapMapper = sysDtitMapMapper;
	}

}
