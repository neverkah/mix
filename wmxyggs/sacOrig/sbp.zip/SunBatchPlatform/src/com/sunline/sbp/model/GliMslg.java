package com.sunline.sbp.model;

import java.sql.Timestamp;

/**
 * @time 2017.7.27 17:38
 * @desc ���Ĵ������ʵ����
 * @table Gli_mslg
 * @author huangzhongjie
 * 
 */
public class GliMslg {

	private Long messid;// ������־ID

	private Integer stacid; // ����

	private String systid;// Դϵͳ

	private String soursq;// Դ������ˮ

	private Timestamp recedt;// ���ձ���ʱ��

	private Timestamp respdt;// ���ر���ʱ��

	private String recems;// ���ձ���

	private String respms;// ��Ӧ����


	private Integer mssize;// ���Ĵ�С

	private String mstype;// ��������

	/**
	 * max constructor
	 * 
	 */
	public GliMslg() {

	}

	public Long getMessid() {
		return messid;
	}

	public void setMessid(Long messid) {
		this.messid = messid;
	}

	public Integer getStacid() {
		return stacid;
	}

	public void setStacid(Integer stacid) {
		this.stacid = stacid;
	}

	public String getSystid() {
		return systid;
	}

	public void setSystid(String systid) {
		this.systid = systid;
	}

	public String getSoursq() {
		return soursq;
	}

	public void setSoursq(String soursq) {
		this.soursq = soursq;
	}

	public Timestamp getRecedt() {
		return recedt;
	}

	public void setRecedt(Timestamp recedt) {
		this.recedt = recedt;
	}

	public Timestamp getRespdt() {
		return respdt;
	}

	public void setRespdt(Timestamp respdt) {
		this.respdt = respdt;
	}

	public String getRecems() {
		return recems;
	}

	public void setRecems(String recems) {
		this.recems = recems;
	}

	public String getRespms() {
		return respms;
	}

	public void setRespms(String respms) {
		this.respms = respms;
	}


	public Integer getMssize() {
		return mssize;
	}

	public void setMssize(Integer mssize) {
		this.mssize = mssize;
	}

	public String getMstype() {
		return mstype;
	}

	public void setMstype(String mstype) {
		this.mstype = mstype;
	}
}
