package com.sunline.sbp.schedule;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.ServiceException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.common.SysVchrErorUtil;
import com.sunline.sbp.core.bean.GlaVchrBean;
import com.sunline.sbp.core.bean.GlaVchrHelper;
import com.sunline.sbp.dao.mapper.GliVoucherMapper;
import com.sunline.sbp.dao.mapper.SysAyncNodeMapper;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.GliVoucher;
import com.sunline.sbp.service.GliVchrBatchDealService;
import com.sunline.sunbp.util.MyBatisUtil;

/**
 * ҵ��ϵͳ�첽��Ϣ������
 * 
 * @author liuchangjin
 * @Date 2014-5-17
 * 
 */
public class GliVchrBatchJob extends Thread {

	private static Logger logger = Logger.getLogger(GliVchrBatchJob.class);

	private final String tranbr;
	private final int stacid;
	private final String trandt;
	private final String pit;
	private final String sourst;
	private final String nodeid;
	
	private final String aynccd = "gli";

	private List<List<GlaVoucher>> vchrsList = new ArrayList<List<GlaVoucher>>();
	private List<List<GliVoucher>> vchrsErrList = new ArrayList<List<GliVoucher>>();
	private List<String> msgList = new ArrayList<String>();
	private SqlSession sqlSession = null;

	public GliVchrBatchJob(int stacid, String trandt, String tranbr, String pit, String sourst, String nodeid) {
		this.stacid = stacid;
		this.trandt = trandt;
		this.tranbr = tranbr;
		this.pit = pit;
		this.sourst = sourst;
		this.nodeid = nodeid;
	}

	public void run() {
		try {
			sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();

//			GliVoucherMapper gliVoucherMapper = sqlSession
//					.getMapper(GliVoucherMapper.class);
			/*
			 * List<GliVoucher> vchrs = gliVoucherMapper.getVchrsByBrch(stacid,
			 * trandt, tranbr);
			 */

			/*
			 * 1�����ȴ���δ��������ˮ��������֮���ٽ���ʧ�ܵ���ˮ 
			 * 2��ȡ��������ˮ�ţ���������
			 */
			/*List<String> soursqs = gliVoucherMapper.getBrchHeadVchrDetail(
					stacid, trandt, tranbr, pit, sourst);
			if (null == soursqs || soursqs.size() == 0) {
				soursqs = gliVoucherMapper.getBrchHeadVchrDetailOfError(stacid,
						trandt, tranbr, pit, sourst);
			}*/
			
			int rbatchCount = 100;
			
			Connection cn = null;
			PreparedStatement vchrSt = null;
			ResultSet rs = null;
			List<GliVoucher> vchrs = new ArrayList<GliVoucher>();
			List<GliVoucher> vchrsNext = new ArrayList<GliVoucher>();
			List<String> subList = new ArrayList<String>();
			List<String> subListNext = new ArrayList<String>();
			try {
				cn = sqlSession.getConnection();
				vchrSt = cn.prepareStatement("select * from  gli_vchr "
						+ "	where stacid = ? and sourst = ? and sourdt = ? and tranbr = ? and soursq like ? and transt in ('0',2) order by soursq");
				vchrSt.setFetchSize(3000);
				vchrSt.setInt(1, stacid);
				vchrSt.setString(2, sourst);
				vchrSt.setString(3, trandt);
				vchrSt.setString(4, tranbr);
				vchrSt.setString(5, "%".concat(pit));
				
				rs = vchrSt.executeQuery();
				int count = 0;
				int sqCount = 0;
				String qmSq = "";
				GliVoucher gliVoucher = null;
				
				
				while(rs.next()){
					
					if(!vchrsNext.isEmpty()){
						vchrs.addAll(vchrsNext);
						vchrsNext.clear();
						
						subList.addAll(subListNext);
						qmSq = subListNext.get(0);
						subListNext.clear();
						
					}
					
					if(count++ < 1000000 && sqCount <= rbatchCount){
						
						gliVoucher = new GliVoucher();
						
						gliVoucher.setStacid(rs.getInt("stacid"));
						gliVoucher.setAcctbr(rs.getString("acctbr"));
						gliVoucher.setAcctno(rs.getString("acctno"));
						gliVoucher.setAmntcd(rs.getString("amntcd"));
						gliVoucher.setAssis0(rs.getString("assis0"));
						gliVoucher.setAssis1(rs.getString("assis1"));
						gliVoucher.setAssis2(rs.getString("assis2"));
						gliVoucher.setAssis3(rs.getString("assis3"));
						gliVoucher.setAssis4(rs.getString("assis4"));
						gliVoucher.setAssis5(rs.getString("assis5"));
						gliVoucher.setAssis6(rs.getString("assis6"));
						gliVoucher.setAssis7(rs.getString("assis7"));
						gliVoucher.setAssis8(rs.getString("assis8"));
						gliVoucher.setAssis9(rs.getString("assis9"));
						gliVoucher.setCentcd(rs.getString("centcd"));
						gliVoucher.setCrcycd(rs.getString("crcycd"));
						gliVoucher.setCustcd(rs.getString("custcd"));
						gliVoucher.setExchcn(rs.getBigDecimal("exchcn"));
						gliVoucher.setExchus(rs.getBigDecimal("exchus"));
						gliVoucher.setItemcd(rs.getString("itemcd"));
						gliVoucher.setPrducd(rs.getString("prducd"));
						gliVoucher.setPrlncd(rs.getString("prlncd"));
						gliVoucher.setPrsncd(rs.getString("prsncd"));
						gliVoucher.setSmrytx(rs.getString("smrytx"));
						gliVoucher.setSourdt(rs.getString("sourdt"));
						gliVoucher.setSoursq(rs.getString("soursq"));
						gliVoucher.setSourst(rs.getString("sourst"));
						gliVoucher.setToitem(rs.getString("toitem"));
						gliVoucher.setTranam(rs.getBigDecimal("tranam"));
						gliVoucher.setTranbr(rs.getString("tranbr"));
						gliVoucher.setTrandt(rs.getString("trandt"));
						gliVoucher.setTrantp(rs.getString("trantp"));
						gliVoucher.setUsercd(rs.getString("usercd"));
						gliVoucher.setVchrsq(rs.getString("vchrsq"));
						
						vchrs.add(gliVoucher);
						
						if(!qmSq.equals(rs.getString("soursq"))){
							qmSq = rs.getString("soursq");
							subList.add(rs.getString("soursq"));
							sqCount++;
						}
						
						if(sqCount == (rbatchCount + 1)){
							
							vchrsNext.add(gliVoucher);
							subListNext.add(rs.getString("soursq"));
							
							vchrs.remove(gliVoucher);
							subList.remove(rs.getString("soursq"));
							
							scheduleBatch(vchrs, subList);
							vchrs.clear();
							subList.clear();
							sqCount = 1;
							count = 1;
						}
						
					}

				}
				
				scheduleBatch(vchrs, subList);
				vchrs.clear();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e);
			}finally{
				
				SysAyncNodeMapper sysAyncNodeMapper = sqlSession.getMapper(SysAyncNodeMapper.class);
				try{
					int result = sysAyncNodeMapper.deleteNode(aynccd,stacid, nodeid, trandt, sourst, tranbr, pit);
					logger.fatal("�Ƴ��ڵ������"+result);
					if(result != 1){
						logger.error("�Ƴ��ڵ�����ʧ�ܡ��Ƴ�����"+result);
					}else{
						logger.fatal("delete nodeid:"+nodeid+",brch:"+tranbr+",pit:"+pit);
					}
					sqlSession.commit();
				}catch(Exception ex){
					logger.error("�Ƴ��ڵ������쳣:"+ex.getMessage(),ex);
				}
				
				if(null != rs){
					try {
						rs.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if(null != vchrSt){
					try {
						vchrSt.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if( null != cn){
					try {
						cn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			
			
			/*// �°汾
			int endIdx = 100;
			List<GliVoucher> vchrs = null;
			logger.info("������" + tranbr + "����Χϵͳ��Ʊ������" + soursqs.size());
			while (soursqs != null && !soursqs.isEmpty()) {
				if (endIdx > soursqs.size()) {
					endIdx = soursqs.size();
				}
				List<String> subList = soursqs.subList(0, endIdx);
				vchrs = gliVoucherMapper.getBrchVchrDetailByTransq(subList,
						stacid, trandt, tranbr, sourst);

				scheduleBatch(vchrs, subList);
			}*/
		} finally {
			
			
			
			if (null != sqlSession) {
				sqlSession.close();
			}
		}

	}

	private int targetVchrFailed() throws AnalyseException {

		int resultCount = 0;
		try {

			GliVoucherMapper gliVoucherMapper = sqlSession
					.getMapper(GliVoucherMapper.class);

			for (int idx = 0; idx < vchrsErrList.size(); idx++) {
				for (int idy = 0; idy < vchrsErrList.get(idx).size(); idy++) {
					GliVoucher __vchr = vchrsErrList.get(idx).get(idy);
					resultCount += gliVoucherMapper.updateToError(__vchr);
					SysVchrErorUtil.writeLog(__vchr.getStacid(),
							__vchr.getSourst(), __vchr.getTrandt(),
							__vchr.getSoursq(), __vchr.getVchrsq(),
							msgList.get(idx));
				}
			}
			logger.info("����Ʊ��ʶ��ɣ���" + vchrsErrList.size() + "��!");
		} catch (Exception ex) {
			logger.error("��ʶ��Χ��ƱΪʧ��ʱϵͳ�����쳣������ʧ�ܡ�", ex);
			throw new AnalyseException("��ʶ��Χ��ƱΪʧ��ʱϵͳ�����쳣������ʧ�ܡ�", ex);
		} finally {
		}

		return resultCount;
	}

	private int targetVchrSuccBatch() throws AnalyseException {

		int resultCount = 0;
		List<GlaVoucher> gliVchrs = new ArrayList<GlaVoucher>();
		for (List<GlaVoucher> entity : vchrsList) {
			gliVchrs.addAll(entity);
		}

		if (gliVchrs.isEmpty()) {
			return 0;
		}

		// �����ύ����
		int batchCount = 1000;
		GliVoucherMapper gliVoucherMapper = sqlSession
				.getMapper(GliVoucherMapper.class);
		try {
			int ednIdx = 0;
			for (int beginIdx = 0; beginIdx < gliVchrs.size();) {
				ednIdx = beginIdx + batchCount < gliVchrs.size() ? beginIdx
						+ batchCount : gliVchrs.size();

				List<GlaVoucher> sunList = gliVchrs.subList(beginIdx, ednIdx);
				beginIdx = beginIdx + batchCount;
				resultCount += gliVoucherMapper.updateToSuccBatch(stacid,
						trandt, tranbr, sunList, sourst);
				logger.info("������" + tranbr + "�������ˮ��ɹ���ʶ......�ۼƴ����ɹ���������"
						+ resultCount);
			}
			logger.info("��ȷ��Ʊ��ʶ��ɣ���" + gliVchrs.size() + "�ʣ�");
		} catch (Exception ex) {
			String message = "���ڣ�" + trandt + "���׻�����" + tranbr + "��"
					+ gliVchrs.size() + "�ʴ�Ʊ����ʧ�ܡ�";
			logger.error(message, ex);
			throw new AnalyseException(message, ex);
		}
		return resultCount;
	}

	private void scheduleBatch(List<GliVoucher> vchrs, List<String> subList) {
		try {

			logger.fatal("������" + tranbr + "������ת�沿����ˮ����:" + vchrs.size());
			
			int count = 0;
			int Errcount = 0;
			for (int i = 0; i < vchrs.size(); i++) {
				List<GliVoucher> gliVchr = new ArrayList<GliVoucher>();
				try {
					List<GlaVoucher> staVchr = new ArrayList<GlaVoucher>();

					gliVchr.add(vchrs.get(i));

					staVchr.add(GlaVchrBean.toGlaVchr(vchrs.get(i)));

					for (int y = i + 1; y < vchrs.size(); y++) {

						if (vchrs.get(i).getSoursq()
								.equals(vchrs.get(y).getSoursq())) {
							i = y;
							gliVchr.add(vchrs.get(y));
							staVchr.add(GlaVchrBean.toGlaVchr(vchrs.get(y)));
						} else {
							break;
						}
					}

					if (GlaVchrHelper.checkBalanceOfGlaVchrs(staVchr)) {
						if(GlaVchrHelper.setClertgOfGlaVchrs(staVchr)){
							
						}
						vchrsList.add(staVchr);
						count += staVchr.size();
					}
				} catch (EngineRuntimeException ex) {
					msgList.add(ex.getMessage());
					Errcount += gliVchr.size();
					vchrsErrList.add(gliVchr);
				} catch (Exception ex) {
					msgList.add(ex.getMessage());
					Errcount += gliVchr.size();
					vchrsErrList.add(gliVchr);
				}
			}

			logger.info("��Χϵͳ�л���" + tranbr + "��ƱԤ������ɡ�");

			int resultErrCount = targetVchrFailed();
			int resultCount = targetVchrSuccBatch();
			
			logger.info("resultErrCount:" + resultErrCount + ",resultCount:"
					+ resultCount + ",count:" + count);

			if (resultErrCount != Errcount) {
				logger.error("����" + stacid + "����" + trandt + "����" + tranbr
						+ "����Χ��Ʊ����״̬�쳣����������");
				throw new AnalyseException("����" + stacid + "����" + trandt + "����"
						+ tranbr + "����Χ��Ʊ����״̬�쳣����������");
			}

			if (resultCount != count) {
				logger.error("����" + stacid + "����" + trandt + "����" + tranbr
						+ "�����ݷ���ת������Ʊ������Χ��Ʊ��״̬�쳣����������");
				throw new AnalyseException("����" + stacid + "����" + trandt + "����" + tranbr
						+ "�����ݷ���ת������Ʊ������Χ��Ʊ��״̬�쳣����������");
			}

			if ((resultErrCount + resultCount) != vchrs.size()) {
				logger.error("����" + stacid + "����" + trandt + "����" + tranbr
						+ "�Ĵ�Ʊ�����쳣�����ݴ���ʱϵͳ�����쳣");
				throw new AnalyseException("����" + stacid + "����" + trandt + "����" + tranbr
						+ "�Ĵ�Ʊ�����쳣�����ݴ���ʱϵͳ�����쳣");
			}

			int result = 0;
			if ((resultErrCount + resultCount) == vchrs.size()
					&& vchrsList.size() > 0) {
				GliVchrBatchDealService glaVoucherDao = ApplicationBeanFactory
						.getApplicationContextInstance().getBean(
								GliVchrBatchDealService.class);
				result = glaVoucherDao.vchrTransaction(vchrsList, trandt,
						tranbr);
				// �����˶�
				if (result != resultCount) {
					logger.error("��Ʊת���ڱ������ݿ�ʱ�쳣��result=" + result);
					
					throw new AnalyseException("��Ʊת���ڱ������ݿ�ʱ�쳣��");
				}
			}

			sqlSession.commit();
			subList.clear();
			logger.info("������" + tranbr + "��Ʊת����ɣ�����=" + result);
		} catch (AnalyseException ex1) {
			logger.error("��Χϵͳ��Ʊת��ʧ�ܡ�" + ex1.getMessage(), ex1);
			sqlSession.rollback();
		} catch (ServiceException ex2) {
			sqlSession.rollback();
			logger.error("��Χϵͳ��Ʊת��ʧ�ܡ�" + ex2.getMessage(), ex2);
		} catch (Exception ex3) {
			logger.error("��Χϵͳ��Ʊת���쳣��", ex3);
			sqlSession.rollback();
		}finally{
			vchrsList.clear();
			vchrsErrList.clear();
			msgList.clear();
		}
	}

}
