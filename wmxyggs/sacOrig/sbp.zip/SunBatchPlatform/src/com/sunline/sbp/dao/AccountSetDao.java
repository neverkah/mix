package com.sunline.sbp.dao;

import java.util.List;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.model.AccountSet;

public interface AccountSetDao {
	public String getTrandt(int stacid) throws AnalyseException;
	public List<AccountSet> getStacLinks(int stacid) throws AnalyseException;
}
