package com.sunline.sbp.model;

/**
 * �����(sys_prof)
 * @author Zhangjin
 *
 */
public class SysProf {
	String proftp;
	String profid;
	String profna;
	String efctdt;
	String inefdt;
	String desctx;
	String enname;
	String vermod;
	String module;
	String projcd;
	public String getProftp() {
		return proftp;
	}
	public void setProftp(String proftp) {
		this.proftp = proftp;
	}
	public String getProfid() {
		return profid;
	}
	public void setProfid(String profid) {
		this.profid = profid;
	}
	public String getProfna() {
		return profna;
	}
	public void setProfna(String profna) {
		this.profna = profna;
	}
	public String getEfctdt() {
		return efctdt;
	}
	public void setEfctdt(String efctdt) {
		this.efctdt = efctdt;
	}
	public String getInefdt() {
		return inefdt;
	}
	public void setInefdt(String inefdt) {
		this.inefdt = inefdt;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getEnname() {
		return enname;
	}
	public void setEnname(String enname) {
		this.enname = enname;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
}
