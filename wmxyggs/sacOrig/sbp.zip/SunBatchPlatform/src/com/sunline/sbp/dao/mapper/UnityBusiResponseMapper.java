package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

public interface UnityBusiResponseMapper {
	public void busiSuccUpdate(@Param("busicl") String busicl , @Param("trandt") String trandt , @Param("transq") String transq);
}
