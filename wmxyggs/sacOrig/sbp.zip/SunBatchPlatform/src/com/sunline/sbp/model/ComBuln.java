package com.sunline.sbp.model;

/**
 * ����
 * @author liuchj@sunline.cn
 *
 */

public class ComBuln {
	private int stacid;
	private String bulncd;
	private String sprrcd;
	private String bulnna;
	private String detltg;
	private String bulntp;
	private String usedtp;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getBulncd() {
		return bulncd;
	}
	public void setBulncd(String bulncd) {
		this.bulncd = bulncd;
	}
	public String getSprrcd() {
		return sprrcd;
	}
	public void setSprrcd(String sprrcd) {
		this.sprrcd = sprrcd;
	}
	public String getBulnna() {
		return bulnna;
	}
	public void setBulnna(String bulnna) {
		this.bulnna = bulnna;
	}
	public String getDetltg() {
		return detltg;
	}
	public void setDetltg(String detltg) {
		this.detltg = detltg;
	}
	public String getBulntp() {
		return bulntp;
	}
	public void setBulntp(String bulntp) {
		this.bulntp = bulntp;
	}
	public String getUsedtp() {
		return usedtp;
	}
	public void setUsedtp(String usedtp) {
		this.usedtp = usedtp;
	}
}
