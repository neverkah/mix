package com.sunline.sbp.dao;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.SysDtitMapBean;

public interface SysDtitMapDao {
	public SysDtitMapBean getDtitInfo(SysDtitMapBean param) throws EngineRuntimeException;
}
