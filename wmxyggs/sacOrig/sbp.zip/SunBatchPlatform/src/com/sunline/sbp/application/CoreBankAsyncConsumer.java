package com.sunline.sbp.application;

import static com.sunline.sbp.application.Help.initMetaConfig;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.dao.AnalyseCenterDao;
import com.sunline.sbp.datamerger.BusiDecisionMaker;
import com.sunline.sbp.datamerger.BusinessObject;
import com.taobao.metamorphosis.Message;
import com.taobao.metamorphosis.client.MessageSessionFactory;
import com.taobao.metamorphosis.client.MetaMessageSessionFactory;
import com.taobao.metamorphosis.client.consumer.ConsumerConfig;
import com.taobao.metamorphosis.client.consumer.MessageConsumer;
import com.taobao.metamorphosis.client.consumer.MessageListener;

/**
 * ����ϵͳҵ����Ϣ������
 * @author Zhangjin
 *
 */
public class CoreBankAsyncConsumer {
	static int msgcount = 0;
	
	private static Logger logger = Logger.getLogger(CoreBankAsyncConsumer.class);

	public static void main(final String[] args) throws Exception {
		// New session factory,ǿ�ҽ���ʹ�õ���
		final MessageSessionFactory sessionFactory = new MetaMessageSessionFactory(
				initMetaConfig());

		// subscribed topic
		final String topic = "core";
		// consumer group
		final String group = "meta-core";
		// create consumer,ǿ�ҽ���ʹ�õ���
		final MessageConsumer consumer = sessionFactory
				.createConsumer(new ConsumerConfig(group));
		// subscribe topic
		consumer.subscribe(topic, 1024 * 1024, new MessageListener() {

			@Override
			public void recieveMessages(final Message message) {

				String bussinessInfo = new String(message.getData());
				JSONObject jsonObject = null;
				try {
					jsonObject = JSONObject.parseObject(bussinessInfo);
				} catch (Exception ex) {
					logger.debug("err:::" + bussinessInfo);
					ex.printStackTrace();
				}

				// ���ɹ鼯���ݶ���
				BusinessObject businessObject = null;
				try {
					businessObject = BusiDecisionMaker
							.createBusiness(jsonObject);
				} catch (EngineRuntimeException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				// ���׷���
				AnalyseCenterDao analyseCenter = (AnalyseCenterDao) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(
								AnalyseCenterDao.class);
				try {
					analyseCenter.dealBusiEntityTransaction(businessObject);
				} catch (EngineRuntimeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				logger.debug("Receive message "
						+ new String(message.getData()));
			}

			@Override
			public Executor getExecutor() {
				// Thread pool to process messages,maybe null.
				// logger.debug("executor....");
				// return null;
				// Executors.newCachedThreadPool();
				return Executors.newFixedThreadPool(10);
			}
		});
		// complete subscribe
		consumer.completeSubscribe();
	}

}
