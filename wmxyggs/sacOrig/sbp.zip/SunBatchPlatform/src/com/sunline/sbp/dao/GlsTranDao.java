package com.sunline.sbp.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.GlsTran;

public interface GlsTranDao {
	public GlsTran getEntity(int stacid , String systid,String trandt , String transq);
	public List<GlsTran> getWithBrch(int stacid ,String trandt , String tranbr , String systid);
	
	/**
	 * ����״̬�������ɹ�
	 * @param stacid ����
	 * @param systid ϵͳʶ���
	 * @param trandt ��������
	 * @param transq ������ˮ
	 * @return
	 * @throws EngineRuntimeException
	 */
	public int updateSucc(int stacid , String systid,String trandt , String transq) throws EngineRuntimeException;
	
	/**
	 * ��������״̬�������ɹ�
	 * @param list
	 * @return
	 */
	public int updateSuccBatch(List<GlsExtd> list) throws EngineRuntimeException;
	
	/**
	 * ����״̬������ʧ��
	 * @param stacid
	 * @param systid
	 * @param trandt
	 * @param transq
	 * @return
	 * @throws EngineRuntimeException
	 */
	public int updateFailed(int stacid , String systid,String trandt , String transq) throws EngineRuntimeException;
	
	public int updateFailedBatch(List<GlsExtd> list) throws EngineRuntimeException;
	
	public List<String> selectAllTranbrOfToTran(@Param("trandt") String trandt);
}
