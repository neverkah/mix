package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.SysAcctOpen;

public interface SysAcctOpenMapper {
	public SysAcctOpen selectEntity(SysAcctOpen entity);
	
	/**
	 * ��ȡ�¿��˻��˺�
	 * @param stacid ���ױ�ʶ
	 * @param systid ϵͳ��ʶ
	 * @param brchcd ��������
	 * @param crcycd ����
	 * @param acctno �˺�ǰ׺
	 * @return
	 */
	public String getMaxSubAcct(@Param("stacid") int stacid ,@Param("systid") String systid , @Param("brchcd") String brchcd , @Param("crcycd") String crcycd , @Param("acctcdpx") String acctcdpx);
	public int updateOrder(SysAcctOpen entity);
	public int insertAcctnoOpenInfo(SysAcctOpen entity);
}
