package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * ��Ʒ��Ӧ�������ñ�
 * @author xiaotian
 *
 */
public class SysDtitConf implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4270125370960047219L;
	private String prodcd;
	private String prodp1;
	private String prodp2;
	private String prodp3;
	private String prodp4;
	private String prodp5;
	private String prodp6;
	private String prodp7;
	private String prodp8;
	private String prodp9;
	private String prodpa;
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public String getProdp1() {
		return prodp1;
	}
	public void setProdp1(String prodp1) {
		this.prodp1 = prodp1;
	}
	public String getProdp2() {
		return prodp2;
	}
	public void setProdp2(String prodp2) {
		this.prodp2 = prodp2;
	}
	public String getProdp3() {
		return prodp3;
	}
	public void setProdp3(String prodp3) {
		this.prodp3 = prodp3;
	}
	public String getProdp4() {
		return prodp4;
	}
	public void setProdp4(String prodp4) {
		this.prodp4 = prodp4;
	}
	public String getProdp5() {
		return prodp5;
	}
	public void setProdp5(String prodp5) {
		this.prodp5 = prodp5;
	}
	public String getProdp6() {
		return prodp6;
	}
	public void setProdp6(String prodp6) {
		this.prodp6 = prodp6;
	}
	public String getProdp7() {
		return prodp7;
	}
	public void setProdp7(String prodp7) {
		this.prodp7 = prodp7;
	}
	public String getProdp8() {
		return prodp8;
	}
	public void setProdp8(String prodp8) {
		this.prodp8 = prodp8;
	}
	public String getProdp9() {
		return prodp9;
	}
	public void setProdp9(String prodp9) {
		this.prodp9 = prodp9;
	}
	public String getProdpa() {
		return prodpa;
	}
	public void setProdpa(String prodpa) {
		this.prodpa = prodpa;
	}
}
