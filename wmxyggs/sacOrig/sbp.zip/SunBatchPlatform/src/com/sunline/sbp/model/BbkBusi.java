package com.sunline.sbp.model;

/**
 * 
 * @���� ����bbk_busi��bean
 * @���� 
 * @author liuchj@sunline.cn
 * @project ����ϵͳ�������
 * @data 2014��4��16��
 */
public class BbkBusi {
	private int stacid;
	private String systid;
	private String trandt;
	private String transq;
	private String tranbr;
	private String prcscd;
	private String prodcd;
	private String typecd;
	private double captam;
	private double dwinam;
	private double indvam;
	private double rebfam;
	private String crcycd;
	private String status;
	private String bathid;
	
	public String getBathid() {
		return bathid;
	}
	public void setBathid(String bathid) {
		this.bathid = bathid;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public String getTypecd() {
		return typecd;
	}
	public void setTypecd(String typecd) {
		this.typecd = typecd;
	}
	public double getCaptam() {
		return captam;
	}
	public void setCaptam(double captam) {
		this.captam = captam;
	}
	public double getDwinam() {
		return dwinam;
	}
	public void setDwinam(double dwinam) {
		this.dwinam = dwinam;
	}
	public double getIndvam() {
		return indvam;
	}
	public void setIndvam(double indvam) {
		this.indvam = indvam;
	}
	public double getRebfam() {
		return rebfam;
	}
	public void setRebfam(double rebfam) {
		this.rebfam = rebfam;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	
}
