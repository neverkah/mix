package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.ClpConf;

public interface ClpConfMapper {
	public ClpConf[] getEntites(ClpConf clpConf);
}
