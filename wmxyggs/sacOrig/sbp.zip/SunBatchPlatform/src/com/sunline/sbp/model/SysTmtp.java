package com.sunline.sbp.model;

/**
 * ģ�����ͱ�
 * @author Zhangjin
 *
 */
public class SysTmtp {
	String tmpltp;
	String levltp;
	String tmtpna;
	String enname;
	String desctx;
	String vermod;
	String module;
	String projcd;
	public String getTmpltp() {
		return tmpltp;
	}
	public void setTmpltp(String tmpltp) {
		this.tmpltp = tmpltp;
	}
	public String getLevltp() {
		return levltp;
	}
	public void setLevltp(String levltp) {
		this.levltp = levltp;
	}
	public String getTmtpna() {
		return tmtpna;
	}
	public void setTmtpna(String tmtpna) {
		this.tmtpna = tmtpna;
	}
	public String getEnname() {
		return enname;
	}
	public void setEnname(String enname) {
		this.enname = enname;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
}
