package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.MidTran;

public interface MidTranMapper {
	public void insert(MidTran midtran);
	public void update(MidTran midTran);
	public MidTran selectEntity(@Param("trandt") String trandt , @Param("transq") String transq, @Param("middsq") String middsq , @Param("systid") String systid);
	public void updateBkfnstSucc(MidTran midTran);
}
