package com.sunline.sbp.dao;

import java.util.List;

import com.sunline.sbp.model.ComPrsn;

public interface ComPrsnDao {
	public List<ComPrsn> getAllEntities();
}
