package com.sunline.sbp.dao.mapper;

import java.util.List;

import com.sunline.sbp.model.GlsCmddEror;

public interface GlsCmddErorMapper {
	public void insertEntity(GlsCmddEror entity);
	public void insertEntities(List<GlsCmddEror> entity);
}
