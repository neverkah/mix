package com.sunline.sbp.commanddeal;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.dao.mapper.InvestmentTranMapper;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.InvestmentTran;

/**
 * Ͷ���ཻ����ϸ
 * @author Hopechj
 *
 */
public class InvestmentCommand implements TranCommandObject {
	
	private InvestmentTranMapper investmentTranMapper;
	private InvestmentTran command;
	private GlaVoucher glaVoucher;
	private Logger logger = Logger.getLogger(TranCommandObject.class);

	@Override
	public void initialize(String trandt, String transq , String cmmdsq, String systid) throws AnalyseException {
		// TODO Auto-generated method stub
		logger.debug("ָ���ʼ��...");
		try{
			command = investmentTranMapper.selectEntity(trandt, transq , cmmdsq , systid);
		}catch(Exception ex){
			logger.error("ϵͳ��ѯ���󣡣�����");
		}
		
		if(null == command){
			if( null == command){
				logger.error("��ȡͶ���ཻ������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq + ",Ͷ����ˮ��" + cmmdsq);
				throw new AnalyseException("��ȡͶ���ཻ������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq);
			}
		}else{
			logger.debug("ָ���ʼ���ɹ���");
		}
	}

	@Override
	public void setVoucherInfo() {
		// TODO Auto-generated method stub
			glaVoucher = new GlaVoucher();
			glaVoucher.setAcctbr(command.getAcctbr());
			glaVoucher.setAcctno("*");
			//������ϢϢʱ�Ǵ���
			glaVoucher.setAmntcd(command.getAmntcd());
			glaVoucher.setAssis0(command.getAssis0());
			glaVoucher.setAssis1(command.getAssis1());
			glaVoucher.setAssis2(command.getAssis2());
			glaVoucher.setAssis3(command.getAssis3());
			glaVoucher.setAssis4(command.getAssis4());
			glaVoucher.setAssis5(command.getAssis5());
			glaVoucher.setAssis6(command.getAssis6());
			glaVoucher.setAssis7(command.getAssis7());
			glaVoucher.setAssis8(command.getAssis8());
			glaVoucher.setAssis9(command.getAssis9());
			glaVoucher.setCentcd(command.getCentcd());
			glaVoucher.setCrcycd(command.getCrcycd());
			
			//�������
			glaVoucher.setItemcd(command.getDtitcd());
			
			glaVoucher.setPrducd(command.getProdcd());
			glaVoucher.setPrlncd(command.getPrlncd());
			glaVoucher.setPrsncd(command.getPrsncd());
			glaVoucher.setSmrytx(command.getSmrytx());
			glaVoucher.setSourdt(command.getTrandt());
			glaVoucher.setSoursq(command.getTransq());
			glaVoucher.setSourst(command.getSystid());
			glaVoucher.setStacid(command.getStacid());
			glaVoucher.setSystid(command.getSystid());
			glaVoucher.setTranam(command.getTranam());
			glaVoucher.setTranbr(command.getTranbr());
			glaVoucher.setTrandt(command.getTrandt());
			glaVoucher.setTrantp(Enumeration.TRANTP.TRAN.value);
			glaVoucher.setUsercd(Enumeration.USERCD.ENGINE.value);
			glaVoucher.setClertg(Enumeration.CLERTG.CLERTG_0.value);
		
	}

	@Override
	public String getTrprcd() {
		// TODO Auto-generated method stub
		return command.getLnbltp();
	}

	@Override
	public String getDtitcd() {
		// TODO Auto-generated method stub
		return command.getDtitcd();
	}

	@Override
	public GlaVoucher getGlaVoucher() {
		// TODO Auto-generated method stub
		return glaVoucher;
	}

	public InvestmentTranMapper getInvestmentTranMapper() {
		return investmentTranMapper;
	}

	public void setInvestmentTranMapper(InvestmentTranMapper investmentTranMapper) {
		this.investmentTranMapper = investmentTranMapper;
	}

	@Override
	public String postingSucc() throws AnalyseException {
		// TODO Auto-generated method stub
		String executeResult;
		try{
			investmentTranMapper.postingUpdate(command);
			executeResult = Constants.EXECUTE_SUCC;
		}catch(Exception ex){
			executeResult = Constants.EXECUTE_FAIL;
			throw new AnalyseException("����ָ��Ϊ�ѹ���ʧ��",ex);
		}
		return executeResult;
	}

	@Override
	public String getTrancd() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getStacid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getStacid();
	}

	@Override
	public void initialize(JSONObject jsonObject) throws AnalyseException {
		// TODO Auto-generated method stub
		command = JSON.parseObject(jsonObject.toJSONString(), InvestmentTran.class);
	}

	@Override
	public String getTrandt() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTrandt();
	}

	@Override
	public String getSystid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getSystid();
	}

	@Override
	public String getTransq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTransq();
	}

	@Override
	public String getCmmdsq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getIvetsq();
	}
	
	
}
