package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * ���׷�������ӳ���
 * @author Zhangjin
 *
 */
public class SysTmapTran implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2364772132431572765L;
	private int stacid;
	private String prcscd;
	private String dttrcd;
	private int trtlno;
	private int sortno;
	private String condcd;
	private String proftp;
	private String profid;
	private String fildcd;
	private String mpcdin;
	private String mpcdot;
	private String nulflg;
	private String desctx;
	private String vermod;
	private String module;
	private String projcd;
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public String getDttrcd() {
		return dttrcd;
	}
	public void setDttrcd(String dttrcd) {
		this.dttrcd = dttrcd;
	}
	public int getTrtlno() {
		return trtlno;
	}
	public void setTrtlno(int trtlno) {
		this.trtlno = trtlno;
	}
	public int getSortno() {
		return sortno;
	}
	public void setSortno(int sortno) {
		this.sortno = sortno;
	}
	public String getCondcd() {
		return condcd;
	}
	public void setCondcd(String condcd) {
		this.condcd = condcd;
	}
	public String getProftp() {
		return proftp;
	}
	public void setProftp(String proftp) {
		this.proftp = proftp;
	}
	public String getProfid() {
		return profid;
	}
	public void setProfid(String profid) {
		this.profid = profid;
	}
	public String getFildcd() {
		return fildcd;
	}
	public void setFildcd(String fildcd) {
		this.fildcd = fildcd;
	}
	public String getMpcdin() {
		return mpcdin;
	}
	public void setMpcdin(String mpcdin) {
		this.mpcdin = mpcdin;
	}
	public String getMpcdot() {
		return mpcdot;
	}
	public void setMpcdot(String mpcdot) {
		this.mpcdot = mpcdot;
	}
	public String getNulflg() {
		return nulflg;
	}
	public void setNulflg(String nulflg) {
		this.nulflg = nulflg;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
}
