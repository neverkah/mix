package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.SysPftp;

public interface SysPftpMapper {
	public SysPftp getEntity(SysPftp sysPftp);
}
