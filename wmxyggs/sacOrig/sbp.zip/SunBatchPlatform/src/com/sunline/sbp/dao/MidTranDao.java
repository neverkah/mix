package com.sunline.sbp.dao;

import com.sunline.sbp.model.MidTran;

public interface MidTranDao {
	public void insert(MidTran midTran);
}
