package com.sunline.sbp.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.dao.GlsTranDao;
import com.sunline.sbp.dao.mapper.GlsTranMapper;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.GlsTran;

public class GlsTranDaoImpl implements GlsTranDao {
	
	private GlsTranMapper glsTranMapper;
	private Logger logger = Logger.getLogger(GlsTranDaoImpl.class);

	@Override
	public GlsTran getEntity(int stacid, String systid, String trandt,
			String transq) {
		// TODO Auto-generated method stub
		GlsTran glsTran = glsTranMapper.selectEntity(stacid, systid, trandt, transq);
		return glsTran;
	}
	
	

	@Override
	public int updateSucc(int stacid, String systid, String trandt,
			String transq) throws EngineRuntimeException {
		int executeCount = 0;
		// TODO Auto-generated method stub
		if(null == glsTranMapper){
			logger.error("glsTranMapperΪ�գ�");
		}
		
		try{
			executeCount = glsTranMapper.toTagSucc(stacid, systid, trandt, transq);
		}catch(Exception ex){
			throw new EngineRuntimeException("",ex);
		}
		return executeCount;
		
	}
	
	@Override
	public int updateSuccBatch(List<GlsExtd> list) throws EngineRuntimeException{
		// TODO Auto-generated method stub
		int executeCount = 0;
		if(null == glsTranMapper){
			logger.error("glsTranMapperΪ�գ�");
		}
		try{
			executeCount = glsTranMapper.toTagSuccBat(list,list.get(0).getTrandt(),list.get(0).getSystid());
		}catch(Exception ex){
			logger.error("����������ˮ״̬Ϊ�ɹ�ʱʧ��",ex);
			throw new EngineRuntimeException("����������ˮ״̬Ϊ�ɹ�ʱʧ��",ex);
		}
		return executeCount;
		
	}

	@Override
	public int updateFailed(int stacid, String systid, String trandt,
			String transq) throws EngineRuntimeException{
		// TODO Auto-generated method stub
		int executeCount = 0;
		if(null == glsTranMapper){
			logger.error("glsTranMapperΪ�գ�");
		}
		try{
			executeCount = glsTranMapper.toTagFailed(stacid, systid, trandt, transq);
		}catch(Exception ex){
			throw new EngineRuntimeException("���ʸ�����Χ��ˮ״̬����",ex);
		}
		return executeCount;
	}
	
	@Override
	public int updateFailedBatch(List<GlsExtd> list) throws EngineRuntimeException{
		// TODO Auto-generated method stub
		int executeCount = 0;
		if(null == glsTranMapper){
			logger.error("glsTranMapperΪ�գ�");
		}
		try{
			executeCount = glsTranMapper.toTagFailedBatch(list,list.get(0).getTrandt(),list.get(0).getSystid());
		}catch(Exception ex){
			throw new EngineRuntimeException("����������Χ��ˮ״̬����",ex);
		}
		return executeCount;
	}
	
	public GlsTranMapper getGlsTranMapper() {
		return glsTranMapper;
	}

	public void setGlsTranMapper(GlsTranMapper glsTranMapper) {
		this.glsTranMapper = glsTranMapper;
	}



	@Override
	public List<GlsTran> getWithBrch(int stacid, String trandt,
			String tranbr , String systid) {
		// TODO Auto-generated method stub
		List<GlsTran> glsTrans = glsTranMapper.selectEntitiesWithBrch(stacid, trandt, tranbr , systid);
		return glsTrans;
	}



	@Override
	public List<String> selectAllTranbrOfToTran(String trandt) {
		// TODO Auto-generated method stub
		return glsTranMapper.selectAllTranbrOfToTran(trandt);
	}

}
