package com.sunline.sbp.dao.impl.rule;

import java.util.HashMap;

/**
 * ��Ϣָ��
 * @author ZhangJin
 */










import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.DataObjectUtil;
import com.sunline.foundation.TranamInfoEntity;
import com.sunline.sbp.base.RuleBeanObject;
import com.sunline.sbp.dao.mapper.DepositPayInterestMapper;
import com.sunline.sbp.dao.mapper.GlsExtdMapper;
import com.sunline.sbp.model.DepositPayInterest;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;
import com.sunline.sbp.model.SysIomp;

public class DepositPayInterestRule implements RuleBeanObject {
	
	private DepositPayInterestMapper depositPayInterestMapper;
	private DepositPayInterest command;
	private GlsExtdMapper glsExtdMapper;
	private GlsExtd extd;
	private HashMap<String , Object> data;
	private SysIomp[] iopms;
	private SysIntf sysIntf;
	private SysIntfDetl[] intfDetl;
	
	@Override
	public void setMapOfInIntf(final SysIntf sysIntf , final SysIomp[] iopms ,final SysIntfDetl[] detls) {
		// TODO Auto-generated method stub
		this.iopms = iopms;
		this.sysIntf = sysIntf;
		this.intfDetl = detls;
	}

	@Override
	public String initialize(HashMap<String , Object> data) throws AnalyseException {
		// TODO Auto-generated method stub
		command = new DepositPayInterest();
		command.setAcctbr(DataObjectUtil.getHashMapStr(data,"acctbr").toString());
		command.setAcctno(DataObjectUtil.getHashMapStr(data,"acctno").toString());
		command.setAcmlbl(DataObjectUtil.getBigDecimalValue(data,"acmlbl"));
		command.setCalcfg(DataObjectUtil.getHashMapStr(data,"calcfg").toString());
		command.setCorrtg(DataObjectUtil.getHashMapStr(data,"corrtg").toString());
		command.setCrcycd(DataObjectUtil.getHashMapStr(data,"crcycd").toString());
		command.setDtitcd(DataObjectUtil.getHashMapStr(data,"dtitcd").toString());
		command.setEddate(DataObjectUtil.getHashMapStr(data,"eddate").toString());
		command.setPyinsq(DataObjectUtil.getHashMapStr(data,"pyinsq").toString());
		command.setStdate(DataObjectUtil.getHashMapStr(data,"stdate").toString());
		command.setSubsac(DataObjectUtil.getHashMapStr(data,"subsac").toString());
		command.setStacid(DataObjectUtil.getIntegerValue(data, "stacid"));
		command.setSystid(DataObjectUtil.getHashMapStr(data,"systid").toString());
		command.setTranam(DataObjectUtil.getBigDecimalValue(data,"tranam"));
		command.setTranbr(DataObjectUtil.getHashMapStr(data,"tranbr").toString());
		command.setTrandt(DataObjectUtil.getHashMapStr(data,"trandt").toString());
		command.setTransq(DataObjectUtil.getHashMapStr(data,"transq").toString());
		command.setTrantp(DataObjectUtil.getHashMapStr(data,"trantp").toString());
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public String check() {
		// TODO Auto-generated method stub
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public GlsExtd execute(int orderCount) {
		// TODO Auto-generated method stub
		//depositPayInterestMapper.insertEntity(command);
		
		extd = new GlsExtd();
		extd.setStacid(command.getStacid());
		extd.setSystid(command.getSystid());
		extd.setTrandt(command.getTrandt());
		extd.setTranbr(command.getTranbr());
		extd.setTransq(command.getTransq());
		extd.setSortno(orderCount);
		extd.setCmmdtg(Constants.COMMAND_IDENTITY_PI);
		extd.setAmntcd(Constants.AMNTCD_CREDIT);
		extd.setCrcycd(command.getCrcycd());
		extd.setTranam(command.getTranam());
		
		return extd;
	}

	@Override
	public TranamInfoEntity getTranamInfo() {
		// TODO Auto-generated method stub
		HashMap<String , Double> data = new HashMap<String , Double>();
		/*
		 * ��Ϣ��¼��
		 * �裺Ӧ����Ϣ
		 *   �����ڲ��˻�
		 */
		return new TranamInfoEntity(Constants.AMNTCD_DEBIT,command.getTranam());
	}

	public DepositPayInterestMapper getDepositPayInterestMapper() {
		return depositPayInterestMapper;
	}

	public void setDepositPayInterestMapper(
			DepositPayInterestMapper depositPayInterestMapper) {
		this.depositPayInterestMapper = depositPayInterestMapper;
	}

	public GlsExtdMapper getGlsExtdMapper() {
		return glsExtdMapper;
	}

	public void setGlsExtdMapper(GlsExtdMapper glsExtdMapper) {
		this.glsExtdMapper = glsExtdMapper;
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return data;
	}

	@Override
	public JSONObject getCmmd() {
		// TODO Auto-generated method stub
		return (JSONObject)JSON.toJSON(command);
	}
	
}
