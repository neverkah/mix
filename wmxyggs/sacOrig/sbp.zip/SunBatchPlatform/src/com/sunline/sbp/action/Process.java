package com.sunline.sbp.action;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.dao.AccountingTreatmentDao;
import com.sunline.sbp.dao.AnalyseCenterDao;
import com.sunline.sbp.model.AsbBusi;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.MidTran;
import com.sunline.sbp.service.MidTranAction;

public class Process {
	
	private String systid , trandt , transq;
	
	private Logger logger = Logger.getLogger(Process.class);
	
	public void insertTran(){
		
		MidTranAction midTranAction = (MidTranAction)ApplicationBeanFactory.getApplicationContextInstance().getBean(MidTranAction.class);
		
		HashMap<String,Object> data = new HashMap<String,Object>();
		
		try{
			data.put("systid", "FI");
			data.put("trandt", "20121206");
			data.put("transq", "000000");
			data.put("tranbr", "01002");
			data.put("dtitcd", "01002");
			data.put("tranam", 456);
			data.put("amntcd", "C");
			
			MidTran midtran = new MidTran();
			
			midtran.setAmntcd("D");
			midtran.setDtitcd(data.get("dtitcd").toString());
			midtran.setTranam(BigDecimal.valueOf(Double.parseDouble(data.get("tranam").toString())));
			midtran.setSystid(data.get("systid").toString());
			midtran.setTranbr(data.get("tranbr").toString());
			midtran.setTrandt(data.get("trandt").toString());
			midtran.setTransq(data.get("transq").toString());
			
			if(null != midTranAction){
				midTranAction.insert(midtran);
			}else{
				logger.debug("midTranAction is null");
			}
			
			midtran.setSystid("FI");
			
			if(null != midTranAction){
				//midTranAction.insert(midtran);
			}else{
				logger.debug("midTranAction is null");
			}
		}catch(Exception ex){
			//throw new RuntimeException("failed");
			ex.printStackTrace();
		}
        
	}
	
	public static void main(String[] args) throws EngineRuntimeException{
		Process emain = new Process();
		
		ArrayList<HashMap<String,String>> als = new ArrayList<HashMap<String,String>>();
		HashMap<String , String > busi = new HashMap<String , String>();
		HashMap<String , String > busi2 = new HashMap<String , String>();
		busi.put("systid", "FI");
		busi.put("trandt", "20121221");
		busi.put("transq", "010001001");
		als.add(busi);
		busi2.put("systid", "FI");
		busi2.put("trandt", "20121221");
		busi2.put("transq", "010001002");
		als.add(busi2);
		
		for(HashMap<String,String> entity : als){
			long startTime=System.currentTimeMillis();   //��ȡ��ʼʱ��
			
			ArrayList<GlsExtd> extd = emain.anyal(entity);
			
			emain.generateVoucher(extd);
			
			long endTime=System.currentTimeMillis(); //��ȡ����ʱ��
			Logger.getLogger(Process.class).debug("=====================��������ʱ�䣺 "+(endTime-startTime)+"ms");
		}
		
	}
	
	private ArrayList<GlsExtd> anyal(HashMap<String,String> bentity) throws EngineRuntimeException{
		
		AnalyseCenterDao analyseCenter = (AnalyseCenterDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AnalyseCenterDao.class);
		
		AsbBusi entity = new AsbBusi();
		entity.setSystid(bentity.get("systid"));
		entity.setTrandt(bentity.get("trandt"));
		entity.setTransq(bentity.get("transq"));
		
		//AsbBusi asbBusis = asbBusiDao.selectBusi(entity);

		//return analyseCenter.dealBusiness(bentity);
		return null;
		
	}
	
	private void generateVoucher(ArrayList<GlsExtd> extds) throws EngineRuntimeException{
		AccountingTreatmentDao ap = (AccountingTreatmentDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AccountingTreatmentDao.class);
		ap.processVectorTransaction(extds);
	}
}
