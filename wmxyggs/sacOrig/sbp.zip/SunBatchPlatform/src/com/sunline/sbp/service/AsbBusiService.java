package com.sunline.sbp.service;

import com.sunline.sbp.model.AsbBusi;

public interface AsbBusiService {
	public AsbBusi[] selectAsbBusi(AsbBusi entity);
}
