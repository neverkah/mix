package com.sunline.sbp.dao;

import java.util.List;

import com.sunline.sbp.model.SysProduct;

public interface SysProductDao {
	public List<SysProduct> getAllEntities();
}
