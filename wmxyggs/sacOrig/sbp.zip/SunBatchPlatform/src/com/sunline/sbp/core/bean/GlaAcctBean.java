package com.sunline.sbp.core.bean;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.dao.mapper.ComCrcyMapper;
import com.sunline.sbp.dao.mapper.GlaAcctMapper;
import com.sunline.sbp.model.AccountingItem;
import com.sunline.sbp.model.ComBrch;
import com.sunline.sbp.model.ComCrcy;
import com.sunline.sbp.model.GlaAcct;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.SysAcctOpen;
import com.sunline.sbp.model.validation.GlaAcctValidateBean;
import com.sunline.sunbp.util.MyBatisUtil;

public class GlaAcctBean {
	
	private static Logger logger = Logger.getLogger(GlaAcctBean.class);

	private static String acctcd;
	private static final int SYSTID_LENGTH = 2;
	private static final int BRCHCD_LENGTH = 7;
	private static final int CRCYCD_LENGTH = 3;
	private static final int ITEMCD_LENGTH = 6;
	
	/**
	 * ˳��ų���
	 */
	private static final int ORDER_LENGTH = 5;
	
	private static Hashtable<String, ComCrcy> crcyCache = new Hashtable<String, ComCrcy>();

	
	public static String getAcctno(String systid,
			String brchcd, String crcycd , String itemcd,int order){
		
		String acct_order = "00000000".concat(String.valueOf(order));
		acct_order = acct_order.substring(acct_order.length()-ORDER_LENGTH,acct_order.length());
		
		String acctno = systid.concat(brchcd).concat(crcycd).concat(getItemcd(itemcd)).concat(acct_order);
		logger.debug("acctno:" + acctno);
		return acctno;
	}
	
	public static String getAcctcd(int stacid,String systid,
			String brchcd, String crcycd , String itemcd,int aorder) throws AnalyseException{
		int acctnoSubLength = 5;
		String nextOrderStr = "000000000"+aorder;
		String subacct =  nextOrderStr.substring(nextOrderStr.length()-acctnoSubLength);
		String acctcd = getAcctcdPx(stacid,systid, brchcd, crcycd, itemcd).concat(subacct);
		logger.debug("acctno:" + acctcd);
		return acctcd;
	}
	
	/**
	 * ��ȡ�˺�ǰ׺�����ס�ϵͳ��ʶ + �������� + ���� + ��Ŀǰ6λ��
	 * @param stacid
	 * @param systid
	 * @param brchcd
	 * @param crcycd
	 * @param itemcd
	 * @return
	 * @throws AnalyseException 
	 */
	public static String getAcctcdPx(int stacid,String systid,
			String brchcd, String crcycd , String itemcd) throws AnalyseException{
		//ת�����ִ���δ�������ִ���crcyen   modify by zhangdq
		String crcyen="";
		try {
			ComCrcy comCrcy = getCrcyFromCrcyCache(crcycd);
			crcyen = comCrcy.getCrcyen();
		} catch (AnalyseException e) {
			// TODO Auto-generated catch block
			throw new AnalyseException(e.getMessage(),e);
		}
		
		String acctcdpx = String.valueOf(stacid).concat(systid).concat(brchcd).concat(crcyen).concat(getItemcd(itemcd));
		logger.debug("acctcdpx:" + acctcdpx);
		return acctcdpx;
	}

	public GlaAcctBean(String acctcd) {
		this.acctcd = acctcd;
	}

	public String init(String acctcd) {
		this.acctcd = acctcd;
		return this.acctcd;
	}

	public void updateAccount(GlaVoucher vchr, GlaAcct acctno) {

	}

	public String getSystid() {
		return this.acctcd.substring(0, SYSTID_LENGTH);
	}

	public static int getOrder(String acctno) {
		String order = acctno.substring(SYSTID_LENGTH + BRCHCD_LENGTH
				+ CRCYCD_LENGTH + ITEMCD_LENGTH);
		if(order.startsWith("0")){
			return Integer.parseInt(order);
		}else{
			return 0;
		}
	}
	
	public static String getNextAcctnoOfItem(String acctno){
		int order = getOrder(acctno) + 1;
		String dealOrder = "0000000000" + order;
		return acctno.substring(0,SYSTID_LENGTH + BRCHCD_LENGTH
				+ CRCYCD_LENGTH + ITEMCD_LENGTH) + dealOrder.substring(dealOrder.length()- ORDER_LENGTH);
	}
	
	public static String getItemcd(String itemcd){
		itemcd = itemcd + "000000";
		return itemcd.substring(0,ITEMCD_LENGTH);
	}
	
	public static SysAcctOpen getAcctOpenInfo(int stacid , String systid , String brchcd , String crcycd , String itemcd ){
		SysAcctOpen acctOpenEntity = new SysAcctOpen();
		acctOpenEntity.setStacid(stacid);
		acctOpenEntity.setSystid(systid);
		acctOpenEntity.setBrchcd(brchcd);
		acctOpenEntity.setItemcd(getItemcd(itemcd));
		acctOpenEntity.setCrcycd(crcycd);
		return acctOpenEntity;
	}
	
	public static void updateAccountBalance(int stacid, String systid, String brchcd,
			String itemcd, String crcycd, String subscd,
			String amntcd,BigDecimal tranam,String transq,String pmodck,String soursq,String trandt , AccountingItem itemEntity,GlaAcct acctEntity){

		// TODO Auto-generated method stub
		HashMap<String,String> map = new HashMap<String,String>();
		logger.debug("����["+stacid+"]ϵͳ["+systid+"]����["+brchcd+"]��Ŀ["+itemcd+"]����["+crcycd+"]��Ŀ��["+subscd+"]�����˻����");
		
		//String trandt = accountSetDao.getTrandt(stacid);
		
		//itemEntity = accountingItemDao.getEntityByPrimaryKey(stacid,itemcd);
		
		BigDecimal onlnbl = acctEntity.getOnlnbl();
		String blncdn = acctEntity.getBlncdn();
		
		logger.debug("�˻�����" + acctEntity.getBlncdn());
		if(!itemEntity.getItemdn().equals(Enumeration.Amntcd.Z.value) && !itemEntity.getItemdn().equals(Enumeration.Amntcd.B.value)){
			if(acctEntity.getBlncdn().equals(Enumeration.Amntcd.C.value)){
				blncdn = Enumeration.Amntcd.C.value;
				onlnbl = onlnbl.add(amntcd.equals(Enumeration.Amntcd.C.value) || amntcd.equals(Enumeration.Amntcd.P.value)?tranam:tranam.negate());
			}else if(acctEntity.getBlncdn().equals(Enumeration.Amntcd.D.value)){
				blncdn = Enumeration.Amntcd.D.value;
				onlnbl = onlnbl.add(amntcd.equals(Enumeration.Amntcd.D.value) || amntcd.equals(Enumeration.Amntcd.R.value)?tranam:tranam.negate());
			}else if(acctEntity.getBlncdn().equals(Enumeration.Amntcd.R.value)){
				blncdn = Enumeration.Amntcd.R.value;
				//modify by zhanghong@sunline.cn ©���޸����
				onlnbl = onlnbl.add(amntcd.equals(Enumeration.Amntcd.D.value) || amntcd.equals(Enumeration.Amntcd.R.value)?tranam:tranam.negate());
			}
		}else if(acctEntity.getBlncdn().equals(Enumeration.Amntcd.Z.value) || itemEntity.getItemdn().equals(Enumeration.Amntcd.Z.value)){
			/*
			 * modify by zhanghong@sunline.cn ����Ŀ����Ϊ��Z��,'B'ʱ���˺�������Ա��������ӳ�ڽ跽��ʱ���˺�����Ϊ�裬����ӳ�ڴ�����ʱ���˺�����Ϊ����
			 */
			if(acctEntity.getBlncdn().equals(Enumeration.Amntcd.Z.value)){
				onlnbl = onlnbl.add(amntcd.equals(Enumeration.Amntcd.D.value) || amntcd.equals(Enumeration.Amntcd.R.value)?tranam:tranam.negate());
				if(onlnbl.compareTo(Constants.DECIMAL_ZERO) < 0){
					blncdn = Enumeration.Amntcd.C.value;
				}else if(onlnbl.compareTo(Constants.DECIMAL_ZERO) > 0){
					blncdn = Enumeration.Amntcd.D.value;
				}
				onlnbl = onlnbl.abs();
			}else if(!acctEntity.getBlncdn().equals(Enumeration.Amntcd.Z.value) && itemEntity.getItemdn().equals(Enumeration.Amntcd.Z.value)){
				onlnbl = onlnbl.add(amntcd.equals(acctEntity.getBlncdn())?tranam:tranam.negate());
				if(onlnbl.compareTo(Constants.DECIMAL_ZERO) == -1){
					if(acctEntity.getBlncdn().equals(Enumeration.Amntcd.D.value)){
						blncdn = Enumeration.Amntcd.C.value;
					}else{
						blncdn = Enumeration.Amntcd.D.value;
					}
				}else if(onlnbl.compareTo(Constants.DECIMAL_ZERO) == 1){
					blncdn = acctEntity.getBlncdn();
				}
				onlnbl = onlnbl.abs();
			}
			
		}else if(acctEntity.getBlncdn().equals(Enumeration.Amntcd.B.value) || itemEntity.getItemdn().equals(Enumeration.Amntcd.B.value)){
			
			if(acctEntity.getBlncdn().equals(Enumeration.Amntcd.B.value)){
				onlnbl = onlnbl.add(amntcd.equals(Enumeration.Amntcd.D.value) || amntcd.equals(Enumeration.Amntcd.R.value)?tranam:tranam.negate());
				if(onlnbl.compareTo(Constants.DECIMAL_ZERO) == -1){
					blncdn = Enumeration.Amntcd.C.value;
				}else if(onlnbl.compareTo(Constants.DECIMAL_ZERO) == 1){
					blncdn = Enumeration.Amntcd.D.value;
				}
				onlnbl = onlnbl.abs();
			}else if(!acctEntity.getBlncdn().equals(Enumeration.Amntcd.B.value) && itemEntity.getItemdn().equals(Enumeration.Amntcd.B.value)){
				onlnbl = onlnbl.add(amntcd.equals(acctEntity.getBlncdn())?tranam:tranam.negate());
				if(onlnbl.compareTo(Constants.DECIMAL_ZERO) == -1){
					if(acctEntity.getBlncdn().equals(Enumeration.Amntcd.D.value)){
						blncdn = Enumeration.Amntcd.C.value;
					}else{
						blncdn = Enumeration.Amntcd.D.value;
					}
				}else if(onlnbl.compareTo(Constants.DECIMAL_ZERO) == 1){
					blncdn = acctEntity.getBlncdn();
				}
				onlnbl = onlnbl.abs();
			}
		}else{
			logger.error("�˻�����["+acctEntity.getBlncdn()+"]�Ƿ�");
		}
		
		//͸֧����
		if(pmodck.equals("1") && acctEntity.getPmodtg().equals("0") 
				&&( acctEntity.getBlncdn().equals(Enumeration.Amntcd.C.value) ||
						acctEntity.getBlncdn().equals(Enumeration.Amntcd.D.value) ||
						acctEntity.getBlncdn().equals(Enumeration.Amntcd.R.value))
				&& (onlnbl.compareTo(Constants.DECIMAL_ZERO) == -1)){
			//throw new AnalyseException("�˻�["+acctno+"]������͸֧");
			map.put("trandt", trandt);
			map.put("transq", soursq);
			//map.put("erortx", "�˻�["+acctno+"]������͸֧");
			/*glaGlisMapper.insertErorTax(map);
			updateAccountBalance(stacid, systid, brchcd,
					itemcd, crcycd, subscd,
					amntcd,0-tranam,transq,pmodck,soursq);*/
		}
		
		acctEntity.setOnlnbl(onlnbl);
		acctEntity.setBlncdn(blncdn);
		acctEntity.setLstrdt(trandt);// �˻������������
		acctEntity.setLstrsq(transq);// �˻����������ˮ
		
		logger.debug("�˻�["+acctEntity.getAcctcd()+"]������ɹ���");
		
	}
	
	
	
	/**
	 * ���������˻�Bean
	 * @param stacid ����
	 * @param acctcd �˻�Ψһ��ʶ
	 * @param itemEntity ��Ŀ��Ϣ
	 * @param brchEntity ����������Ϣ
	 * @param glaVoucher ��Ʊ��Ϣ
	 * @return
	 * @throws AnalyseException
	 */
	public static GlaAcct generateAcctEntity(int stacid,String acctcd , AccountingItem itemEntity , ComBrch brchEntity , GlaVoucher glaVoucher) throws AnalyseException{
		
		//�˻����2:��׼�˻���3:ר���˻�����Ĭ��Ϊ��׼�˻�
		String acctlg = Enumeration.GLA_ACCT_ACCTLG.BASE.value;
		
		if(null != glaVoucher.getSubsac() && glaVoucher.getSubsac().trim().length() > 0 ){
			if(itemEntity.getItemtp().equalsIgnoreCase(Enumeration.ITEMTP.ASSETSVSLIABILITY.value)){
				//ר���˻�
				acctlg = Enumeration.GLA_ACCT_ACCTLG.SPECIALUSE.value;
			}else{
				logger.error("��Ʒ�¼�п�Ŀ��"+itemEntity.getItemcd()+"�������ʲ���ծ��ͬ���Ŀ��������Ŀ�ţ�"+glaVoucher.getSubsac()+"�����ݿ�������");
				throw new AnalyseException("��Ʒ�¼�п�Ŀ��"+itemEntity.getItemcd()+"�������ʲ���ծ��ͬ���Ŀ��������Ŀ�ţ�"+glaVoucher.getSubsac()+"�����ݿ�������");
			}
		}
		
		GlaAcct acctEntity = new GlaAcct();
		acctEntity.setStacid(stacid);
		acctEntity.setAcctcd(acctcd);			
		
		acctEntity.setPmodtg(itemEntity.getPomdtg());
		acctEntity.setAcctna(itemEntity.getItemna()+"("+brchEntity.getBrchna()+")");
		acctEntity.setBrchno(brchEntity.getBrchcd());
		acctEntity.setItemcd(itemEntity.getItemcd());
		//ֻ���л�׼��/ר���˻�����
		acctEntity.setAcctcl(acctlg);
		acctEntity.setCrcycd(glaVoucher.getCrcycd());
		acctEntity.setOpenbr(brchEntity.getBrchcd());
		acctEntity.setOpendt(glaVoucher.getTrandt());
		acctEntity.setOptrsq("*");
		acctEntity.setIoflag(itemEntity.getIoflag());
		acctEntity.setBlncdn(itemEntity.getItemdn());
		acctEntity.setLastdn(itemEntity.getItemdn());
		acctEntity.setOnlnbl(Constants.DECIMAL_ZERO);
		acctEntity.setLastbl(Constants.DECIMAL_ZERO);
		acctEntity.setAcctst("1");
		acctEntity.setSystid(glaVoucher.getSystid());
		acctEntity.setOpenus("#");
		acctEntity.setDrhdbk("0");
		acctEntity.setCrhdbk("0");
		acctEntity.setSubscd(glaVoucher.getSubsac());
		acctEntity.setLstrdt(glaVoucher.getTrandt());
		acctEntity.setLstrsq("*");
		acctEntity.setLastdt("");
		acctEntity.setClosdt("");
		acctEntity.setCltrsq("");
		acctEntity.setOpenus(Enumeration.USERCD.ENGINE.value);
		acctEntity.setClosdt("");
		acctEntity.setAcmlbl(Constants.DECIMAL_ZERO);
		acctEntity.setAcmldt("");
		
		acctEntity.setCentcd(glaVoucher.getCentcd());
		acctEntity.setPrsncd(glaVoucher.getPrsncd());
		acctEntity.setCustcd(glaVoucher.getCustcd());
		acctEntity.setPrducd(glaVoucher.getPrducd());
		acctEntity.setPrlncd(glaVoucher.getPrlncd());
		acctEntity.setAcctno(glaVoucher.getAcctno());
		acctEntity.setAssis0(glaVoucher.getAssis0());
		acctEntity.setAssis1(glaVoucher.getAssis1());
		acctEntity.setAssis2(glaVoucher.getAssis2());
		acctEntity.setAssis3(glaVoucher.getAssis3());
		acctEntity.setAssis4(glaVoucher.getAssis4());
		acctEntity.setAssis5(glaVoucher.getAssis5());
		acctEntity.setAssis6(glaVoucher.getAssis6());
		acctEntity.setAssis7(glaVoucher.getAssis7());
		acctEntity.setAssis8(glaVoucher.getAssis8());
		acctEntity.setAssis9(glaVoucher.getAssis9()); 
		                                         
		return acctEntity;                       
		
	}
	//��ȡ���ֵĻ�����Ϣ modify by zhangdq
	private static ComCrcy getCrcyFromCrcyCache(String crcycd)
			throws AnalyseException {
		ComCrcy crcyInfo = crcyCache.get(crcycd);
		if (null == crcyInfo && null == (crcyInfo = freshCrcyCache(crcycd))) {
			logger.error("����"+crcycd+"δ���û򲻴���");
			throw new AnalyseException("����"+crcycd+"δ���û򲻴���");
		}
		return crcyInfo;
	}
	//ˢ�±��ֻ�����Ϣ
	private static ComCrcy freshCrcyCache(String crcycd) throws AnalyseException{
		crcyCache.clear();
		SqlSession sqlSession = MyBatisUtil
					.getSqlSessionFactory()
					.openSession(false);
		ComCrcy[] crcys = sqlSession.getMapper(
				ComCrcyMapper.class).selectFullComCrcys();
		for (int i = 0; i < crcys.length; i++) {
			crcyCache.put(crcys[i].getCrcycd(), crcys[i]);
		}
		return crcyCache.get(crcycd);
	}

}
