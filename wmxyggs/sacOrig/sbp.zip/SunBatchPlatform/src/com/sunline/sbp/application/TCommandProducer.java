package com.sunline.sbp.application;

import static com.sunline.sbp.application.Help.initMetaConfig;

import java.io.IOException;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.sunline.sbp.dao.mapper.GlsTranMapper;
import com.sunline.sbp.model.GlsTran;
import com.sunline.sunbp.util.MyBatisUtil;
import com.taobao.metamorphosis.Message;
import com.taobao.metamorphosis.client.MessageSessionFactory;
import com.taobao.metamorphosis.client.MetaMessageSessionFactory;
import com.taobao.metamorphosis.client.producer.MessageProducer;
import com.taobao.metamorphosis.client.producer.SendResult;

public class TCommandProducer {

	public static void main(final String[] args) throws Exception {

		final String topic = "gl-vchr";

		MessageSessionFactory sessionFactory = new MetaMessageSessionFactory(
				initMetaConfig());
		MessageProducer producer = sessionFactory.createProducer();
		producer.publish(topic);

		GlsTran[] entities = fetch("20141002");

		for (GlsTran entity : entities) {
			final String message = JSON.toJSONString(entity);
			SendResult sendResult = producer.sendMessage(
					new Message(topic, message.getBytes()));
			try {
				if (!sendResult.isSuccess()) {
					System.out.println("ERROR:" + sendResult.getErrorMessage());
					throw new RuntimeException("send message failed");
				}else{
					System.out.println("SUCC:");
				}
			} catch (final Exception e) {
				e.printStackTrace();
			}
		}
	}

	private static GlsTran[] fetch(String trandt) throws IOException {
		
		SqlSession sqlSession = MyBatisUtil
				.getSqlSessionFactory()
				.openSession();
		
		GlsTran[] extds = sqlSession.getMapper(GlsTranMapper.class).selectEntities(1, "00", "20141002", "2%");
		
		Logger.getLogger(TCommandProducer.class).debug("Type message to send:");

		return extds;
		// JSONObject jsonObject = JSONObject.fromObject(entities[1]);
		// return jsonObject.toString();
	}

}
