package com.sunline.sbp.model;

public class ComExsr {
	private int stacid;
	private String acexcd;
	private String sourcd;
	private String sourna;
	private String sprrcd;
	private String detltg;
	private String sourtp;
	private String valide;
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getAcexcd() {
		return acexcd;
	}
	public void setAcexcd(String acexcd) {
		this.acexcd = acexcd;
	}
	public String getSourcd() {
		return sourcd;
	}
	public void setSourcd(String sourcd) {
		this.sourcd = sourcd;
	}
	public String getSourna() {
		return sourna;
	}
	public void setSourna(String sourna) {
		this.sourna = sourna;
	}
	public String getSprrcd() {
		return sprrcd;
	}
	public void setSprrcd(String sprrcd) {
		this.sprrcd = sprrcd;
	}
	public String getDetltg() {
		return detltg;
	}
	public void setDetltg(String detltg) {
		this.detltg = detltg;
	}
	public String getSourtp() {
		return sourtp;
	}
	public void setSourtp(String sourtp) {
		this.sourtp = sourtp;
	}
	public String getValide() {
		return valide;
	}
	public void setValide(String valide) {
		this.valide = valide;
	}
}
