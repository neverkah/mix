package com.sunline.sbp.dao.impl;

import java.util.Hashtable;
import java.util.List;

import com.sunline.sbp.dao.SysProductDao;
import com.sunline.sbp.dao.mapper.SysProductMapper;
import com.sunline.sbp.model.SysProduct;

public class SysProductDaoImpl implements SysProductDao {
	
	private SysProductMapper sysProductMapper;
	
	private int initail = 0;
	
	/**
	 * ȫ��Ϣ����
	 */
	private static Hashtable<String,SysProduct> acctDatas = new Hashtable<String,SysProduct>();

	@Override
	public List<SysProduct> getAllEntities() {
		// TODO Auto-generated method stub
		List<SysProduct> tableData = sysProductMapper.getAllEntities();
		for(SysProduct entity : tableData){
			acctDatas.put(entity.getProdcd(), entity);
		}
		return tableData;
	}
	
	public Hashtable<String,SysProduct> getCacheData(){
		if(initail == 0){
			synchronized(this) {
				if(initail == 0){
					getAllEntities();
					initail = 1;
				}
			}
		}
		return acctDatas;
	}
	
	public boolean frushCache(){
		acctDatas.clear();
		getAllEntities();
		return true;
	}

	public SysProductMapper getSysProductMapper() {
		return sysProductMapper;
	}

	public void setSysProductMapper(SysProductMapper sysProductMapper) {
		this.sysProductMapper = sysProductMapper;
	}
}
