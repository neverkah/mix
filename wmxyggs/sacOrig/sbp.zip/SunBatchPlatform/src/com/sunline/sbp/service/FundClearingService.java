package com.sunline.sbp.service;

import com.sunline.foundation.ServiceException;

public interface FundClearingService {
	public String runningTransaction(int stacid) throws ServiceException;
}
