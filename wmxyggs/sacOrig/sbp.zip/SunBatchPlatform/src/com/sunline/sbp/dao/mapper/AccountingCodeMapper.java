package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.AccountingCode;

public interface AccountingCodeMapper {
	public AccountingCode getEntities(AccountingCode dtitcd);
}
