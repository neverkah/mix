package com.sunline.sbp.model;

/**
 * ϵͳ���������Ͷ����(sys_prtp)
 * @author Zhangjin
 *
 */

public class SysPrtp {
    private String prgptp;
	private String prtpkd;
	private String prgpna;
	private String enname;
	private String desctx;
	private String vermod;
	private String module;
	private String projcd;
	
	public String getPrgptp() {
		return prgptp;
	}
	public void setPrgptp(String prgptp) {
		this.prgptp = prgptp;
	}
	public String getPrtpkd() {
		return prtpkd;
	}
	public void setPrtpkd(String prtpkd) {
		this.prtpkd = prtpkd;
	}
	public String getPrgpna() {
		return prgpna;
	}
	public void setPrgpna(String prgpna) {
		this.prgpna = prgpna;
	}
	public String getEnname() {
		return enname;
	}
	public void setEnname(String enname) {
		this.enname = enname;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
	
	
}
