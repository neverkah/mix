package com.sunline.sbp.model;

import java.io.Serializable;

public class SysIomp implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6114881108234012127L;
	private String ruleid;
	private String ftokey;
	private String mapkey;
	private String smrytx;
	public String getRuleid() {
		return ruleid;
	}
	public void setRuleid(String ruleid) {
		this.ruleid = ruleid;
	}
	public String getFtokey() {
		return ftokey;
	}
	public void setFtokey(String ftokey) {
		this.ftokey = ftokey;
	}
	public String getMapkey() {
		return mapkey;
	}
	public void setMapkey(String mapkey) {
		this.mapkey = mapkey;
	}
	public String getSmrytx() {
		return smrytx;
	}
	public void setSmrytx(String smrytx) {
		this.smrytx = smrytx;
	}
}
