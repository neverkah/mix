package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.SysCond;
import com.sunline.sbp.model.SysCondDetl;


public interface SysCondDetlMapper {
	public SysCondDetl[] getDetailOfCond(SysCond entity);
}
