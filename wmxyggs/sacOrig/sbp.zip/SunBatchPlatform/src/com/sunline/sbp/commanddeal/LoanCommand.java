package com.sunline.sbp.commanddeal;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.dao.mapper.LoanTranInfoMapper;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.LoanTranInfo;

/**
 * �������ϸ
 * 
 * @author Hopechj
 * 
 */
public class LoanCommand implements TranCommandObject {

	private Logger logger = Logger.getLogger(LoanCommand.class);

	private LoanTranInfoMapper loanTranInfoMapper;
	private LoanTranInfo command;
	private GlaVoucher glaVoucher=new GlaVoucher();
	

	@Override
	public void initialize(String trandt, String transq, String cmmdsq,
			String systid) throws AnalyseException {
		// TODO Auto-generated method stub
		command = loanTranInfoMapper.selectEntity(trandt, transq, cmmdsq,
				systid);
		if (null == command) {
			if (null == command) {
				logger.error("��ȡ�����ָ������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��"
						+ transq);
				throw new AnalyseException("��ȡ�����ָ������ʧ�ܣ�" + "�������ڣ�" + trandt
						+ ",������ˮ��" + transq);
			}
		}
	}

	@Override
	public void initialize(JSONObject jsonObject) throws AnalyseException {
		// TODO Auto-generated method stub
		command = JSON.parseObject(jsonObject.toJSONString(),
				LoanTranInfo.class);
		glaVoucher.setPrducd(jsonObject.getString("prodcd"));
		glaVoucher.setCustcd(jsonObject.getString("custcd"));
		glaVoucher.setPrsncd(jsonObject.getString("prsncd"));
		glaVoucher.setPrlncd(jsonObject.getString("prlncd"));
		glaVoucher.setAcctno(jsonObject.getString("acctno"));
		glaVoucher.setCentcd(jsonObject.getString("centcd"));
		glaVoucher.setAssis0(jsonObject.getString("assis0"));
		glaVoucher.setAssis1(jsonObject.getString("assis1"));
		glaVoucher.setAssis2(jsonObject.getString("assis2"));
		glaVoucher.setAssis3(jsonObject.getString("assis3"));
		glaVoucher.setAssis4(jsonObject.getString("assis4"));
		glaVoucher.setAssis5(jsonObject.getString("assis5"));
		glaVoucher.setAssis6(jsonObject.getString("assis6"));
		glaVoucher.setAssis7(jsonObject.getString("assis7"));
		glaVoucher.setAssis8(jsonObject.getString("assis8"));
		glaVoucher.setAssis9(jsonObject.getString("assis9"));
	}

	@Override
	public void setVoucherInfo() {
		// TODO Auto-generated method stub

		glaVoucher.setAcctbr(command.getAcctbr());
		glaVoucher.setAmntcd(command.getAmntcd());
		glaVoucher.setCrcycd(command.getCrcycd());
		glaVoucher.setItemcd(command.getDtitcd());
		glaVoucher.setSmrytx("");
		glaVoucher.setSourdt(command.getTrandt());
		glaVoucher.setSoursq(command.getTransq());
		glaVoucher.setSourst(command.getSystid());
		glaVoucher.setStacid(command.getStacid());
		glaVoucher.setSystid(command.getSystid());
		glaVoucher.setTranam(command.getTranam());
		glaVoucher.setTranbr(command.getTranbr());
		glaVoucher.setTrandt(command.getTrandt());
		glaVoucher.setTrantp(command.getTrantp());
		glaVoucher.setUsercd(Enumeration.USERCD.ENGINE.value);
		glaVoucher.setClertg(Enumeration.CLERTG.CLERTG_0.value);
	}

	@Override
	public String getTrprcd() {
		// TODO Auto-generated method stub
		return command.getLnbltp();
	}

	@Override
	public String getTrancd() {
		// TODO Auto-generated method stub
		return command.getTrancd();
	}

	@Override
	public String getDtitcd() {
		// TODO Auto-generated method stub
		return command.getDtitcd();
	}

	@Override
	public GlaVoucher getGlaVoucher() {
		// TODO Auto-generated method stub
		return glaVoucher;
	}

	public LoanTranInfoMapper getLoanTranInfoMapper() {
		return loanTranInfoMapper;
	}

	public void setLoanTranInfoMapper(LoanTranInfoMapper loanTranInfoMapper) {
		this.loanTranInfoMapper = loanTranInfoMapper;
	}

	@Override
	public String postingSucc() {
		// TODO Auto-generated method stub
		String executeResult;
		try {
			loanTranInfoMapper.postingUpdate(command);
			executeResult = Constants.EXECUTE_SUCC;
		} catch (Exception ex) {
			executeResult = Constants.EXECUTE_FAIL;
		}
		return executeResult;
	}

	@Override
	public int getStacid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getStacid();
	}

	@Override
	public String getTrandt() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTrandt();
	}

	@Override
	public String getSystid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getSystid();
	}

	@Override
	public String getTransq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTransq();
	}

	@Override
	public String getCmmdsq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getLoansq();
	}

}
