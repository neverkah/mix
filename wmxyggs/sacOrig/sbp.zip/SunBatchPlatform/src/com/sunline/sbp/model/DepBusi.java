package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * �����ҵ��(ҵ��鼯)��dep_busi��
 * @author Zhangjin
 *
 */
public class DepBusi {
	
	private int stacid;
	private String systid;
	private String trandt;
	private String tranbr;
	private String transq;
	private String bsnssq;
	private String prcscd;
	/**����*/
	private String debttp;
	private String prodcd;
	/**����*/
	private String termcd;
	private String trantp;
	private String acctno;
	private String tobrch;
	private String toacno;
	private String smrycd;
	private String crcycd;
	private BigDecimal capiam;
	private BigDecimal pyinam;
	private BigDecimal acinam;
	private BigDecimal poudam;
	private BigDecimal pdcsam;
	private BigDecimal intxam;
	private String dcmttp;
	private String dealst;
	private String bathid;
	
	public String getBathid() {
		return bathid;
	}
	public void setBathid(String bathid) {
		this.bathid = bathid;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public String getDebttp() {
		return debttp;
	}
	public void setDebttp(String debttp) {
		this.debttp = debttp;
	}
	public String getTermcd() {
		return termcd;
	}
	public void setTermcd(String termcd) {
		this.termcd = termcd;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getTobrch() {
		return tobrch;
	}
	public void setTobrch(String tobrch) {
		this.tobrch = tobrch;
	}
	public String getToacno() {
		return toacno;
	}
	public void setToacno(String toacno) {
		this.toacno = toacno;
	}
	public String getSmrycd() {
		return smrycd;
	}
	public void setSmrycd(String smrycd) {
		this.smrycd = smrycd;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getCapiam() {
		return capiam;
	}
	public void setCapiam(BigDecimal capiam) {
		this.capiam = capiam;
	}
	public BigDecimal getPyinam() {
		return pyinam;
	}
	public void setPyinam(BigDecimal pyinam) {
		this.pyinam = pyinam;
	}
	public BigDecimal getAcinam() {
		return acinam;
	}
	public void setAcinam(BigDecimal acinam) {
		this.acinam = acinam;
	}
	public BigDecimal getPoudam() {
		return poudam;
	}
	public void setPoudam(BigDecimal poudam) {
		this.poudam = poudam;
	}
	public BigDecimal getPdcsam() {
		return pdcsam;
	}
	public void setPdcsam(BigDecimal pdcsam) {
		this.pdcsam = pdcsam;
	}
	public BigDecimal getIntxam() {
		return intxam;
	}
	public void setIntxam(BigDecimal intxam) {
		this.intxam = intxam;
	}
	public String getDcmttp() {
		return dcmttp;
	}
	public void setDcmttp(String dcmttp) {
		this.dcmttp = dcmttp;
	}
	public String getDealst() {
		return dealst;
	}
	public void setDealst(String dealst) {
		this.dealst = dealst;
	}
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getBsnssq() {
		return bsnssq;
	}
	public void setBsnssq(String bsnssq) {
		this.bsnssq = bsnssq;
	}
	
}
