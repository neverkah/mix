package com.sunline.sbp.dao.mapper;

import java.util.List;

import com.sunline.sbp.model.ComCust;

public interface ComCustMapper {
	public List<ComCust> getAllEntities();
}
