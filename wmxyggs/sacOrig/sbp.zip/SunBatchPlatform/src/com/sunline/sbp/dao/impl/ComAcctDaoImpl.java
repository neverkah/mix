package com.sunline.sbp.dao.impl;

import java.util.Hashtable;
import java.util.List;

import com.sunline.foundation.Constants;
import com.sunline.sbp.dao.ComAcctDao;
import com.sunline.sbp.dao.mapper.ComAcctMapper;
import com.sunline.sbp.model.ComAcct;

public class ComAcctDaoImpl implements ComAcctDao {
	
	private ComAcctMapper comAcctMapper;
	
	private int initail = 0;
	
	/**
	 * ȫ��Ϣ����
	 */
	private static Hashtable<String,ComAcct> acctDatas = new Hashtable<String,ComAcct>();

	@Override
	public List<ComAcct> getAllEntities() {
		// TODO Auto-generated method stub
		List<ComAcct> tableData = comAcctMapper.getAllEntities();
		for(ComAcct entity : tableData){
			acctDatas.put(entity.getStacid()+Constants.DTAG+entity.getAcctno(), entity);
		}
		return tableData;
	}
	
	public Hashtable<String,ComAcct> getCacheData(){
		if(initail == 0){
			synchronized(this) {
				if(initail == 0){
					getAllEntities();
					initail = 1;
				}
			}
		}
		return acctDatas;
	}
	
	public boolean frushCache(){
		acctDatas.clear();
		getAllEntities();
		return true;
	}

	public ComAcctMapper getComAcctMapper() {
		return comAcctMapper;
	}

	public void setComAcctMapper(ComAcctMapper comAcctMapper) {
		this.comAcctMapper = comAcctMapper;
	}
}
