package com.sunline.sbp.commanddeal;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.dao.mapper.RvchCommandMapper;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.GlsCmddRvch;

/**
 * 
 * @���� ������ָ��
 * @���� ������ָ�gls_cmdd_rvch��
 * @author zhanghong@sunline.cn
 * @project ����ϵͳ�������
 * @data 2014��7��2��
 */
public class rvchCommand implements TranCommandObject {
	
	
	private RvchCommandMapper rvchCommandMapper;
	private GlsCmddRvch command;
	private GlaVoucher glaVoucher;
	
	private final Logger logger = Logger.getLogger(rvchCommand.class);

	@Override
	public void setVoucherInfo() {
		// TODO Auto-generated method stub
		glaVoucher = new GlaVoucher();
		glaVoucher.setAcctbr(command.getAcctbr());
		glaVoucher.setAcctno("*");
		glaVoucher.setAmntcd(command.getAmntcd());
		glaVoucher.setAssis0("*");
		glaVoucher.setAssis1("*");
		glaVoucher.setAssis3("*");
		glaVoucher.setAssis4("*");
		glaVoucher.setAssis5("*");
		glaVoucher.setAssis6("*");
		glaVoucher.setAssis7("*");
		glaVoucher.setAssis8("*");
		glaVoucher.setAssis9("*");
		glaVoucher.setCentcd("*");
		glaVoucher.setCrcycd(command.getCrcycd());
		
		glaVoucher.setItemcd(command.getDtitcd());
		glaVoucher.setPrducd("*");
		glaVoucher.setPrlncd("*");
		glaVoucher.setPrsncd("*");
		glaVoucher.setSourdt(command.getTrandt());
		glaVoucher.setSoursq(command.getTransq());
		glaVoucher.setSourst(command.getSystid());
		glaVoucher.setStacid(command.getStacid());
		glaVoucher.setSystid(command.getSystid());
		glaVoucher.setTranam(command.getTranam());
		glaVoucher.setTranbr(command.getTranbr());
		glaVoucher.setTrandt(command.getTrandt());
		glaVoucher.setTrantp(command.getTrantp());
		glaVoucher.setUsercd(Enumeration.USERCD.ENGINE.value);
		glaVoucher.setClertg(Enumeration.CLERTG.CLERTG_0.value);
	}

	@Override
	public void initialize(String trandt, String transq , String cmmdsq ,String systid) throws AnalyseException {
		// TODO Auto-generated method stub
		command = rvchCommandMapper.selectEntity(trandt, transq, cmmdsq ,systid);
		if( null == command){
			logger.error("��ȡ����������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq +",ָ����ˮ��" + cmmdsq);
			throw new AnalyseException("��ȡ����������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq+",ָ����ˮ��" + cmmdsq);
		}
	}

	@Override
	public String getTrprcd() {
		// TODO Auto-generated method stub
		return command.getBltype();
	}

	@Override
	public String getDtitcd() {
		// TODO Auto-generated method stub
		return command.getDtitcd();
	}

	@Override
	public GlaVoucher getGlaVoucher() {
		// TODO Auto-generated method stub
		return glaVoucher;
	}

	public RvchCommandMapper getRvchCommandMapper() {
		return rvchCommandMapper;
	}

	public void setRvchCommandMapper(RvchCommandMapper rvchCommandMapper) {
		this.rvchCommandMapper = rvchCommandMapper;
	}

	@Override
	public String postingSucc() {
		// TODO Auto-generated method stub
		String executeResult;
		try{
			rvchCommandMapper.postingUpdate(command);
			executeResult = Constants.EXECUTE_SUCC;
		}catch(Exception ex){
			executeResult = Constants.EXECUTE_FAIL;
		}
		return executeResult;
	}

	@Override
	public String getTrancd() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getStacid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getStacid();
	}

	@Override
	public void initialize(JSONObject jsonObject) throws AnalyseException {
		// TODO Auto-generated method stub
		command = JSON.parseObject(jsonObject.toJSONString(), GlsCmddRvch.class);
	}

	@Override
	public String getTrandt() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTrandt();
	}

	@Override
	public String getSystid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getSystid();
	}

	@Override
	public String getTransq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTransq();
	}

	@Override
	public String getCmmdsq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getRvchsq();
	}

}

