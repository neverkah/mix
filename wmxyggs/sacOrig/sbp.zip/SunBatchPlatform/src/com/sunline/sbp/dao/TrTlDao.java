package com.sunline.sbp.dao;

import com.sunline.sbp.model.SysTrtl;

public interface TrTlDao {
	public SysTrtl[] getEntities();
}
