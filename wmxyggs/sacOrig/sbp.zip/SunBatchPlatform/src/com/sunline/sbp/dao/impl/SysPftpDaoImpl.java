package com.sunline.sbp.dao.impl;

import com.sunline.foundation.Logger;
import com.sunline.sbp.dao.SysPftpDao;
import com.sunline.sbp.dao.mapper.SysPftpMapper;
import com.sunline.sbp.model.SysPftp;

public class SysPftpDaoImpl implements SysPftpDao {
	
	private SysPftpMapper sysPftpMapper;

	@Override
	public SysPftp getEntityByPK(SysPftp sysPftp) {
		// TODO Auto-generated method stub
		SysPftp pftpEntity = sysPftpMapper.getEntity(sysPftp);
		if(null == pftpEntity){
			Logger.getLogger(SysPftpDaoImpl.class).debug("��ȡ����"+sysPftp.getProftp()+"������Ϣʧ��");
		}
		return pftpEntity;
	}

	public SysPftpMapper getSysPftpMapper() {
		return sysPftpMapper;
	}

	public void setSysPftpMapper(SysPftpMapper sysPftpMapper) {
		this.sysPftpMapper = sysPftpMapper;
	}
	
	
}
