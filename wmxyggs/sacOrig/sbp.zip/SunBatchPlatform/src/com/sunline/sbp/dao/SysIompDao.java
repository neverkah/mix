package com.sunline.sbp.dao;

import com.sunline.sbp.model.SysIomp;

public interface SysIompDao {
	public SysIomp[] getMapInfo(String ruleid);
}
