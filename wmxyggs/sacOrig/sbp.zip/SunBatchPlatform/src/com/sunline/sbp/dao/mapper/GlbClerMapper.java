package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.GlbCler;

public interface GlbClerMapper {
	public void insertEntities(GlbCler entities);
	public int updateTrandtTransq(GlbCler entitie);
}
