package com.sunline.sbp.datamerger;

import org.apache.log4j.Logger;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.dao.TranProcessDao;
import com.sunline.sbp.dao.impl.TranProcessDaoImpl;
import com.sunline.sbp.model.AsbBusi;
import com.sunline.sbp.model.AsbDpra;
import com.sunline.sbp.model.BbkBusi;
import com.sunline.sbp.model.DepBusi;
import com.sunline.sbp.model.GlbCler;
import com.sunline.sbp.model.IvestmentBusi;
import com.sunline.sbp.model.LoanBusi;
import com.sunline.sbp.model.TranProcess;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class BusiDecisionMaker {

	public static BusinessObject createBusiness(JSONObject jsonObject) throws EngineRuntimeException{
		
		Logger logger = Logger.getLogger(BusiDecisionMaker.class);
		
		logger.debug("��ʼ����BusinessObject����...");
		BusinessObject businessObject = null;

		if(jsonObject.containsKey("prcscd")){
			String prcscd = jsonObject.getString("prcscd");
			logger.debug("�����룺" + prcscd);
			String moducd = getModule(prcscd);
			if(moducd.equalsIgnoreCase("AS")){
				//Object bean = JSONObject.toBean(jsonObject, AsbBusi.class);
				AsbBusi busi = JSON.parseObject(jsonObject.toJSONString(), AsbBusi.class);
				businessObject = new AsbBusiMerger(busi);
			}else if(moducd.equalsIgnoreCase("AD")){
				//�ʲ��۾ɣ�̯����
				//Object bean = JSONObject.toBean(jsonObject, AsbDpra.class);
				AsbDpra busi = JSON.parseObject(jsonObject.toString(), AsbDpra.class);
				businessObject = new AsbDpraMerger(busi);
			}else if(moducd.equalsIgnoreCase("DP")){
				//���
				//Object bean = JSONObject.toBean(jsonObject, DepBusi.class);
				DepBusi busi = JSON.parseObject(jsonObject.toJSONString(), DepBusi.class);
				businessObject = new DepBusiMerger(busi);
			}else if(moducd.equalsIgnoreCase("IV")){
				//Ͷ��
				//Object bean = JSONObject.toBean(jsonObject, IvestmentBusi.class);
				IvestmentBusi busi = JSON.parseObject(jsonObject.toJSONString(),IvestmentBusi.class);
				businessObject = new IvestmentBusiMerger(busi);
			}else if(moducd.equalsIgnoreCase("BK")){
				//�ع�
				//Object bean = JSONObject.toBean(jsonObject, BbkBusi.class);
				BbkBusi busi = JSON.parseObject(jsonObject.toJSONString(), BbkBusi.class);
				businessObject = new BbkBusiMerger(busi);
			}else if(moducd.equalsIgnoreCase("CL")){
				//����
				//Object bean = JSONObject.toBean(jsonObject, GlbCler.class);
				GlbCler busi = JSON.parseObject(jsonObject.toJSONString(),GlbCler.class);
				businessObject = new GlbClerMerger(busi);
			}else if(moducd.equalsIgnoreCase("LN")){
				//�������
				//Object bean = JSONObject.toBean(jsonObject, LoanBusi.class);
				LoanBusi busi = JSON.parseObject(jsonObject.toJSONString(), LoanBusi.class);
				businessObject = new LoanBusiMerger(busi);
			}
			
		}else{
			logger.error("��������ȱ�ٴ����루prcscd����Ϣ!Data:" + jsonObject.toString());
			throw new EngineRuntimeException("��������ȱ�ٴ����루prcscd��");
			
		}
		return businessObject;
	}
	
	private static String getModule(String prcscd) throws EngineRuntimeException{
		
		Logger logger = Logger.getLogger(BusiDecisionMaker.class);
		
		TranProcessDaoImpl prcsInfoDao = (TranProcessDaoImpl)ApplicationBeanFactory.getApplicationContextInstance().getBean(TranProcessDao.class);
		
		String module = null;
		TranProcess prcs = new TranProcess();
		prcs.setPrcscd(prcscd);
		prcs.setProjcd(".");
		if(null == prcsInfoDao){
			String message = "ϵͳ�޷���ȡ������["+prcscd+"]��DAO";
			logger.error(message);
			throw new EngineRuntimeException(message);
		}
		prcs = prcsInfoDao.getTranProcessProperty(prcs);
		if(null == prcs){
			String message = "ϵͳ�޷���ȡ������["+prcscd+"]��������Ϣ";
			logger.error(message);
			throw new EngineRuntimeException(message);
		}
		module = prcs.getModule();
		logger.debug("����������ģ�飺" + module);
		return module;
	}
}
