package com.sunline.sbp.base;

import java.util.HashMap;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;

public class DataContext {
	private HashMap<String, Object> dataContext;
	private final String COMM = "comm";
	
	private Logger logger = Logger.getLogger(DataContext.class);
	
	public DataContext(){
		dataContext = new HashMap<String, Object>();
	}
	
	private void init(){
		logger.info("��ʼ���������������...");
		dataContext = new HashMap<String, Object>();
	}
	
	public void putComm(String key , Object value){
		if( null == dataContext){
			init();
		}
		
		if(!dataContext.containsKey(COMM)){
			logger.info("��ʼ���������������֮������...");
			dataContext.put(COMM, new HashMap<String,Object>());
		}
		logger.info("��Ϣ"+key+"��ֵ" + dataContext.get(key)+"������Ϊ" + value);
		getCommInfo().put(key, value);
	}
	
	/**
	 * 
	 * @param map
	 */
	public void putCommAll(HashMap<String, Object> map){
		if(!dataContext.containsKey(COMM)){
			dataContext.put(COMM, new HashMap<String,Object>());
		}
		getCommInfo().putAll(map);
	}
	
	/**
	 * 
	 * @param key
	 * @param value
	 * @param trancd
	 * @throws AnalyseException 
	 */
	public void putTranInfo(String key , Object value , String trancd) {
		
		String caseTrancd = trancd.toLowerCase();
		
		if(null == dataContext){
			try {
				throw new AnalyseException("ϵͳ�쳣�����������������Ϊ�ա�");
			} catch (AnalyseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(!dataContext.containsKey(caseTrancd)){
			initTranContext(caseTrancd);
		}
		
		HashMap<String, Object> tranMap = getTranInfo(caseTrancd);
		
		if(tranMap.containsKey(key)){
			logger.debug("��Ϣ"+key+"��ֵ" + tranMap.get(key)+"������Ϊ" + value);
		}
		logger.debug("�ӽ���" + trancd + "������������Ϣ" + key + "=" + value);
		tranMap.put(key, value);
		
	}
	
	public void putTranInfoAll(HashMap<String, Object> map ,String trancd){
		Iterator<String> set = map.keySet().iterator();
		String key = null;
		while (set.hasNext()){
			key = set.next();
			putTranInfo(key,map.get(key),trancd);
		}
	}
	
	/**
	 * ��ʼ����������������
	 * @param trancd
	 */
	private void initTranContext(String trancd){
		logger.debug("��ʼ�ӻ�����"+trancd+"��������...");
		dataContext.put(trancd.toLowerCase(), new HashMap<String, Object>());
	}
	
	/**
	 * 
	 * @param trancd
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public HashMap<String, Object> getInfo(String trancd){
		
		HashMap<String, Object> tranInfo = null;
		
		//��������
		tranInfo = (HashMap<String, Object>)getCommInfo().clone();
		
		//���ؽ������ݡ��������������빫�������ظ����򸲸�
		if(dataContext.containsKey(trancd.toLowerCase())){
			tranInfo.putAll(getTranInfo(trancd.toLowerCase()));
		}
		
		return tranInfo;
		
	}
	
	public Object get(String key , String trancd){
		Object value = null;
		HashMap<String, Object> tranMap = getTranInfo(trancd.toLowerCase());
		if( null != tranMap && tranMap.containsKey(key)){
			value = tranMap.get(key);
		}else{
			value = getCommInfo().get(key);
		}
		return value;
	}
	
	public Object get(String key){
		Object value = null;
		HashMap<String, Object> tranMap = getCommInfo();
		if( null != tranMap && tranMap.containsKey(key)){
			value = tranMap.get(key);
		}
		return value;
	}
	
	@SuppressWarnings("unchecked")
	private HashMap<String,Object> getTranInfo(String trancd){
		return (HashMap<String,Object>)dataContext.get(trancd.toLowerCase());
	} 
	
	@SuppressWarnings("unchecked")
	private HashMap<String,Object> getCommInfo(){
		return (HashMap<String,Object>)dataContext.get(COMM);
	}
	
	public HashMap<String, Object> getDataContext(){
		return dataContext;
	}
}
