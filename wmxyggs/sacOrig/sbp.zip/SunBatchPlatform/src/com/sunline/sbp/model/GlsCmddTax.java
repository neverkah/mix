package com.sunline.sbp.model;

import java.math.BigDecimal;

public class GlsCmddTax {
	private int stacid;
	private String systid;
	private String trandt;
	private String taxseq;
	private String transq;
	private String tranbr;
	private String trantp;
	private String crcycd;
	private BigDecimal intxam;
	private String dtitcd;
	private String acctbr;
	private String acctno;
	private String dpacno;
	private String prodcd;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTaxseq() {
		return taxseq;
	}
	public void setTaxseq(String taxseq) {
		this.taxseq = taxseq;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getIntxam() {
		return intxam;
	}
	public void setIntxam(BigDecimal intxam) {
		this.intxam = intxam;
	}
	public String getDtitcd() {
		return dtitcd;
	}
	public void setDtitcd(String dtitcd) {
		this.dtitcd = dtitcd;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getDpacno() {
		return dpacno;
	}
	public void setDpacno(String dpacno) {
		this.dpacno = dpacno;
	}
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	
	

}
