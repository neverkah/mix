package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * 
 * @���� ������ͺ���ֽ��JavaBean
 * @���� ��sys_lndt
 * @author liuchj@sunline.cn
 * @project ����ϵͳ�������
 * @data 2014��5��7��
 */
public class SysLndt implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int stacid;
	private String dtitcd;
	private String trancd;
	private String lntype;
	private String dttype;
	private String amntcd;
	private String usedtp;
	private String efctdt;
	private String inefdt;
	private String desctx;
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getDtitcd() {
		return dtitcd;
	}
	public void setDtitcd(String dtitcd) {
		this.dtitcd = dtitcd;
	}
	public String getTrancd() {
		return trancd;
	}
	public void setTrancd(String trancd) {
		this.trancd = trancd;
	}
	public String getLntype() {
		return lntype;
	}
	public void setLntype(String lntype) {
		this.lntype = lntype;
	}
	public String getDttype() {
		return dttype;
	}
	public void setDttype(String dttype) {
		this.dttype = dttype;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}
	public String getUsedtp() {
		return usedtp;
	}
	public void setUsedtp(String usedtp) {
		this.usedtp = usedtp;
	}
	public String getEfctdt() {
		return efctdt;
	}
	public void setEfctdt(String efctdt) {
		this.efctdt = efctdt;
	}
	public String getInefdt() {
		return inefdt;
	}
	public void setInefdt(String inefdt) {
		this.inefdt = inefdt;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
}
