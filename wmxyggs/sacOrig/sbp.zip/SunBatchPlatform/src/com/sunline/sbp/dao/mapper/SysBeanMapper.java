package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.SysBean;

public interface SysBeanMapper {
	public SysBean getEntityByPK(SysBean sysBean);
}
