package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * ���̶��壨sys_bean��
 * @author Zhangjin
 *
 */

public class SysBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6607607839713842595L;
	private String beanid;
	private String pckgcd;
	private String beande;
	private String beanna;
	private String paracd;
	private String usedtp;
	private String desctx;
	private String vermod;
	private String module;
	private String projcd;
	
	public String getBeanid() {
		return beanid;
	}
	public void setBeanid(String beanid) {
		this.beanid = beanid;
	}
	public String getPckgcd() {
		return pckgcd;
	}
	public void setPckgcd(String pckgcd) {
		this.pckgcd = pckgcd;
	}
	public String getBeande() {
		return beande;
	}
	public void setBeande(String beande) {
		this.beande = beande;
	}
	public String getBeanna() {
		return beanna;
	}
	public void setBeanna(String beanna) {
		this.beanna = beanna;
	}
	public String getParacd() {
		return paracd;
	}
	public void setParacd(String paracd) {
		this.paracd = paracd;
	}
	public String getUsedtp() {
		return usedtp;
	}
	public void setUsedtp(String usedtp) {
		this.usedtp = usedtp;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
}
