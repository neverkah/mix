package com.sunline.sbp.base;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.dao.impl.rule.AsbDpraRule;
import com.sunline.sbp.dao.impl.rule.AsbTranRule;
import com.sunline.sbp.dao.impl.rule.CashReceiptAndPaymentTranRule;
import com.sunline.sbp.dao.impl.rule.DepositDrawalInterestTranRule;
import com.sunline.sbp.dao.impl.rule.DepositPayInterestRule;
import com.sunline.sbp.dao.impl.rule.DepositTranInfoRule;
import com.sunline.sbp.dao.impl.rule.LoadTranDetlRule;
import com.sunline.sbp.dao.impl.rule.MidTranRule;

public class RuleBeanObjectGenerator {
	
	private static Logger logger = Logger.getLogger(RuleBeanObjectGenerator.class);
	
	public static RuleBeanObject getDealBean(String beanID) throws AnalyseException {

		RuleBeanObject ruleBeanObject = null;
		logger.debug("׼����ö���" + beanID + ".....");
		if (beanID.equalsIgnoreCase("inacTranRule")) {

			try {
				ruleBeanObject = (com.sunline.sbp.dao.impl.rule.InacTranRule) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
			}

		}else if (beanID.equalsIgnoreCase("midTranRule")) {

			try {
				ruleBeanObject = (MidTranRule) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
			}

		}else if(beanID.equalsIgnoreCase("asbTranRule")){
			try {
				ruleBeanObject = (AsbTranRule) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
			}
		}else if(beanID.equalsIgnoreCase("asbDpraRule")){
			try {
				ruleBeanObject = (AsbDpraRule) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
			}
		}else if(beanID.equalsIgnoreCase("csiotranrule")){
			try {
				ruleBeanObject = (CashReceiptAndPaymentTranRule) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
			}
		}else if(beanID.equalsIgnoreCase("depPayInsterestRule")){
			try {
				ruleBeanObject = (DepositPayInterestRule) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
			}
		}else if(beanID.equalsIgnoreCase("depdwinRule")){
			try {
				ruleBeanObject = (DepositDrawalInterestTranRule) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
			}
		}else if(beanID.equalsIgnoreCase("loadTranRule")){
			try {
				ruleBeanObject = (LoadTranDetlRule) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
			}
		}else if(beanID.equalsIgnoreCase("depTranRule")){
			try {
				ruleBeanObject = (DepositTranInfoRule) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
			}
		}else {
			try {
				ruleBeanObject = (RuleBeanObject) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
				logger.error("���ɹ������ʧ�ܣ�" + beanID + "δע��!");
			}
		}
		
		if(null != ruleBeanObject){
			logger.debug("��ȡ����" + beanID + "�ɹ�");
		}else{
			throw new AnalyseException("���ɹ������ʧ�ܣ�" + beanID + "δע��!");
		}
		
		return ruleBeanObject;
	}

}
