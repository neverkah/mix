package com.sunline.sbp.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.GlsTran;

public interface GlsTranMapper {
	public GlsTran[] selectEntities(@Param("stacid") int stacid , @Param("systid") String systid , @Param("trandt") String trandt , @Param("transq") String transq);
	public GlsTran selectEntity(@Param("stacid") int stacid , @Param("systid") String systid , @Param("trandt") String trandt , @Param("transq") String transq);
	public List<GlsTran> selectEntitiesWithBrch(@Param("stacid") int stacid , @Param("trandt") String trandt , @Param("tranbr") String tranbr , @Param("systid") String systid);
	public int toTagSucc(@Param("stacid") int stacid , @Param("systid") String systid , @Param("trandt") String trandt , @Param("transq") String transq);
	/**
	 * ��������״̬�������ɹ�
	 * @param list
	 * @return
	 */
	public int toTagSuccBat(@Param("list") List<GlsExtd> list , @Param("trandt") String trandt , @Param("systid") String systid);
	public int toTagFailed(@Param("stacid") int stacid , @Param("systid") String systid , @Param("trandt") String trandt , @Param("transq") String transq);
	
	/**
	 * ��������״̬����������
	 * @param list
	 * @return
	 */
	public int toTagFailedBatch(@Param("list") List<GlsExtd> list , @Param("trandt") String trandt , @Param("systid") String systid);
	
	/**
	 * ��ȡ�������Ľ��׻���
	 * @param trandt
	 * @return
	 */
	public List<String> selectAllTranbrOfToTran(@Param("trandt") String trandt);
}
