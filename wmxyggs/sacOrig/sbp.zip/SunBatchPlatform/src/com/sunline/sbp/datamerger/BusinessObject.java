package com.sunline.sbp.datamerger;

public interface BusinessObject {
	public int getStacid();
	public void setStacid(int stacid);
	public String getPrcscd();
	public String getBusiType();
	public Object getBusinessObject();
	public String getBsnsdt();
	public String getBsnssq();
	public String getSystid();
	public String getProdcd();
}
