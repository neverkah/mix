package com.sunline.sbp.model;

/**
 * ��ӳ�����
 * @���� 
 * @���� ����sys_vchr_eror
 * @author liuchj@sunline.cn
 * @project ����ϵͳ�������
 * @data 2014��11��12��
 */
public class SysVchrEror {
	private int stacid;
	private String systid;
	private String trandt;
	private String transq;
	private String vchrsq;
	private String logmsg;
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getVchrsq() {
		return vchrsq;
	}
	public void setVchrsq(String vchrsq) {
		this.vchrsq = vchrsq;
	}
	public String getLogmsg() {
		return logmsg;
	}
	public void setLogmsg(String logmsg) {
		this.logmsg = logmsg;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
}
