package com.sunline.sbp.dao.impl.rule;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.DataObjectUtil;
import com.sunline.foundation.Enumeration;
import com.sunline.foundation.TranamInfoEntity;
import com.sunline.sbp.base.RuleBeanObject;
import com.sunline.sbp.dao.mapper.DepositCommandMapper;
import com.sunline.sbp.dao.mapper.GlsExtdMapper;
import com.sunline.sbp.model.DepositCommand;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;
import com.sunline.sbp.model.SysIomp;

/**
 * ����ָ��
 * @author ZhangJin
 *
 */

public class DepositTranInfoRule implements RuleBeanObject {
	
	private DepositCommandMapper depositCommandMapper;
	private DepositCommand command;
	private GlsExtdMapper glsExtdMapper;
	private GlsExtd extd;
	private HashMap<String , Object> data;
	private SysIomp[] iopms;
	private SysIntf sysIntf;
	private SysIntfDetl[] intfDetl;
	
	private Logger logger = Logger.getLogger(DepositTranInfoRule.class);
	
	@Override
	public void setMapOfInIntf(final SysIntf sysIntf , final SysIomp[] iopms ,final SysIntfDetl[] detls) {
		// TODO Auto-generated method stub
		this.iopms = iopms;
		this.sysIntf = sysIntf;
		this.intfDetl = detls;
	}

	@Override
	public String initialize(HashMap<String , Object> data) throws AnalyseException {
		// TODO Auto-generated method stub
		logger.debug("��������ȡ�����н���ָ�����װ...��ʼ");
		this.data = data;
		command = new DepositCommand();
		command.setAcctbr(DataObjectUtil.getHashMapStr(data,"acctbr").toString());
		command.setAcctno(DataObjectUtil.getHashMapStr(data,"acctno","*").toString());
		command.setAmntcd(DataObjectUtil.getHashMapStr(data,"amntcd").toString());
		command.setBltype(DataObjectUtil.getHashMapStr(data,"bltype").toString());
		command.setCorrtg(DataObjectUtil.getHashMapStr(data,"corrtg","0").toString());
		command.setCrcycd(DataObjectUtil.getHashMapStr(data,"crcycd").toString());
		command.setDtitcd(DataObjectUtil.getHashMapStr(data,"dtitcd").toString());
		command.setModutp(DataObjectUtil.getHashMapStr(data,"modutp","*").toString());
		command.setRvpysq(DataObjectUtil.getHashMapStr(data,"cmmdsq").toString());
		//command.setSmrycd(DataObjectUtil.getHashMapStr(data,"smrycd").toString());
		command.setSubsac(DataObjectUtil.getHashMapStr(data,"subsac","*").toString());
		command.setSystid(DataObjectUtil.getHashMapStr(data,"systid").toString());
		command.setTranam(DataObjectUtil.getBigDecimalValue(data,"tranam"));
		command.setTranbr(DataObjectUtil.getHashMapStr(data,"tranbr").toString());
		command.setTrandt(DataObjectUtil.getHashMapStr(data,"trandt").toString());
		command.setTransq(DataObjectUtil.getHashMapStr(data,"transq").toString());
		command.setTrantp(DataObjectUtil.getHashMapStr(data,"trantp").toString());
		command.setProdcd(DataObjectUtil.getHashMapStr(data,"prodcd").toString());
		command.setStacid(DataObjectUtil.getIntegerValue(data,"stacid"));
		logger.debug("��������ȡ�����н���ָ�����װ...���");
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public String check() {
		// TODO Auto-generated method stub
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public GlsExtd execute(int orderCount) {
		// TODO Auto-generated method stub
		//depositCommandMapper.insertEntity(command);
		
		extd = new GlsExtd();
		extd.setStacid(command.getStacid());
		extd.setSystid(command.getSystid());
		extd.setTrandt(command.getTrandt());
		extd.setTranbr(command.getTranbr());
		extd.setTransq(command.getTransq());
		extd.setSortno(orderCount);
		extd.setCmmdtg(Constants.COMMAND_IDENTITY_DP);
		extd.setAmntcd(command.getAmntcd());
		extd.setTrantp(Enumeration.TRANTP.CASH.value);
		extd.setCrcycd(command.getCrcycd());
		extd.setTranam(command.getTranam());
		extd.setCmmdsq(command.getRvpysq());
		if(null != data.get("bsnssq")){
			extd.setBsnssq(data.get("bsnssq").toString());
		}
		
		return extd;
	}

	@Override
	public TranamInfoEntity getTranamInfo() {
		// TODO Auto-generated method stub
		return new TranamInfoEntity(command.getAmntcd(),command.getTranam());
	}

	public DepositCommandMapper getDepositCommandMapper() {
		return depositCommandMapper;
	}

	public void setDepositCommandMapper(DepositCommandMapper depositCommandMapper) {
		this.depositCommandMapper = depositCommandMapper;
	}

	public GlsExtdMapper getGlsExtdMapper() {
		return glsExtdMapper;
	}

	public void setGlsExtdMapper(GlsExtdMapper glsExtdMapper) {
		this.glsExtdMapper = glsExtdMapper;
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return data;
	}

	@Override
	public JSONObject getCmmd() {
		// TODO Auto-generated method stub
		return (JSONObject)JSON.toJSON(command);
	}
	
}
