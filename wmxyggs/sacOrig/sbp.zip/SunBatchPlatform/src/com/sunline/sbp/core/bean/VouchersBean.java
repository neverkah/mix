package com.sunline.sbp.core.bean;

public class VouchersBean {
	private int stacid;
	private String systid;
	private String trandt;
	private String transq;
	private int tranno;
	private String vchrsq;
	private String tranbr;
	private String acctbr;
	private String itemcd;
	private String crcycd;
	private String centcd;
	private String prsncd;
	private String custcd;
	private String prducd;
	private String prlncd;
	private String trantp;
	private String amntcd;
	private double tranam;
	private double tranbl;
	private String blncdn;
	private String smrytx;
	private double exchcn;
	private double exchus;
	private String usercd;
	private String sourdt;
	private String soursq;
	private String sourst;
	private String srvcsq;
	private double bearbl;
	private String beardn;
	private String toitem;
	private String ioflag;
	private String assis0;
	private String assis1;
	private String assis2;
	private String assis3;
	private String assis4;
	private String assis5;
	private String assis6;
	private String assis7;
	private String assis8;
	private String assis9;
	private String acctno;
	private String clertg;
	private String cleror;
	private String centsq;
	private String brchsq;
	private String clerdt;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getVchrsq() {
		return vchrsq;
	}
	public void setVchrsq(String vchrsq) {
		this.vchrsq = vchrsq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getItemcd() {
		return itemcd;
	}
	public void setItemcd(String itemcd) {
		this.itemcd = itemcd;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getCentcd() {
		return centcd;
	}
	public void setCentcd(String centcd) {
		this.centcd = centcd;
	}
	public String getPrsncd() {
		return prsncd;
	}
	public void setPrsncd(String prsncd) {
		this.prsncd = prsncd;
	}
	public String getCustcd() {
		return custcd;
	}
	public void setCustcd(String custcd) {
		this.custcd = custcd;
	}
	public String getPrducd() {
		return prducd;
	}
	public void setPrducd(String prducd) {
		this.prducd = prducd;
	}
	public String getPrlncd() {
		return prlncd;
	}
	public void setPrlncd(String prlncd) {
		this.prlncd = prlncd;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}
	public double getTranam() {
		return tranam;
	}
	public void setTranam(double tranam) {
		this.tranam = tranam;
	}
	public double getTranbl() {
		return tranbl;
	}
	public void setTranbl(double tranbl) {
		this.tranbl = tranbl;
	}
	public String getBlncdn() {
		return blncdn;
	}
	public void setBlncdn(String blncdn) {
		this.blncdn = blncdn;
	}
	public String getSmrytx() {
		return smrytx;
	}
	public void setSmrytx(String smrytx) {
		this.smrytx = smrytx;
	}
	public double getExchcn() {
		return exchcn;
	}
	public void setExchcn(double exchcn) {
		this.exchcn = exchcn;
	}
	public double getExchus() {
		return exchus;
	}
	public void setExchus(double exchus) {
		this.exchus = exchus;
	}
	public String getUsercd() {
		return usercd;
	}
	public void setUsercd(String usercd) {
		this.usercd = usercd;
	}
	public String getSourdt() {
		return sourdt;
	}
	public void setSourdt(String sourdt) {
		this.sourdt = sourdt;
	}
	public String getSoursq() {
		return soursq;
	}
	public void setSoursq(String soursq) {
		this.soursq = soursq;
	}
	public String getSourst() {
		return sourst;
	}
	public void setSourst(String sourst) {
		this.sourst = sourst;
	}
	public String getSrvcsq() {
		return srvcsq;
	}
	public void setSrvcsq(String srvcsq) {
		this.srvcsq = srvcsq;
	}
	public double getBearbl() {
		return bearbl;
	}
	public void setBearbl(double bearbl) {
		this.bearbl = bearbl;
	}
	public String getBeardn() {
		return beardn;
	}
	public void setBeardn(String beardn) {
		this.beardn = beardn;
	}
	public String getToitem() {
		return toitem;
	}
	public void setToitem(String toitem) {
		this.toitem = toitem;
	}
	public String getIoflag(){
		return ioflag;
	}
	public void setIoflag(String ioflag){
		this.ioflag = ioflag;
	}
	public String getAssis0() {
		return assis0;
	}
	public void setAssis0(String assis0) {
		this.assis0 = assis0;
	}
	public String getAssis1() {
		return assis1;
	}
	public void setAssis1(String assis1) {
		this.assis1 = assis1;
	}
	public String getAssis2() {
		return assis2;
	}
	public void setAssis2(String assis2) {
		this.assis2 = assis2;
	}
	public String getAssis3() {
		return assis3;
	}
	public void setAssis3(String assis3) {
		this.assis3 = assis3;
	}
	public String getAssis4() {
		return assis4;
	}
	public void setAssis4(String assis4) {
		this.assis4 = assis4;
	}
	public String getAssis5() {
		return assis5;
	}
	public void setAssis5(String assis5) {
		this.assis5 = assis5;
	}
	public String getAssis6() {
		return assis6;
	}
	public void setAssis6(String assis6) {
		this.assis6 = assis6;
	}
	public String getAssis7() {
		return assis7;
	}
	public void setAssis7(String assis7) {
		this.assis7 = assis7;
	}
	public String getAssis8() {
		return assis8;
	}
	public void setAssis8(String assis8) {
		this.assis8 = assis8;
	}
	public String getAssis9() {
		return assis9;
	}
	public void setAssis9(String assis9) {
		this.assis9 = assis9;
	}
	public String getAcctno() {
		return acctno;
	}
	/**
	 * �˺�
	 * @param acctno
	 */
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public int getTranno() {
		return tranno;
	}
	public void setTranno(int tranno) {
		this.tranno = tranno;
	}
	public String getClertg() {
		return clertg;
	}
	public void setClertg(String clertg) {
		this.clertg = clertg;
	}
	public String getCleror() {
		return cleror;
	}
	public void setCleror(String cleror) {
		this.cleror = cleror;
	}
	public String getCentsq() {
		return centsq;
	}
	public void setCentsq(String centsq) {
		this.centsq = centsq;
	}
	public String getBrchsq() {
		return brchsq;
	}
	public void setBrchsq(String brchsq) {
		this.brchsq = brchsq;
	}
	public String getClerdt() {
		return clerdt;
	}
	public void setClerdt(String clerdt) {
		this.clerdt = clerdt;
	}
}
