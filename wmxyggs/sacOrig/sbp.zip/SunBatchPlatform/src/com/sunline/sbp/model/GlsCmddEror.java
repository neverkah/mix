package com.sunline.sbp.model;

public class GlsCmddEror {
	private String trandt;
	private String transq;
	private String erortx;
	
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getErortx() {
		return erortx;
	}
	public void setErortx(String erortx) {
		this.erortx = erortx;
	}
	
	
}
