package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * 
 * @���� JavaBeanʵ��
 * @���� ��gla_acct
 * @author liuchj@sunline.cn
 * @project ����ϵͳ�������
 * @data 2014��4��28��
 */
public class GlaAcct {
	private int stacid;
	private String acctcd;
	private String acctna;
	private String systid;
	private String brchno;
	private String crcycd;
	private String itemcd;
	private String acctcl;
	private String subscd;
	private String openbr;
	private String opendt;
	private String optrsq;
	private String lstrdt;
	private String lstrsq;
	private String closdt;
	private String cltrsq;
	private String ioflag;
	private String blncdn;
	private BigDecimal onlnbl;
	private String lastdn;
	private BigDecimal lastbl;
	private String lastdt;
	private BigDecimal acmlbl;
	private String acmldt;
	private String acctst;
	private String drhdbk;
	private String crhdbk;
	private String openus;
	private String closus;
	private String pmodtg;
	
	private String acctno ; //��ά�˻�
	private String centcd ; //��������
	private String prsncd ; //ְԱ
	private String custcd ; //��������
	private String prducd ; //��Ʒ
	private String prlncd ; //ҵ������
	private String assis0 ; //��������
	private String assis1 ; //��������
	private String assis2 ; //��������
	private String assis3 ; //��������
	private String assis4 ; //��������
	private String assis5 ; //��������
	private String assis6 ; //��������
	private String assis7 ; //��������
	private String assis8 ; //��������
	private String assis9 ; //��������
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getAcctcd() {
		return acctcd;
	}
	public void setAcctcd(String acctcd) {
		this.acctcd = acctcd;
	}
	
	public String getAcctna() {
		return acctna;
	}
	public void setAcctna(String acctna) {
		this.acctna = acctna;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getBrchno() {
		return brchno;
	}
	public void setBrchno(String brchno) {
		this.brchno = brchno;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getItemcd() {
		return itemcd;
	}
	public void setItemcd(String itemcd) {
		this.itemcd = itemcd;
	}
	public String getAcctcl() {
		return acctcl;
	}
	public void setAcctcl(String acctcl) {
		this.acctcl = acctcl;
	}
	public String getSubscd() {
		return subscd;
	}
	public void setSubscd(String subscd) {
		this.subscd = subscd;
	}
	public String getOpenbr() {
		return openbr;
	}
	public void setOpenbr(String openbr) {
		this.openbr = openbr;
	}
	public String getOpendt() {
		return opendt;
	}
	public void setOpendt(String opendt) {
		this.opendt = opendt;
	}
	public String getOptrsq() {
		return optrsq;
	}
	public void setOptrsq(String optrsq) {
		this.optrsq = optrsq;
	}
	public String getLstrdt() {
		return lstrdt;
	}
	public void setLstrdt(String lstrdt) {
		this.lstrdt = lstrdt;
	}
	public String getLstrsq() {
		return lstrsq;
	}
	public void setLstrsq(String lstrsq) {
		this.lstrsq = lstrsq;
	}
	public String getClosdt() {
		return closdt;
	}
	public void setClosdt(String closdt) {
		this.closdt = closdt;
	}
	public String getCltrsq() {
		return cltrsq;
	}
	public void setCltrsq(String cltrsq) {
		this.cltrsq = cltrsq;
	}
	public String getIoflag() {
		return ioflag;
	}
	public void setIoflag(String ioflag) {
		this.ioflag = ioflag;
	}
	public String getBlncdn() {
		return blncdn;
	}
	public void setBlncdn(String blncdn) {
		this.blncdn = blncdn;
	}
	public BigDecimal getOnlnbl() {
		return onlnbl;
	}
	public void setOnlnbl(BigDecimal onlnbl) {
		this.onlnbl = onlnbl;
	}
	public String getLastdn() {
		return lastdn;
	}
	public void setLastdn(String lastdn) {
		this.lastdn = lastdn;
	}
	public BigDecimal getLastbl() {
		return lastbl;
	}
	public void setLastbl(BigDecimal lastbl) {
		this.lastbl = lastbl;
	}
	public String getLastdt() {
		return lastdt;
	}
	public void setLastdt(String lastdt) {
		this.lastdt = lastdt;
	}
	public BigDecimal getAcmlbl() {
		return acmlbl;
	}
	public void setAcmlbl(BigDecimal acmlbl) {
		this.acmlbl = acmlbl;
	}
	public String getAcmldt() {
		return acmldt;
	}
	public void setAcmldt(String acmldt) {
		this.acmldt = acmldt;
	}
	public String getAcctst() {
		return acctst;
	}
	public void setAcctst(String acctst) {
		this.acctst = acctst;
	}
	public String getDrhdbk() {
		return drhdbk;
	}
	public void setDrhdbk(String drhdbk) {
		this.drhdbk = drhdbk;
	}
	public String getCrhdbk() {
		return crhdbk;
	}
	public void setCrhdbk(String crhdbk) {
		this.crhdbk = crhdbk;
	}
	public String getOpenus() {
		return openus;
	}
	public void setOpenus(String openus) {
		this.openus = openus;
	}
	public String getClosus() {
		return closus;
	}
	public void setClosus(String closus) {
		this.closus = closus;
	}
	public String getPmodtg() {
		return pmodtg;
	}
	public void setPmodtg(String pmodtg) {
		this.pmodtg = pmodtg;
	}
	
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getCentcd() {
		return centcd;
	}
	public void setCentcd(String centcd) {
		this.centcd = centcd;
	}
	public String getPrsncd() {
		return prsncd;
	}
	public void setPrsncd(String prsncd) {
		this.prsncd = prsncd;
	}
	public String getCustcd() {
		return custcd;
	}
	public void setCustcd(String custcd) {
		this.custcd = custcd;
	}
	public String getPrducd() {
		return prducd;
	}
	public void setPrducd(String prducd) {
		this.prducd = prducd;
	}
	public String getPrlncd() {
		return prlncd;
	}
	public void setPrlncd(String prlncd) {
		this.prlncd = prlncd;
	}
	public String getAssis0() {
		return assis0;
	}
	public void setAssis0(String assis0) {
		this.assis0 = assis0;
	}
	public String getAssis1() {
		return assis1;
	}
	public void setAssis1(String assis1) {
		this.assis1 = assis1;
	}
	public String getAssis2() {
		return assis2;
	}
	public void setAssis2(String assis2) {
		this.assis2 = assis2;
	}
	public String getAssis3() {
		return assis3;
	}
	public void setAssis3(String assis3) {
		this.assis3 = assis3;
	}
	public String getAssis4() {
		return assis4;
	}
	public void setAssis4(String assis4) {
		this.assis4 = assis4;
	}
	public String getAssis5() {
		return assis5;
	}
	public void setAssis5(String assis5) {
		this.assis5 = assis5;
	}
	public String getAssis6() {
		return assis6;
	}
	public void setAssis6(String assis6) {
		this.assis6 = assis6;
	}
	public String getAssis7() {
		return assis7;
	}
	public void setAssis7(String assis7) {
		this.assis7 = assis7;
	}
	public String getAssis8() {
		return assis8;
	}
	public void setAssis8(String assis8) {
		this.assis8 = assis8;
	}
	public String getAssis9() {
		return assis9;
	}
	public void setAssis9(String assis9) {
		this.assis9 = assis9;
	}
}
