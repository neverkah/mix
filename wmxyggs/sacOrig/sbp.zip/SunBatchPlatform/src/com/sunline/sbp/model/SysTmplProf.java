package com.sunline.sbp.model;

/**
 * ģ�����ͱ�(sys_tmtp)
 * @author Zhangjin
 *
 */

public class SysTmplProf {
	String tmpltp;
	String proftp;
	String vermod;
	String module;
	String projcd;
	public String getTmpltp() {
		return tmpltp;
	}
	public void setTmpltp(String tmpltp) {
		this.tmpltp = tmpltp;
	}
	public String getProftp() {
		return proftp;
	}
	public void setProftp(String proftp) {
		this.proftp = proftp;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
}
