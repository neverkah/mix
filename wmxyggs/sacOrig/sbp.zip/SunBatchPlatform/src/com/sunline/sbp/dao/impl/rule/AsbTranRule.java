package com.sunline.sbp.dao.impl.rule;

import java.math.BigDecimal;
import java.util.HashMap;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.DataObjectUtil;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.TranamInfoEntity;
import com.sunline.sbp.base.RuleBeanObject;
import com.sunline.sbp.dao.impl.SystemInterfaceDaoImpl;
import com.sunline.sbp.dao.mapper.AsbTranMapper;
import com.sunline.sbp.dao.mapper.GlsExtdMapper;
import com.sunline.sbp.model.AsbTran;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;
import com.sunline.sbp.model.SysIomp;

/***
 * ����Ϣ�ʲ���������ϸ
 * @author Zhangjin
 *
 */

public class AsbTranRule implements RuleBeanObject {
	private AsbTran command;
	private GlsExtd extd;
	private AsbTranMapper asbTranMapper;
	private GlsExtdMapper glsExtdMapper;
	private SystemInterfaceDaoImpl sysIntfDaoImpl;
	
	private HashMap<String , Object> data;
	private SysIomp[] iopms;
	private SysIntf sysIntf;
	private SysIntfDetl[] intfDetl;
	
	@Override
	public void setMapOfInIntf(final SysIntf sysIntf , final SysIomp[] iopms ,final SysIntfDetl[] detls) {
		// TODO Auto-generated method stub
		this.iopms = iopms;
		this.sysIntf = sysIntf;
		this.intfDetl = detls;
	}
	
	@Override
	public String initialize(HashMap<String , Object> data) throws AnalyseException{
		command = new AsbTran();
		command.setStacid(Integer.parseInt(DataObjectUtil.getHashMapStr(data,"stacid").toString()));
		command.setAmntcd(DataObjectUtil.getHashMapStr(data,"amntcd").toString());
		command.setDtitcd(DataObjectUtil.getHashMapStr(data,"dtitcd").toString());
		command.setTranam(BigDecimal.valueOf(Double.parseDouble(DataObjectUtil.getHashMapStr(data,"tranam").toString())));
		command.setSystid(DataObjectUtil.getHashMapStr(data,"systid").toString());
		command.setTranbr(DataObjectUtil.getHashMapStr(data,"tranbr").toString());
		command.setTrandt(DataObjectUtil.getHashMapStr(data,"trandt").toString());
		command.setTransq(DataObjectUtil.getHashMapStr(data,"transq").toString());
		command.setTrantp(DataObjectUtil.getHashMapStr(data,"trantp").toString());
		command.setAsetno(DataObjectUtil.getHashMapStr(data,"asetno").toString());
		command.setLnbltp(DataObjectUtil.getHashMapStr(data,"lnbltp").toString());
		command.setCrcycd(DataObjectUtil.getHashMapStr(data,"crcycd").toString());
		command.setSmrytx(DataObjectUtil.getHashMapStr(data,"smrytx").toString());
		return "EX0000";
	}
	
	public String check() throws EngineRuntimeException{
		sysIntfDaoImpl.checkValidate(sysIntf,data);
		return Constants.EXECUTE_SUCC;
	}
	
	@Override
	public GlsExtd execute(int orderCount){
		//asbTranMapper.insertObject(command);
		//����ָ��Ǽ�
		extd = new GlsExtd();
		extd.setStacid(command.getStacid());
		extd.setSystid(command.getSystid());
		extd.setTrandt(command.getTrandt());
		extd.setTranbr(command.getTranbr());
		extd.setTransq(command.getTransq());
		extd.setSortno(orderCount);
		extd.setCmmdtg(Constants.COMMAND_IDENTITY_AS);
		extd.setAmntcd(command.getAmntcd());
		extd.setCrcycd(command.getCrcycd());
		extd.setTranam(command.getTranam());
		return extd;
	}
	
	@Override
	public TranamInfoEntity getTranamInfo(){
		return new TranamInfoEntity(command.getAmntcd(),command.getTranam());
	}

	public AsbTranMapper getAsbTranMapper() {
		return asbTranMapper;
	}

	public void setAsbTranMapper(AsbTranMapper asbTranMapper) {
		this.asbTranMapper = asbTranMapper;
	}

	public GlsExtdMapper getGlsExtdMapper() {
		return glsExtdMapper;
	}

	public void setGlsExtdMapper(GlsExtdMapper glsExtdMapper) {
		this.glsExtdMapper = glsExtdMapper;
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return data;
	}

	@Override
	public JSONObject getCmmd() {
		// TODO Auto-generated method stub
		return (JSONObject)JSON.toJSON(command);
	}
	
}
