package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * Ͷ�ʽ�����ϸ��gls_ivt_tran��
 * @author Zhangjin
 *
 */

public class InvestmentTran {
	private int stacid;
	private String systid;
	private String trandt;
	private String transq;
	private String ivetsq;
	private String tranbr;
	private String acctbr;
	private String amntcd;
	private String crcycd;
	private BigDecimal tranam;
	private String lnbltp;
	private String dtitcd;
	private String smrytx;
	private String bkfnst;
		
	private String  centcd ;
	private String  prsncd ;
	private String  custcd ;
	private String  prlncd ;
	private String  acctno ;
	private String  assis0 ;
	private String  assis1 ;
	private String  assis2 ;
	private String  assis3 ;
	private String  assis4 ;
	private String  assis5 ;
	private String  assis6 ;
	private String  assis7 ;
	private String  assis8 ;
	private String  assis9 ;
	private String  prodcd;
	
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public String getCentcd() {
		return centcd;
	}
	public void setCentcd(String centcd) {
		this.centcd = centcd;
	}
	public String getPrsncd() {
		return prsncd;
	}
	public void setPrsncd(String prsncd) {
		this.prsncd = prsncd;
	}
	public String getCustcd() {
		return custcd;
	}
	public void setCustcd(String custcd) {
		this.custcd = custcd;
	}
	public String getPrlncd() {
		return prlncd;
	}
	public void setPrlncd(String prlncd) {
		this.prlncd = prlncd;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getAssis0() {
		return assis0;
	}
	public void setAssis0(String assis0) {
		this.assis0 = assis0;
	}
	public String getAssis1() {
		return assis1;
	}
	public void setAssis1(String assis1) {
		this.assis1 = assis1;
	}
	public String getAssis2() {
		return assis2;
	}
	public void setAssis2(String assis2) {
		this.assis2 = assis2;
	}
	public String getAssis3() {
		return assis3;
	}
	public void setAssis3(String assis3) {
		this.assis3 = assis3;
	}
	public String getAssis4() {
		return assis4;
	}
	public void setAssis4(String assis4) {
		this.assis4 = assis4;
	}
	public String getAssis5() {
		return assis5;
	}
	public void setAssis5(String assis5) {
		this.assis5 = assis5;
	}
	public String getAssis6() {
		return assis6;
	}
	public void setAssis6(String assis6) {
		this.assis6 = assis6;
	}
	public String getAssis7() {
		return assis7;
	}
	public void setAssis7(String assis7) {
		this.assis7 = assis7;
	}
	public String getAssis8() {
		return assis8;
	}
	public void setAssis8(String assis8) {
		this.assis8 = assis8;
	}
	public String getAssis9() {
		return assis9;
	}
	public void setAssis9(String assis9) {
		this.assis9 = assis9;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getIvetsq() {
		return ivetsq;
	}
	public void setIvetsq(String ivetsq) {
		this.ivetsq = ivetsq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public String getLnbltp() {
		return lnbltp;
	}
	public void setLnbltp(String lnbltp) {
		this.lnbltp = lnbltp;
	}
	public String getDtitcd() {
		return dtitcd;
	}
	public void setDtitcd(String dtitcd) {
		this.dtitcd = dtitcd;
	}
	public String getBkfnst() {
		return bkfnst;
	}
	public void setBkfnst(String bkfnst) {
		this.bkfnst = bkfnst;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getSmrytx() {
		return smrytx;
	}
	public void setSmrytx(String smrytx) {
		this.smrytx = smrytx;
	}
}
