package com.sunline.sbp.dao;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.SysBean;

public interface SysBeanDao {
	public SysBean getEntityByPK(SysBean sysBean) throws EngineRuntimeException;
}
