package com.sunline.sbp.dao;

import java.util.List;

import com.sunline.sbp.model.ComExsr;

public interface ComExsrDao {
	public List<ComExsr> getAllEntities();
}
