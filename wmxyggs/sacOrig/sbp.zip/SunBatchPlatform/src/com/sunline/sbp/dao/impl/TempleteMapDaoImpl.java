package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.dao.TempleteMapDao;
import com.sunline.sbp.dao.mapper.TemplateMapMapper;
import com.sunline.sbp.model.TempleteMap;

public class TempleteMapDaoImpl implements TempleteMapDao {
	
	private TemplateMapMapper templateMapMapper;
	private Logger logger = Logger.getLogger("��ȡģ����������...");

	@Override
	public TempleteMap[] getTempleteMaps(TempleteMap templeteMap) throws EngineRuntimeException{
		// TODO Auto-generated method stub
		TempleteMap[] tmaps = templateMapMapper.getTempleteMaps(templeteMap);
		if(null == tmaps || tmaps.length == 0){
			String message = "ģ�壨tmpltp=" + templeteMap.getTmpltp() + ",tmplid=" + templeteMap.getTmplid() + "��û�����ù��������˵�[ҵ��ģ�����]��������";
			logger.error(message);
			throw new AnalyseException(message);
		}else{
			logger.info("�����ɹ�");
		}
		return tmaps;
	}

	public TemplateMapMapper getTemplateMapMapper() {
		return templateMapMapper;
	}

	public void setTemplateMapMapper(TemplateMapMapper templateMapMapper) {
		this.templateMapMapper = templateMapMapper;
	}
	
}
