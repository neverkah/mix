package com.sunline.sbp.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.SysAyncNode;

public interface SysAyncNodeMapper {
	public List<SysAyncNode> getNodes(@Param("aynccd") String aynccd, @Param("stacid") int stacid, @Param("nodeid") String nodeid);
	public List<SysAyncNode> getZombieNodes(@Param("aynccd") String aynccd, @Param("stacid") int stacid, @Param("nodeid") String nodeid, @Param("regiti") String regiti);
	public SysAyncNode getNodeByKey(@Param("aynccd") String aynccd, @Param("stacid") int stacid, @Param("trandt") String trandt, @Param("sourst") String sourst, @Param("brchcd") String brchcd, @Param("pitncd") String pitncd);
	public int addNode(@Param("aynccd") String aynccd, @Param("stacid") int stacid, @Param("nodeid") String nodeid, @Param("trandt") String trandt, @Param("sourst") String sourst, @Param("brchcd") String brchcd, @Param("pitncd") String pitncd, @Param("regiti") String regiti);
	public int deleteNode(@Param("aynccd") String aynccd, @Param("stacid") int stacid, @Param("nodeid") String nodeid, @Param("trandt") String trandt, @Param("sourst") String sourst, @Param("brchcd") String brchcd, @Param("pitncd") String pitncd);
	public int initNodes(@Param("aynccd") String aynccd, @Param("stacid") int stacid, @Param("nodeid") String nodeid);
	public int deleteZombieNodes(@Param("aynccd") String aynccd, @Param("stacid") int stacid, @Param("nodeid") String nodeid, @Param("regiti") String regiti);
}
