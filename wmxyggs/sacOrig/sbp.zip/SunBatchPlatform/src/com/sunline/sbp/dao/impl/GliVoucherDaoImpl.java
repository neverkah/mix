package com.sunline.sbp.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.sunline.foundation.Constants;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.dao.GliVoucherDao;
import com.sunline.sbp.dao.mapper.GliVoucherMapper;
import com.sunline.sbp.model.GliVoucher;

public class GliVoucherDaoImpl implements GliVoucherDao {
	
private Logger logger = Logger.getLogger(GliVoucherDaoImpl.class);
	
	private GliVoucherMapper gliVoucherMapper;
	private final int BATCH_COUNT = 1000;

	@Override
	public String insertEntity(List<GliVoucher> entity)
			throws EngineRuntimeException {
		// TODO Auto-generated method stub
		try{
			
			//SQL���ִ��ʱ����Ϊ1000����������1000��ʱ���������ύ
			if(BATCH_COUNT >= entity.size()){
				gliVoucherMapper.insertEntitiesBatch(entity);
			}else{
				int fromIndex = 0;
				for(int toIndex = BATCH_COUNT ; toIndex < entity.size() ;){
					gliVoucherMapper.insertEntitiesBatch(entity.subList(fromIndex, toIndex));
					fromIndex = toIndex;
					toIndex = toIndex + BATCH_COUNT;
				}
				gliVoucherMapper.insertEntitiesBatch(entity.subList(fromIndex, entity.size()));
			}
		}catch(Exception ex){
			logger.error("����ʵʱ��Ʊ��Ϣʧ�ܡ�" + ex);
			throw new EngineRuntimeException("����ʵʱ��Ʊ��¼ʧ�ܣ�",ex);
		}
		logger.debug("���洫Ʊ��Ϣ�ɹ���");
		return Constants.EXECUTE_SUCC;
	}

	public GliVoucherMapper getGliVoucherMapper() {
		return gliVoucherMapper;
	}

	public void setGliVoucherMapper(GliVoucherMapper gliVoucherMapper) {
		this.gliVoucherMapper = gliVoucherMapper;
	}

}
