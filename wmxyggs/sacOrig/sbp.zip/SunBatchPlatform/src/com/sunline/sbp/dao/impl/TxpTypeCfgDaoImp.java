package com.sunline.sbp.dao.impl;

import java.util.Hashtable;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.core.bean.CacheTargetBean;
import com.sunline.sbp.dao.TxpTypeCfgDao;
import  com.sunline.sbp.dao.mapper.TxpTypeCfgMapper;
import com.sunline.sbp.model.TxpTypeCfg;
import com.sunline.sbp.model.TxpTypeOpen;

public class TxpTypeCfgDaoImp implements TxpTypeCfgDao {
	
	private TxpTypeCfgMapper TxpTypeCfgMapper;
	private Logger logger = Logger.getLogger(TxpTypeCfgDaoImp.class);
	
	private final String nullTxpTypeCfgTag = "nullnull";

	
	/**
	 * ȫ��Ŀ��Ϣ����
	 */
	private static Hashtable<String,TxpTypeCfg> txtpMapDatas = new Hashtable<String,TxpTypeCfg>();

	public TxpTypeCfgMapper getTxpTypeCfgMapper() {
		return TxpTypeCfgMapper;
	}

	public void setTxpTypeCfgMapper(TxpTypeCfgMapper TxpTypeCfgMapper) {
		this.TxpTypeCfgMapper = TxpTypeCfgMapper;
	}
	
	public TxpTypeOpen[] getTxpTypeOpen(int stacid) throws AnalyseException{
		
		logger.debug("��ȡ��˰��������������Ϣ��������Ϣ��"+String.valueOf(stacid));
		
		TxpTypeOpen[] txptypeopens = TxpTypeCfgMapper.selectTxpTypeOpen(stacid);
		if(null == txptypeopens){
			logger.error("��ȡ��˰��������������Ϣʧ�ܣ�");
			throw new AnalyseException("��ȡ��˰��������������Ϣʧ�ܣ�");
		}
		
		return txptypeopens;
	}
	
	@Override
	public TxpTypeCfg getEntityByPrimaryKey(int stacid,String prodcd,String prodp1,String prodp2,String prodp3,String prodp4,
			String prodp5,String prodp6,String prodp7,String prodp8,String prodp9,String prodpa) throws AnalyseException {
		
		String key = String.valueOf(stacid).concat(Constants.MIDTQG).concat(prodcd)
				  .concat(Constants.MIDTQG).concat(prodp1)
				  .concat(Constants.MIDTQG).concat(prodp2)
				  .concat(Constants.MIDTQG).concat(prodp3)
				  .concat(Constants.MIDTQG).concat(prodp4)
				  .concat(Constants.MIDTQG).concat(prodp5)
				  .concat(Constants.MIDTQG).concat(prodp6)
				  .concat(Constants.MIDTQG).concat(prodp7)
				  .concat(Constants.MIDTQG).concat(prodp8)
				  .concat(Constants.MIDTQG).concat(prodp9)
				  .concat(Constants.MIDTQG).concat(prodpa);
		
		logger.debug("��ȡ��˰���������Ϣ��������Ϣ"+key);
		
		TxpTypeCfg txtpMapInfo = txtpMapDatas.get(key);
		int isFresh = CacheTargetBean.getCacheTarget("txtpMapCache");
		if(isFresh == 1){
			synchronized(this){
				if(CacheTargetBean.getCacheTarget("txtpMapCache") == 1){
					txtpMapDatas.clear();
					CacheTargetBean.updateCacheTarget("txtpMapCache");
				}
			}
		}
		if(null == txtpMapInfo){
			TxpTypeCfg txtpMapEntity = TxpTypeCfgMapper.selectEntity(stacid, prodcd, prodp1, prodp2, prodp3, prodp4, prodp5, prodp6, prodp7, prodp8, prodp9, prodpa);
			if(null == txtpMapEntity){
				txtpMapEntity = new TxpTypeCfg();
				txtpMapEntity.setTypecd(nullTxpTypeCfgTag);
				txtpMapDatas.put(key, txtpMapEntity);
			}else{
				txtpMapInfo = txtpMapEntity;
				txtpMapDatas.put(key, txtpMapEntity);
			}
		}
		
		
		return txtpMapInfo;
	}
	
	/**
	 * ��ʼ��
	 * @param stacid
	 * @throws AnalyseException
	 */
	private void initCacheData(int stacid) throws AnalyseException{
		
		if(null == txtpMapDatas){
			txtpMapDatas = new Hashtable<String,TxpTypeCfg>();
			TxpTypeCfg[] tableDatas = getEntitiesOfTable(stacid);
				logger.debug("��ȡ���׵ļ�˰�����������" + tableDatas.length);
				for(TxpTypeCfg tableData : tableDatas){
					txtpMapDatas.put(String.valueOf(stacid).concat(Constants.MIDTQG).concat(tableData.getProdcd())
														   .concat(Constants.MIDTQG).concat(tableData.getProdp1())
														   .concat(Constants.MIDTQG).concat(tableData.getProdp2())
														   .concat(Constants.MIDTQG).concat(tableData.getProdp3())
														   .concat(Constants.MIDTQG).concat(tableData.getProdp4())
														   .concat(Constants.MIDTQG).concat(tableData.getProdp5())
														   .concat(Constants.MIDTQG).concat(tableData.getProdp6())
														   .concat(Constants.MIDTQG).concat(tableData.getProdp7())
														   .concat(Constants.MIDTQG).concat(tableData.getProdp8())
														   .concat(Constants.MIDTQG).concat(tableData.getProdp9())
														   .concat(Constants.MIDTQG).concat(tableData.getProdpa()), tableData);
				}
		}
		
	}

	@Override
	public TxpTypeCfg[] getEntitiesOfTable(int stacid)
			throws AnalyseException {
		// TODO Auto-generated method stub
		TxpTypeCfg[] tableData = TxpTypeCfgMapper.selectFullEntities(stacid);
		return tableData;
	}

}

