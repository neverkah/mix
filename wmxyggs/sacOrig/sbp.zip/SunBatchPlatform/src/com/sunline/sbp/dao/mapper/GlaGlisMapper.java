package com.sunline.sbp.dao.mapper;

import java.util.HashMap;

import com.sunline.sbp.model.GlaGlis;
import com.sunline.sbp.model.GlaVoucher;

public interface GlaGlisMapper {
	public GlaGlis getEntityLock(GlaVoucher entity);
	public void updateEntity(GlaGlis entity);
	public void insertEntity(GlaGlis entity);
	public void insertErorTax(HashMap<String,String> map);
}
