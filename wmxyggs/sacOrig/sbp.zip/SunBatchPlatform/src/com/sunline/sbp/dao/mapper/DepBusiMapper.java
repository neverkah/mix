package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.DepBusi;

public interface DepBusiMapper {
	public DepBusi[] selectEntities(DepBusi entity);
}
