package com.sunline.sbp.action;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.dao.AsbBusiDao;
import com.sunline.sbp.model.AsbBusi;


public class DataTest {
	
	private Logger logger = Logger.getLogger(DataTest.class);
	
	public static void main(String[] args){
		DataTest df = new DataTest();
		df.gete();
	}
	
	public void gete(){
		/*DepBusi entity = new DepBusi();
		entity.setTrandt("20121212");
		entity.setTransq("%");
		
		DepBusiDao depd = (DepBusiDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(DepBusiDao.class);
		
		DepBusi[] busis = depd.getEntities(entity);

		for (DepBusi busi : busis) {
			
			JSONObject obj = JSONObject.fromObject(busi);
			
			logger.debug(obj);
		}*/
		
		AsbBusi entity = new AsbBusi();
		entity.setTrandt("20121221");
		entity.setTransq("%");
		
		AsbBusiDao depd = (AsbBusiDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AsbBusiDao.class);
		
		AsbBusi[] busis = depd.selectBusi(entity);

		for (AsbBusi busi : busis) {
			
			String obj = JSON.toJSONString(busi);
			//String me = new String(obj);
			logger.debug(obj);
		}
		
	}
	
}
