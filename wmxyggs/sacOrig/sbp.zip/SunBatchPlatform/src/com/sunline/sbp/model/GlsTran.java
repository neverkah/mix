package com.sunline.sbp.model;

public class GlsTran {
	private String trandt;
	private String transq;
	private String tranti;
	private String trantp;
	private String prcscd;
	private String servtp;
	private String tranbr;
	private String pckgsq;
	private String csbxno;
	private String menuid;
	private String tmnlid;
	private String transt;
	private String crcycd;
	private String systid;
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranti() {
		return tranti;
	}
	public void setTranti(String tranti) {
		this.tranti = tranti;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public String getServtp() {
		return servtp;
	}
	public void setServtp(String servtp) {
		this.servtp = servtp;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getPckgsq() {
		return pckgsq;
	}
	public void setPckgsq(String pckgsq) {
		this.pckgsq = pckgsq;
	}
	public String getCsbxno() {
		return csbxno;
	}
	public void setCsbxno(String csbxno) {
		this.csbxno = csbxno;
	}
	public String getMenuid() {
		return menuid;
	}
	public void setMenuid(String menuid) {
		this.menuid = menuid;
	}
	public String getTmnlid() {
		return tmnlid;
	}
	public void setTmnlid(String tmnlid) {
		this.tmnlid = tmnlid;
	}
	public String getTranst() {
		return transt;
	}
	public void setTranst(String transt) {
		this.transt = transt;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	
}
