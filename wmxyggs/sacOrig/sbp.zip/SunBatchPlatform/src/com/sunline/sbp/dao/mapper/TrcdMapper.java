package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.SysTrcd;

public interface TrcdMapper {
	public SysTrcd getTrcd(SysTrcd trancd);
}
