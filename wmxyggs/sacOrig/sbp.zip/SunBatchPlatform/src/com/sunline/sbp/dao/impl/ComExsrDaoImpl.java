package com.sunline.sbp.dao.impl;

import java.util.Hashtable;
import java.util.List;

import com.sunline.foundation.Constants;
import com.sunline.sbp.dao.ComExsrDao;
import com.sunline.sbp.dao.mapper.ComExsrMapper;
import com.sunline.sbp.model.ComExsr;

public class ComExsrDaoImpl implements ComExsrDao {
	
	private ComExsrMapper comExsrMapper;
	private int initail = 0;
	
	/**
	 * ȫ��Ϣ����
	 */
	private static Hashtable<String,ComExsr> exsrDatas = new Hashtable<String,ComExsr>();

	@Override
	public List<ComExsr> getAllEntities() {
		// TODO Auto-generated method stub
		List<ComExsr> tableData = comExsrMapper.getAllEntities();
		for(ComExsr entity : tableData){
			exsrDatas.put(entity.getStacid()+Constants.DTAG+entity.getAcexcd()+Constants.DTAG+entity.getSourcd(), entity);
		}
		return tableData;
	}
	
	public Hashtable<String,ComExsr> getCacheData(){
		if(initail == 0){
			synchronized(this) {
				if(initail == 0){
					getAllEntities();
					initail = 1;
				}
			}
		}
		return exsrDatas;
	}
	
	public boolean frushCache(){
		exsrDatas.clear();
		getAllEntities();
		return true;
	}

	public ComExsrMapper getComExsrMapper() {
		return comExsrMapper;
	}

	public void setComExsrMapper(ComExsrMapper comExsrMapper) {
		this.comExsrMapper = comExsrMapper;
	}
	
}
