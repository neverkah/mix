package com.sunline.sbp.dao;

import java.util.Map;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.model.ComItex;

public interface ComItexDao {
	public Map<String,ComItex> getAllItex() throws AnalyseException;
}
