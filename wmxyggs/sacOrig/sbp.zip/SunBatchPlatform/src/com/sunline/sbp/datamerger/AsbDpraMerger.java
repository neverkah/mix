package com.sunline.sbp.datamerger;

import com.sunline.sbp.model.AsbDpra;

public class AsbDpraMerger implements BusinessObject {
	
	private AsbDpra busi;
	private String prcscd;
	private String typecd;
	
	public String getProdcd(){
		return typecd;
	}
	
	public AsbDpraMerger(AsbDpra param){
		this.busi = param;
		this.prcscd = param.getPrcscd();
		this.typecd = param.getDtitcd();
	}
	
	@Override
	public String getPrcscd() {
		// TODO Auto-generated method stub
		return prcscd;
	}

	@Override
	public String getBusiType() {
		// TODO Auto-generated method stub
		return typecd;
	}

	@Override
	public Object getBusinessObject() {
		// TODO Auto-generated method stub
		return busi;
	}

	@Override
	public String getBsnsdt() {
		// TODO Auto-generated method stub
		return busi.getTrandt();
	}

	@Override
	public String getBsnssq() {
		// TODO Auto-generated method stub
		return busi.getTransq();
	}

	@Override
	public String getSystid() {
		// TODO Auto-generated method stub
		return busi.getSystid();
	}

	@Override
	public int getStacid() {
		// TODO Auto-generated method stub
		return busi.getStacid();
	}

	@Override
	public void setStacid(int stacid) {
		// TODO Auto-generated method stub
		this.busi.setStacid(stacid);
	}

}
