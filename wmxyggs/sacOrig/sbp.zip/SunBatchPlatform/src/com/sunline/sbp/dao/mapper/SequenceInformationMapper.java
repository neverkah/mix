package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.SequenceInformation;

public interface SequenceInformationMapper {
	
	public SequenceInformation selectEntity(SequenceInformation entity);
	
	public SequenceInformation selectEntityByLock(SequenceInformation entity);
	
	public int insertEntity(SequenceInformation entity);
	
	public int updateEntity(SequenceInformation entity);

	public void increaseMaxisq(@Param(value = "sqnocd") String sqnocd,
			@Param(value = "brchcd") String brchcd,
			@Param(value = "sqnodt") String sqnodt,
			@Param(value = "sqnonm") int sqnonm);
}
