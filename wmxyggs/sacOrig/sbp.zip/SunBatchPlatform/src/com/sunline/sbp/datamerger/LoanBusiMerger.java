package com.sunline.sbp.datamerger;

import com.sunline.sbp.model.LoanBusi;

public class LoanBusiMerger implements BusinessObject {
	
	private LoanBusi busi;
	private String prcscd;
	private String typecd;
	private String prodcd;
	private int stacid;

	@Override
	public String getPrcscd() {
		// TODO Auto-generated method stub
		return prcscd;
	}
	
	public LoanBusiMerger(LoanBusi param){
		this.busi = param;
		this.prcscd = busi.getPrcscd();
		this.typecd = param.getProdcd();
		this.stacid = busi.getStacid();
		this.prodcd = busi.getProdcd();
	}

	@Override
	public String getBusiType() {
		// TODO Auto-generated method stub
		return typecd;
	}

	@Override
	public Object getBusinessObject() {
		// TODO Auto-generated method stub
		return busi;
	}

	@Override
	public String getBsnsdt() {
		// TODO Auto-generated method stub
		return busi.getTrandt();
	}

	@Override
	public String getBsnssq() {
		// TODO Auto-generated method stub
		return busi.getTransq();
	}

	@Override
	public String getSystid() {
		// TODO Auto-generated method stub
		return busi.getSystid();
	}

	@Override
	public String getProdcd() {
		// TODO Auto-generated method stub
		return prodcd;
	}

	@Override
	public int getStacid() {
		// TODO Auto-generated method stub
		return stacid;
	}

	@Override
	public void setStacid(int stacid) {
		// TODO Auto-generated method stub
		this.busi.setStacid(stacid);
	}

}
