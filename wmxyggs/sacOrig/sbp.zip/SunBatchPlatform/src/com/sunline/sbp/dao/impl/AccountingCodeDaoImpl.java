package com.sunline.sbp.dao.impl;

import java.util.Hashtable;

import org.apache.log4j.Logger;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.tools.StringUtil;
import com.sunline.sbp.core.bean.CacheTargetBean;
import com.sunline.sbp.dao.AccountingCodeDao;
import com.sunline.sbp.dao.mapper.AccountingCodeMapper;
import com.sunline.sbp.model.AccountingCode;

public class AccountingCodeDaoImpl implements AccountingCodeDao {
	
	private static Hashtable<String,AccountingCode> accountingCodeCache = new Hashtable<String,AccountingCode>();
	
	private AccountingCodeMapper accountingCodeMapper;
	Logger logger = Logger.getLogger(AccountingCodeDaoImpl.class);
	
	public AccountingCode getItemCode(int stacid , String dtitcd , String trprcd) throws EngineRuntimeException{
		
		if(stacid == 0 || !StringUtil.isNotNull(dtitcd) || !StringUtil.isNotNull(trprcd)){
			String message = "������Ϣ������["+stacid+"]�������["+dtitcd+"]����["+trprcd+"]���������ݲ�����";
			logger.error(message);
			throw new EngineRuntimeException(message);
		}
		
		String key = String.valueOf(stacid).concat("-").concat(dtitcd).concat("-").concat(trprcd); 
		
		int isFresh = CacheTargetBean.getCacheTarget("AccountingCodeCache");
		if(isFresh == 1){
			synchronized(this){
				if(CacheTargetBean.getCacheTarget("AccountingCodeCache") == 1){
					accountingCodeCache.clear();
					CacheTargetBean.updateCacheTarget("AccountingCodeCache");
				}
			}
		}
		
		AccountingCode accountingCode = null;
		if(accountingCodeCache.containsKey(key)){
			accountingCode = accountingCodeCache.get(key);
		}else{
			accountingCode = new AccountingCode();
			accountingCode.setStacid(stacid);
			accountingCode.setTypecd(dtitcd);
			accountingCode.setTrprcd(trprcd);
			try{
				accountingCode = accountingCodeMapper.getEntities(accountingCode);
			}catch(Exception ex){
				String message = "��ȡ������Ϣ������["+stacid+"]�������["+dtitcd+"]����["+trprcd+"]��ʱϵͳ�쳣";
				logger.error(message,ex);
				throw new EngineRuntimeException(message,ex);
			}
			
			if(null == accountingCode){
				String message = "������Ϣ������["+stacid+"]�������["+dtitcd+"]����["+trprcd+"]��δ����";
				logger.error(message);
				throw new EngineRuntimeException(message);
			}
			accountingCodeCache.put(key, accountingCode);
		}
		return accountingCode;
	}

	public AccountingCodeMapper getAccountingCodeMapper() {
		return accountingCodeMapper;
	}

	public void setAccountingCodeMapper(AccountingCodeMapper accountingCodeMapper) {
		this.accountingCodeMapper = accountingCodeMapper;
	}
	
	
}
