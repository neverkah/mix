package com.sunline.sbp.dao.mapper;

import java.util.List;

import com.sunline.sbp.model.ComBuln;

public interface ComBulnMapper {
	public List<ComBuln> getAllEntities();
}
