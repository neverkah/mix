package com.sunline.sbp.common;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.Enumeration;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.service.GliLogService;

public class GliMslgUtil {

	private static Logger logger = Logger.getLogger(GliMslgUtil.class);

	/**
	 * @Title: insertGliMslg
	 * @Description: ��¼ʵʱ������־
	 * @param bussinessInfo
	 * @param gliMslgJSONObject
	 * @param recedt
	 * @param respdt
	 * @param pastau
	 * @param executeMsg
	 * @param paerlg
	 * @return: void
	 */

	public static void writeLog(String bussinessInfo, JSONObject gliMslgJSONObject, Timestamp recedt, Timestamp respdt,
			String executeMsg, String mstype) {
		try {
			GliLogService gliLogService = ApplicationBeanFactory.getApplicationContextInstance().getBean(GliLogService.class);
			gliLogService.insertGliMslg(bussinessInfo, gliMslgJSONObject, recedt, respdt, executeMsg, mstype);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

}
