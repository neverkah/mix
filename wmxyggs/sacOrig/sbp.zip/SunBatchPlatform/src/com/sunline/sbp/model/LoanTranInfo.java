package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * �������ϸ(gls_loan_tran)
 * @author Zhangjin
 *
 */

public class LoanTranInfo {
	private int stacid;
	private String systid;
	private String trandt;
	private String loansq;
	private String transq;
	private String tranbr;
	private String trantp;
	private String acctbr;
	private String dtitcd;
	private String lnbltp;
	private String acpdcd;
	private String trancd;
	private String amntcd;
	private String crcycd;
	private BigDecimal tranam;
	private String bkfnst;
	
	private String centcd;// '�������� ';
	private String prsncd;// 'ְԱ ';
	private String custcd;// '�ͻ� ';
	private String prodcd;// '��Ʒ ';
	private String prlncd;// '��Ʒ�� ';
	private String acctno;// '�˻� ';
	private String assis0;// '��������0���Զ��壩';
	private String assis1;// '��������1���Զ��壩';
	private String assis2;// '��������2���Զ��壩';
	private String assis3;// '��������3���Զ��壩';
	private String assis4;// '��������4���Զ��壩';
	private String assis5;// '��������5���Զ��壩';
	private String assis6;// '��������6���Զ��壩';
	private String assis7;// '��������7���Զ��壩';
	private String assis8;// '��������8���Զ��壩';
	private String assis9;// '��������9���Զ��壩';

	public String getCentcd() {
		return centcd;
	}
	public void setCentcd(String centcd) {
		this.centcd = centcd;
	}
	public String getPrsncd() {
		return prsncd;
	}
	public void setPrsncd(String prsncd) {
		this.prsncd = prsncd;
	}
	public String getCustcd() {
		return custcd;
	}
	public void setCustcd(String custcd) {
		this.custcd = custcd;
	}
	public String getPrlncd() {
		return prlncd;
	}
	public void setPrlncd(String prlncd) {
		this.prlncd = prlncd;
	}
	public String getAssis0() {
		return assis0;
	}
	public void setAssis0(String assis0) {
		this.assis0 = assis0;
	}
	public String getAssis1() {
		return assis1;
	}
	public void setAssis1(String assis1) {
		this.assis1 = assis1;
	}
	public String getAssis2() {
		return assis2;
	}
	public void setAssis2(String assis2) {
		this.assis2 = assis2;
	}
	public String getAssis3() {
		return assis3;
	}
	public void setAssis3(String assis3) {
		this.assis3 = assis3;
	}
	public String getAssis4() {
		return assis4;
	}
	public void setAssis4(String assis4) {
		this.assis4 = assis4;
	}
	public String getAssis5() {
		return assis5;
	}
	public void setAssis5(String assis5) {
		this.assis5 = assis5;
	}
	public String getAssis6() {
		return assis6;
	}
	public void setAssis6(String assis6) {
		this.assis6 = assis6;
	}
	public String getAssis7() {
		return assis7;
	}
	public void setAssis7(String assis7) {
		this.assis7 = assis7;
	}
	public String getAssis8() {
		return assis8;
	}
	public void setAssis8(String assis8) {
		this.assis8 = assis8;
	}
	public String getAssis9() {
		return assis9;
	}
	public void setAssis9(String assis9) {
		this.assis9 = assis9;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getLoansq() {
		return loansq;
	}
	public void setLoansq(String loansq) {
		this.loansq = loansq;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getDtitcd() {
		return dtitcd;
	}
	public void setDtitcd(String dtitcd) {
		this.dtitcd = dtitcd;
	}
	public String getLnbltp() {
		return lnbltp;
	}
	public void setLnbltp(String lnbltp) {
		this.lnbltp = lnbltp;
	}
	public String getAcpdcd() {
		return acpdcd;
	}
	public void setAcpdcd(String acpdcd) {
		this.acpdcd = acpdcd;
	}
	public String getTrancd() {
		return trancd;
	}
	public void setTrancd(String trancd) {
		this.trancd = trancd;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public String getBkfnst() {
		return bkfnst;
	}
	public void setBkfnst(String bkfnst) {
		this.bkfnst = bkfnst;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	
	
}
