package com.sunline.sbp.dao;

import java.util.List;

import com.sunline.sbp.model.ComCust;

public interface ComCustDao {
	public List<ComCust> getAllEntities();
}
