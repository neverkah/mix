package com.sunline.sbp.dao.impl.rule;

import java.math.BigDecimal;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.DataObjectUtil;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.Enumeration;
import com.sunline.foundation.TranamInfoEntity;
import com.sunline.onln.application.provider.CommandGlServiceImpl;
import com.sunline.sbp.base.RuleBeanObject;
import com.sunline.sbp.dao.impl.SystemInterfaceDaoImpl;
import com.sunline.sbp.dao.mapper.GlsExtdMapper;
import com.sunline.sbp.dao.mapper.MidTranMapper;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.MidTran;
import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;
import com.sunline.sbp.model.SysIomp;

/***
 * ��������������ϸ
 * @author Zhangjin
 *
 */

public class MidTranRule implements RuleBeanObject{
	private MidTranMapper midTranMapper;
	private MidTran command;
	private GlsExtdMapper glsExtdMapper;
	private SystemInterfaceDaoImpl sysIntfDaoImpl;
	private GlsExtd extd;
	private HashMap<String , Object> data;
	private SysIomp[] iopms;
	private SysIntf sysIntf;
	private SysIntfDetl[] intfDetl;
	
	private Logger logger = Logger.getLogger(CommandGlServiceImpl.class);
	
	@Override
	public void setMapOfInIntf(final SysIntf sysIntf , final SysIomp[] iopms ,final SysIntfDetl[] detls) {
		this.iopms = iopms;
		this.sysIntf = sysIntf;
		this.intfDetl = detls;
	}
	
	@Override
	public String initialize(HashMap<String , Object> data) throws AnalyseException{
		command = new MidTran();
		this.data = data;
		command.setStacid(Integer.parseInt(DataObjectUtil.getHashMapStr(data,"stacid").toString()));
		command.setAmntcd(DataObjectUtil.getHashMapStr(data,"amntcd").toString());
		command.setDtitcd(DataObjectUtil.getHashMapStr(data,"dtitcd").toString());
		command.setTranam(BigDecimal.valueOf(Double.parseDouble(DataObjectUtil.getHashMapStr(data,"tranam").toString())));
		command.setSystid(DataObjectUtil.getHashMapStr(data,"systid").toString());
		command.setTranbr(DataObjectUtil.getHashMapStr(data,"tranbr").toString());
		command.setAcctbr(DataObjectUtil.getHashMapStr(data,"acctbr").toString());
		command.setTrandt(DataObjectUtil.getHashMapStr(data,"trandt").toString());
		command.setMiddsq(DataObjectUtil.getHashMapStr(data,"cmmdsq").toString());
		command.setTransq(DataObjectUtil.getHashMapStr(data,"transq").toString());
		command.setCrcycd(DataObjectUtil.getHashMapStr(data,"crcycd").toString());
		command.setSmrytx(DataObjectUtil.getHashMapStr(data,"smrytx","ϵͳ������").toString());
		return "EX0000";
	}
	
	public String check() throws EngineRuntimeException{
		//sysIntfDaoImpl.checkValidate(sysIntf,data);
		return Constants.EXECUTE_SUCC;
	}
	
	@Override
	public GlsExtd execute(int orderCount) throws EngineRuntimeException{
		//����ָ�����ݱ�
		try{
			logger.debug("stacid:"+command.getStacid());
			logger.debug("amntcd:"+command.getAmntcd());
			logger.debug("dtitcd:"+command.getDtitcd());
			logger.debug("tranam:"+command.getTranam());
			logger.debug("Systid:"+command.getSystid());
			logger.debug("Tranbr:"+command.getTranbr());
			logger.debug("Trandt:"+command.getTrandt());
			logger.debug("Middsq:"+command.getMiddsq());
			logger.debug("Transq"+command.getTransq());
			logger.debug("Crcycd"+command.getCrcycd());
			logger.debug("Smrytx"+command.getSmrytx());
			//����� 2016-10-07
			//midTranMapper.insert(command);
		}catch(Exception ex){
			throw new EngineRuntimeException("����ָ�������ʧ��",ex);
		}
				
		extd = new GlsExtd();
		extd.setStacid(command.getStacid());
		extd.setSystid(command.getSystid());
		extd.setTrandt(command.getTrandt());
		extd.setTranbr(command.getTranbr());
		extd.setTransq(command.getTransq());
		extd.setSortno(orderCount);
		extd.setCmmdtg(Constants.COMMAND_IDENTITY_MI);
		extd.setTrantp(Enumeration.TRANTP.TRAN.value);
		extd.setAmntcd(command.getAmntcd());
		extd.setCrcycd(command.getCrcycd());
		extd.setTranam(command.getTranam());
		extd.setCmmdsq(command.getMiddsq());
		if(null != data.get("bsnssq")){
			extd.setBsnssq(data.get("bsnssq").toString());
		}
		return extd;
	}
	
	@Override
	public TranamInfoEntity getTranamInfo(){
		return new TranamInfoEntity(command.getAmntcd(),command.getTranam());
	}

	public MidTranMapper getMidTranMapper() {
		return midTranMapper;
	}

	public void setMidTranMapper(MidTranMapper midTranMapper) {
		this.midTranMapper = midTranMapper;
	}

	public GlsExtdMapper getGlsExtdMapper() {
		return glsExtdMapper;
	}

	public void setGlsExtdMapper(GlsExtdMapper glsExtdMapper) {
		this.glsExtdMapper = glsExtdMapper;
	}

	public SystemInterfaceDaoImpl getSysIntfDaoImpl() {
		return sysIntfDaoImpl;
	}

	public void setSysIntfDaoImpl(SystemInterfaceDaoImpl sysIntfDaoImpl) {
		this.sysIntfDaoImpl = sysIntfDaoImpl;
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return data;
	}

	@Override
	public JSONObject getCmmd() {
		return (JSONObject)JSON.toJSON(command);
	}
}
