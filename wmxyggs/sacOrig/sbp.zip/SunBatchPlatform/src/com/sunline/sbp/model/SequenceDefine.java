package com.sunline.sbp.model;

/**
 * ��ˮ�����Ͷ���(com_sqdf)
 * @author Zhangjin
 *
 */

public class SequenceDefine {
	private String sqnocd;
	private String sqnona;
	private long sqnolt;
	private long initno;
	private long maxino;
	private String rptmtp;
	private String sqnorg;
	private String prfxtp;
	private String sqnotp;
	private String islkac;
	
	public String getSqnocd() {
		return sqnocd;
	}
	public void setSqnocd(String sqnocd) {
		this.sqnocd = sqnocd;
	}
	public String getSqnona() {
		return sqnona;
	}
	public void setSqnona(String sqnona) {
		this.sqnona = sqnona;
	}
	public long getSqnolt() {
		return sqnolt;
	}
	public void setSqnolt(long sqnolt) {
		this.sqnolt = sqnolt;
	}
	public long getInitno() {
		return initno;
	}
	public void setInitno(long initno) {
		this.initno = initno;
	}
	public long getMaxino() {
		return maxino;
	}
	public void setMaxino(long maxino) {
		this.maxino = maxino;
	}
	public String getRptmtp() {
		return rptmtp;
	}
	public void setRptmtp(String rptmtp) {
		this.rptmtp = rptmtp;
	}
	public String getSqnorg() {
		return sqnorg;
	}
	public void setSqnorg(String sqnorg) {
		this.sqnorg = sqnorg;
	}
	public String getPrfxtp() {
		return prfxtp;
	}
	public void setPrfxtp(String prfxtp) {
		this.prfxtp = prfxtp;
	}
	public String getSqnotp() {
		return sqnotp;
	}
	public void setSqnotp(String sqnotp) {
		this.sqnotp = sqnotp;
	}
	public String getIslkac() {
		return islkac;
	}
	public void setIslkac(String islkac) {
		this.islkac = islkac;
	}
	
	
}
