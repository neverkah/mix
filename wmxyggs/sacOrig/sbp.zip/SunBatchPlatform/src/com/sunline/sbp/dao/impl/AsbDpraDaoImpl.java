package com.sunline.sbp.dao.impl;

import com.sunline.sbp.dao.AsbDpraDao;
import com.sunline.sbp.dao.mapper.AsbDpraMapper;
import com.sunline.sbp.model.AsbDpra;

public class AsbDpraDaoImpl implements AsbDpraDao {
	
	private AsbDpraMapper asbDpraMapper;

	@Override
	public void insert(AsbDpra entity) {
		// TODO Auto-generated method stub
		asbDpraMapper.insertEntity(entity);
	}

	public AsbDpraMapper getAsbDpraMapper() {
		return asbDpraMapper;
	}

	public void setAsbDpraMapper(AsbDpraMapper asbDpraMapper) {
		this.asbDpraMapper = asbDpraMapper;
	}
	
	

}
