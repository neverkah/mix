package com.sunline.sbp.model;

/**
 * �ʲ�ҵ��鼯����
 * @author Zhangjin
 *
 */

public class AsbBusi{
	private int stacid;
	private String systid;
	private String trandt;
	private String transq;
	private String tranbr;
	private String asetno;
	private String prcscd;
	private String prodcd;
	private String asettp;
	private double inchvl;
	private double dpravl;
	private double publvl;
	private double devvvl;
	private String trantp;
	private String lnbltp;
	private double outtvl;
	private double incmvl;
	private String tobrch;
	private String smrytx;
	private String status;
	private String crcycd;
	private String bathid;
	
	public String getBathid() {
		return bathid;
	}
	public void setBathid(String bathid) {
		this.bathid = bathid;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public String getAsettp() {
		return asettp;
	}
	public void setAsettp(String asettp) {
		this.asettp = asettp;
	}
	public double getInchvl() {
		return inchvl;
	}
	public void setInchvl(double inchvl) {
		this.inchvl = inchvl;
	}
	public double getDpravl() {
		return dpravl;
	}
	public void setDpravl(double dpravl) {
		this.dpravl = dpravl;
	}
	public double getPublvl() {
		return publvl;
	}
	public void setPublvl(double publvl) {
		this.publvl = publvl;
	}
	public double getDevvvl() {
		return devvvl;
	}
	public void setDevvvl(double devvvl) {
		this.devvvl = devvvl;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public double getOuttvl() {
		return outtvl;
	}
	public void setOuttvl(double outtvl) {
		this.outtvl = outtvl;
	}
	public double getIncmvl() {
		return incmvl;
	}
	public void setIncmvl(double incmvl) {
		this.incmvl = incmvl;
	}
	public String getTobrch() {
		return tobrch;
	}
	public void setTobrch(String tobrch) {
		this.tobrch = tobrch;
	}
	public String getSmrytx() {
		return smrytx;
	}
	public void setSmrytx(String smrytx) {
		this.smrytx = smrytx;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getAsetno() {
		return asetno;
	}
	public void setAsetno(String asetno) {
		this.asetno = asetno;
	}
	public String getLnbltp() {
		return lnbltp;
	}
	public void setLnbltp(String lnbltp) {
		this.lnbltp = lnbltp;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	
}
