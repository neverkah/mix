package com.sunline.sbp.dao.impl;

import java.util.Hashtable;
import java.util.List;

import com.sunline.foundation.Constants;
import com.sunline.sbp.dao.ComCustDao;
import com.sunline.sbp.dao.mapper.ComCustMapper;
import com.sunline.sbp.model.ComCust;

public class ComCustDaoImpl implements ComCustDao {
	
	private ComCustMapper comCustMapper;
	
	private int initail = 0;
	
	/**
	 * ȫ��Ϣ����
	 */
	private static Hashtable<String,ComCust> custDatas = new Hashtable<String,ComCust>();

	@Override
	public List<ComCust> getAllEntities() {
		// TODO Auto-generated method stub
		List<ComCust> tableData = comCustMapper.getAllEntities();
		for(ComCust entity : tableData){
			custDatas.put(entity.getStacid()+Constants.DTAG+entity.getCustcd(), entity);
		}
		return tableData;
	}
	
	public Hashtable<String,ComCust> getCacheData(){
		if(initail == 0){
			synchronized(this) {
				if(initail == 0){
					getAllEntities();
					initail = 1;
				}
			}
		}
		return custDatas;
	}
	
	public boolean frushCache(){
		custDatas.clear();
		getAllEntities();
		return true;
	}

	public ComCustMapper getComCustMapper() {
		return comCustMapper;
	}

	public void setComCustMapper(ComCustMapper comCustMapper) {
		this.comCustMapper = comCustMapper;
	}

}
