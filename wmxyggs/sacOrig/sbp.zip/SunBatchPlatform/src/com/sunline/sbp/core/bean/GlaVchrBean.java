package com.sunline.sbp.core.bean;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.dao.AccountingItemDao;
import com.sunline.sbp.model.AccountingItem;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.GliVoucher;

public class GlaVchrBean {
	
	private static Logger logger = Logger.getLogger(GlaVchrBean.class);
	
	public static GlaVoucher clone(final GlaVoucher vchr){
		GlaVoucher cloneObject = new GlaVoucher();
		cloneObject.setAcctbr(vchr.getAcctbr());
		cloneObject.setAcctno(vchr.getAcctno());
		cloneObject.setAmntcd(vchr.getAmntcd());
		cloneObject.setAssis0(vchr.getAssis0());
		cloneObject.setAssis1(vchr.getAssis1());
		cloneObject.setAssis2(vchr.getAssis2());
		cloneObject.setAssis3(vchr.getAssis3());
		cloneObject.setAssis4(vchr.getAssis4());
		cloneObject.setAssis5(vchr.getAssis5());
		cloneObject.setAssis6(vchr.getAssis6());
		cloneObject.setAssis7(vchr.getAssis7());
		cloneObject.setAssis8(vchr.getAssis8());
		cloneObject.setAssis9(vchr.getAssis9());
		cloneObject.setBearbl(vchr.getBearbl());
		cloneObject.setBeardn(vchr.getBeardn());
		cloneObject.setBlncdn(vchr.getBlncdn());
		cloneObject.setBrchsq(vchr.getBrchsq());
		cloneObject.setCentcd(vchr.getCentcd());
		cloneObject.setCentsq(vchr.getCentsq());
		cloneObject.setClerdt(vchr.getClerdt());
		cloneObject.setClerod(vchr.getClerod());
		cloneObject.setClertg(vchr.getClertg());
		cloneObject.setCrcycd(vchr.getCrcycd());
		cloneObject.setCustcd(vchr.getCustcd());
		cloneObject.setExchcn(vchr.getExchcn());
		cloneObject.setExchus(vchr.getExchus());
		cloneObject.setIoflag(vchr.getIoflag());
		cloneObject.setItemcd(vchr.getItemcd());
		cloneObject.setPrducd(vchr.getPrducd());
		cloneObject.setPrlncd(vchr.getPrlncd());
		cloneObject.setPrsncd(vchr.getPrsncd());
		cloneObject.setSmrytx(vchr.getSmrytx());
		cloneObject.setSourdt(vchr.getSourdt());
		cloneObject.setSoursq(vchr.getSoursq());
		cloneObject.setSourst(vchr.getSourst());
		cloneObject.setSrvcsq(vchr.getSrvcsq());
		cloneObject.setStacid(vchr.getStacid());
		cloneObject.setSystid(vchr.getSystid());
		cloneObject.setToitem(vchr.getToitem());
		cloneObject.setTranam(vchr.getTranam());
		cloneObject.setTranbl(vchr.getTranbl());
		cloneObject.setTranbr(vchr.getTranbr());
		cloneObject.setTrandt(vchr.getTrandt());
		cloneObject.setTrannm(vchr.getTrannm());
		cloneObject.setTranno(vchr.getTranno());
		cloneObject.setTransq(vchr.getTransq());
		cloneObject.setTrantp(vchr.getTrantp());
		cloneObject.setUsercd(vchr.getUsercd());
		cloneObject.setVchrsq(vchr.getVchrsq());
		cloneObject.setSubsac(vchr.getSubsac());
		
		return cloneObject;
	}
	
	/**
	 * ����gli_vchr��¼����gla_vchr��¼
	 * @param gli_vchr
	 * @return gla_vchr
	 * @throws AnalyseException 
	 */
	public static GlaVoucher toGlaVchr(final GliVoucher vchr) throws AnalyseException {
		GlaVoucher glaObject = new GlaVoucher();
		glaObject.setAcctbr(vchr.getAcctbr());
		glaObject.setAcctno(vchr.getAcctno());
		glaObject.setAmntcd(vchr.getAmntcd());
		glaObject.setAssis0(vchr.getAssis0());
		glaObject.setAssis1(vchr.getAssis1());
		glaObject.setAssis2(vchr.getAssis2());
		glaObject.setAssis3(vchr.getAssis3());
		glaObject.setAssis4(vchr.getAssis4());
		glaObject.setAssis5(vchr.getAssis5());
		glaObject.setAssis6(vchr.getAssis6());
		glaObject.setAssis7(vchr.getAssis7());
		glaObject.setAssis8(vchr.getAssis8());
		glaObject.setAssis9(vchr.getAssis9());
		glaObject.setBearbl(BigDecimal.ZERO);
		glaObject.setCrcycd(vchr.getCrcycd());
		glaObject.setCustcd(vchr.getCustcd());
		glaObject.setExchcn(vchr.getExchcn());
		glaObject.setExchus(vchr.getExchus());
		glaObject.setItemcd(vchr.getItemcd());
		glaObject.setPrducd(vchr.getPrducd());
		glaObject.setPrlncd(vchr.getPrlncd());
		glaObject.setPrsncd(vchr.getPrsncd());
		glaObject.setSmrytx(vchr.getSmrytx());
		glaObject.setSourdt(vchr.getSourdt());
		glaObject.setSoursq(vchr.getSoursq());
		glaObject.setSourst(vchr.getSourst());
		glaObject.setSrvcsq(vchr.getVchrsq());
		glaObject.setStacid(vchr.getStacid());
		glaObject.setSystid(vchr.getSourst());
		glaObject.setToitem(vchr.getToitem());
		glaObject.setTranam(vchr.getTranam());
		glaObject.setTranbl(BigDecimal.ZERO);
		glaObject.setTranbr(vchr.getTranbr());
		glaObject.setTrandt(vchr.getSourdt());
		glaObject.setTrannm(vchr.getTrannm());
		glaObject.setTrantp(vchr.getTrantp());
		glaObject.setUsercd(vchr.getUsercd());
		glaObject.setTranst(vchr.getTranst());
		glaObject.setClertg("0");
		
		try {
			AccountingItemDao accountingItemDao = ApplicationBeanFactory.getApplicationContextInstance().getBean(AccountingItemDao.class);
			AccountingItem itemInfo = accountingItemDao.getEntityByPrimaryKey(vchr.getStacid(), vchr.getItemcd());
			glaObject.setIoflag(itemInfo.getIoflag());
		}catch (AnalyseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage(),e);
			throw new AnalyseException(e.getMessage(),e);
		}catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("��ѯgli_vchr�Ŀ�Ŀ��Ϣʱϵͳ�쳣��soursq:"+vchr.getSoursq(),e);
			throw new AnalyseException("��ѯ��Χ��Ʊ�еĿ�Ŀ��Ϣʱϵͳ��������Ʊ��Ϣ����ˮ��-"+vchr.getSoursq()+",��Ʊ���-" + vchr.getVchrsq(),e);
		}finally{
		}
		logger.debug("��Χϵͳ��Ʊת��Ԥ�����ɹ���transq:" + vchr.getSoursq()+" vchrsq:" + vchr.getVchrsq());
		return glaObject;
	}
	
	public String printInfo(final GliVoucher vchr){
		String info = "��¼��Ϣ��";
		info = info + "����=" + vchr.getStacid();
		info = info + "������=" + vchr.getTrandt();
		info = info + "����ƿ�Ŀ=" + vchr.getItemcd();
		info = info + "�����˻���=" + vchr.getAcctbr();
		info = info + "�����=" + vchr.getTranam();
		info = info + "������=" + vchr.getCrcycd();
		return null;
	}
}
