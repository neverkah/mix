package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * �ʲ��۾ɣ�̯����ҵ�������
 * @author Zhangjin
 *
 */
public class AsbDpra {
	private int stacid;
	private String systid;
	private String tranbr;
	private String trandt;
	private String transq;
	private String dtitcd;
	private String asetno;
	private String crcycd;
	private BigDecimal tranam;
	private String reastp;
	private String amntcd;
	private String bkfnst;
	
	private final String prcscd = "asdpra";
	
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getDtitcd() {
		return dtitcd;
	}
	public void setDtitcd(String dtitcd) {
		this.dtitcd = dtitcd;
	}
	public String getAsetno() {
		return asetno;
	}
	public void setAsetno(String asetno) {
		this.asetno = asetno;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public String getReastp() {
		return reastp;
	}
	public void setReastp(String reastp) {
		this.reastp = reastp;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String trancd) {
		this.amntcd = trancd;
	}
	public String getBkfnst() {
		return bkfnst;
	}
	public void setBkfnst(String bkfnst) {
		this.bkfnst = bkfnst;
	}
	
	public String getPrcscd(){
		return prcscd;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	
}
