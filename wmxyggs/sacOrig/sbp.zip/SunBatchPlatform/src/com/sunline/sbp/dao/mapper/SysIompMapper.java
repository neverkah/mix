package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.SysIomp;

public interface SysIompMapper {
	public SysIomp[] getEntites(@Param("ruleid") String ruleid);
}
