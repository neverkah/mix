package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * �ʲ�������ϸ��
 * @author Zhangjin
 *
 */

public class AsbTran {
	private int stacid;
	private String systid;
	private String trandt;
	private String transq;
	private String asetno;
	private String tranbr;
	private String amntcd;
	private String trantp;
	private String crcycd;
	private String dtitcd;
	private String lnbltp;
	private BigDecimal tranam;
	private String smrytx;
	
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}
	public String getDtitcd() {
		return dtitcd;
	}
	public void setDtitcd(String dtitcd) {
		this.dtitcd = dtitcd;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public String getSmrytx() {
		return smrytx;
	}
	public void setSmrytx(String smrytx) {
		this.smrytx = smrytx;
	}
	public String getAsetno() {
		return asetno;
	}
	public void setAsetno(String asetno) {
		this.asetno = asetno;
	}
	public String getLnbltp() {
		return lnbltp;
	}
	public void setLnbltp(String lnbltp) {
		this.lnbltp = lnbltp;
	}
}
