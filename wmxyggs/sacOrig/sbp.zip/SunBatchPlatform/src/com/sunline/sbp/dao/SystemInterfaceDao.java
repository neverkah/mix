package com.sunline.sbp.dao;

import java.util.HashMap;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;

public interface SystemInterfaceDao {
	public SysIntfDetl[] getIntfDetl(SysIntf sysIntf) throws EngineRuntimeException;
	public String checkValidate(SysIntf sysIntf, HashMap<String , Object> dataContext) throws EngineRuntimeException;
}
