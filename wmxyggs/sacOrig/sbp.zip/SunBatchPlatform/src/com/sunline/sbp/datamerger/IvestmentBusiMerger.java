package com.sunline.sbp.datamerger;

import com.sunline.sbp.model.IvestmentBusi;

public class IvestmentBusiMerger implements BusinessObject {
	
	private IvestmentBusi busi;
	private String prcscd;
	private String typecd;
	private int stacid;
	
	public String getProdcd(){
		return busi.getProdcd();
	}
	
	public IvestmentBusiMerger(IvestmentBusi busi){
		this.busi = busi;
		this.prcscd = busi.getPrcscd();
		this.typecd = busi.getIvsttp();
		this.stacid = busi.getStacid();
	}

	@Override
	public String getPrcscd() {
		// TODO Auto-generated method stub
		return prcscd;
	}

	@Override
	public String getBusiType() {
		// TODO Auto-generated method stub
		return typecd;
	}

	@Override
	public Object getBusinessObject() {
		// TODO Auto-generated method stub
		return busi;
	}

	@Override
	public String getBsnsdt() {
		// TODO Auto-generated method stub
		return busi.getBsnsdt();
	}

	@Override
	public String getBsnssq() {
		// TODO Auto-generated method stub
		return busi.getBsnssq();
	}

	@Override
	public String getSystid() {
		// TODO Auto-generated method stub
		return busi.getSystid();
	}

	@Override
	public int getStacid() {
		// TODO Auto-generated method stub
		return stacid;
	}

	@Override
	public void setStacid(int stacid) {
		// TODO Auto-generated method stub
		this.busi.setStacid(stacid);
	}

}
