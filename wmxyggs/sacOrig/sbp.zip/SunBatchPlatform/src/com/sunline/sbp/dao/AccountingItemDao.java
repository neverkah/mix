package com.sunline.sbp.dao;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.model.AccountingItem;

public interface AccountingItemDao {
	public AccountingItem getEntityByPrimaryKey(int stacid , String itemcd) throws AnalyseException;
	public AccountingItem[] getEntitiesOfTable(int stacid) throws AnalyseException;
}
