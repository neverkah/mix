package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.TrbBusiInfo;
import com.sunline.sbp.model.TrbRecvInfo;
import com.sunline.sbp.model.TrbTxlsInfo;


public interface  TxbBusiInfoMapper {
	
	public String insertTrbRecv(TrbRecvInfo entity);
	public String insertTrbBusi(TrbBusiInfo entity);
	public String insertTrbTxls(TrbTxlsInfo entity);
}
