package com.sunline.sbp.service;

import java.sql.SQLException;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.transaction.Transaction;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.DataObjectUtil;
import com.sunline.sbp.dao.mapper.AsbTranMapper;
import com.sunline.sbp.model.AsbTran;
import com.sunline.sunbp.util.MyBatisUtil;

public class AsbTranAction {
	public void insertObject(HashMap<String,Object> data) throws AnalyseException{
		SqlSessionFactory sqlSessionFactory = MyBatisUtil.getSqlSessionFactory();
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		TransactionFactory transactionFactory = new JdbcTransactionFactory();   //���񹤳�

		Transaction newTransaction = transactionFactory.newTransaction(sqlSession.getConnection());  //��������
		
		AsbTranMapper asbtranMapper = sqlSession.getMapper(AsbTranMapper.class);
		
		AsbTran asbTran = new AsbTran();
		
		asbTran.setAmntcd(null == data.get("tramcd")? Constants.AMNTCD_DEBIT:Constants.AMNTCD_CREDIT);
		asbTran.setDtitcd(data.get("asettp").toString());
		asbTran.setTranam(DataObjectUtil.getBigDecimalValue(data,"inchvl"));
		asbTran.setSystid(data.get("systid").toString());
		asbTran.setTranbr(data.get("tranbr").toString());
		asbTran.setTrandt(data.get("trandt").toString());
		asbTran.setTransq(data.get("transq").toString());
		
		asbtranMapper.insertObject(asbTran);
		try {
			newTransaction.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			newTransaction.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
