package com.sunline.sbp.model;

/**
 * ϵͳ������(sys_cond)
 * @author Zhangjin
 *
 */

public class SysCond {
	String condcd;
	String condtp;
	String condna;
	String enname;
	String desctx;
	String vermod;
	String module;
	String projcd;
	public String getCondcd() {
		return condcd;
	}
	public void setCondcd(String condcd) {
		this.condcd = condcd;
	}
	public String getCondtp() {
		return condtp;
	}
	public void setCondtp(String condtp) {
		this.condtp = condtp;
	}
	public String getCondna() {
		return condna;
	}
	public void setCondna(String condna) {
		this.condna = condna;
	}
	public String getEnname() {
		return enname;
	}
	public void setEnname(String enname) {
		this.enname = enname;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
}
