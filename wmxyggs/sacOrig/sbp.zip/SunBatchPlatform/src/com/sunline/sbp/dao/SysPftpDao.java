package com.sunline.sbp.dao;

import com.sunline.sbp.model.SysPftp;

public interface SysPftpDao {
	public SysPftp getEntityByPK(SysPftp sysPftp);
}
