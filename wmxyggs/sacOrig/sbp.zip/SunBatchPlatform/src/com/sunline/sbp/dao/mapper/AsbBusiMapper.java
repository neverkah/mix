package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.AsbBusi;

public interface AsbBusiMapper {
	public AsbBusi[] selectBusi(AsbBusi entity);
	public void executeSucc(AsbBusi entity);
}
