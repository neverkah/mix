package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.ProfParamer;

public interface SysProfParaMapper {
	public ProfParamer[] getProfParamers(ProfParamer profParamer);
}
