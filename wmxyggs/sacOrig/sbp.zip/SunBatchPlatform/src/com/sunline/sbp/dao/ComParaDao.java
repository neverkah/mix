package com.sunline.sbp.dao;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.model.ComPara;

public interface ComParaDao {
	public ComPara getParamInfoByKey(int stacid , String parana) throws AnalyseException;
}
