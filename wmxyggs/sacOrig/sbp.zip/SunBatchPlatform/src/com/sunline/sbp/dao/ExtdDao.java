package com.sunline.sbp.dao;

import java.util.ArrayList;
import java.util.List;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.GlsTran;

public interface ExtdDao {
	public GlsExtd[] selectEntities(String trandt);
	public GlsExtd[] selectEntity(String systid , String trandt , String transq);
	public List<GlsExtd> selectEntitiesBatch(List<GlsTran> trans , String trandt , String systid);
	public boolean toTagSucc(String systid , String trandt , String transq , int sortno) throws EngineRuntimeException;
	public int insertBatch(ArrayList<GlsExtd> entities) throws EngineRuntimeException;
	public void insertEntity(GlsExtd entity) throws EngineRuntimeException;
}
