package com.sunline.sbp.dao.impl;

import java.util.Hashtable;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.core.bean.CacheTargetBean;
import com.sunline.sbp.core.bean.ComItemBean;
import com.sunline.sbp.dao.AccountingItemDao;
import com.sunline.sbp.dao.mapper.AccountingItemMapper;
import com.sunline.sbp.model.AccountingItem;

public class AccountingItemDaoImpl implements AccountingItemDao {
	
	private AccountingItemMapper accountingItemMapper;
	private Logger logger = Logger.getLogger(AccountingItemDaoImpl.class);
	
	/**
	 * ȫ��Ŀ��Ϣ����
	 */
	private static Hashtable<String,AccountingItem> itemDatas = new Hashtable<String,AccountingItem>();

	public AccountingItemMapper getAccountingItemMapper() {
		return accountingItemMapper;
	}

	public void setAccountingItemMapper(AccountingItemMapper accountingItemMapper) {
		this.accountingItemMapper = accountingItemMapper;
	}

	@Override
	public AccountingItem getEntityByPrimaryKey(int stacid, String itemcd) throws AnalyseException {
		// TODO Auto-generated method stub
		logger.debug("��ȡ��Ŀ������Ϣ����Ŀ���ţ�" + itemcd + "�����ף�" + stacid);
		
		AccountingItem itemInfo = itemDatas.get(String.valueOf(stacid).concat(Constants.MIDTQG).concat(itemcd));
		int isFresh = CacheTargetBean.getCacheTarget("itemCache");
		if(isFresh == 1){
			synchronized(this){
				if(CacheTargetBean.getCacheTarget("itemCache") == 1){
					itemDatas.clear();
					CacheTargetBean.updateCacheTarget("itemCache");
				}
			}
		}
		if(null == itemInfo){
			AccountingItem itemEntity = accountingItemMapper.selectEntity(stacid, itemcd);
			if(null == itemEntity){
				logger.error("������["+stacid+"]�в����ڿ�Ŀ["+itemcd+"]");
				throw new AnalyseException("����" + stacid + "���޿�Ŀ" + itemcd);
			}else{
				if(ComItemBean.checkAccountingProperty(itemEntity)){
					itemInfo = itemEntity;
					itemDatas.put(String.valueOf(stacid).concat(Constants.MIDTQG).concat(itemcd), itemEntity);
				}
			}
		}
		if(!itemInfo.getItemdn().equals(Enumeration.Amntcd.D.value)
				&& !itemInfo.getItemdn().equals(Enumeration.Amntcd.C.value)
				&& !itemInfo.getItemdn().equals(Enumeration.Amntcd.R.value)
				&& !itemInfo.getItemdn().equals(Enumeration.Amntcd.Z.value)
				&& !itemInfo.getItemdn().equals(Enumeration.Amntcd.B.value)
				&& !itemInfo.getItemdn().equals(Enumeration.Amntcd.P.value)){
			logger.error("����["+stacid+"]�п�Ŀ["+itemcd+"]��Ϣ���ԡ�����["+itemInfo.getItemdn()+"]�Ƿ���������ҵ���ֵ䲻һ��");
			throw new AnalyseException("����["+stacid+"]�п�Ŀ["+itemcd+"]��Ϣ���ԡ�����["+itemInfo.getItemdn()+"]�Ƿ���������ҵ���ֵ䲻һ��");
		}
		return itemInfo;
	}
	
	/**
	 * ��ʼ��
	 * @param stacid
	 * @throws AnalyseException
	 */
	private void initCacheData(int stacid) throws AnalyseException{
		if(null == itemDatas){
			itemDatas = new Hashtable<String,AccountingItem>();
				AccountingItem[] tableDatas = getEntitiesOfTable(stacid);
				logger.error("��ȡ���׵�ȫ��Ŀ����" + tableDatas.length);
				for(AccountingItem tableData : tableDatas){
					itemDatas.put(String.valueOf(stacid).concat(Constants.MIDTQG).concat(tableData.getItemcd()), tableData);
				}
		}
	}

	@Override
	public AccountingItem[] getEntitiesOfTable(int stacid)
			throws AnalyseException {
		// TODO Auto-generated method stub
		AccountingItem[] tableData = accountingItemMapper.selectFullEntities(stacid);
		return tableData;
	}

}
