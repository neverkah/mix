package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.DepositCommand;

public interface DepositCommandMapper {
	public String insertEntity(DepositCommand entity);
	public DepositCommand selectEntity(@Param("trandt") String trandt , @Param("transq") String transq, @Param("cmmdsq") String cmmdsq , @Param("systid") String systid);
	public void postingUpdate(DepositCommand entity);
}
