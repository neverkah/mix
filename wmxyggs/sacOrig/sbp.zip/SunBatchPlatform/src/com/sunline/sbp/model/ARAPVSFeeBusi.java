package com.sunline.sbp.model;

/**
 * Ӧ��Ӧ������ҵ��
 * @author Zhangjin
 *
 */
public class ARAPVSFeeBusi {
	private String systid;
	private String trandt;
	private String transq;
	private String subseq;
	private String tranbr;
	private String prcscd;
	private String trantp;
	private String busitp;
	private double tranam;
	private String crcycd;
	private String status;
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getSubseq() {
		return subseq;
	}
	public void setSubseq(String subseq) {
		this.subseq = subseq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public String getBusitp() {
		return busitp;
	}
	public void setBusitp(String busitp) {
		this.busitp = busitp;
	}
	public double getTranam() {
		return tranam;
	}
	public void setTranam(double tranam) {
		this.tranam = tranam;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
