package com.sunline.sbp.model;

public class ComAcct {
	private int stacid;
	private String systid;
	private String acctno;
	private String acctna;
	private String brchcd;
	private String itemcd;
	private String crcycd;
	private String openbr;
	private String opendt;
	private String closdt;
	private String ioflag;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getAcctna() {
		return acctna;
	}
	public void setAcctna(String acctna) {
		this.acctna = acctna;
	}
	public String getBrchcd() {
		return brchcd;
	}
	public void setBrchcd(String brchcd) {
		this.brchcd = brchcd;
	}
	public String getItemcd() {
		return itemcd;
	}
	public void setItemcd(String itemcd) {
		this.itemcd = itemcd;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getOpenbr() {
		return openbr;
	}
	public void setOpenbr(String openbr) {
		this.openbr = openbr;
	}
	public String getOpendt() {
		return opendt;
	}
	public void setOpendt(String opendt) {
		this.opendt = opendt;
	}
	public String getClosdt() {
		return closdt;
	}
	public void setClosdt(String closdt) {
		this.closdt = closdt;
	}
	public String getIoflag() {
		return ioflag;
	}
	public void setIoflag(String ioflag) {
		this.ioflag = ioflag;
	}
}
