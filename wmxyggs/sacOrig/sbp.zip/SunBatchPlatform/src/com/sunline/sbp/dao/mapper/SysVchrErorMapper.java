package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.SysVchrEror;

public interface SysVchrErorMapper {
	public int insertEntity(SysVchrEror entity);
}
