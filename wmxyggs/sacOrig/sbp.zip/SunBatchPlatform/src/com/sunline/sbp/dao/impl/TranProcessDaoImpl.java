package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.dao.TranProcessDao;
import com.sunline.sbp.dao.mapper.TranProcessMapper;
import com.sunline.sbp.model.TranProcess;

public class TranProcessDaoImpl implements TranProcessDao {
	
	private TranProcessMapper tranProcessMapper;
	private Logger logger = Logger.getLogger(TranProcessDaoImpl.class);

	@Override
	public TranProcess getTranProcessProperty(TranProcess query) throws EngineRuntimeException{
		// TODO Auto-generated method stub
		if( null == query){
			logger.error("����Ϊ��");
			throw new AnalyseException("����Ϊ��");
		}
		
		if(null == tranProcessMapper){
			logger.error("����tranProcessMapperע��ʧ��");
			throw new AnalyseException("����tranProcessMapperע��ʧ��");
		}
		
		TranProcess entity = tranProcessMapper.getEntity(query);
		if(null == entity){
			logger.error("�����벻���ڣ�prcscd=" + query.getPrcscd() + ",projcd=" + query.getProjcd() + "��");
			throw new AnalyseException("�����벻���ڣ�prcscd=" + query.getPrcscd() + ",projcd=" + query.getProjcd() + "��");
		}
		return entity;
	}

	public TranProcessMapper getTranProcessMapper() {
		return tranProcessMapper;
	}

	public void setTranProcessMapper(TranProcessMapper tranProcessMapper) {
		this.tranProcessMapper = tranProcessMapper;
	}
	
	
}
