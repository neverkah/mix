package com.sunline.sbp.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DuplicateKeyException;

import com.sunline.foundation.Constants;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.dao.ExtdDao;
import com.sunline.sbp.dao.mapper.GlsExtdMapper;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.GlsTran;

public class ExtdDaoImpl implements ExtdDao {
	
	private Logger logger = Logger.getLogger(ExtdDaoImpl.class);
	
	private GlsExtdMapper glsExtdMapper;

	@Override
	public GlsExtd[] selectEntities(String trandt) {
		// TODO Auto-generated method stub
		GlsExtd entity = new GlsExtd();
		entity.setTrandt(trandt);
		entity.setTransq("%");
		GlsExtd[] entities = glsExtdMapper.selectEntities(entity);
		return entities;
	}
	
	@Override
	public boolean toTagSucc(String systid , String trandt, String transq, int sortno) throws EngineRuntimeException{
		int sqlcount = glsExtdMapper.toTagSucc(systid, transq, trandt, sortno);
		boolean result = sqlcount > 0 ? true : false;
		if(!result){
			throw new EngineRuntimeException("��Ʊ���ܼ�¼��ʶ�ɹ�����ʧ��");
		}
		return result;
	}

	@Override
	public GlsExtd[] selectEntity(String systid, String trandt, String transq) {
		// TODO Auto-generated method stub
		GlsExtd[] entity = glsExtdMapper.selectEntity(systid,trandt,transq);
		return entity;
	}
	
	public GlsExtdMapper getGlsExtdMapper() {
		return glsExtdMapper;
	}

	public void setGlsExtdMapper(GlsExtdMapper glsExtdMapper) {
		this.glsExtdMapper = glsExtdMapper;
	}

	@Override
	public int insertBatch(ArrayList<GlsExtd> entities)
			throws EngineRuntimeException {
		// TODO Auto-generated method stub
		//�����ύ����
		int batchCount = 2000;
		int insertRecordCount = 0;
		
		//���ݺϷ���У�飨��ţ�
		for(int idx = 0 ; idx < entities.size() - 1; idx++){
			for(int idy = idx + 1 ; idy < entities.size() ; idy++){
				if(entities.get(idx).getSortno() == entities.get(idy).getSortno()){
					logger.error("ϵͳ�����쳣��ָ�����������������ظ�");
					throw new EngineRuntimeException(Constants.EXECUTE_EXCEPTION + ":ָ���������������ظ�:");
				}
			}
		}
		
		try{
			int ednIdx = 0;
			for(int beginIdx = 0 ; beginIdx < entities.size() ; ){
				ednIdx = beginIdx + batchCount < entities.size() ? beginIdx + batchCount : entities.size();
				List<GlsExtd> subExtds = entities.subList(beginIdx, ednIdx);
				beginIdx = beginIdx + batchCount;
				insertRecordCount += glsExtdMapper.insertEntities(subExtds);
			}
			logger.info("ָ����ܱ�����ɹ���������" + insertRecordCount);
		}catch(DuplicateKeyException ex){
			String message = "";
			logger.error(message + ex.getMessage() , ex);
			throw new EngineRuntimeException(Constants.EXECUTE_DUPLICATE + ":�����ظ�����:",ex);
		}catch(Exception ex){
			logger.error("ϵͳ�쳣" + ex.getMessage() , ex);
			throw new EngineRuntimeException(Constants.EXECUTE_EXCEPTION + ":����ʧ��:",ex);
		}
		return insertRecordCount;
	}

	@Override
	public void insertEntity(GlsExtd entity) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		try{
			glsExtdMapper.insertEntity(entity);
		}catch(DuplicateKeyException ex){
			logger.error("ErrorCode=1");
			throw new EngineRuntimeException(Constants.EXECUTE_DUPLICATE + ":�ظ�����:" + ex.getMessage(),ex);
		}catch(Exception ex){
			throw new EngineRuntimeException("����ָ����ܱ�ʧ��:" + ex.getMessage(),ex);
		}
		
	}

	@Override
	public List<GlsExtd> selectEntitiesBatch(List<GlsTran> trans , String trandt , String systid) {
		// TODO Auto-generated method stub
		return glsExtdMapper.selectEntitiesBatch(trans , trandt , systid);
	}

}
