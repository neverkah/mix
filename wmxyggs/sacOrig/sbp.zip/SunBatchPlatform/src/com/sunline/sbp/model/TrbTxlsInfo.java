package com.sunline.sbp.model;

import java.math.BigDecimal;

public class TrbTxlsInfo {
	private int stacid;
	private String systid;
	private String trandt;
	private String transq;
	private String vchrsq;
	private String tranbr;
	private String acctbr;
	private String custcd;
	private String busitp;
	private String crcycd;
	private String vatxrt;
	private String smrytx;
	private String status;
	private String catxtp;
	private String exeptg;
	private String typecd;
	private String crcyiv;
	private BigDecimal tranam;
	private BigDecimal taxbam;
	private BigDecimal pricam;
	private BigDecimal exchrt;
	private BigDecimal expram;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getVchrsq() {
		return vchrsq;
	}
	public void setVchrsq(String vchrsq) {
		this.vchrsq = vchrsq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getCustcd() {
		return custcd;
	}
	public void setCustcd(String custcd) {
		this.custcd = custcd;
	}
	public String getBusitp() {
		return busitp;
	}
	public void setBusitp(String busitp) {
		this.busitp = busitp;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getVatxrt() {
		return vatxrt;
	}
	public void setVatxrt(String vatxrt) {
		this.vatxrt = vatxrt;
	}
	public String getSmrytx() {
		return smrytx;
	}
	public void setSmrytx(String smrytx) {
		this.smrytx = smrytx;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCatxtp() {
		return catxtp;
	}
	public void setCatxtp(String catxtp) {
		this.catxtp = catxtp;
	}
	public String getExeptg() {
		return exeptg;
	}
	public void setExeptg(String exeptg) {
		this.exeptg = exeptg;
	}
	public String getTypecd() {
		return typecd;
	}
	public void setTypecd(String typecd) {
		this.typecd = typecd;
	}
	public String getCrcyiv() {
		return crcyiv;
	}
	public void setCrcyiv(String crcyiv) {
		this.crcyiv = crcyiv;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public BigDecimal getTaxbam() {
		return taxbam;
	}
	public void setTaxbam(BigDecimal taxbam) {
		this.taxbam = taxbam;
	}
	public BigDecimal getPricam() {
		return pricam;
	}
	public void setPricam(BigDecimal pricam) {
		this.pricam = pricam;
	}
	public BigDecimal getExchrt() {
		return exchrt;
	}
	public void setExchrt(BigDecimal exchrt) {
		this.exchrt = exchrt;
	}
	public BigDecimal getExpram() {
		return expram;
	}
	public void setExpram(BigDecimal expram) {
		this.expram = expram;
	}
}
