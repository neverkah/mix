package com.sunline.sbp.dao;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.model.ComCrcy;

public interface ComCrcyDao {
	public ComCrcy getComCrcyByPrimKey(String crcycd) throws AnalyseException;
}
