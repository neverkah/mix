package com.sunline.sbp.dao.impl.rule;

import java.math.BigDecimal;
import java.util.HashMap;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.DataObjectUtil;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.TranamInfoEntity;
import com.sunline.sbp.base.RuleBeanObject;
import com.sunline.sbp.dao.impl.SystemInterfaceDaoImpl;
import com.sunline.sbp.dao.mapper.AsbDpraMapper;
import com.sunline.sbp.dao.mapper.GlsExtdMapper;
import com.sunline.sbp.model.AsbDpra;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;
import com.sunline.sbp.model.SysIomp;

/**
 * ����Ϣ�ʲ��۾ɱ䶯��ϸ
 * @author Zhangjin
 *
 */

public class AsbDpraRule implements RuleBeanObject {
	
	private AsbDpra command = new AsbDpra();
	private AsbDpraMapper asbDpraMapper;
	private GlsExtdMapper glsExtdMapper;
	private SystemInterfaceDaoImpl sysIntfDaoImpl;
	private GlsExtd extd;
	private HashMap<String , Object> data;
	private SysIomp[] iopms;
	private SysIntf sysIntf;
	private SysIntfDetl[] intfDetl;
	
	@Override
	public void setMapOfInIntf(final SysIntf sysIntf , final SysIomp[] iopms ,final SysIntfDetl[] detls) {
		// TODO Auto-generated method stub
		this.iopms = iopms;
		this.sysIntf = sysIntf;
		this.intfDetl = detls;
	}

	@Override
	public String initialize(HashMap<String , Object> data) throws AnalyseException {
		// TODO Auto-generated method stub 
		command.setAsetno(DataObjectUtil.getHashMapStr(data,"asetno").toString());
		command.setCrcycd(DataObjectUtil.getHashMapStr(data,"crcycd").toString());
		command.setDtitcd(DataObjectUtil.getHashMapStr(data,"prodcd").toString());
		command.setTranam(BigDecimal.valueOf(Double.parseDouble(DataObjectUtil.getHashMapStr(data,"dpravl","00").toString())));
		command.setReastp(DataObjectUtil.getHashMapStr(data,"reastp","00").toString());
		command.setDtitcd(DataObjectUtil.getHashMapStr(data,"dtitcd","00").toString());
		command.setSystid(DataObjectUtil.getHashMapStr(data,"systid").toString());
		command.setTranbr(DataObjectUtil.getHashMapStr(data,"tranbr").toString());
		command.setAmntcd(DataObjectUtil.getHashMapStr(data,"amntcd").toString());
		command.setTrandt(DataObjectUtil.getHashMapStr(data,"trandt").toString());
		command.setTransq(DataObjectUtil.getHashMapStr(data,"transq").toString());
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public String check() throws EngineRuntimeException {
		// TODO Auto-generated method stub
		//sysIntfDaoImpl.checkValidate(sysIntf,data);
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public GlsExtd execute(int orderCount) {
		// TODO Auto-generated method stub
		//asbDpraMapper.insertEntity(command);
		
		extd = new GlsExtd();
		extd.setStacid(command.getStacid());
		extd.setSystid(command.getSystid());
		extd.setTrandt(command.getTrandt());
		extd.setTranbr(command.getTranbr());
		extd.setTransq(command.getTransq());
		extd.setSortno(orderCount);
		extd.setCmmdtg(Constants.COMMAND_IDENTITY_AD);
		extd.setAmntcd(command.getAmntcd());
		extd.setCrcycd(command.getCrcycd());
		extd.setTranam(command.getTranam());
		
		//glsExtdMapper.insertEntity(command.getSystid(),command.getTrandt(),command.getTransq(),orderCount,Constants.COMMAND_IDENTITY_AD,command.getAmntcd(),command.getCrcycd(),command.getTranam());
		return extd;
	}

	@Override
	public TranamInfoEntity getTranamInfo() {
		// TODO Auto-generated method stub
		return new TranamInfoEntity(command.getAmntcd(),command.getTranam());
	}

	public AsbDpraMapper getAsbDpraMapper() {
		return asbDpraMapper;
	}

	public void setAsbDpraMapper(AsbDpraMapper asbDpraMapper) {
		this.asbDpraMapper = asbDpraMapper;
	}

	public GlsExtdMapper getGlsExtdMapper() {
		return glsExtdMapper;
	}

	public void setGlsExtdMapper(GlsExtdMapper glsExtdMapper) {
		this.glsExtdMapper = glsExtdMapper;
	}

	public SystemInterfaceDaoImpl getSysIntfDaoImpl() {
		return sysIntfDaoImpl;
	}

	public void setSysIntfDaoImpl(SystemInterfaceDaoImpl sysIntfDaoImpl) {
		this.sysIntfDaoImpl = sysIntfDaoImpl;
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return data;
	}

	@Override
	public JSONObject getCmmd() {
		// TODO Auto-generated method stub
		return (JSONObject)JSON.toJSON(command);
	}
}
