package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.AsbTran;

public interface AsbTranMapper {
	public void insertObject(AsbTran asbtran);
	public AsbTran selectEntity(@Param("trandt") String trandt , @Param("transq") String transq , @Param("cmmdsq") String cmmdsq , @Param("systid") String systid);
	public int updateBkfnstSucc(AsbTran asbtran);
}
