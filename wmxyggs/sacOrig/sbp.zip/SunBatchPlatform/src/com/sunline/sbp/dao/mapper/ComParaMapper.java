package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.ComPara;

/**
 * �ͻ�������
 * @author xiaotian
 *
 */
public interface ComParaMapper {
	public ComPara getEntityByPrimKey(@Param("stacid") int stacid , @Param("parana") String parana);
}
