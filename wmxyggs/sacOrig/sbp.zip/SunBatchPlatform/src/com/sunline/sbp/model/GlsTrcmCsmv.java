package com.sunline.sbp.model;

import java.math.BigDecimal;

public class GlsTrcmCsmv {
	
	private int stacid;
	private String systid;
	private String trandt;
	private String csmvsq;
	private String transq;
	private String tranbr;
	private String csbxtp;
	private String csbxno;
	private String acctbr;
	private String crcycd;
	private BigDecimal tranam;
	private String amntcd;
	private String bkfnst;
	
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getCsmvsq() {
		return csmvsq;
	}
	public void setCsmvsq(String csmvsq) {
		this.csmvsq = csmvsq;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getCsbxtp() {
		return csbxtp;
	}
	public void setCsbxtp(String csbxtp) {
		this.csbxtp = csbxtp;
	}
	public String getCsbxno() {
		return csbxno;
	}
	public void setCsbxno(String csbxno) {
		this.csbxno = csbxno;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}
	public String getBkfnst() {
		return bkfnst;
	}
	public void setBkfnst(String bkfnst) {
		this.bkfnst = bkfnst;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	
}
