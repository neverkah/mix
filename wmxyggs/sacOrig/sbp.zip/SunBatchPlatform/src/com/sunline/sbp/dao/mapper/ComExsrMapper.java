package com.sunline.sbp.dao.mapper;

import java.util.List;

import com.sunline.sbp.model.ComExsr;

public interface ComExsrMapper {
	public List<ComExsr> getAllEntities();
}
