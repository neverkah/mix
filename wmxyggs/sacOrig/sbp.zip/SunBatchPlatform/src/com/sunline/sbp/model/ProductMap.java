package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * ��Ʒģ��ӳ���(sys_pmap)
 * @author Zhangjin
 *
 */
public class ProductMap implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 38871461108193354L;
	private int stacid;
	private String prodcd;
	private String trancd;
	private String corrtg;
	private String tmpltp;
	private String tmplid;
	private String vermod;
	private String module;
	private String projcd;
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public String getTrancd() {
		return trancd;
	}
	public void setTrancd(String trancd) {
		this.trancd = trancd;
	}
	public String getCorrtg() {
		return corrtg;
	}
	public void setCorrtg(String corrtg) {
		this.corrtg = corrtg;
	}
	public String getTmpltp() {
		return tmpltp;
	}
	public void setTmpltp(String tmpltp) {
		this.tmpltp = tmpltp;
	}
	public String getTmplid() {
		return tmplid;
	}
	public void setTmplid(String tmplid) {
		this.tmplid = tmplid;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
	
	
}
