/*
 * (C) 2007-2012 Alibaba Group Holding Limited.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * Authors:
 *   wuhua <wq163@163.com> , boyan <killme2008@gmail.com>
 */
package com.sunline.sbp.application;

import static com.sunline.sbp.application.Help.initMetaConfig;

import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.dao.AccountingTreatmentDao;
import com.sunline.sbp.dao.AnalyseCenterDao;
import com.sunline.sbp.datamerger.BusiDecisionMaker;
import com.sunline.sbp.datamerger.BusinessObject;
import com.sunline.sbp.model.GlsExtd;
import com.taobao.metamorphosis.Message;
import com.taobao.metamorphosis.client.MessageSessionFactory;
import com.taobao.metamorphosis.client.MetaMessageSessionFactory;
import com.taobao.metamorphosis.client.consumer.ConsumerConfig;
import com.taobao.metamorphosis.client.consumer.MessageConsumer;
import com.taobao.metamorphosis.client.consumer.MessageListener;


/**
 * ����ϵͳ�첽��Ϣ������
 * 
 * @author boyan
 * @Date 2011-5-17
 * 
 */
public class FIAsyncConsumer {
	static int mycount = 0;
	static long timeMy = 0;
	
	private static Logger logger = Logger.getLogger(FIAsyncConsumer.class);
	
    public static void main(final String[] args) throws Exception {
        // New session factory,ǿ�ҽ���ʹ�õ���
        final MessageSessionFactory sessionFactory = new MetaMessageSessionFactory(initMetaConfig());

        // subscribed topic
        final String topic = "gl-busi";
        // consumer group
        final String group = "meta-fi";
        // create consumer,ǿ�ҽ���ʹ�õ���
        final MessageConsumer consumer = sessionFactory.createConsumer(new ConsumerConfig(group));
        // subscribe topic
        
        consumer.subscribe(topic, 1024 * 1024, new MessageListener() {
        	
            @Override
            public void recieveMessages(final Message message) {
            	
            	String bussinessInfo = null;
				//try {
					bussinessInfo = new String(message.getData());
				//} catch (UnsupportedEncodingException e) {
				//	// TODO Auto-generated catch block
				//	e.printStackTrace();
				//}
            	JSONObject jsonObject = null;
            	try{
            		jsonObject = JSONObject.parseObject(bussinessInfo);
            	}catch(Exception ex){
            		logger.error("===================================================//");
            		logger.error(bussinessInfo);
            		logger.error("===================================================//~");
            		
            		ex.printStackTrace();
            		return;
            	}
            	long beginT = System.nanoTime();
            	
            	BusinessObject businessObject;
            	AnalyseCenterDao analyseCenter;
            	
            	//���׷���
            	try{
            		
            		//���ɹ鼯���ݶ���
                	businessObject = BusiDecisionMaker.createBusiness(jsonObject);
                	analyseCenter = (AnalyseCenterDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AnalyseCenterDao.class);
                	ArrayList<GlsExtd> extds = analyseCenter.dealBusiEntityTransaction(businessObject);
                	
                	/*GlsExtd extdEntity = new GlsExtd();
                	extdEntity.setSystid(businessObject.getSystid());
                	extdEntity.setTrandt(businessObject.getBsnsdt());
                	extdEntity.setTransq(businessObject.getBsnssq());*/
                	//���׷���
                	AccountingTreatmentDao ap = (AccountingTreatmentDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AccountingTreatmentDao.class);
            		ap.processVectorTransaction(extds);
                	
            	}catch(Exception ex){
            		logger.error("===================================================//");
            		logger.error(bussinessInfo);
            		ex.printStackTrace();
            		logger.error("===================================================//~");
            		try {
						//throw new Exception("ҵ����ʧ��");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
            	}
        		long endT = System.nanoTime();
        		timeMy = timeMy + (endT - beginT)/1000000L;
            }

            @Override
            public Executor getExecutor() {
                // Thread pool to process messages,maybe null.
                //return null;
            	//Executors.newCachedThreadPool();
            	ExecutorService executor = Executors.newFixedThreadPool(8);
            	return executor;
            }
        });
        // complete subscribe
        consumer.completeSubscribe();
    }
    
    public static void printTime(){
    	Logger.getLogger(FIAsyncConsumer.class).debug(System.nanoTime()/1000000L);
    }

}