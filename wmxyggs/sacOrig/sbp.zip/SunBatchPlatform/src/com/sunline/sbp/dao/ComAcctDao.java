package com.sunline.sbp.dao;

import java.util.List;

import com.sunline.sbp.model.ComAcct;

public interface ComAcctDao {
	public List<ComAcct> getAllEntities();
}
