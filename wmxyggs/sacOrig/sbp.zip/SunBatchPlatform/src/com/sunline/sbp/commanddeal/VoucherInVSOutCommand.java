package com.sunline.sbp.commanddeal;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.dao.mapper.VoucherInVSOutMapper;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.VoucherInVSOut;

/**
 * ƾ֤�����ָ��(gls_trcm_dcio)
 * @author Hopechj
 *
 */

public class VoucherInVSOutCommand implements TranCommandObject {
	
	private VoucherInVSOutMapper voucherInVSOutMapper;
	private VoucherInVSOut command;
	private GlaVoucher glaVoucher;
	
	private Logger logger = Logger.getLogger(VoucherInVSOutCommand.class);

	@Override
	public void initialize(String trandt, String transq , String cmmdsq, String systid) throws AnalyseException {
		// TODO Auto-generated method stub
		command = voucherInVSOutMapper.selectEntity(trandt, transq , cmmdsq,systid);
		if( null == command){
			logger.error("��ȡ��������ʧ�ܣ�" + "�������ڣ�" + trandt + ",ָ����ˮ��" + cmmdsq);
			throw new AnalyseException("��ȡ��������ʧ�ܣ�" + "�������ڣ�" + trandt + ",ָ����ˮ��" + cmmdsq);
		}
	}

	@Override
	public void setVoucherInfo() {
		// TODO Auto-generated method stub
		glaVoucher = new GlaVoucher();
		glaVoucher.setAcctbr(command.getBrchcd());
		glaVoucher.setAcctno("*");
		glaVoucher.setAmntcd(command.getRcpytg());
		glaVoucher.setAssis0("*");
		glaVoucher.setAssis1("*");
		glaVoucher.setAssis3("*");
		glaVoucher.setAssis4("*");
		glaVoucher.setAssis5("*");
		glaVoucher.setAssis6("*");
		glaVoucher.setAssis7("*");
		glaVoucher.setAssis8("*");
		glaVoucher.setAssis9("*");
		glaVoucher.setCentcd("*");
		
		//������Ĭ��Ϊ������ҡ�
		glaVoucher.setCrcycd(Constants.CRCYCD_RMB);
		
		//ƾ֤����
		glaVoucher.setItemcd(command.getDcmttp());
		
		glaVoucher.setPrducd("*");
		glaVoucher.setPrlncd("*");
		glaVoucher.setPrsncd("*");
		glaVoucher.setSmrytx(command.getSmrycd());
		glaVoucher.setSourdt(command.getTrandt());
		glaVoucher.setSoursq(command.getTransq());
		glaVoucher.setSourst(command.getSystid());
		glaVoucher.setStacid(command.getStacid());
		glaVoucher.setSystid(command.getSystid());
		glaVoucher.setTranam(command.getTranam());
		glaVoucher.setTranbr(command.getTranbr());
		glaVoucher.setTrandt(command.getTrandt());
		glaVoucher.setTrantp(Enumeration.TRANTP.TRAN.value);
		glaVoucher.setUsercd(Enumeration.USERCD.ENGINE.value);
		glaVoucher.setClertg(Enumeration.CLERTG.CLERTG_0.value);
	}

	@Override
	public String getTrprcd() {
		// TODO Auto-generated method stub
		return Constants.TRPRCD_DEFAULT;
	}

	@Override
	public String getDtitcd() {
		// TODO Auto-generated method stub
		return "OT".concat(command.getDcmttp());
	}

	@Override
	public GlaVoucher getGlaVoucher() {
		// TODO Auto-generated method stub
		return this.glaVoucher;
	}

	@Override
	public String postingSucc() {
		// TODO Auto-generated method stub
		String executeResult;
		try{
			voucherInVSOutMapper.postingUpdate(command);
			executeResult = Constants.EXECUTE_SUCC;
		}catch(Exception ex){
			executeResult = Constants.EXECUTE_FAIL;
		}
		return executeResult;
	}

	public VoucherInVSOutMapper getVoucherInVSOutMapper() {
		return voucherInVSOutMapper;
	}

	public void setVoucherInVSOutMapper(VoucherInVSOutMapper voucherInVSOutMapper) {
		this.voucherInVSOutMapper = voucherInVSOutMapper;
	}

	@Override
	public String getTrancd() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getStacid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getStacid();
	}

	@Override
	public void initialize(JSONObject jsonObject) throws AnalyseException {
		// TODO Auto-generated method stub
		command = JSON.parseObject(jsonObject.toJSONString(), VoucherInVSOut.class);
	}

	@Override
	public String getTrandt() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTrandt();
	}

	@Override
	public String getSystid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getSystid();
	}

	@Override
	public String getTransq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTransq();
	}

	@Override
	public String getCmmdsq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getDciosq();
	}

}
