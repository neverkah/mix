package com.sunline.sbp.model;

public class TxpTypeOpen {
	
	private int stacid;
	private String propcd;
	private String propna;
	private String openst;
	private int ordrno;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getPropcd() {
		return propcd;
	}
	public void setPropcd(String propcd) {
		this.propcd = propcd;
	}
	public String getPropna() {
		return propna;
	}
	public void setPropna(String propna) {
		this.propna = propna;
	}
	public String getOpenst() {
		return openst;
	}
	public void setOpenst(String openst) {
		this.openst = openst;
	}
	public int getOrdrno() {
		return ordrno;
	}
	public void setOrdrno(int ordrno) {
		this.ordrno = ordrno;
	}
}
