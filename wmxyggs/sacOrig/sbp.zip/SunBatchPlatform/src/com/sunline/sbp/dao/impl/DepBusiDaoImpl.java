package com.sunline.sbp.dao.impl;

import com.sunline.sbp.dao.DepBusiDao;
import com.sunline.sbp.dao.mapper.DepBusiMapper;
import com.sunline.sbp.model.DepBusi;

public class DepBusiDaoImpl implements DepBusiDao {
	
	private DepBusiMapper depBusiMapper;

	@Override
	public DepBusi[] getEntities(DepBusi entity) {
		// TODO Auto-generated method stub
		return depBusiMapper.selectEntities(entity);
	}

	public DepBusiMapper getDepBusiMapper() {
		return depBusiMapper;
	}

	public void setDepBusiMapper(DepBusiMapper depBusiMapper) {
		this.depBusiMapper = depBusiMapper;
	}
	
	
}
