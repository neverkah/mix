package com.sunline.sbp.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.GlsTran;

public interface GlsExtdMapper {
	public GlsExtd[] selectEntities(GlsExtd entity);

	public void insertEntity(GlsExtd entity);
	
	public int insertEntities(List<GlsExtd> list);
	
	public GlsExtd[] selectEntity(@Param("systid") String systid , @Param("trandt") String trandt , @Param("transq") String transq);
	
	public List<GlsExtd> selectEntitiesBatch(@Param("list") List<GlsTran> trans , @Param("systid") String systid , @Param("trandt") String trandt);
	
	/**
	 * �����ɹ�
	 * @param systid
	 * @param transq
	 * @param trandt
	 * @param sortno
	 * @return
	 */
	public int toTagSucc(@Param("systid") String systid ,@Param("transq") String transq, @Param("trandt") String trandt , @Param("sortno") int sortno);
}
