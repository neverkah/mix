package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.dao.ComParaDao;
import com.sunline.sbp.dao.mapper.ComParaMapper;
import com.sunline.sbp.model.ComPara;

public class ComParaDaoImpl implements ComParaDao {
	
	private Logger logger = Logger.getLogger(ComParaDaoImpl.class);
	private ComParaMapper comParaMapper;

	@Override
	public ComPara getParamInfoByKey(int stacid, String parana)
			throws AnalyseException {
		// TODO Auto-generated method stub
		if(null == comParaMapper){
			logger.debug("comParaMapper δ��ʼ����");
			throw new AnalyseException("ϵͳ�쳣");
		}else{
			logger.debug("comParaMapper ��ʼ���ɹ���");
		}
		ComPara paraEntity = comParaMapper.getEntityByPrimKey(stacid,parana);
		if(null == paraEntity){
			logger.error("����["+stacid+"]��δ���ò���["+parana+"]");
			throw new AnalyseException("����["+stacid+"]��δ���ò���["+parana+"]");
		}else{
			logger.debug("����["+stacid+"]�в���["+parana+"]��Ϣ��ȡ�ɹ�");
		}
		return paraEntity;
	}
	
	public ComParaMapper getComParaMapper() {
		return comParaMapper;
	}

	public void setComParaMapper(ComParaMapper comParaMapper) {
		this.comParaMapper = comParaMapper;
	}

}
