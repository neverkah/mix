package com.sunline.sbp.dao.impl;

import java.util.Hashtable;
import java.util.List;

import com.sunline.foundation.Constants;
import com.sunline.sbp.dao.ComCentDao;
import com.sunline.sbp.dao.mapper.ComCentMapper;
import com.sunline.sbp.model.ComCent;

public class ComCentDaoImpl implements ComCentDao {
	
	private ComCentMapper comCentMapper;
	
	private int initail = 0;
	
	/**
	 * ȫ��Ϣ����
	 */
	private static Hashtable<String,ComCent> centDatas = new Hashtable<String,ComCent>();

	@Override
	public List<ComCent> getAllEntities() {
		// TODO Auto-generated method stub
		List<ComCent> tableData = comCentMapper.getAllEntities();
		for(ComCent entity : tableData){
			centDatas.put(entity.getStacid()+Constants.DTAG+entity.getBrchcd(), entity);
		}
		return tableData;
	}
	
	public Hashtable<String,ComCent> getCacheData(){
		if(initail == 0){
			synchronized(this) {
				if(initail == 0){
					getAllEntities();
					initail = 1;
				}
			}
		}
		return centDatas;
	}
	
	public boolean frushCache(){
		centDatas.clear();
		getAllEntities();
		return true;
	}

	public ComCentMapper getComCentMapper() {
		return comCentMapper;
	}

	public void setComCentMapper(ComCentMapper comCentMapper) {
		this.comCentMapper = comCentMapper;
	}
}
