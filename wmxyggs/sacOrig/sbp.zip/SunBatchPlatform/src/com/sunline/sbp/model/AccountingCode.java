package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * ������루sys_dtit��
 * @author Zhangjin
 *
 */

public class AccountingCode implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int stacid;
	private String typecd;
	private String trprcd;
	private String dtitna;
	private String itemcd;
	private String reitem;
	private String usedtp;
	private String efctdt;
	private String inefdt;
	private String desctx;
	
	
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getTypecd() {
		return typecd;
	}
	public void setTypecd(String typecd) {
		this.typecd = typecd;
	}
	public String getDtitna() {
		return dtitna;
	}
	public void setDtitna(String dtitna) {
		this.dtitna = dtitna;
	}
	public String getItemcd() {
		return itemcd;
	}
	public void setItemcd(String itemcd) {
		this.itemcd = itemcd;
	}
	public String getReitem() {
		return reitem;
	}
	public void setReitem(String reitem) {
		this.reitem = reitem;
	}
	public String getUsedtp() {
		return usedtp;
	}
	public void setUsedtp(String usedtp) {
		this.usedtp = usedtp;
	}
	public String getEfctdt() {
		return efctdt;
	}
	public void setEfctdt(String efctdt) {
		this.efctdt = efctdt;
	}
	public String getInefdt() {
		return inefdt;
	}
	public void setInefdt(String inefdt) {
		this.inefdt = inefdt;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public void setTrprcd(String trprcd){
		this.trprcd = trprcd;
	}
	public String getTrprcd() {
		return trprcd;
	}
}
