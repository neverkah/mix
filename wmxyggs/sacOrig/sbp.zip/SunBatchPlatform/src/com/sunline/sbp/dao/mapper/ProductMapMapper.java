package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.ProductMap;

public interface ProductMapMapper {
	public ProductMap[] getTempleteOfProduct(ProductMap productMap);
}
