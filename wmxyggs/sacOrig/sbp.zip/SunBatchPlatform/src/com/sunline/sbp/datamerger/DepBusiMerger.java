package com.sunline.sbp.datamerger;

import com.sunline.sbp.model.DepBusi;
//import com.sunline.sbp.model.DepositDrawalInterest;

/**
 * �������ݹ鼯��
 * @author Zhangjin
 *
 */
public class DepBusiMerger implements BusinessObject {
	
	private DepBusi busi;
	private String prcscd;
	private String typecd;
	private String prodcd;
	private int stacid;
	
	public String getProdcd(){
		return prodcd;
	}
	
	public void setProdcd(String prodcd){
		this.prodcd = prodcd;
	}
	
	public DepBusiMerger(DepBusi busi){
		this.busi = busi;
		this.prcscd = busi.getPrcscd();
		this.typecd = busi.getDcmttp() + busi.getTermcd();
		this.stacid = busi.getStacid();
	}
	
	@Override
	public String getPrcscd() {
		// TODO Auto-generated method stub
		return prcscd;
	}

	@Override
	public String getBusiType() {
		// TODO Auto-generated method stub
		return typecd;
	}

	@Override
	public Object getBusinessObject() {
		// TODO Auto-generated method stub
		return busi;
	}

	@Override
	public String getBsnsdt() {
		// TODO Auto-generated method stub
		return busi.getTrandt();
	}

	@Override
	public String getBsnssq() {
		// TODO Auto-generated method stub
		return busi.getTransq();
	}

	@Override
	public String getSystid() {
		// TODO Auto-generated method stub
		return busi.getSystid();
	}

	@Override
	public int getStacid() {
		// TODO Auto-generated method stub
		return stacid;
	}

	@Override
	public void setStacid(int stacid) {
		// TODO Auto-generated method stub
		this.busi.setStacid(stacid);
	}

}
