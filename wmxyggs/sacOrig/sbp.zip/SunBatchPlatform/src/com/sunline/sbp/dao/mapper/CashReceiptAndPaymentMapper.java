package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.CashReceiptAndPayment;

public interface CashReceiptAndPaymentMapper {
	public String insertEntity(CashReceiptAndPayment entity);
	public CashReceiptAndPayment selectEntity(@Param("trandt") String trandt , @Param("transq") String transq , @Param("cmmdsq") String cmmdsq , @Param("systid") String systid);
	public void postingUpdate(CashReceiptAndPayment entity);
}
