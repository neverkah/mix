package com.sunline.sbp.model;

import java.math.BigDecimal;

public class GlaGlis {
	private int stacid;
	private String acctdt;
	private String systid;
	private String brchcd;
	private String itemcd;
	private String centcd;
	private String prsncd;
	private String custcd;
	private String prducd;
	private String prlncd;
	private String acctno;
	private String assis0;
	private String assis1;
	private String assis2;
	private String assis3;
	private String assis4;
	private String assis5;
	private String assis6;
	private String assis7;
	private String assis8;
	private String assis9;
	private String geldtp;
	private String crcycd;
	private String drltbl;
	private String crltbl;
	private BigDecimal drtsam;
	private int drtsnm;
	private BigDecimal crtsam;
	private int crtsnm;
	private BigDecimal drctbl;
	private BigDecimal crctbl;
	private String blncdn;
	private BigDecimal onlnbl;
	private String lastdn;
	private BigDecimal lastbl;
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getAcctdt() {
		return acctdt;
	}
	public void setAcctdt(String acctdt) {
		this.acctdt = acctdt;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getBrchcd() {
		return brchcd;
	}
	public void setBrchcd(String brchcd) {
		this.brchcd = brchcd;
	}
	public String getItemcd() {
		return itemcd;
	}
	public void setItemcd(String itemcd) {
		this.itemcd = itemcd;
	}
	public String getCentcd() {
		return centcd;
	}
	public void setCentcd(String centcd) {
		this.centcd = centcd;
	}
	public String getPrsncd() {
		return prsncd;
	}
	public void setPrsncd(String prsncd) {
		this.prsncd = prsncd;
	}
	public String getCustcd() {
		return custcd;
	}
	public void setCustcd(String custcd) {
		this.custcd = custcd;
	}
	public String getPrducd() {
		return prducd;
	}
	public void setPrducd(String prducd) {
		this.prducd = prducd;
	}
	public String getPrlncd() {
		return prlncd;
	}
	public void setPrlncd(String prlncd) {
		this.prlncd = prlncd;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getAssis0() {
		return assis0;
	}
	public void setAssis0(String assis0) {
		this.assis0 = assis0;
	}
	public String getAssis1() {
		return assis1;
	}
	public void setAssis1(String assis1) {
		this.assis1 = assis1;
	}
	public String getAssis2() {
		return assis2;
	}
	public void setAssis2(String assis2) {
		this.assis2 = assis2;
	}
	public String getAssis3() {
		return assis3;
	}
	public void setAssis3(String assis3) {
		this.assis3 = assis3;
	}
	public String getAssis4() {
		return assis4;
	}
	public void setAssis4(String assis4) {
		this.assis4 = assis4;
	}
	public String getAssis5() {
		return assis5;
	}
	public void setAssis5(String assis5) {
		this.assis5 = assis5;
	}
	public String getAssis6() {
		return assis6;
	}
	public void setAssis6(String assis6) {
		this.assis6 = assis6;
	}
	public String getAssis7() {
		return assis7;
	}
	public void setAssis7(String assis7) {
		this.assis7 = assis7;
	}
	public String getAssis8() {
		return assis8;
	}
	public void setAssis8(String assis8) {
		this.assis8 = assis8;
	}
	public String getAssis9() {
		return assis9;
	}
	public void setAssis9(String assis9) {
		this.assis9 = assis9;
	}
	public String getGeldtp() {
		return geldtp;
	}
	public void setGeldtp(String geldtp) {
		this.geldtp = geldtp;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getDrltbl() {
		return drltbl;
	}
	public void setDrltbl(String drltbl) {
		this.drltbl = drltbl;
	}
	public String getCrltbl() {
		return crltbl;
	}
	public void setCrltbl(String crltbl) {
		this.crltbl = crltbl;
	}
	public BigDecimal getDrtsam() {
		return drtsam;
	}
	public void setDrtsam(BigDecimal drtsam) {
		this.drtsam = drtsam;
	}
	public int getDrtsnm() {
		return drtsnm;
	}
	public void setDrtsnm(int drtsnm) {
		this.drtsnm = drtsnm;
	}
	public BigDecimal getCrtsam() {
		return crtsam;
	}
	public void setCrtsam(BigDecimal crtsam) {
		this.crtsam = crtsam;
	}
	public int getCrtsnm() {
		return crtsnm;
	}
	public void setCrtsnm(int crtsnm) {
		this.crtsnm = crtsnm;
	}
	public BigDecimal getDrctbl() {
		return drctbl;
	}
	public void setDrctbl(BigDecimal drctbl) {
		this.drctbl = drctbl;
	}
	public BigDecimal getCrctbl() {
		return crctbl;
	}
	public void setCrctbl(BigDecimal crctbl) {
		this.crctbl = crctbl;
	}
	public String getBlncdn() {
		return blncdn;
	}
	public void setBlncdn(String blncdn) {
		this.blncdn = blncdn;
	}
	public BigDecimal getOnlnbl() {
		return onlnbl;
	}
	public void setOnlnbl(BigDecimal onlnbl) {
		this.onlnbl = onlnbl;
	}
	public String getLastdn() {
		return lastdn;
	}
	public void setLastdn(String lastdn) {
		this.lastdn = lastdn;
	}
	public BigDecimal getLastbl() {
		return lastbl;
	}
	public void setLastbl(BigDecimal lastbl) {
		this.lastbl = lastbl;
	}
}
