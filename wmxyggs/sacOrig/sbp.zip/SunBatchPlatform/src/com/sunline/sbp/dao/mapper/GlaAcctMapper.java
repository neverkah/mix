package com.sunline.sbp.dao.mapper;

import java.math.BigDecimal;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.GlaAcct;
import com.sunline.sbp.model.GlaVoucher;

public interface GlaAcctMapper {
	
	public List<GlaAcct> selectEntitiesByGlaVoucher(GlaVoucher glaVoucher);
	
	public GlaAcct selectEntityByAccount(@Param("acctcd") String acctcd);
	
	public int insertGlaAcct(GlaAcct acctInfo);
	
	/**
	 * �����˻����
	 * @param acctno �˺�
	 * @param onlnbl ���
	 * @param lstrsq �������ˮ
	 * @param lstrdt ���������
	 * @param blncdn ����
	 */
	public int updateBalance(@Param("acctcd") String acctcd , @Param("onlnbl") BigDecimal onlnbl ,
			@Param("lstrsq") String lstrsq , @Param("lstrdt") String lstrdt , @Param("blncdn") String blncdn);
}
