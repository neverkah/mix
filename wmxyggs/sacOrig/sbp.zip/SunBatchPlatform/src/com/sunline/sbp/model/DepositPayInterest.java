package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * ��Ϣָ��
 * ����gls_cmdd_pyin
 * @author Hopechj
 *
 */
public class DepositPayInterest {
	private int stacid;
	private String systid;
	private String trandt;
	private String pyinsq;
	private String transq;
	private String tranbr;
	private String trantp;
	private String crcycd;
	private BigDecimal tranam;
	private String acctbr;
	private String acctno;
	private String subsac;
	private String dtitcd;
	private String stdate;
	private String eddate;
	private BigDecimal acmlbl;
	private String corrtg;
	private String bkfnst;
	private String calcfg;
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getPyinsq() {
		return pyinsq;
	}
	public void setPyinsq(String pyinsq) {
		this.pyinsq = pyinsq;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getSubsac() {
		return subsac;
	}
	public void setSubsac(String subsac) {
		this.subsac = subsac;
	}
	public String getDtitcd() {
		return dtitcd;
	}
	public void setDtitcd(String dtitcd) {
		this.dtitcd = dtitcd;
	}
	public String getStdate() {
		return stdate;
	}
	public void setStdate(String stdate) {
		this.stdate = stdate;
	}
	public String getEddate() {
		return eddate;
	}
	public void setEddate(String eddate) {
		this.eddate = eddate;
	}
	public BigDecimal getAcmlbl() {
		return acmlbl;
	}
	public void setAcmlbl(BigDecimal acmlbl) {
		this.acmlbl = acmlbl;
	}
	public String getCorrtg() {
		return corrtg;
	}
	public void setCorrtg(String corrtg) {
		this.corrtg = corrtg;
	}
	public String getBkfnst() {
		return bkfnst;
	}
	public void setBkfnst(String bkfnst) {
		this.bkfnst = bkfnst;
	}
	public String getCalcfg() {
		return calcfg;
	}
	public void setCalcfg(String calcfg) {
		this.calcfg = calcfg;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	
	
}
