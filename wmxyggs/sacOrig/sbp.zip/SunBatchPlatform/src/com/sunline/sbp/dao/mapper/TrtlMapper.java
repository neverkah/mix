package com.sunline.sbp.dao.mapper;


import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.SysTrtl;

public interface TrtlMapper {
	public SysTrtl[] getTrtl(@Param("stacid") int stacid ,@Param("prcscd") String prcscd , @Param("projcd") String projcd);
}
