package com.sunline.sbp.dao;

import com.sunline.sbp.model.ProcessTemplateMap;

public interface TemplateMapOfProcessDao {
	public ProcessTemplateMap[] getMapOfTemplate(ProcessTemplateMap processTemplateMap);
}
