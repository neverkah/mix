package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.SysTmapTran;

public interface TmapTranMapper {
	public SysTmapTran[] getTmapsOfTran(SysTmapTran sysTmapTran);
}
