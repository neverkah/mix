package com.sunline.sbp.dao;

import com.sunline.sbp.model.AsbDpra;

public interface AsbDpraDao {
	public void insert(AsbDpra entity);
}
