package com.sunline.sbp.dao.mapper;

import java.util.List;

import com.sunline.sbp.model.ComPrsn;

public interface ComPrsnMapper {
	public List<ComPrsn> getAllEntities();
}
