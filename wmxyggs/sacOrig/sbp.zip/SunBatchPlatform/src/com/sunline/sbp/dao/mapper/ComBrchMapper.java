package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.ComBrch;

public interface ComBrchMapper {
	public ComBrch getEntityByPrimKey(@Param("stacid") int stacid , @Param("brchcd") String brchcd);
	public ComBrch[] getAll();
}
