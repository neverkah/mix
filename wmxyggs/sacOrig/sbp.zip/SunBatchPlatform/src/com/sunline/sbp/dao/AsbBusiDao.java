package com.sunline.sbp.dao;

import com.sunline.sbp.model.AsbBusi;

public interface AsbBusiDao {
	public AsbBusi[] selectBusi(AsbBusi entity);
	public void excuteSucc(AsbBusi asbBusi);
}
