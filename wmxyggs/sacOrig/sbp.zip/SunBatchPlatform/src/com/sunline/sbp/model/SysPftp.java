package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * �������ͱ�(sys_pftp)
 * @author Zhangjin
 *
 */
public class SysPftp implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4647155767037709130L;
	String proftp;
	String pftpna;
	String proccd;
	String desctx;
	String enname;
	String vermod;
	String module;
	String projcd;
	public String getProftp() {
		return proftp;
	}
	public void setProftp(String proftp) {
		this.proftp = proftp;
	}
	public String getPftpna() {
		return pftpna;
	}
	public void setPftpna(String pftpna) {
		this.pftpna = pftpna;
	}
	public String getProccd() {
		return proccd;
	}
	public void setProccd(String proccd) {
		this.proccd = proccd;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getEnname() {
		return enname;
	}
	public void setEnname(String enname) {
		this.enname = enname;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
}
