package com.sunline.sbp.datamerger;

import com.sunline.sbp.model.AsbBusi;

public class AsbBusiMerger implements BusinessObject {
	private AsbBusi asbBusi;
	private String prcscd;
	private String typecd;
	
	public String getProdcd(){
		return asbBusi.getProdcd();
	}
	
	public AsbBusiMerger(AsbBusi asbBusi){
		this.asbBusi = asbBusi;
		this.prcscd = asbBusi.getPrcscd();
		this.typecd = asbBusi.getAsettp();
	}
	
	public String getPrcscd(){
		return this.prcscd;
	}

	@Override
	public String getBusiType() {
		// TODO Auto-generated method stub
		return this.typecd;
	}

	@Override
	public Object getBusinessObject() {
		// TODO Auto-generated method stub
		return this.asbBusi;
	}

	@Override
	public String getBsnsdt() {
		// TODO Auto-generated method stub
		return asbBusi.getTrandt();
	}

	@Override
	public String getBsnssq() {
		// TODO Auto-generated method stub
		return asbBusi.getTransq();
	}

	@Override
	public String getSystid() {
		// TODO Auto-generated method stub
		return asbBusi.getSystid();
	}

	@Override
	public int getStacid() {
		// TODO Auto-generated method stub
		return asbBusi.getStacid();
	}

	@Override
	public void setStacid(int stacid) {
		// TODO Auto-generated method stub
		this.asbBusi.setStacid(stacid);
	}
}
