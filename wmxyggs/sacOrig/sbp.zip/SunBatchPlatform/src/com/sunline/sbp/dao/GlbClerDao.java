package com.sunline.sbp.dao;


import java.util.List;

import com.sunline.sbp.model.GlbCler;

public interface GlbClerDao {
	public int save(List<GlbCler> entities);
	public int updateTrandtTransq(GlbCler entitie);
}
