package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.AsbDpra;

public interface AsbDpraMapper {
	public void insertEntity(AsbDpra entity);
	public AsbDpra selectEntity(@Param("trandt") String trandt , @Param("transq") String transq , @Param("cmmdsq") String cmmdsq , @Param("systid") String systid);
	public void postingUpdate(AsbDpra entity);
}
