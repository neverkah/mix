package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * ϵͳ������ϸ��(sys_cond_detl)
 * @author Zhangjin
 *
 */
public class SysCondDetl implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5631654172192077957L;
	String condcd;
	int sortno;
	String ladstr;
	String funccd;
	String fildcd;
	String cmptyp;
	String cmpcod;
	String cmpval;
	String radstr;
	String oprcod;
	String nulret;
	String desctx;
	String vermod;
	String module;
	String projcd;
	public String getCondcd() {
		return condcd;
	}
	public void setCondcd(String condcd) {
		this.condcd = condcd;
	}
	public int getSortno() {
		return sortno;
	}
	public void setSortno(int sortno) {
		this.sortno = sortno;
	}
	public String getLadstr() {
		return ladstr;
	}
	public void setLadstr(String ladstr) {
		this.ladstr = ladstr;
	}
	public String getFunccd() {
		return funccd;
	}
	public void setFunccd(String funccd) {
		this.funccd = funccd;
	}
	public String getFildcd() {
		return fildcd;
	}
	public void setFildcd(String fildcd) {
		this.fildcd = fildcd;
	}
	public String getCmptyp() {
		return cmptyp;
	}
	public void setCmptyp(String cmptyp) {
		this.cmptyp = cmptyp;
	}
	public String getCmpcod() {
		return cmpcod;
	}
	public void setCmpcod(String cmpcod) {
		this.cmpcod = cmpcod;
	}
	public String getCmpval() {
		return cmpval;
	}
	public void setCmpval(String cmpval) {
		this.cmpval = cmpval;
	}
	public String getRadstr() {
		return radstr;
	}
	public void setRadstr(String radstr) {
		this.radstr = radstr;
	}
	public String getOprcod() {
		return oprcod;
	}
	public void setOprcod(String oprcod) {
		this.oprcod = oprcod;
	}
	public String getNulret() {
		return nulret;
	}
	public void setNulret(String nulret) {
		this.nulret = nulret;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
}
