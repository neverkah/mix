package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.DepositDrawalInterest;

public interface DepositDrawalInterestMapper {
	public String insertEntity(DepositDrawalInterest entity);
	public DepositDrawalInterest selectEntity(@Param("trandt") String trandt , @Param("transq") String transq);
}
