package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.InvestmentTran;

public interface InvestmentTranMapper {
	public InvestmentTran selectEntity(@Param("trandt") String trandt , @Param("transq") String transq , @Param("ivetsq") String ivetsq , @Param("systid") String systid);
	public void insertEntity(InvestmentTran entity);
	public void postingUpdate(InvestmentTran entity);
}
