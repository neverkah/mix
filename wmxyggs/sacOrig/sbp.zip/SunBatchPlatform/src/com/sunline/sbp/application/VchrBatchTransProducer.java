package com.sunline.sbp.application;

import static com.sunline.sbp.application.Help.initMetaConfig;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.sunline.sbp.dao.mapper.GlaVoucherMapper;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.service.impl.FundClearingServiceImpl;
import com.sunline.sunbp.util.MyBatisUtil;
import com.taobao.metamorphosis.Message;
import com.taobao.metamorphosis.client.MessageSessionFactory;
import com.taobao.metamorphosis.client.MetaMessageSessionFactory;
import com.taobao.metamorphosis.client.producer.MessageProducer;
import com.taobao.metamorphosis.client.producer.SendResult;

public class VchrBatchTransProducer {
	static int msgcount = 0;
	private static Logger logger = Logger.getLogger(FundClearingServiceImpl.class);
    public static void main(final String[] args) throws Exception {
        // New session factory,ǿ�ҽ���ʹ�õ���
        final MessageSessionFactory sessionFactory = new MetaMessageSessionFactory(initMetaConfig());
        // create producer,ǿ�ҽ���ʹ�õ���
        final MessageProducer producer = sessionFactory.createProducer();
        // publish topic
        final String topic = "gl-vchr";
        producer.publish(topic);

        
        SqlSessionFactory sqlSessionFactory = MyBatisUtil.getSqlSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession();
        GlaVoucherMapper glaVoucherMapper  = sqlSession.getMapper(GlaVoucherMapper.class);
        
        List<String> transqs = glaVoucherMapper.getHeadTranOfVchrs(1, "20140921", "");
        GlaVoucher[] vchrs = glaVoucherMapper.getVchrsByTransq(1, "20140921", "","%1");
        System.out.println("������" + vchrs.length);
        for(GlaVoucher entity : vchrs){
        	
        	final SendResult sendResult = producer.sendMessage(new Message(topic, JSON.toJSONString(entity).getBytes()));
            // check result
            if (!sendResult.isSuccess()) {
            	logger.error("Send message failed,error message:" + sendResult.getErrorMessage());
            }
            else {
            	logger.debug("Send message successfully,sent to " + sendResult.getPartition());
            }
        }
        
    }
}
