package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * ������ϸ��
 * @author Zhangjin
 *
 */

public class DepositCommand {
	private String systid;
	private String trandt;
	private String rvpysq;
	private String transq;
	private String tranbr;
	private String trantp;
	private String acctbr;
	private String dtitcd;
	private String acctid;
	private String acctno;
	private String subsac;
	private String bltype;
	private String modutp;
	private String smrycd;
	private String amntcd;
	private String crcycd;
	private BigDecimal tranam;
	private String corrtg;
	private String bkfnst;
	private String prodcd;
	private int stacid;
	private String prcscd;
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getRvpysq() {
		return rvpysq;
	}
	public void setRvpysq(String rvpysq) {
		this.rvpysq = rvpysq;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getDtitcd() {
		return dtitcd;
	}
	public void setDtitcd(String dtitcd) {
		this.dtitcd = dtitcd;
	}
	public String getAcctid() {
		return acctid;
	}
	public void setAcctid(String acctid) {
		this.acctid = acctid;
	}
	public String getSmrycd() {
		return smrycd;
	}
	public void setSmrycd(String smrycd) {
		this.smrycd = smrycd;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getSubsac() {
		return subsac;
	}
	public void setSubsac(String subsac) {
		this.subsac = subsac;
	}
	public String getBltype() {
		return bltype;
	}
	public void setBltype(String bltype) {
		this.bltype = bltype;
	}
	public String getModutp() {
		return modutp;
	}
	public void setModutp(String modutp) {
		this.modutp = modutp;
	}
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public String getCorrtg() {
		return corrtg;
	}
	public void setCorrtg(String corrtg) {
		this.corrtg = corrtg;
	}
	public String getBkfnst() {
		return bkfnst;
	}
	public void setBkfnst(String bkfnst) {
		this.bkfnst = bkfnst;
	}
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	
	
}
