package com.sunline.sbp.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.dao.ComItexDao;
import com.sunline.sbp.dao.mapper.ComItexMapper;
import com.sunline.sbp.model.ComItex;

public class ComItexDaoImpl implements ComItexDao {
	
	private ComItexMapper comItexMapper;
	private int initail = 0;
	private static final String DTAG = ".";
	
	private Map<String,ComItex> itexMap = new HashMap<String,ComItex>();

	@Override
	public Map<String,ComItex> getAllItex() throws AnalyseException{
		// TODO Auto-generated method stub
		List<ComItex> itexs = comItexMapper.getAllEntites();
		
		for(ComItex entity:itexs){
			itexMap.put(entity.getStacid()+DTAG+entity.getAssimp(), entity);
		}
		return itexMap;
	}
	
	public Map<String,ComItex> getCacheData() throws AnalyseException{
		if(initail == 0){
			synchronized(this) {
				if(initail == 0){
					getAllItex();
					initail = 1;
				}
			}
		}
		return itexMap;
	}

	public ComItexMapper getComItexMapper() {
		return comItexMapper;
	}

	public void setComItexMapper(ComItexMapper comItexMapper) {
		this.comItexMapper = comItexMapper;
	}
}
