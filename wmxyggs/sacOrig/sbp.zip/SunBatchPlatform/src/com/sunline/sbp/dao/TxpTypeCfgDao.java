package com.sunline.sbp.dao;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.model.TxpTypeCfg;
import com.sunline.sbp.model.TxpTypeConf;
import com.sunline.sbp.model.TxpTypeOpen;

public interface TxpTypeCfgDao {
	public TxpTypeCfg getEntityByPrimaryKey(int stacid,String prodcd,String prodp1,String prodp2,String prodp3,String prodp4,
			String prodp5,String prodp6,String prodp7,String prodp8,String prodp9,String prodpa) throws AnalyseException;
	public TxpTypeCfg[] getEntitiesOfTable(int stacid) throws AnalyseException;
	public TxpTypeOpen[] getTxpTypeOpen(int stacid) throws AnalyseException;
}
