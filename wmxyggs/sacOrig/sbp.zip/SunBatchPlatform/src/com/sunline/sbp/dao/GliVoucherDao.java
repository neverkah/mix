package com.sunline.sbp.dao;

import java.util.List;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.GliVoucher;

public interface GliVoucherDao {
	public String insertEntity(List<GliVoucher> entity ) throws EngineRuntimeException;
}
