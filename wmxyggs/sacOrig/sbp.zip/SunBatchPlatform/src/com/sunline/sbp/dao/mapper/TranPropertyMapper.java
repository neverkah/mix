package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.SysPrtp;

public interface TranPropertyMapper {
	public SysPrtp[] getProperties(String trancd);
}
