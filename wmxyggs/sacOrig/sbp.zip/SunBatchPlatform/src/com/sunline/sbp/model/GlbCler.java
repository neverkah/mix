package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * 
 * @���� ����ǼǱ�
 * @���� ����glb_cler��bean
 * @author liuchj@sunline.cn
 * @project ����ϵͳ�������
 * @data 2014��5��12��
 */
public class GlbCler {
	private int stacid;
	private String bsnsdt;
	private String bsnssq;
	private String brchcd;
	private String clerty;
	private String crcycd;
	private BigDecimal drtsam;
	private BigDecimal crtsam;
	private String clerbr;
	private String amntcd;
	private BigDecimal tranam;
	private String trandt;
	private String transq;
	private int dealst;
	public int getDealst() {
		return dealst;
	}
	public void setDealst(int dealst) {
		this.dealst = dealst;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getBsnsdt() {
		return bsnsdt;
	}
	public void setBsnsdt(String bsnsdt) {
		this.bsnsdt = bsnsdt;
	}
	public String getBsnssq() {
		return bsnssq;
	}
	public void setBsnssq(String bsnssq) {
		this.bsnssq = bsnssq;
	}
	public String getBrchcd() {
		return brchcd;
	}
	public void setBrchcd(String brchcd) {
		this.brchcd = brchcd;
	}
	public String getClerty() {
		return clerty;
	}
	public void setClerty(String clerty) {
		this.clerty = clerty;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getDrtsam() {
		return drtsam;
	}
	public void setDrtsam(BigDecimal drtsam) {
		this.drtsam = drtsam;
	}
	public BigDecimal getCrtsam() {
		return crtsam;
	}
	public void setCrtsam(BigDecimal crtsam) {
		this.crtsam = crtsam;
	}
	public String getClerbr() {
		return clerbr;
	}
	public void setClerbr(String clerbr) {
		this.clerbr = clerbr;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}

}
