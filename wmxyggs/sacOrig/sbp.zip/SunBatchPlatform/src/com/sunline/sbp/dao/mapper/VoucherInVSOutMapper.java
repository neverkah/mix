package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.VoucherInVSOut;

public interface VoucherInVSOutMapper {
	public VoucherInVSOut selectEntity(@Param("trandt") String trandt , @Param("trandq") String transq , @Param("cmmdsq") String cmmdsq , @Param("systid") String systid);
	public void insertEntity(VoucherInVSOut entity);
	public void postingUpdate(VoucherInVSOut entity);
}
