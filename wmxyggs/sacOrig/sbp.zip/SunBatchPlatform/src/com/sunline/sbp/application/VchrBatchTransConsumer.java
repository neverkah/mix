package com.sunline.sbp.application;

/*
 * (C) 2007-2012 Alibaba Group Holding Limited.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * Authors:
 *   wuhua <wq163@163.com> , boyan <killme2008@gmail.com>
 */

import static com.sunline.sbp.application.Help.initMetaConfig;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;

import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.core.bean.GlaAcctBean;
import com.sunline.sbp.core.bean.GlaGlisBean;
import com.sunline.sbp.core.bean.SysAcctOpenBean;
import com.sunline.sbp.dao.mapper.AccountingItemMapper;
import com.sunline.sbp.dao.mapper.ComBrchMapper;
import com.sunline.sbp.dao.mapper.GlaAcctMapper;
import com.sunline.sbp.dao.mapper.GlaGlisMapper;
import com.sunline.sbp.dao.mapper.SysAcctOpenMapper;
import com.sunline.sbp.model.AccountingItem;
import com.sunline.sbp.model.ComBrch;
import com.sunline.sbp.model.GlaAcct;
import com.sunline.sbp.model.GlaGlis;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.SysAcctOpen;
import com.sunline.sunbp.util.MyBatisUtil;
import com.taobao.metamorphosis.Message;
import com.taobao.metamorphosis.client.MessageSessionFactory;
import com.taobao.metamorphosis.client.MetaMessageSessionFactory;
import com.taobao.metamorphosis.client.consumer.ConsumerConfig;
import com.taobao.metamorphosis.client.consumer.MessageConsumer;
import com.taobao.metamorphosis.client.consumer.MessageListener;


/**
 * ����ϵͳ�첽��Ϣ������
 * 
 * @author boyan
 * @Date 2011-5-17
 * 
 */
public class VchrBatchTransConsumer {
	static int mycount = 0;
	static long timeMy = 0;
	
	private static final String DTAG = ".";
	
	private static int rdCount = 0;
	
	private static Logger logger = Logger.getLogger(VchrBatchTransConsumer.class);
	
	private static Hashtable<String,GlaGlis> glisCache = new Hashtable<String,GlaGlis>();
	private static Hashtable<String,GlaVoucher> vchrsCache = new Hashtable<String,GlaVoucher>();
	
	private static Hashtable<String,SysAcctOpen> sysAcctOpenCache = new Hashtable<String,SysAcctOpen>();
	private static Hashtable<String,Integer> sysAcctOpenTagCache = new Hashtable<String,Integer>();
	
	private static Hashtable<String,AccountingItem> itemCache = new Hashtable<String,AccountingItem>();
	private static Hashtable<String,ComBrch> brchCache = new Hashtable<String,ComBrch>();
	
	
	static SqlSessionFactory sqlSessionFactory = MyBatisUtil.getSqlSessionFactory();
    static SqlSession sqlSession = sqlSessionFactory.openSession(ExecutorType.BATCH);
	
	
    public static void main(final String[] args) throws Exception {
        // New session factory,ǿ�ҽ���ʹ�õ���
        final MessageSessionFactory sessionFactory = new MetaMessageSessionFactory(initMetaConfig());

        // subscribed topic
        final String topic = "gl-vchr";
        // consumer group
        final String group = "meta-gl-vchr";
        // create consumer,ǿ�ҽ���ʹ�õ���
        final MessageConsumer consumer = sessionFactory.createConsumer(new ConsumerConfig(group));
        // subscribe topic
        
        AccountingItem[] items = sqlSession.getMapper(AccountingItemMapper.class).selectFullEntities(1);
    	for(int i = 0 ; i < items.length ; i++){
    		itemCache.put(getItemKey(items[i]), items[i]);
    	}
    	
    	ComBrch[] brchs = sqlSession.getMapper(ComBrchMapper.class).getAll();
    	for(int i = 0 ; i < brchs.length ; i++){
    		brchCache.put(getBrchKey(brchs[i].getStacid(),brchs[i].getBrchcd()), brchs[i]);
    	}
        
        consumer.subscribe(topic, 1024 * 1024, new MessageListener() {
        	
            @Override
            public void recieveMessages(final Message message) {
            	
            	String bussinessInfo = null;
            	
				//try {
					bussinessInfo = new String(message.getData());
				//} catch (UnsupportedEncodingException e) {
				//	// TODO Auto-generated catch block
				//	e.printStackTrace();
				//}
            	JSONObject jsonObject = null;
            	try{
            		jsonObject = JSON.parseObject(bussinessInfo);
            	}catch(Exception ex){
            		logger.error("===================================================//");
            		logger.error(bussinessInfo);
            		logger.error("===================================================//~");
            		
            		ex.printStackTrace();
            		return;
            	}
            	long beginT = System.nanoTime();
            	
            	GlaVoucher vchr;
            	
            	
            	
            	//���׷���
            	try{
            		
            		//���ɹ鼯���ݶ���
                	vchr = JSON.parseObject(jsonObject.toJSONString(), GlaVoucher.class);
                	
                	String vchrKey = getVchrKey(vchr);
                	
                	if(vchrsCache.containsKey(vchrKey)){
                		GlaVoucher chr = vchrsCache.get(vchrKey);
                		chr.setTranam(chr.getTranam().add(vchr.getTranam()));
                		//System.out.println("vchr ����");
                	}else{
                		vchrsCache.put(vchrKey, vchr);
                		
                	}
                	
                	GlaGlis glis = sqlSession.getMapper(GlaGlisMapper.class).getEntityLock(vchr);
                	if(null == glis){
                		glis = openGlis(itemCache.get(getItemKey(vchr.getStacid(),vchr.getItemcd())),vchr);
                	}else{
                		
                	}
                	String glisKey = getGlisKey(glis);
                	if(glisCache.containsKey(glisKey)){
                		//System.out.println("glis ����");
                	}else{
                		glisCache.put(glisKey, glis);
                	}
                	
                	if(glisCache.get(glisKey).getOnlnbl().compareTo(Constants.DECIMAL_ZERO) == -1){
                		logger.error(glisCache.get(glisKey).getBrchcd()+":"+glisCache.get(glisKey).getItemcd()+"͸֧");
                	}
                	
                	if(++rdCount >= 1000){
                		
                		Iterator<String> vchrsIt = vchrsCache.keySet().iterator();
                		while(vchrsIt.hasNext()){
                			
                			GlaVoucher ve = vchrsCache.get(vchrsIt.next());
                			
                			GlaGlisMapper glaGlisMapper = sqlSession.getMapper(GlaGlisMapper.class);
                			
                			GlaGlis glise = glaGlisMapper.getEntityLock(ve);
                			
                			AccountingItem itemEntity = itemCache.get(String.valueOf(ve.getStacid()).concat(DTAG).concat(ve.getItemcd()));
                			ComBrch brchEntity = brchCache.get(String.valueOf(ve.getStacid()).concat(DTAG).concat(ve.getAcctbr()));
                			
                			if(null == glise){               				
                				glise = openGlis(itemEntity,ve);
                				glaGlisMapper.insertEntity(glise);
                			}
                			
                			GlaGlisBean.updateBalance(ve, glise, itemEntity);
                			
                			glaGlisMapper.updateEntity(glise);
                			
                			GlaAcctMapper glaAcctMapper = sqlSession.getMapper(GlaAcctMapper.class);
                			
                			List<GlaAcct> acctEntitys = glaAcctMapper.selectEntitiesByGlaVoucher(ve);
                    		
                			GlaAcct acctEntity = null;
                			if(null == acctEntitys || acctEntitys.isEmpty()){
                				
                				SysAcctOpen sysAcctOpen = GlaAcctBean.getAcctOpenInfo(ve.getStacid(), ve.getSystid(), ve.getAcctbr(), ve.getCrcycd(), ve.getItemcd());
                				SysAcctOpen acctOpen = null;
                				
                				if(sysAcctOpenCache.containsKey(getSysAcctOpenKey(sysAcctOpen))){
                					acctOpen = sysAcctOpenCache.get(getSysAcctOpenKey(sysAcctOpen));
                				}else{
                					int acctnoOrder = SysAcctOpenBean.selectEntity(sysAcctOpen);
                				
                					sysAcctOpen.setAorder(acctnoOrder);
                    					acctOpen = sysAcctOpen;
                    				
                					sysAcctOpenCache.put(getSysAcctOpenKey(acctOpen),acctOpen);
                				}
                				
                				String acctcd = GlaAcctBean.getAcctcd(ve.getStacid(), ve.getSystid(), ve.getAcctbr(), ve.getCrcycd(), ve.getItemcd(), acctOpen.getAorder());
                				GlaAcctBean.generateAcctEntity(ve.getStacid(), acctcd, itemEntity, brchEntity, ve);
                				
                			}else if(acctEntitys.size() > 1){
                				logger.error("��ö�["+acctEntitys.size()+"]���˻���Ϣ��ϵͳ���ݴ���");
                				
                			}else{
                				logger.debug("��ȡ�˻���Ϣ�ɹ���"+acctEntitys.size());
                				acctEntity = acctEntitys.get(0);
                				
                			}
                			
                			GlaAcctBean.updateAccountBalance(ve.getStacid(), ve.getSystid(), ve.getAcctbr(), ve.getItemcd(), ve.getCrcycd(), 
                					null, ve.getAmntcd(), 
                					ve.getTranam(), ve.getTransq(),  itemEntity.getPomdtg(), ve.getSoursq(), ve.getTrandt(), itemEntity, acctEntity);
                			

                			glaAcctMapper.updateBalance(acctEntity.getAcctcd(), acctEntity.getOnlnbl(), 
                					acctEntity.getLstrsq(), acctEntity.getLstrdt(), acctEntity.getBlncdn());
                		}
                		
                		//�������¿���������¼
                		Iterator<String> acctOpenIt = sysAcctOpenCache.keySet().iterator();
                		SysAcctOpenMapper sysAcctOpenMapper =  sqlSession.getMapper(SysAcctOpenMapper.class);
                		
                		while(acctOpenIt.hasNext()){
                			SysAcctOpen entity = sysAcctOpenCache.get(acctOpenIt.next());
                			if(sysAcctOpenTagCache.containsKey(getSysAcctOpenKey(entity))){
                				sysAcctOpenMapper.insertAcctnoOpenInfo(entity);
                			}else{
                				sysAcctOpenMapper.updateOrder(entity);
                			}
                			
                		}
                		
                		
                		sqlSession.commit();
                		System.out.println("�����ύ:" + rdCount);
                		rdCount = 0;
                		glisCache.clear();
                		vchrsCache.clear();
                		sysAcctOpenCache.clear();
                		
                	}
                	
            	}catch(Exception ex){
            		logger.error("===================================================//");
            		logger.error(bussinessInfo);
            		ex.printStackTrace();
            		logger.error("===================================================//~");
            		try {
						//throw new Exception("ҵ����ʧ��");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
            	}
        		long endT = System.nanoTime();
        		timeMy = timeMy + (endT - beginT)/1000000L;
            }

            @Override
            public Executor getExecutor() {
                // Thread pool to process messages,maybe null.
                return null;
            	//Executors.newCachedThreadPool();
            	//ExecutorService executor = Executors.newFixedThreadPool(8);
            	//return executor;
            }
        });
        // complete subscribe
        consumer.completeSubscribe();
    }
    
    public static String getSysAcctOpenKey(SysAcctOpen entity){
    	return String.valueOf(entity.getStacid()).concat(DTAG).
    	concat(entity.getSystid()).concat(DTAG).
    	concat(entity.getBrchcd()).concat(DTAG).
    	concat(entity.getCrcycd()).concat(DTAG).
    	concat(entity.getItemcd());
    }
    
    /**
     * STACID, ACCTDT, SYSTID, BRCHCD, ITEMCD, CRCYCD, GELDTP, ACCTNO, ASSIS0, ASSIS1, ASSIS2, ASSIS3, ASSIS4, ASSIS5, ASSIS6, ASSIS7, ASSIS8, ASSIS9
     * @param glaGlis
     * @return
     */
    private static String getGlisKey(GlaGlis glaGlis){
    	return String.valueOf(glaGlis.getStacid()).concat(DTAG).
    			concat(glaGlis.getAcctdt()).concat(DTAG).
    			concat(glaGlis.getSystid()).concat(DTAG).
    			concat(glaGlis.getBrchcd()).concat(DTAG).
    			concat(glaGlis.getItemcd()).concat(DTAG).
    			concat(glaGlis.getCrcycd()).concat(DTAG).
    			concat(glaGlis.getGeldtp()).concat(DTAG).
    			concat(glaGlis.getCentcd()).concat(DTAG).
    			concat(glaGlis.getPrsncd()).concat(DTAG).
    			concat(glaGlis.getCustcd()).concat(DTAG).
    			concat(glaGlis.getPrducd()).concat(DTAG).
    			concat(glaGlis.getPrlncd()).concat(DTAG).
    			concat(glaGlis.getAcctno()).concat(DTAG).
    			concat(glaGlis.getAssis0()).concat(DTAG).
    			concat(glaGlis.getAssis1()).concat(DTAG).
    			concat(glaGlis.getAssis2()).concat(DTAG).
    			concat(glaGlis.getAssis3()).concat(DTAG).
    			concat(glaGlis.getAssis4()).concat(DTAG).
    			concat(glaGlis.getAssis5()).concat(DTAG).
    			concat(glaGlis.getAssis6()).concat(DTAG).
    			concat(glaGlis.getAssis7()).concat(DTAG).
    			concat(glaGlis.getAssis8()).concat(DTAG).
    			concat(glaGlis.getAssis9());
    }
    
    /**
     * STACID, SYSTID, TRANDT, TRANSQ, VCHRSQ
     * @param glaVoucher
     * @return
     */
    private static String getVchrKey(GlaVoucher glaVoucher){
    	return String.valueOf(glaVoucher.getStacid()).concat(DTAG).
    			concat(glaVoucher.getSystid()).concat(DTAG).
    			concat(glaVoucher.getTrandt()).concat(DTAG).
    			concat(glaVoucher.getAcctbr()).concat(DTAG).
    			concat(glaVoucher.getItemcd()).concat(DTAG).
    			concat(glaVoucher.getCrcycd()).concat(DTAG).
    			concat(glaVoucher.getCentcd()).concat(DTAG).
    			concat(glaVoucher.getPrsncd()).concat(DTAG).
    			concat(glaVoucher.getCustcd()).concat(DTAG).
    			concat(glaVoucher.getPrducd()).concat(DTAG).
    			concat(glaVoucher.getPrlncd()).concat(DTAG).
    			concat(glaVoucher.getAcctno()).concat(DTAG).
    			concat(glaVoucher.getTrantp()).concat(DTAG).
    			concat(glaVoucher.getAmntcd()).concat(DTAG).
    			concat(glaVoucher.getAssis0()).concat(DTAG).
    			concat(glaVoucher.getAssis1()).concat(DTAG).
    			concat(glaVoucher.getAssis2()).concat(DTAG).
    			concat(glaVoucher.getAssis3()).concat(DTAG).
    			concat(glaVoucher.getAssis4()).concat(DTAG).
    			concat(glaVoucher.getAssis5()).concat(DTAG).
    			concat(glaVoucher.getAssis6()).concat(DTAG).
    			concat(glaVoucher.getAssis7()).concat(DTAG).
    			concat(glaVoucher.getAssis8()).concat(DTAG).
    			concat(glaVoucher.getAssis9());
    }
    
    private static String getItemKey(AccountingItem item){
    	return String.valueOf(item.getStacid()).concat(DTAG).concat(item.getItemcd());
    }
    
    private static String getItemKey(int stacid , String itemcd){
    	return String.valueOf(stacid).concat(DTAG).concat(itemcd);
    }
    
    private static String getBrchKey(int stacid , String brchcd){
    	return String.valueOf(stacid).concat(DTAG).concat(brchcd);
    }
    
    public static void printTime(){
    	Logger.getLogger(FIAsyncConsumer.class).debug(System.nanoTime()/1000000L);
    }
    
    private static GlaGlis openGlis(AccountingItem itemEntity , GlaVoucher vchr){
		
		//��ȡ��Ŀ����
		//String itemdn = itemEntity.getItemdn();
		String itemdn = itemEntity.getItemdn();
		
		//��Ŀ����Ϊ�跽
		if(itemdn.equalsIgnoreCase(Constants.AMNTCD_CREDIT)){
			itemdn = Constants.AMNTCD_CREDIT;
		}else if(itemdn.equalsIgnoreCase(Enumeration.Amntcd.R.value)){
			itemdn = Enumeration.Amntcd.R.value;
		}else{
			itemdn = Constants.AMNTCD_DEBIT;
		}
		
		if(null == itemdn || itemdn.trim().length() == 0){
			String message = "��Ŀ["+itemEntity.getItemcd()+"]�����ȡʧ�ܣ�";
			logger.debug(message);
			
		}
		
		GlaGlis entity = new GlaGlis();
		entity.setStacid(vchr.getStacid());
		entity.setSystid(vchr.getSystid());
		entity.setAcctdt(vchr.getTrandt());
		entity.setBrchcd(vchr.getAcctbr());
		entity.setItemcd(vchr.getItemcd());
		entity.setCrcycd(vchr.getCrcycd());
		entity.setBlncdn(itemdn);
		entity.setOnlnbl(Constants.DECIMAL_ZERO);
		entity.setLastdn(itemdn);
		entity.setLastbl(Constants.DECIMAL_ZERO);
		entity.setGeldtp("D");
		
		
		logger.debug("��������ɹ�!");
		
		return entity;
	}
}
