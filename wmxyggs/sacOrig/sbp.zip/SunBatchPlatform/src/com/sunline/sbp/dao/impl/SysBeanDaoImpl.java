package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.dao.SysBeanDao;
import com.sunline.sbp.dao.mapper.SysBeanMapper;
import com.sunline.sbp.model.SysBean;

public class SysBeanDaoImpl implements SysBeanDao {
	private SysBeanMapper sysBeanMapper;
	
	private Logger logger = Logger.getLogger(SysBeanDaoImpl.class);
	
	@Override
	public SysBean getEntityByPK(SysBean sysBean) throws EngineRuntimeException{
		SysBean sysBeanEntity = sysBeanMapper.getEntityByPK(sysBean);
		if(null == sysBeanEntity){
			logger.error("����" + sysBean.getBeanid() + "δ���ã�");
			throw new AnalyseException("����" + sysBean.getBeanid() + "δ���ã�");
		}
		return sysBeanEntity;
	}
	public SysBeanMapper getSysBeanMapper() {
		return sysBeanMapper;
	}
	public void setSysBeanMapper(SysBeanMapper sysBeanMapper) {
		this.sysBeanMapper = sysBeanMapper;
	}
	
}
