package com.sunline.sbp.dao.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.GliVoucher;

public interface GliVoucherMapper {
	public void insertEntity(GliVoucher vchr);
	
	public void insertEntitiesBatch(List<GliVoucher> list);

	public int getNextSequence(GliVoucher vchr);

	public void updateClearInfo(@Param("stacid") int stacid,
			@Param("trandt") String trandt, @Param("clerod") String clerod,
			@Param("clerdt") String clerdt);

	/**
	 * �����������⣬������������
	 */
	/*public List<GliVoucher> getVchrsByBrch(@Param("stacid") int stacid,
			@Param("sourdt") String sourdt,@Param("tranbr") String tranbr);*/
	
	public List<String> getBrchHeadVchrDetail(@Param("stacid") int stacid , @Param("trandt") String trandt , @Param("tranbr") String tranbr, @Param("pit") String pit, @Param("sourst") String sourst);
	public List<String> getBrchHeadVchrDetailOfError(@Param("stacid") int stacid , @Param("trandt") String trandt , @Param("tranbr") String tranbr, @Param("pit") String pit, @Param("sourst") String sourst);
	public List<GliVoucher> getBrchVchrDetailByTransq(@Param("list") List<String> entity , @Param("stacid") int stacid , @Param("trandt") String trandt , @Param("tranbr") String tranbr, @Param("sourst") String sourst);
	

	/**
	 * ��ʶ��Ʊ���˳ɹ�
	 * 
	 * @param entity
	 * @return
	 */
	public int updateToSucc(GliVoucher entity);
	
	public int updateToSuccBatch(@Param("stacid") int stacid , @Param("sourdt") String sourdt , @Param("tranbr") String tranbr , @Param("list") List<GlaVoucher> list, @Param("sourst") String sourst);

	/**
	 * ��ʶ��Ʊ����ʧ��
	 * 
	 * @param entity
	 * @return
	 */
	public int updateToError(GliVoucher entity);
	
	public List<Map<String,String>> getTranbrOfVchr(@Param("stacid") int stacid, @Param("sourdt") String sourdt);

}
