package com.sunline.sbp.datamerger;

import com.sunline.sbp.model.GlbCler;

public class GlbClerMerger implements BusinessObject {
	
	private GlbCler busi;
	private String prcscd;
	private String typecd;
	private int stacid;

	@Override
	public String getPrcscd() {
		// TODO Auto-generated method stub
		return prcscd;
	}
	
	public GlbClerMerger(GlbCler param){
		this.busi = param;
		this.prcscd = "incler";
		this.typecd = param.getClerty();
		this.stacid = busi.getStacid();
	}

	@Override
	public String getBusiType() {
		// TODO Auto-generated method stub
		return typecd;
	}

	@Override
	public Object getBusinessObject() {
		// TODO Auto-generated method stub
		return busi;
	}

	@Override
	public String getBsnsdt() {
		// TODO Auto-generated method stub
		return busi.getBsnsdt();
	}

	@Override
	public String getBsnssq() {
		// TODO Auto-generated method stub
		return busi.getBsnssq();
	}

	@Override
	public String getSystid() {
		// TODO Auto-generated method stub
		return "90";
	}

	@Override
	public String getProdcd() {
		// TODO Auto-generated method stub
		return "9999";
	}

	@Override
	public int getStacid() {
		// TODO Auto-generated method stub
		return this.stacid;
	}

	@Override
	public void setStacid(int stacid) {
		// TODO Auto-generated method stub
		this.busi.setStacid(stacid);
	}

}
