package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.sbp.dao.mapper.TrtlMapper;
import com.sunline.sbp.model.SysTrtl;

public class TrtlDaoImpl {
	private TrtlMapper trtlMapper;
	
	private Logger logger = Logger.getLogger(TrtlDaoImpl.class);
	
	public SysTrtl[] getEntities(int stacid, String prcscd,String projcd){
		logger.debug("#########################��ȡ��Ŀ["+projcd+"]�еĴ�����["+prcscd+"]��ϵͳ���׷�������...");
		SysTrtl[] trtls = trtlMapper.getTrtl(stacid, prcscd, projcd);
		if(null == trtls){
			logger.debug("ϵͳδ����");
		}else{
			logger.debug("��ȡ�ɹ���������" + trtls.length);
		}
		
		return trtls;
	}

	public TrtlMapper getTrtlMapper() {
		return trtlMapper;
	}

	public void setTrtlMapper(TrtlMapper trtlMapper) {
		this.trtlMapper = trtlMapper;
	}
}
