package com.sunline.sbp.service.impl;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.DataObjectUtil;
import com.sunline.sbp.dao.impl.MidTranDaoImpl;
import com.sunline.sbp.model.MidTran;
import com.sunline.sbp.service.MidTranAction;

/**
 * 
 * @author Zhangjin
 *
 */
public class MidTranActionImpl implements MidTranAction  {
	
	private MidTranDaoImpl midTranDao;
	private Logger logger = Logger.getLogger(MidTranActionImpl.class);
	
	public MidTranDaoImpl getMidTranDao() {
		return midTranDao;
	}

	public void setMidTranDao(MidTranDaoImpl midTranDao) {
		this.midTranDao = midTranDao;
	}

	@Override
	public void insert(MidTran midtran){
		if( null != midTranDao){
			midTranDao.insert(midtran);
		}else{
			logger.error("midTranDao is null");
		}
		
	}
	
	public void generateTranDetail(){
		
	}
	
	public String initialize(){
		return null;
	}
	
	public String execute() throws AnalyseException{
		HashMap<String,Object> data = new HashMap<String,Object>();
		MidTran midTran = new MidTran();
		data.put("systid", "TS");
		data.put("trandt", "20121206");
		data.put("transq", "000000");
		data.put("tranbr", "01002");
		data.put("dtitcd", "01002");
		data.put("tranam", 111);
		data.put("amntcd", "C");
		
		MidTran midtran = new MidTran();
		
		midtran.setAmntcd("D");
		midtran.setDtitcd(data.get("dtitcd").toString());
		midtran.setTranam(DataObjectUtil.getBigDecimalValue(data,"tranam"));
		midtran.setSystid(data.get("systid").toString());
		midtran.setTranbr(data.get("tranbr").toString());
		midtran.setTrandt(data.get("trandt").toString());
		midtran.setTransq(data.get("transq").toString());
		insert(midTran);
		
		return "EX000000";
	}
	
	
}
