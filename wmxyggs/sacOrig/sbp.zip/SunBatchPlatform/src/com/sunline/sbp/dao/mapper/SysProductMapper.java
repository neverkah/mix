package com.sunline.sbp.dao.mapper;

import java.util.List;

import com.sunline.sbp.model.SysProduct;

public interface SysProductMapper {
	public List<SysProduct> getAllEntities();
}
