package com.sunline.sbp.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.sunline.foundation.Constants;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.ServiceException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.dao.AccountingTreatmentDao;
import com.sunline.sbp.dao.ExtdDao;
import com.sunline.sbp.dao.GlaVoucherDao;
import com.sunline.sbp.dao.GlsCmddErorDao;
import com.sunline.sbp.dao.GlsTranDao;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.GlsCmddEror;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.GlsTran;
import com.sunline.sbp.service.CommandTranService;

/**
 * 
 * @author Zhangjin
 *
 */
public class CommandTranServiceImpl implements CommandTranService {

	private Logger logger = Logger.getLogger(CommandTranServiceImpl.class);

	@Override
	public String goTransaction(ArrayList<GlsExtd> extdEntities)
			throws ServiceException {
		//
		int stacid = 1;
		String message = Constants.EXECUTE_NULL;
		String systid = extdEntities.get(0).getSystid();
		String trandt = extdEntities.get(0).getTrandt();
		String transq = extdEntities.get(0).getTransq();
		String tranbr = extdEntities.get(0).getTranbr();

		logger.info("ָ����������ʼ��====================");
		logger.info("systid:" + systid + ",trandt:" + trandt + ",transq:"
				+ transq);

		GlsTranDao glstrandao = (GlsTranDao) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(GlsTranDao.class);

		GlaVoucherDao voucherDao = (GlaVoucherDao) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(GlaVoucherDao.class);
		GlsCmddErorDao glsCmddErorDao = (GlsCmddErorDao) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(GlsCmddErorDao.class);

		AccountingTreatmentDao ap = (AccountingTreatmentDao) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(
						AccountingTreatmentDao.class);

		List<GlaVoucher> vchrResult = null;
		GlsExtd glsTransSucc = null;
		GlsExtd glsTransFailed = null;
		GlsCmddEror eror = null;
		try {
			vchrResult = ap.processVectorTransaction(extdEntities);
		} catch (EngineRuntimeException ex) {
			message = Constants.EXECUTE_FAIL;
			eror = new GlsCmddEror();
			eror.setErortx(ex.getMessage());
			eror.setTrandt(trandt);
			eror.setTransq(transq);
		} finally {
			if (null != vchrResult) {
				glsTransSucc = extdEntities.get(0);
				message = Constants.EXECUTE_SUCC;
			} else {
				glsTransFailed = extdEntities.get(0);
				// ��¼ָ�����������־
			}
		}

		if (null != vchrResult) {
			List<List<GlaVoucher>> listVchrs = new ArrayList<List<GlaVoucher>>();
			listVchrs.add(vchrResult);
			voucherDao.insertEntitiesBatch(listVchrs,trandt,tranbr,vchrResult.get(0).getSourac());
		}

		// �����ɹ�
		if (null != glsTransSucc) {
			int succTranCount = glstrandao.updateSucc(stacid,
					glsTransSucc.getSystid(), glsTransSucc.getTrandt(),
					glsTransSucc.getTransq());
			logger.info("��ˮ�����ɹ�������" + succTranCount);
		}

		// ����ʧ��
		if (null != glsTransFailed) {
			int failTranCount = glstrandao.updateFailed(stacid,
					glsTransFailed.getSystid(), glsTransFailed.getTrandt(),
					glsTransFailed.getTransq());
			logger.info("��ˮ����ʧ��������" + failTranCount);
		}

		if (null != eror) {
			glsCmddErorDao.insert(eror);
		}

		return message;
	}

	@Override
	public String goBatTransaction(List<GlsTran> glsTrans)
			throws ServiceException {
		//
		String message = Constants.EXECUTE_EXCEPTION;

		String systid = glsTrans.get(0).getSystid();
		String trandt = glsTrans.get(0).getTrandt();
		String tranbr = glsTrans.get(0).getTranbr();

		logger.info("��������ˮ:��ϵͳ��"+systid+",������"+tranbr+",���ڣ�"+trandt+",������"+glsTrans.size()+"��ָ����������ʼ��====================");

		GlsTranDao glstrandao = (GlsTranDao) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(GlsTranDao.class);

		ExtdDao extdDao = (ExtdDao) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(ExtdDao.class);

		GlaVoucherDao voucherDao = (GlaVoucherDao) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(GlaVoucherDao.class);
		/*
		 * List<GlsTran> glsTrans = glstrandao.getWithBrch(stacid, trandt,
		 * tranbr);
		 */
		List<GlsExtd> glsTransFailed = new ArrayList<GlsExtd>();
		List<GlsExtd> glsTransSucc = new ArrayList<GlsExtd>();
		List<GlsCmddEror> erorLog = new ArrayList<GlsCmddEror>();

		// ���׷���
		try {

			List<GlsExtd> extds = extdDao.selectEntitiesBatch(glsTrans, systid,
					trandt);

			AccountingTreatmentDao ap = (AccountingTreatmentDao) ApplicationBeanFactory
					.getApplicationContextInstance().getBean(
							AccountingTreatmentDao.class);

			GlsCmddErorDao glsCmddErorDao = (GlsCmddErorDao) ApplicationBeanFactory
					.getApplicationContextInstance().getBean(
							GlsCmddErorDao.class);

			List<List<GlaVoucher>> vchrs = new ArrayList<List<GlaVoucher>>();

			for (int idx = 0; idx < extds.size();) {
				int idy = idx + 1;
				for (idy = idx + 1; idy < extds.size(); idy++) {
					if (!extds.get(idx).getTransq()
							.equals(extds.get(idy).getTransq())) {
						break;
					}
				}
				List<GlaVoucher> vchrResult = null;
				try {
					vchrResult = ap.processVectorTransaction(extds.subList(idx,
							idy));
				} catch (EngineRuntimeException ex) {
					GlsCmddEror eror = new GlsCmddEror();
					eror.setErortx(ex.getMessage());
					eror.setTrandt(extds.get(idx).getTrandt());
					eror.setTransq(extds.get(idx).getTransq());

					erorLog.add(eror);
				} finally {
					if (null != vchrResult) {
						vchrs.add(vchrResult);
						glsTransSucc.add(extds.get(idx));
					} else {
						glsTransFailed.add(extds.get(idx));
						// ��¼ָ�����������־
					}
				}

				idx = idy;

			}

			// �����ɹ�
			int succTranCount = 0;
			if (null != glsTransSucc && !glsTransSucc.isEmpty()) {
				logger.info("��ˮ�����ɹ�������" + glsTransSucc.size());
				succTranCount = glstrandao.updateSuccBatch(glsTransSucc);
				logger.info("��ˮ�����ɹ�״̬����������" + succTranCount);
			}else{
				logger.info("��ˮ�������޳ɹ����ݣ�");
			}

			// ����ʧ��
			int failTranCount = 0;
			if (null != glsTransFailed && !glsTransFailed.isEmpty()) {
				logger.info("��ˮ����ʧ��������" + glsTransFailed.size());
				failTranCount = glstrandao
						.updateFailedBatch(glsTransFailed);
				logger.info("��ˮ����ʧ��״̬ȷ��������" + failTranCount);
			}else{
				logger.info("��ˮ�������޳������ݣ�");
			}
			
			//����һ����У��
			if(glsTrans.size() != (succTranCount + failTranCount)){
				message = "����������"+glsTrans.size()+"��ɹ�ȷ������"+succTranCount + "ʧ��ȷ������" + failTranCount+"֮�Ͳ���ȣ�����״̬�����쳣��";
				logger.error(message);
				throw new EngineRuntimeException(message);
			}
			
			if (null != vchrs && vchrs.size() > 0) {
				voucherDao.insertEntitiesBatch(vchrs,trandt,tranbr,vchrs.get(0).get(0).getSourac());
			}

			if (null != erorLog && !erorLog.isEmpty()) {
				glsCmddErorDao.insertBatch(erorLog);
			}

			message = Constants.EXECUTE_SUCC;

			logger.info("ָ������ɹ���#####message:" + message
					+ "~///////");
		} catch (EngineRuntimeException eex) {
			message = "ָ�����ʧ�ܣ�#####error code:" + message
					+ "#####message:" + eex.getMessage() + "~///////";
			logger.error(message);
			logger.error(eex);
			message = Constants.EXECUTE_FAIL + "-" + message;
			throw new ServiceException(message, eex);
		} catch (Exception ex) {
			message = "ָ������쳣��#####message:" + ex.getMessage()
					+ "~///////";
			logger.error(message);
			logger.error(ex);
			message = Constants.EXECUTE_EXCEPTION + "-ָ������쳣��" + message;
			throw new ServiceException(message, ex);
		} finally {
			glsTransSucc.clear();
			glsTransFailed.clear();
			erorLog.clear();
			logger.info("ָ��������������====================");
		}

		return message;
	}

	@Override
	public String confirmTransaction(ArrayList<GlsExtd> extdEntities)
			throws ServiceException {
		// TODO Auto-generated method stub
		GlsTranDao glstrandao = (GlsTranDao) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(GlsTranDao.class);
		String message = Constants.EXECUTE_EXCEPTION;

		GlsTran glsTrans = glstrandao.getEntity(1, extdEntities.get(0)
				.getSystid(), extdEntities.get(0).getTrandt(), extdEntities
				.get(0).getTransq());
		if (null != glsTrans) {
			if (glsTrans.getTranst().equals("1")) {
				message = Constants.EXECUTE_SUCC;
			} else {
				message = goTransaction(extdEntities);
			}
		} else {
			message = Constants.EXECUTE_EXCEPTION + "-"
					+ "ϵͳ����glstranΪ�գ�transq:" + extdEntities.get(0).getTransq();
			logger.error(message);
			throw new ServiceException(message);
		}
		return message;
	}

}
