package com.sunline.sbp.dao.impl.rule;

import java.math.BigDecimal;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.DataObjectUtil;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.TranamInfoEntity;
import com.sunline.sbp.base.RuleBeanObject;
import com.sunline.sbp.dao.mapper.GlsExtdMapper;
import com.sunline.sbp.dao.mapper.TxbBusiInfoMapper;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;
import com.sunline.sbp.model.SysIomp;
import com.sunline.sbp.model.TrbBusiInfo;
import com.sunline.sbp.model.TrbRecvInfo;
import com.sunline.sbp.model.TrbTxlsInfo;

/***
 * �����ָ��
 * @author Zhangjin
 *
 */
public class GlPriceTaxSeparated implements RuleBeanObject {
	
	private TxbBusiInfoMapper TxbBusiInfoMapper;
	private TrbRecvInfo command;
	private TrbBusiInfo trbbusi;
	private TrbTxlsInfo trbtxls;
	private HashMap<String , Object> data;
	private GlsExtdMapper glsExtdMapper;
	private GlsExtd extd;
	private SysIomp[] iopms;
	private SysIntf sysIntf;
	private SysIntfDetl[] intfDetl;
	private Logger logger = Logger.getLogger(LoadTranDetlRule.class);
	
	@Override
	public void setMapOfInIntf(final SysIntf sysIntf , final SysIomp[] iopms ,final SysIntfDetl[] detls) {
		// TODO Auto-generated method stub
		this.iopms = iopms;
		this.sysIntf = sysIntf;
		this.intfDetl = detls;
	}

	@Override
	public String initialize(HashMap<String , Object> data) throws AnalyseException {
		// TODO Auto-generated method stub
		this.data = data;
		try{
			
			data.put("loansq", DataObjectUtil.getHashMapStr(data,"cmmdsq").toString());
			
			if("TIS,TISTAX".contains(DataObjectUtil.getHashMapStr(data,"opracd").toString()) 
					&& !"TAX".equals(DataObjectUtil.getHashMapStr(data,"opracd").toString())){
				if(DataObjectUtil.getHashMapStr(data,"inout").toString().equalsIgnoreCase("IN")){
					command = new TrbRecvInfo();
					command.setAcctbr(DataObjectUtil.getHashMapStr(data,"acctbr").toString());
					command.setCrcysd("01");
					command.setCrcyiv("01");
					command.setCrcycd(DataObjectUtil.getHashMapStr(data,"crcycd").toString());
					command.setCustcd(DataObjectUtil.getHashMapStr(data,"dccatp").toString());
					command.setTypecd(DataObjectUtil.getHashMapStr(data,"txtpcd").toString());
					command.setVatxrt(DataObjectUtil.getHashMapStr(data,"vatxrt").toString());
					command.setVchrsq(DataObjectUtil.getHashMapStr(data,"loansq").toString());
					command.setStacid(DataObjectUtil.getIntegerValue(data, "stacid"));
					command.setSystid(DataObjectUtil.getHashMapStr(data,"systid").toString());
					if(Constants.AMNTCD_CREDIT.equals(DataObjectUtil.getHashMapStr(data,"amntcd").toString())){
						command.setTranam(BigDecimal.ZERO.subtract(new BigDecimal(DataObjectUtil.getHashMapStr(data,"captam").toString())));
						command.setVatxam(BigDecimal.ZERO.subtract(new BigDecimal(DataObjectUtil.getHashMapStr(data,"vatxam").toString())));
						command.setPricam(BigDecimal.ZERO.subtract(new BigDecimal(DataObjectUtil.getHashMapStr(data,"price").toString())));
					}else{
						command.setVatxam(new BigDecimal(DataObjectUtil.getHashMapStr(data,"captam").toString()));
						command.setVatxam(new BigDecimal(DataObjectUtil.getHashMapStr(data,"vatxam").toString()));
						command.setPricam(new BigDecimal(DataObjectUtil.getHashMapStr(data,"price").toString()));
					}
					command.setTranbr(DataObjectUtil.getHashMapStr(data,"tranbr").toString());
					command.setTrandt(DataObjectUtil.getHashMapStr(data,"trandt").toString());
					command.setTransq(DataObjectUtil.getHashMapStr(data,"transq").toString());
					command.setPrcscd(DataObjectUtil.getHashMapStr(data,"loanp7","*").toString());
				}else if(DataObjectUtil.getHashMapStr(data,"inout").toString().equalsIgnoreCase("OU")){
					trbbusi = new TrbBusiInfo();
					trbbusi.setAcctbr(DataObjectUtil.getHashMapStr(data,"acctbr").toString());
					trbbusi.setCrcyiv("01");
					trbbusi.setCrcycd(DataObjectUtil.getHashMapStr(data,"crcycd").toString());
					trbbusi.setCustcd(DataObjectUtil.getHashMapStr(data,"dccatp").toString());
					trbbusi.setTypecd(DataObjectUtil.getHashMapStr(data,"txtpcd").toString());
					trbbusi.setVatxrt(DataObjectUtil.getHashMapStr(data,"vatxrt").toString());
					trbbusi.setVchrsq(DataObjectUtil.getHashMapStr(data,"loansq").toString());
					trbbusi.setStacid(DataObjectUtil.getIntegerValue(data, "stacid"));
					trbbusi.setSystid(DataObjectUtil.getHashMapStr(data,"systid").toString());
					trbbusi.setTranbr(DataObjectUtil.getHashMapStr(data,"tranbr").toString());
					if(Constants.AMNTCD_CREDIT.equals(DataObjectUtil.getHashMapStr(data,"amntcd").toString())){
						trbbusi.setTranam(new BigDecimal(DataObjectUtil.getHashMapStr(data,"captam").toString()));
						trbbusi.setVatxam(new BigDecimal(DataObjectUtil.getHashMapStr(data,"vatxam").toString()));
						trbbusi.setPricam(new BigDecimal(DataObjectUtil.getHashMapStr(data,"price").toString()));
					}else{
						trbbusi.setTranam(BigDecimal.ZERO.subtract(new BigDecimal(DataObjectUtil.getHashMapStr(data,"captam").toString())));
						trbbusi.setVatxam(BigDecimal.ZERO.subtract(new BigDecimal(DataObjectUtil.getHashMapStr(data,"vatxam").toString())));
						trbbusi.setPricam(BigDecimal.ZERO.subtract(new BigDecimal(DataObjectUtil.getHashMapStr(data,"price").toString())));
					}
					trbbusi.setTrandt(DataObjectUtil.getHashMapStr(data,"trandt").toString());
					trbbusi.setTransq(DataObjectUtil.getHashMapStr(data,"transq").toString());
					trbbusi.setPrcscd(DataObjectUtil.getHashMapStr(data,"loanp7","*").toString());
				}
			}
			
			if("TAX,TISTAX".contains(DataObjectUtil.getHashMapStr(data,"opracd").toString())
					&& !"TIS".equals(DataObjectUtil.getHashMapStr(data,"opracd").toString())){
				trbtxls = new TrbTxlsInfo();
				trbtxls.setStacid(DataObjectUtil.getIntegerValue(data, "stacid"));
				trbtxls.setSystid(DataObjectUtil.getHashMapStr(data,"systid").toString());
				trbtxls.setTrandt(DataObjectUtil.getHashMapStr(data,"trandt").toString());
				trbtxls.setTransq(DataObjectUtil.getHashMapStr(data,"transq").toString());
				trbtxls.setVchrsq(DataObjectUtil.getHashMapStr(data,"loansq").toString());
				trbtxls.setAcctbr(DataObjectUtil.getHashMapStr(data,"acctbr").toString());
				trbtxls.setTranbr(DataObjectUtil.getHashMapStr(data,"tranbr").toString());
				trbtxls.setCustcd(DataObjectUtil.getHashMapStr(data,"dccatp").toString());
				trbtxls.setBusitp("0");
				trbtxls.setCrcycd(DataObjectUtil.getHashMapStr(data,"crcycd").toString());
				if(("IN".equalsIgnoreCase(DataObjectUtil.getHashMapStr(data,"inout").toString()) && Constants.AMNTCD_DEBIT.equals(DataObjectUtil.getHashMapStr(data,"amntcd").toString()))
						|| ("OU".equalsIgnoreCase(DataObjectUtil.getHashMapStr(data,"inout").toString()) && Constants.AMNTCD_CREDIT.equals(DataObjectUtil.getHashMapStr(data,"amntcd").toString()))){
					trbtxls.setTranam(new BigDecimal(DataObjectUtil.getHashMapStr(data,"captam").toString()));
					trbtxls.setTaxbam(new BigDecimal(DataObjectUtil.getHashMapStr(data,"vatxam").toString()));
					trbtxls.setPricam(new BigDecimal(DataObjectUtil.getHashMapStr(data,"price").toString()));
				}else{
					trbtxls.setTranam(BigDecimal.ZERO.subtract(new BigDecimal(DataObjectUtil.getHashMapStr(data,"captam").toString())));
					trbtxls.setTaxbam(BigDecimal.ZERO.subtract(new BigDecimal(DataObjectUtil.getHashMapStr(data,"vatxam").toString())));
					trbtxls.setPricam(BigDecimal.ZERO.subtract(new BigDecimal(DataObjectUtil.getHashMapStr(data,"price").toString())));
				}
				trbtxls.setVatxrt(DataObjectUtil.getHashMapStr(data,"vatxrt").toString());
				trbtxls.setStatus("0");
				trbtxls.setCrcyiv("01");
				trbtxls.setTypecd(DataObjectUtil.getHashMapStr(data,"txtpcd").toString());
				trbtxls.setExeptg(DataObjectUtil.getHashMapStr(data,"exeptg").toString());
				trbtxls.setCatxtp(DataObjectUtil.getHashMapStr(data,"catxtp").toString());
				trbtxls.setExpram(BigDecimal.valueOf(Double.parseDouble(DataObjectUtil.getHashMapStr(data,"price").toString())));
				trbtxls.setExchrt(BigDecimal.ZERO);
			}
		}catch(AnalyseException aex){
			throw new AnalyseException(DataObjectUtil.getHashMapStr(data,"TRANINFO") + ":" + aex.getMessage(),aex);
		}catch(Exception ex){
			throw new AnalyseException(DataObjectUtil.getHashMapStr(data,"TRANINFO") + ":" + ex.getMessage(),ex);
		}
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public String check() throws EngineRuntimeException {
		// TODO Auto-generated method stub
		//sysIntfDaoImpl.checkValidate(sysIntf,data);
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public GlsExtd execute(int orderCount) {
		// TODO Auto-generated method stub
		if(null != command){
			TxbBusiInfoMapper.insertTrbRecv(command);
		}else if(null != trbbusi){
			TxbBusiInfoMapper.insertTrbBusi(trbbusi);
		}
		
		if(null != trbtxls){
			TxbBusiInfoMapper.insertTrbTxls(trbtxls);
		}
		return null;
	}

	@Override
	public TranamInfoEntity getTranamInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	public TxbBusiInfoMapper getTxbBusiInfoMapper() {
		return TxbBusiInfoMapper;
	}

	public void setTxbBusiInfoMapper(TxbBusiInfoMapper TxbBusiInfoMapper) {
		this.TxbBusiInfoMapper = TxbBusiInfoMapper;
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return data;
	}
	@Override
	public JSONObject getCmmd() {
		// TODO Auto-generated method stub
		return (JSONObject)JSON.toJSON(command);
	}
	public static void main(String arg[]) {
		System.out.println(BigDecimal.ZERO.subtract(BigDecimal.valueOf(Double.valueOf("9.00"))));
	}
	
}

