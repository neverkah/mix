package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.SysLndt;

public interface SysLndtMapper {
	public SysLndt[] getEntities(SysLndt lndt);
	public int countEntities(SysLndt lndt);
}
