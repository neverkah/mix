package com.sunline.sbp.core.bean;

import java.util.Date;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.dao.mapper.SysAcctOpenMapper;
import com.sunline.sbp.model.SysAcctOpen;
import com.sunline.sunbp.util.MyBatisUtil;

public class SysAcctOpenBean {
	
	private static Logger logger = Logger.getLogger(SysAcctOpenBean.class);
	
	public static int selectEntity(SysAcctOpen entity) throws AnalyseException {
		// TODO Auto-generated method stub
		if(0 == entity.getStacid()
				|| null == entity.getSystid()
				|| null == entity.getBrchcd()
				|| null == entity.getCrcycd()
				|| null == entity.getItemcd()){
			logger.error("�������Ϸ�:"+entity.toString());
			throw new AnalyseException("�������Ϸ�:"+entity.toString());
		}
		
		SqlSession sqlSession = null;
		try{
			sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
			//logger.error("ACCT��ȡsqlSession�ĳɹ�logger");
		}catch(Exception ex){
			if(null == sqlSession){
				logger.error("ACCT��ȡsqlSessionʧ��logger",ex);
				throw new AnalyseException("ACCT��ȡsqlSessionʧ��",ex);
			}
		}
		
		SysAcctOpenMapper sysAcctOpenMapper = sqlSession.getMapper(SysAcctOpenMapper.class);
		
		int nextOrder = 1;
		try{
			
			SysAcctOpen sysAcctOpenRecord = sysAcctOpenMapper.selectEntity(entity);
			Date d0  = new Date();
			if(null == sysAcctOpenRecord){
				entity.setAorder(1);
				int record = sysAcctOpenMapper.insertAcctnoOpenInfo(entity);
				if(record != 1){
					throw new Exception("����������������¼ʧ��");
				}
			}else{
				nextOrder = sysAcctOpenRecord.getAorder() + 1;
				int record = sysAcctOpenMapper.updateOrder(entity);
				if(record != 1){
					throw new Exception("�������������¼�¼ʧ��");
				}
			}
			Date d1 = new Date();
			logger.info("open acctno:"+(d1.getTime()-d0.getTime())+"ms");
			sqlSession.commit();
		}catch(Exception ex){
			sqlSession.rollback();
			logger.info("�˻���Ϣ���£�");
			logger.info("systid=" + entity.getSystid());
			logger.info("brchcd=" + entity.getBrchcd());
			logger.info("itemcd=" + entity.getItemcd());
			logger.info("crcycd=" + entity.getCrcycd());
			throw new AnalyseException("ACCT��ȡ������¼�쳣:���ڶ��������ܴ���1����������¼,����"+ex.getMessage(),ex);
		}finally{
			if(null != sqlSession){
				sqlSession.close();
			}
		}
		
		return nextOrder;
	}
}
