package com.sunline.sbp.core.bean;

public class CacheTargetBean {
	private static int LNDTCACHE = 0;
	private static int DTITCACHE = 0;
	private static int BRCHCACHE = 0;
	private static int ITEMCACHE = 0;
	
	
	/**
	 * ��ȡˢ�»����״̬
	 * @param name
	 * @return
	 */
	public static int getCacheTarget(String name){
		if(name.equalsIgnoreCase("lndtCache")){
			return LNDTCACHE;
		}else if(name.equalsIgnoreCase("itemCache")){
			return ITEMCACHE;
		}else if(name.equalsIgnoreCase("brchCache")){
			return BRCHCACHE;
		}else if(name.equalsIgnoreCase("AccountingCodeCache")){
			return DTITCACHE;
		}else{
			return 0;
		}
	}
	
	/**
	 * ����ˢ�»����ָ����и���
	 * @param name
	 */
	public static void freshCacheTarget(String name){
		if(name.equalsIgnoreCase("lndtCache")){
			LNDTCACHE = 1;
		}else if(name.equalsIgnoreCase("itemCache")){
			ITEMCACHE = 1;
		}else if(name.equalsIgnoreCase("brchCache")){
			BRCHCACHE = 1;
		}else if(name.equalsIgnoreCase("AccountingCodeCache")){
			DTITCACHE = 1;
		}
	}
	
	/**
	 * ����ˢ�����
	 * @param name
	 */
	public static void updateCacheTarget(String name){
		
		if(name.equalsIgnoreCase("lndtCache")){
			LNDTCACHE = 0;
		}else if(name.equalsIgnoreCase("itemCache")){
			ITEMCACHE = 0;
		}else if(name.equalsIgnoreCase("brchCache")){
			BRCHCACHE = 0;
		}else if(name.equalsIgnoreCase("AccountingCodeCache")){
			DTITCACHE = 0;
		}
	}
	
}
