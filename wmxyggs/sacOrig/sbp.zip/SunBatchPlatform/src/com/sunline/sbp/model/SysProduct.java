package com.sunline.sbp.model;

/**
 * ϵͳ��Ʒ��(sys_prod)
 * @author Zhangjin
 *
 */
public class SysProduct {
	private String prodcd;
	private String prodtp;
	private String pdgpcd;
	private String prgptp;
	private String prgpid;
	private String prodna;
	private String enname;
	private String desctx;
	private String vermod;
	private String module;
	private String projcd;
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public String getProdtp() {
		return prodtp;
	}
	public void setProdtp(String prodtp) {
		this.prodtp = prodtp;
	}
	public String getPdgpcd() {
		return pdgpcd;
	}
	public void setPdgpcd(String pdgpcd) {
		this.pdgpcd = pdgpcd;
	}
	public String getPrgptp() {
		return prgptp;
	}
	public void setPrgptp(String prgptp) {
		this.prgptp = prgptp;
	}
	public String getPrgpid() {
		return prgpid;
	}
	public void setPrgpid(String prgpid) {
		this.prgpid = prgpid;
	}
	public String getProdna() {
		return prodna;
	}
	public void setProdna(String prodna) {
		this.prodna = prodna;
	}
	public String getEnname() {
		return enname;
	}
	public void setEnname(String enname) {
		this.enname = enname;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
	
	
}
