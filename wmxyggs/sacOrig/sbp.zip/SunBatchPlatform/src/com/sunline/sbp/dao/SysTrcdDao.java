package com.sunline.sbp.dao;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.SysTrcd;

public interface SysTrcdDao {
	public SysTrcd getSysTrcdEntity(String prcscd , String projcd) throws EngineRuntimeException;
}
