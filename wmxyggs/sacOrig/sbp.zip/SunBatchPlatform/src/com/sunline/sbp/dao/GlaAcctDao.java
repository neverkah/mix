package com.sunline.sbp.dao;

import java.math.BigDecimal;

import com.sunline.foundation.EngineRuntimeException;

public interface GlaAcctDao {
	/**
	 * �¿��ʻ�
	 * 
	 * @param stacid
	 *            ����
	 * @param systid
	 *            ϵͳ��ʶ
	 * @param brchcd
	 *            ��������
	 * @param itemcd
	 *            ��Ŀ
	 * @param crcycd
	 *            ����
	 * @return
	 * @throws EngineRuntimeException
	 */
	public String openAccount(int stacid, String systid, String trandt,String brchcd,
			String itemcd, String crcycd, String subscd)
			throws EngineRuntimeException;
	
	/**
	 * �����˻����
	 * @param stacid
	 * @param systid
	 * @param brchcd
	 * @param itemcd
	 * @param crcycd
	 * @param subscd
	 * @param amntcd
	 * @param tranam
	 * @param transq
	 * @param pmodck
	 * @return
	 * @throws EngineRuntimeException
	 */
	public boolean updateAccountBalance(int stacid, String systid, String brchcd,
			String itemcd, String crcycd, String subscd, String amntcd,
			BigDecimal tranam, String transq, String pmodck,String soursq)
			throws EngineRuntimeException;

}
