package com.sunline.sbp.application;

import static com.sunline.sbp.application.Help.initMetaConfig;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.onln.application.provider.CommandGlServiceImpl;
import com.sunline.sbp.service.impl.FundClearingServiceImpl;
import com.taobao.metamorphosis.Message;
import com.taobao.metamorphosis.client.MessageSessionFactory;
import com.taobao.metamorphosis.client.MetaMessageSessionFactory;
import com.taobao.metamorphosis.client.consumer.ConsumerConfig;
import com.taobao.metamorphosis.client.consumer.MessageConsumer;
import com.taobao.metamorphosis.client.consumer.MessageListener;

public class CommandConsumer {
	static int mycount = 0;
	static long timeMy = 0;
	private static Logger logger = Logger.getLogger(FundClearingServiceImpl.class);
    public static void main(final String[] args) throws Exception {
        // New session factory,ǿ�ҽ���ʹ�õ���
        final MessageSessionFactory sessionFactory = new MetaMessageSessionFactory(initMetaConfig());

        // subscribed topic
        final String topic = "gl-vchr";
        // consumer group
        final String group = "meta-gcmmd";
        // create consumer,ǿ�ҽ���ʹ�õ���
        final MessageConsumer consumer = sessionFactory.createConsumer(new ConsumerConfig(group));
        // subscribe topic
        
        final ExecutorService fixedThreadPool = Executors.newFixedThreadPool(20);
        
        final CommandGlServiceImpl 
    		ap = (CommandGlServiceImpl) ApplicationBeanFactory
					.getApplicationContextInstance().getBean("cmmdService");
        
        consumer.subscribe(topic, 1024 * 1024 , new MessageListener() {
        	
            @Override
            public void recieveMessages(final Message message) {
            	
            	String bussinessInfo = new String(message.getData());
            	JSONObject jsonObject = null;
            	try{
            		jsonObject = JSON.parseObject(bussinessInfo);
            	}catch(Exception ex){
            		logger.error("err:::" + bussinessInfo);
            		ex.printStackTrace();
            	}finally{
            		System.out.println("jsonObject:" + jsonObject.getString("transq"));
            		//logger.info("jsonObject:" + jsonObject);
            	}
            	long beginT = System.nanoTime();
            	//���ɹ鼯���ݶ���
            	//BusinessObject businessObject = BusiDecisionMaker.createBusiness(jsonObject);
            	/*GlsExtd entity = (GlsExtd)JSONObject.toBean(jsonObject, GlsExtd.class);
            	ArrayList<GlsExtd> list = new ArrayList<GlsExtd>();
            	list.add(entity);*/
            	//���׷���
            	
        		String result_message = null;
            	try {
            		System.out.println("transq:" + jsonObject.getString("transq"));
            		result_message = ap.commandTransaction(1, jsonObject.getString("systid"), jsonObject.getString("trandt"), jsonObject.getString("transq"));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally{
					//���´���״̬��������־
					System.out.println("result_message:" +result_message);
				}
        		long endT = System.nanoTime();
        		timeMy = timeMy + (endT - beginT)/1000L;
        		logger.debug("Receive message " + new String(message.getData()) + "-----" + (endT-beginT)/1000000L);
            }

            @Override
            public Executor getExecutor() {
                // Thread pool to process messages,maybe null.
            	//logger.debug("executor....");
                return fixedThreadPool;
            	//Executors.newCachedThreadPool();
            	//return Executors.newFixedThreadPool(5);
            }
        });
        // complete subscribe
        consumer.completeSubscribe();
    }

}
