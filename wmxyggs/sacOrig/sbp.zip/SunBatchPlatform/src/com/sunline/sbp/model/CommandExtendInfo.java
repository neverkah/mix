package com.sunline.sbp.model;

public class CommandExtendInfo {
	private String prcscd;
	private String tablna;
	private String cmmdtg;
	private String projcd;
	
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public String getTablna() {
		return tablna;
	}
	public void setTablna(String tablna) {
		this.tablna = tablna;
	}
	public String getCmmdtg() {
		return cmmdtg;
	}
	public void setCmmdtg(String cmmdtg) {
		this.cmmdtg = cmmdtg;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
}
