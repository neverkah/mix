package com.sunline.sbp.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.Enumeration;
import com.sunline.foundation.ServiceException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.core.bean.GlaVchrBean;
import com.sunline.sbp.dao.GlaVoucherDao;
import com.sunline.sbp.dao.GliVoucherDao;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.GliVoucher;
import com.sunline.sbp.service.GliVchrPassService;
import com.sunline.sunbp.util.DataCheckUtil;

/**
 * 
 * @author Zhangjin
 *
 */
public class GliVchrPassServiceImpl implements GliVchrPassService {
	
	private Logger logger = Logger.getLogger(GliVchrPassServiceImpl.class);

	@Override
	public void vchrTransaction(JSONArray jsonArray) throws ServiceException {
		// TODO Auto-generated method stub
		ArrayList<GliVoucher> gliVchrs = (ArrayList<GliVoucher>) JSON.parseArray(jsonArray.toJSONString(), GliVoucher.class);
		GlaVoucherDao glaVchrDao = (GlaVoucherDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(GlaVoucherDao.class);
		GliVoucherDao gliVchrDao = (GliVoucherDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(GliVoucherDao.class);
		
		List<GlaVoucher> glaVchrs = new ArrayList<GlaVoucher>();
		
		//���ݺϷ���У�ԣ����ڿ�Ŀ���ƽ���顢���׻�������������
		String result = DataCheckUtil.checkVchrBalance(gliVchrs);
		if(!DataCheckUtil.isTrueOrFalse(result)){
			logger.error(result);
			throw new ServiceException(result);
		}
		
		for(GliVoucher entity : gliVchrs){
			entity.setTranst(Enumeration.GLI_VCHR_TRANST.TRANST_OK.value);
			GlaVoucher glaVchr = GlaVchrBean.toGlaVchr(entity);
			
			//��ƴ�Ʊ���棬��ʶΪ�ѹ���
			glaVchr.setTranst(Enumeration.GLA_VCHR_TRANST.TRANST_OK.value);
			
			glaVchrs.add(glaVchr);
			
			//��Ŀ������
			/*��������vchrerͳһ����
			 * 1 �����»��м����ӵ���ʱ liuchj@sunline.cn 2015-6-1
			 * 2 ���ʵʱ���£������ܻ���ֲ�һ����
			 */
			//ap.updateBalance(glaVchr);
		}
		
		try {
			//���浽�ӿڴ�Ʊ��
			gliVchrDao.insertEntity(gliVchrs);
			
			//���浽���˴�Ʊ��
			List<List<GlaVoucher>> glavchrList = new ArrayList<List<GlaVoucher>>();
			glavchrList.add(glaVchrs);
			glaVchrDao.insertEntitiesBatch(glavchrList, glaVchrs.get(0).getTrandt(), glaVchrs.get(0).getTranbr(),glaVchrs.get(0).getSourac());
			
		} catch (EngineRuntimeException e) {
			// TODO Auto-generated catch block
			logger.error(e);
			throw new ServiceException(e.getMessage(),e);
		}catch(Exception e){
			logger.error(e);
			throw new ServiceException("ϵͳ�쳣",e);
		}
		
	}
}
