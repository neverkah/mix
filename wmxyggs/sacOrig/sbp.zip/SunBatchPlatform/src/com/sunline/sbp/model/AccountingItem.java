package com.sunline.sbp.model;

/**
 * ��ƿ�Ŀ��com_item��
 * @author Zhangjin
 *
 */

public class AccountingItem {
	private int stacid;
	private String itemcd;
	private String sprrcd;
	private String itemna;
	private String cutrna;
	private String itemtp;
	private String itempr;
	private String detltg;
	private String itemdn;
	private String usedtp;
	private String measut;
	private String confin;
	private String pomdtg;
	private String mntytg;
	private String ioflag;
	private String inactp;
	private String brchtg;
	private String prcdtg;
	private String bulntg;
	private String custtg;
	private String emlytg;
	private String accttg;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getItemcd() {
		return itemcd;
	}
	public void setItemcd(String itemcd) {
		this.itemcd = itemcd;
	}
	public String getSprrcd() {
		return sprrcd;
	}
	public void setSprrcd(String sprrcd) {
		this.sprrcd = sprrcd;
	}
	public String getItemna() {
		return itemna;
	}
	public void setItemna(String itemna) {
		this.itemna = itemna;
	}
	public String getCutrna() {
		return cutrna;
	}
	public void setCutrna(String cutrna) {
		this.cutrna = cutrna;
	}
	public String getItemtp() {
		return itemtp;
	}
	public void setItemtp(String itemtp) {
		this.itemtp = itemtp;
	}
	public String getItempr() {
		return itempr;
	}
	public void setItempr(String itempr) {
		this.itempr = itempr;
	}
	public String getDetltg() {
		return detltg;
	}
	public void setDetltg(String detltg) {
		this.detltg = detltg;
	}
	public String getItemdn() {
		return itemdn;
	}
	public void setItemdn(String itemdn) {
		this.itemdn = itemdn;
	}
	public String getUsedtp() {
		return usedtp;
	}
	public void setUsedtp(String usedtp) {
		this.usedtp = usedtp;
	}
	public String getMeasut() {
		return measut;
	}
	public void setMeasut(String measut) {
		this.measut = measut;
	}
	public String getConfin() {
		return confin;
	}
	public void setConfin(String confin) {
		this.confin = confin;
	}
	public String getPomdtg() {
		return pomdtg;
	}
	public void setPomdtg(String pomdtg) {
		this.pomdtg = pomdtg;
	}
	public String getMntytg() {
		return mntytg;
	}
	public void setMntytg(String mntytg) {
		this.mntytg = mntytg;
	}
	public String getInactp() {
		return inactp;
	}
	public void setInactp(String inactp) {
		this.inactp = inactp;
	}
	public String getBrchtg() {
		return brchtg;
	}
	public void setBrchtg(String brchtg) {
		this.brchtg = brchtg;
	}
	public String getPrcdtg() {
		return prcdtg;
	}
	public void setPrcdtg(String prcdtg) {
		this.prcdtg = prcdtg;
	}
	public String getBulntg() {
		return bulntg;
	}
	public void setBulntg(String bulntg) {
		this.bulntg = bulntg;
	}
	public String getCusttg() {
		return custtg;
	}
	public void setCusttg(String custtg) {
		this.custtg = custtg;
	}
	public String getEmlytg() {
		return emlytg;
	}
	public void setEmlytg(String emlytg) {
		this.emlytg = emlytg;
	}
	public String getAccttg() {
		return accttg;
	}
	public void setAccttg(String accttg) {
		this.accttg = accttg;
	}
	public String getIoflag(){
		return ioflag;
	}
	public void setIoflag(String ioflag){
		this.ioflag = ioflag;
	}
}
