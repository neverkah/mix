package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * �ֽ��ո�������ϸ��
 * @author Zhangjin
 *
 */
public class CashReceiptAndPayment {
	private int stacid;
	private String systid;
	private String trandt;
	private String csiosq;
	private String transq;
	private String tranbr;
	private String csbxtp;
	private String csbxno;
	private String acctbr;
	private String crcycd;
	private BigDecimal tranam;
	private String bookus;
	private String ckbkus;
	private String corrtg;
	private String prodcd;
	private String amntcd;
	private String bkfnst;
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getCsiosq() {
		return csiosq;
	}
	public void setCsiosq(String csiosq) {
		this.csiosq = csiosq;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getCsbxtp() {
		return csbxtp;
	}
	public void setCsbxtp(String csbxtp) {
		this.csbxtp = csbxtp;
	}
	public String getCsbxno() {
		return csbxno;
	}
	public void setCsbxno(String csbxno) {
		this.csbxno = csbxno;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public String getBookus() {
		return bookus;
	}
	public void setBookus(String bookus) {
		this.bookus = bookus;
	}
	public String getCkbkus() {
		return ckbkus;
	}
	public void setCkbkus(String ckbkus) {
		this.ckbkus = ckbkus;
	}
	public String getCorrtg() {
		return corrtg;
	}
	public void setCorrtg(String corrtg) {
		this.corrtg = corrtg;
	}
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}
	public String getBkfnst() {
		return bkfnst;
	}
	public void setBkfnst(String bkfnst) {
		this.bkfnst = bkfnst;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	
	

}
