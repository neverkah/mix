package com.sunline.sbp.service.impl;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.Constants;
import com.sunline.foundation.ServiceException;
import com.sunline.sbp.core.bean.CacheTargetBean;
import com.sunline.sbp.service.CacheFreshAction;

/**
 * 
 * @author Zhangjin
 *
 */
public class CacheFreshActionImpl implements CacheFreshAction {
	
	private Logger logger = Logger.getLogger(CacheFreshActionImpl.class);

	@Override
	public String operate(JSONObject jsonObject) throws ServiceException {
		// TODO Auto-generated method stub
		
		String cacheName = null;
		String message = Constants.EXECUTE_NULL;
		try{
			cacheName = jsonObject.getString("name");
			CacheTargetBean.freshCacheTarget(cacheName);
			logger.fatal("����"+ cacheName + "ˢ�³ɹ���");
		}catch(Exception rex){
			message = Constants.EXECUTE_EXCEPTION + ":ϵͳ�쳣" + "ˢ�»���"+ cacheName + "ʧ��";
    		logger.error(message,rex);
    		throw new ServiceException(message,rex);
		}
		
		return Constants.EXECUTE_SUCC;
	}

}
