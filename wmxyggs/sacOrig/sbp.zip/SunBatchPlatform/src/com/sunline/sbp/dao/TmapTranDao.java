package com.sunline.sbp.dao;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.SysTmapTran;

public interface TmapTranDao {
	public SysTmapTran[] getTmapTrans(SysTmapTran sysTmapTran) throws EngineRuntimeException;
}
