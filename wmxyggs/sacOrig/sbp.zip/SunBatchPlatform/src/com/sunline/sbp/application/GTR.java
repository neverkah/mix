package com.sunline.sbp.application;

import org.apache.log4j.Logger;

public class GTR {
	private static Logger logger = Logger.getLogger(GTR.class);
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i = 701 ; i <= 1000 ; i++){
			logger.debug("{\"systid\":\"fi\",\"trandt\":\"20121221\",\"transq\":\"010020"+i+"\",\"tranbr\":\"01002\",\"asetno\":\"*\",\"prcscd\":\"asbreg\",\"asettp\":\"010001\",\"inchvl\":20,\"dpravl\":0,\"trantp\":\"TR\",\"smrytx\":\"�̶��ʲ�����\",\"crcycd\":\"01\"}");
		}
	}

}
