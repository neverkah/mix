package com.sunline.sbp.dao.impl;

import java.util.Hashtable;
import java.util.List;

import com.sunline.foundation.Constants;
import com.sunline.sbp.dao.ComBulnDao;
import com.sunline.sbp.dao.mapper.ComBulnMapper;
import com.sunline.sbp.model.ComBuln;

public class ComBulnDaoImpl implements ComBulnDao {
	
	private ComBulnMapper comBulnMapper;
	
	private int initail = 0;
	
	/**
	 * ȫ��Ϣ����
	 */
	private static Hashtable<String,ComBuln> bulnDatas = new Hashtable<String,ComBuln>();

	@Override
	public List<ComBuln> getAllEntities() {
		// TODO Auto-generated method stub
		List<ComBuln> tableData = comBulnMapper.getAllEntities();
		for(ComBuln entity : tableData){
			bulnDatas.put(entity.getStacid()+Constants.DTAG+entity.getBulncd(), entity);
		}
		return tableData;
	}
	
	public Hashtable<String,ComBuln> getCacheData(){
		if(initail == 0){
			synchronized(this) {
				if(initail == 0){
					getAllEntities();
					initail = 1;
				}
			}
		}
		return bulnDatas;
	}
	
	public boolean frushCache(){
		bulnDatas.clear();
		getAllEntities();
		return true;
	}

	public ComBulnMapper getComBulnMapper() {
		return comBulnMapper;
	}

	public void setComBulnMapper(ComBulnMapper comBulnMapper) {
		this.comBulnMapper = comBulnMapper;
	}

}
