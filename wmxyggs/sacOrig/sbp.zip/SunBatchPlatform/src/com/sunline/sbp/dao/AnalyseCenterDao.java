package com.sunline.sbp.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.core.bean.ExtdVSCmmdBean;
import com.sunline.sbp.datamerger.BusinessObject;
import com.sunline.sbp.model.GlsExtd;

/**
 * 
 * @author Zhangjin
 *
 */
public interface AnalyseCenterDao {
	public ExtdVSCmmdBean welcomeTransaction(BusinessObject business , int orderCount) throws EngineRuntimeException;
	public ArrayList<GlsExtd> dealBusiEntityTransaction(BusinessObject business) throws EngineRuntimeException;
	public ArrayList<GlsExtd> dealBusiEntityTransaction(ArrayList<BusinessObject> businesses) throws EngineRuntimeException;
	public ExtdVSCmmdBean dealBusiEntityV2Transaction(ArrayList<BusinessObject> businesses) throws EngineRuntimeException;
}
