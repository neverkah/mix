package com.sunline.sbp.base;

public abstract class InterfaceObject {
	
	private String systid;
	private String prcscd;
		
	public String getSystid(){
		return this.systid;
	}
	
	public String getPrcscd(){
		return this.prcscd;
	}
}
