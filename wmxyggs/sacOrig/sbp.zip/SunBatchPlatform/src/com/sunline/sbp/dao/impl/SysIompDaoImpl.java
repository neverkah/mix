package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.tools.StringUtil;
import com.sunline.sbp.dao.SysIompDao;
import com.sunline.sbp.dao.mapper.SysIompMapper;
import com.sunline.sbp.model.SysIomp;

public class SysIompDaoImpl implements SysIompDao {
	
	private Logger logger = Logger.getLogger(SysIompDaoImpl.class);
	
	SysIompMapper sysIompMapper;

	@Override
	public SysIomp[] getMapInfo(String ruleid) {
		// TODO Auto-generated method stub
		logger.debug("����ӳ����봮��" + ruleid);
		if(!StringUtil.isNotNull(ruleid)){
			String message = "�����������ӳ��ID����Ϊ��";
			logger.error(message);
		}
		SysIomp[] iomps = sysIompMapper.getEntites(ruleid);
		return iomps;
	}

	public SysIompMapper getSysIompMapper() {
		return sysIompMapper;
	}

	public void setSysIompMapper(SysIompMapper sysIompMapper) {
		this.sysIompMapper = sysIompMapper;
	}
	
}
