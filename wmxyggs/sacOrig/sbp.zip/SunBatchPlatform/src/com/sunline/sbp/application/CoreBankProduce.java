package com.sunline.sbp.application;

import static com.sunline.sbp.application.Help.initMetaConfig;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.log4j.Logger;

import com.sunline.sbp.service.impl.FundClearingServiceImpl;
import com.taobao.metamorphosis.Message;
import com.taobao.metamorphosis.client.MessageSessionFactory;
import com.taobao.metamorphosis.client.MetaMessageSessionFactory;
import com.taobao.metamorphosis.client.producer.MessageProducer;
import com.taobao.metamorphosis.client.producer.SendResult;

public class CoreBankProduce {
	static int msgcount = 0;
	private static Logger logger = Logger.getLogger(FundClearingServiceImpl.class);
    public static void main(final String[] args) throws Exception {
        // New session factory,ǿ�ҽ���ʹ�õ���
        final MessageSessionFactory sessionFactory = new MetaMessageSessionFactory(initMetaConfig());
        // create producer,ǿ�ҽ���ʹ�õ���
        final MessageProducer producer = sessionFactory.createProducer();
        // publish topic
        final String topic = "core";
        producer.publish(topic);

        //final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        FileReader filereader=null;
        try {			
        	filereader = new FileReader("E:\\sungl\\SunGLBP_workspace\\Example\\lib\\busi.txt");		
        } catch (FileNotFoundException e) {			
        		// TODO Auto-generated catch block			
        		e.printStackTrace();
        }
        final BufferedReader reader = new BufferedReader(filereader);
        String line = null;
        while (msgcount < 10000 && (line = readLine(reader)) != null) {
            // send message
            final SendResult sendResult = producer.sendMessage(new Message(topic, line.getBytes()));
            // check result
            if (!sendResult.isSuccess()) {
            	logger.error("Send message failed,error message:" + sendResult.getErrorMessage());
            }
            else {
            	logger.debug("Send message successfully,sent to " + sendResult.getPartition());
            }
        }
        reader.close();
        filereader.close();
    }


    private static String readLine(final BufferedReader reader) throws IOException {
    	logger.debug("Type a message to send:");
        msgcount++;
        return reader.readLine();
    }
}
