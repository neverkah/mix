package com.sunline.sbp.service;

import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.ServiceException;

public interface CacheFreshAction {
	public String operate(JSONObject jsonObject) throws ServiceException;
}
