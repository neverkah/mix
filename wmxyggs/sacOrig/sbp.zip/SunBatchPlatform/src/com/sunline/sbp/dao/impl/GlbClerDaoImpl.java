package com.sunline.sbp.dao.impl;

import java.util.List;

import com.sunline.sbp.dao.GlbClerDao;
import com.sunline.sbp.dao.mapper.GlbClerMapper;
import com.sunline.sbp.model.GlbCler;

public class GlbClerDaoImpl implements GlbClerDao {
	
	GlbClerMapper glbClerMapper;

	@Override
	public int save(List<GlbCler> entities) {
		// TODO Auto-generated method stub
		//���ݺϷ���У��
		for(GlbCler entity : entities){
			glbClerMapper.insertEntities(entity);
		}
		
		return 0;
	}

	public GlbClerMapper getGlbClerMapper() {
		return glbClerMapper;
	}

	public void setGlbClerMapper(GlbClerMapper glbClerMapper) {
		this.glbClerMapper = glbClerMapper;
	}

	@Override
	public int updateTrandtTransq(GlbCler entitie) {
		int count  = glbClerMapper.updateTrandtTransq(entitie);
		return count;
	}
	
	
}
