package com.sunline.sbp.dao;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.SysDtitConf;

public interface SysDtitConfDao {
	public SysDtitConf getProdcdProperties(int stacid,String prodcd) throws EngineRuntimeException;
}
