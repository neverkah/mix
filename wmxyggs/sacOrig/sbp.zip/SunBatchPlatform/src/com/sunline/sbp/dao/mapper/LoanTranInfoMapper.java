package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.LoanTranInfo;

public interface LoanTranInfoMapper {
	public String insertEntity(LoanTranInfo entity);
	public LoanTranInfo selectEntity(@Param("trandt") String trandt , @Param("transq") String transq , @Param("cmmdsq") String cmmdsq , @Param("systid") String systid);
	public void postingUpdate(LoanTranInfo entity);
}
