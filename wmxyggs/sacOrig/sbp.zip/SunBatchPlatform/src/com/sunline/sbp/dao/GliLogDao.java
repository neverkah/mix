package com.sunline.sbp.dao;

import java.sql.Timestamp;

import com.alibaba.fastjson.JSONObject;

public interface GliLogDao {
	public void insertGliMslg(String bussinessInfo, JSONObject gliMslgJSONObject, Timestamp recedt, Timestamp respdt,
			String executeMsg, String mstype);
	
	
}
