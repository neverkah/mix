package com.sunline.sbp.service;

import com.alibaba.fastjson.JSONArray;
import com.sunline.foundation.ServiceException;

public interface GliVchrPassService {
	public void vchrTransaction(JSONArray jsonArray) throws ServiceException;
}
