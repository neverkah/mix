package com.sunline.sbp.model;

public class ComCust {
	private int stacid;
	private String custcd;
	private String custna;
	private String sprrcd;
	private String detltg;
	private String custtp;
	private String orgcod;
	private String corpps;
	private String idnumb;
	private String phbumb;
	private String addres;
	private String licens;
	private String linkps;
	private String usedtp;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getCustcd() {
		return custcd;
	}
	public void setCustcd(String custcd) {
		this.custcd = custcd;
	}
	public String getCustna() {
		return custna;
	}
	public void setCustna(String custna) {
		this.custna = custna;
	}
	public String getSprrcd() {
		return sprrcd;
	}
	public void setSprrcd(String sprrcd) {
		this.sprrcd = sprrcd;
	}
	public String getDetltg() {
		return detltg;
	}
	public void setDetltg(String detltg) {
		this.detltg = detltg;
	}
	public String getCusttp() {
		return custtp;
	}
	public void setCusttp(String custtp) {
		this.custtp = custtp;
	}
	public String getOrgcod() {
		return orgcod;
	}
	public void setOrgcod(String orgcod) {
		this.orgcod = orgcod;
	}
	public String getCorpps() {
		return corpps;
	}
	public void setCorpps(String corpps) {
		this.corpps = corpps;
	}
	public String getIdnumb() {
		return idnumb;
	}
	public void setIdnumb(String idnumb) {
		this.idnumb = idnumb;
	}
	public String getPhbumb() {
		return phbumb;
	}
	public void setPhbumb(String phbumb) {
		this.phbumb = phbumb;
	}
	public String getAddres() {
		return addres;
	}
	public void setAddres(String addres) {
		this.addres = addres;
	}
	public String getLicens() {
		return licens;
	}
	public void setLicens(String licens) {
		this.licens = licens;
	}
	public String getLinkps() {
		return linkps;
	}
	public void setLinkps(String linkps) {
		this.linkps = linkps;
	}
	public String getUsedtp() {
		return usedtp;
	}
	public void setUsedtp(String usedtp) {
		this.usedtp = usedtp;
	}
}
