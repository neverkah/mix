package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.TxpTypeCfg;
import com.sunline.sbp.model.TxpTypeOpen;

public interface TxpTypeCfgMapper {
	public TxpTypeCfg selectEntity(@Param("stacid") int stacid , @Param("prodcd") String prodcd , @Param("prodp1") String prodp1 ,
			 @Param("prodp2") String prodp2,  @Param("prodp3") String prodp3,@Param("prodp4") String prodp4 ,  @Param("prodp5") String prodp5 ,
			 @Param("prodp6") String prodp6,  @Param("prodp7") String prodp7,@Param("prodp8") String prodp8 ,  @Param("prodp9") String prodp9 ,
			 @Param("prodpa") String prodpa);
	public TxpTypeCfg[] selectFullEntities(@Param("stacid") int stacid);
	public TxpTypeOpen[] selectTxpTypeOpen(@Param("stacid") int stacid);
}
