package com.sunline.sbp.dao;

import java.util.List;

import com.sunline.sbp.model.ComBuln;

public interface ComBulnDao {
	public List<ComBuln> getAllEntities();
}
