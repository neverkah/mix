package com.sunline.sbp.model;

public class ComPrsn {
	private String prsncd;
	private String prsnna;
	private int stacid;
	private String brchcd;
	private String sprrcd;
	private String usedtp;
	private String detltg;
	private String prsntp;
	private String idcard;
	private String wkfuna;
	public String getPrsncd() {
		return prsncd;
	}
	public void setPrsncd(String prsncd) {
		this.prsncd = prsncd;
	}
	public String getPrsnna() {
		return prsnna;
	}
	public void setPrsnna(String prsnna) {
		this.prsnna = prsnna;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getBrchcd() {
		return brchcd;
	}
	public void setBrchcd(String brchcd) {
		this.brchcd = brchcd;
	}
	public String getSprrcd() {
		return sprrcd;
	}
	public void setSprrcd(String sprrcd) {
		this.sprrcd = sprrcd;
	}
	public String getUsedtp() {
		return usedtp;
	}
	public void setUsedtp(String usedtp) {
		this.usedtp = usedtp;
	}
	public String getDetltg() {
		return detltg;
	}
	public void setDetltg(String detltg) {
		this.detltg = detltg;
	}
	public String getPrsntp() {
		return prsntp;
	}
	public void setPrsntp(String prsntp) {
		this.prsntp = prsntp;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	public String getWkfuna() {
		return wkfuna;
	}
	public void setWkfuna(String wkfuna) {
		this.wkfuna = wkfuna;
	}
}
