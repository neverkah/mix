package com.sunline.sbp.core.bean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.Enumeration;
import com.sunline.foundation.TranamEntity;
import com.sunline.sbp.model.AccountingItem;
import com.sunline.sbp.model.ComAcct;
import com.sunline.sbp.model.ComBuln;
import com.sunline.sbp.model.ComCent;
import com.sunline.sbp.model.ComCust;
import com.sunline.sbp.model.ComExsr;
import com.sunline.sbp.model.ComItex;
import com.sunline.sbp.model.ComPrsn;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.SysProduct;
import com.sunline.sunbp.util.DataCheckUtil;

public class GlaVchrHelper {

	private static Logger logger = Logger.getLogger(GlaVchrHelper.class);

	/**
	 * ��Ʊ�ĺϷ��Լ��
	 * 
	 * @param vchr
	 * @param item
	 * @return
	 * @throws AnalyseException
	 */
	public static boolean checkValidate(GlaVoucher vchr, AccountingItem item,
			Map<String, ComItex> comItexMap,
			Hashtable<String, ComExsr> exsrDatas,
			Hashtable<String, ComBuln> bulnDatas,
			Hashtable<String, ComCust> custDatas,
			Hashtable<String, ComAcct> acctDatas,
			Hashtable<String, ComPrsn> prsnDatas,
			Hashtable<String, ComCent> centDatas,
			Hashtable<String, SysProduct> prduDatas) throws AnalyseException {
		if (!vchr.getAmntcd().equals(Enumeration.Amntcd.D.value)
				&& !vchr.getAmntcd().equals(Enumeration.Amntcd.C.value)
				&& !vchr.getAmntcd().equals(Enumeration.Amntcd.P.value)
				&& !vchr.getAmntcd().equals(Enumeration.Amntcd.R.value)) {
			throw new AnalyseException("��ˮ:" + vchr.getSoursq() + "�����ķ�¼֮�п�Ŀ��"
					+ vchr.getItemcd() + "�Ľ��׷���" + vchr.getAmntcd() + "�Ƿ���");
		}

		checkPrlncdValide(comItexMap, bulnDatas, vchr, Constants.ASSI_PRLNCD,
				vchr.getPrlncd());

		checkCustcdValide(comItexMap, custDatas, vchr, Constants.ASSI_CUSTCD,
				vchr.getCustcd());

		checkAcctnoValide(comItexMap, acctDatas, vchr, Constants.ASSI_ACCTNO,
				vchr.getAcctno());

		checkPrsncdValide(comItexMap, prsnDatas, vchr, Constants.ASSI_PRSNCD,
				vchr.getPrsncd());

		checkCentcdValide(comItexMap, centDatas, vchr, Constants.ASSI_CENTCD,
				vchr.getCentcd());

		checkPrducdValide(comItexMap, prduDatas, vchr, Constants.ASSI_PRDUCD,
				vchr.getPrducd());

		checkAssisValide(comItexMap, exsrDatas, vchr, Constants.ASSI_ASSIS0,
				vchr.getAssis0());

		checkAssisValide(comItexMap, exsrDatas, vchr, Constants.ASSI_ASSIS1,
				vchr.getAssis1());

		checkAssisValide(comItexMap, exsrDatas, vchr, Constants.ASSI_ASSIS2,
				vchr.getAssis2());

		checkAssisValide(comItexMap, exsrDatas, vchr, Constants.ASSI_ASSIS3,
				vchr.getAssis3());

		checkAssisValide(comItexMap, exsrDatas, vchr, Constants.ASSI_ASSIS4,
				vchr.getAssis4());

		checkAssisValide(comItexMap, exsrDatas, vchr, Constants.ASSI_ASSIS5,
				vchr.getAssis5());

		checkAssisValide(comItexMap, exsrDatas, vchr, Constants.ASSI_ASSIS6,
				vchr.getAssis6());

		checkAssisValide(comItexMap, exsrDatas, vchr, Constants.ASSI_ASSIS7,
				vchr.getAssis7());

		checkAssisValide(comItexMap, exsrDatas, vchr, Constants.ASSI_ASSIS8,
				vchr.getAssis8());

		checkAssisValide(comItexMap, exsrDatas, vchr, Constants.ASSI_ASSIS9,
				vchr.getAssis9());

		return true;
	}

	private static void checkAssisValide(Map<String, ComItex> comItexMap,
			Hashtable<String, ComExsr> exsrDatas, GlaVoucher vchr,
			String assisKey, String assisValue) throws AnalyseException {
		
		if( !comItexMap.containsKey(vchr.getStacid() + Constants.DTAG
				+ assisKey)){
			logger.info("���ף�" + vchr.getStacid()
					+ "δ��ʼ��ά�ȡ�" + assisKey + "��������������Ϣ");
			return;
		}
		
		ComItex comItex = comItexMap.get(vchr.getStacid() + Constants.DTAG
				+ assisKey);

		// ������ã��������Ч��У�飺�����ҷ�ĩ��
		if (null != comItex.getValide()
				&& comItex.getValide().equals("1")) {
			String exsrKey = vchr.getStacid() + Constants.DTAG
					+ comItex.getAcexcd() + Constants.DTAG + assisValue;
			if (exsrDatas.containsKey(exsrKey)) {
				if (!exsrDatas.get(exsrKey).getDetltg().equals("1")) {
					throw new AnalyseException("��ˮ:" + vchr.getSoursq()
							+ "�����ķ�¼������ά�ȡ�" + comItex.getAcexna() + "����ֵ"
							+ assisValue + "����ĩ��");
				} else if (!exsrDatas.get(exsrKey).getValide().equals("1")) {
					throw new AnalyseException("��ˮ:" + vchr.getSoursq()
							+ "�����ķ�¼������ά�ȡ�" + comItex.getAcexna() + "����ֵ"
							+ assisValue + "������Ч״̬");
				}
			} else {
				throw new AnalyseException("��ˮ:" + vchr.getSoursq()
						+ "�����ķ�¼������ά�ȡ�" + comItex.getAcexna() + "����ֵ"
						+ assisValue + "�����ڡ�");
			}
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("���ף�" + vchr.getStacid() + ",ά�ȣ�" + assisKey
						+ "δ����");
			}
		}
	}

	private static void checkPrlncdValide(Map<String, ComItex> comItexMap,
			Hashtable<String, ComBuln> bulnDatas, GlaVoucher vchr,
			String assisKey, String assisValue) throws AnalyseException {
		
		if( !comItexMap.containsKey(vchr.getStacid() + Constants.DTAG
				+ assisKey)){
			logger.info("���ף�" + vchr.getStacid()
					+ "ȱ��ά�ȡ�" + assisKey + "���ĳ�ʼ������������Ϣ");
			return;
		}
		
		ComItex comItex = comItexMap.get(vchr.getStacid() + Constants.DTAG
				+ assisKey);
		String exsrKey = vchr.getStacid() + Constants.DTAG + assisValue;

		if (logger.isDebugEnabled()) {
			logger.debug("comItex:" + comItex + ",exsrKey:" + exsrKey);
		}

		// ������ã��������Ч��У�飺�����ҷ�ĩ��
		if (null != comItex.getValide()
				&& comItex.getValide().equals("1")) {
			if (bulnDatas.containsKey(exsrKey)) {
				if (!bulnDatas.get(exsrKey).getDetltg().equals("1")) {
					throw new AnalyseException("��ˮ:" + vchr.getSoursq()
							+ "�����ķ�¼������ά�ȡ�" + comItex.getAcexna() + "����ֵ"
							+ assisValue + "����ĩ��");
				} else if (!bulnDatas.get(exsrKey).getUsedtp().equals("1")) {
					throw new AnalyseException("��ˮ:" + vchr.getSoursq()
							+ "�����ķ�¼������ά�ȡ�" + comItex.getAcexna() + "����ֵ"
							+ assisValue + "������Ч״̬");
				}
			} else {
				throw new AnalyseException("��ˮ:" + vchr.getSoursq()
						+ "�����ķ�¼������ά�ȡ�" + comItex.getAcexna() + "����ֵ"
						+ assisValue + "�����ڡ�");
			}
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("���ף�" + vchr.getStacid() + ",ά�ȣ�" + assisKey
						+ "δ����");
			}
		}
	}

	private static void checkCustcdValide(Map<String, ComItex> comItexMap,
			Hashtable<String, ComCust> custDatas, GlaVoucher vchr,
			String assisKey, String assisValue) throws AnalyseException {
		
		if( !comItexMap.containsKey(vchr.getStacid() + Constants.DTAG
				+ assisKey)){
			logger.info("���ף�" + vchr.getStacid()
					+ "δ��ʼ��ά�ȡ�" + assisKey + "��������������Ϣ");
			return;
		}
		
		ComItex comItex = comItexMap.get(vchr.getStacid() + Constants.DTAG
				+ assisKey);
		String exsrKey = vchr.getStacid() + Constants.DTAG + assisValue;

		// ������ã��������Ч��У�飺�����ҷ�ĩ��
		if (null != comItex.getValide() 
				&& comItex.getValide().equals("1")) {
			if (custDatas.containsKey(exsrKey)) {
				if (!custDatas.get(exsrKey).getDetltg().equals("1")) {
					throw new AnalyseException("��ˮ:" + vchr.getSoursq()
							+ "�����ķ�¼֮��ά��" + comItex.getAcexna() + "��ֵ"
							+ assisValue + "����ĩ��");
				} else if (!custDatas.get(exsrKey).getUsedtp().equals("1")) {
					throw new AnalyseException("��ˮ:" + vchr.getSoursq()
							+ "�����ķ�¼֮��ά��" + comItex.getAcexna() + "��ֵ"
							+ assisValue + "������Ч״̬");
				}
			} else {
				throw new AnalyseException("��ˮ:" + vchr.getSoursq()
						+ "�����ķ�¼֮��ά��" + comItex.getAcexna() + "��ֵ" + assisValue
						+ "�����ڡ�");
			}
		}else{
			if(logger.isDebugEnabled()){
				logger.debug("���ף�" + vchr.getStacid()
					+ "ά�ȡ�" + assisKey + "��δ����");
			}
		}
	}

	private static void checkCentcdValide(Map<String, ComItex> comItexMap,
			Hashtable<String, ComCent> centDatas, GlaVoucher vchr,
			String assisKey, String assisValue) throws AnalyseException {
		
		if( !comItexMap.containsKey(vchr.getStacid() + Constants.DTAG
				+ assisKey)){
			logger.info("���ף�" + vchr.getStacid()
					+ "δ��ʼ��ά�ȡ�" + assisKey + "��������������Ϣ");
			return;
		}
		
		ComItex comItex = comItexMap.get(vchr.getStacid() + Constants.DTAG
				+ assisKey);
		String exsrKey = vchr.getStacid() + Constants.DTAG + assisValue;

		// ������ã��������Ч��У�飺�����ҷ�ĩ��
		if (null != comItex.getValide() 
				&& comItex.getValide().equals("1")) {
			if (centDatas.containsKey(exsrKey)) {
				if (!centDatas.get(exsrKey).getDetltg().equals("1")) {
					throw new AnalyseException("��ˮ:" + vchr.getSoursq()
							+ "�����ķ�¼֮��ά��" + comItex.getAcexna() + "��ֵ"
							+ assisValue + "����ĩ��");
				} else if (!centDatas.get(exsrKey).getUsedtp().equals("1")) {
					throw new AnalyseException("��ˮ:" + vchr.getSoursq()
							+ "�����ķ�¼֮��ά��" + comItex.getAcexna() + "��ֵ"
							+ assisValue + "������Ч״̬");
				}
			} else {
				throw new AnalyseException("��ˮ:" + vchr.getSoursq()
						+ "�����ķ�¼֮��ά��" + comItex.getAcexna() + "��ֵ" + assisValue
						+ "�����ڡ�");
			}
		}else{
			if(logger.isDebugEnabled()){
				logger.debug("���ף�" + vchr.getStacid()
					+ "ά�ȡ�" + assisKey + "��δ����");
			}
		}
	}

	private static void checkPrsncdValide(Map<String, ComItex> comItexMap,
			Hashtable<String, ComPrsn> prsnDatas, GlaVoucher vchr,
			String assisKey, String assisValue) throws AnalyseException {
		
		if( !comItexMap.containsKey(vchr.getStacid() + Constants.DTAG
				+ assisKey)){
			logger.info("���ף�" + vchr.getStacid()
					+ "ȱ��ά�ȡ�" + assisKey + "���ĳ�ʼ������������Ϣ");
			return;
		}
		
		ComItex comItex = comItexMap.get(vchr.getStacid() + Constants.DTAG
				+ assisKey);
		String exsrKey = vchr.getStacid() + Constants.DTAG + assisValue;

		// ������ã��������Ч��У�飺�����ҷ�ĩ��
		if (null != comItex.getValide()
				&& comItex.getValide().equals("1")) {
			if (prsnDatas.containsKey(exsrKey)) {
				if (!prsnDatas.get(exsrKey).getDetltg().equals("1")) {
					throw new AnalyseException("��ˮ:" + vchr.getSoursq()
							+ "�����ķ�¼֮��ά��" + comItex.getAcexna() + "��ֵ"
							+ assisValue + "����ĩ��");
				} else if (!prsnDatas.get(exsrKey).getUsedtp().equals("1")) {
					throw new AnalyseException("��ˮ:" + vchr.getSoursq()
							+ "�����ķ�¼֮��ά��" + comItex.getAcexna() + "��ֵ"
							+ assisValue + "������Ч״̬");
				}
			} else {
				throw new AnalyseException("��ˮ:" + vchr.getSoursq()
						+ "�����ķ�¼֮��ά��" + comItex.getAcexna() + "��ֵ" + assisValue
						+ "�����ڡ�");
			}
		}else{
			if(logger.isDebugEnabled()){
				logger.debug("���ף�" + vchr.getStacid()
					+ "ά�ȡ�" + assisKey + "��δ����");
			}
		}
	}

	private static void checkAcctnoValide(Map<String, ComItex> comItexMap,
			Hashtable<String, ComAcct> acctDatas, GlaVoucher vchr,
			String assisKey, String assisValue) throws AnalyseException {
		
		if( !comItexMap.containsKey(vchr.getStacid() + Constants.DTAG
				+ assisKey)){
			logger.info("���ף�" + vchr.getStacid()
					+ "ȱ��ά�ȡ�" + assisKey + "���ĳ�ʼ������������Ϣ");
			return;
		}
		
		ComItex comItex = comItexMap.get(vchr.getStacid() + Constants.DTAG
				+ assisKey);
		String exsrKey = vchr.getStacid() + Constants.DTAG + assisValue;

		// ������ã��������Ч��У�飺�����ҷ�ĩ��
		if (null != comItex.getValide()
				&& comItex.getValide().equals("1")) {
			if (acctDatas.containsKey(exsrKey)) {
			} else {
				throw new AnalyseException("��ˮ:" + vchr.getSoursq()
						+ "�����ķ�¼֮��ά��" + comItex.getAcexna() + "��ֵ" + assisValue
						+ "�����ڡ�");
			}
		}else{
			if(logger.isDebugEnabled()){
				logger.debug("���ף�" + vchr.getStacid()
					+ "ά�ȡ�" + assisKey + "��δ����");
			}
		}
	}

	private static void checkPrducdValide(Map<String, ComItex> comItexMap,
			Hashtable<String, SysProduct> prduDatas, GlaVoucher vchr,
			String assisKey, String assisValue) throws AnalyseException {
		
		if( !comItexMap.containsKey(vchr.getStacid() + Constants.DTAG
				+ assisKey)){
			logger.info("���ף�" + vchr.getStacid()
					+ "ȱ��ά�ȡ�" + assisKey + "���ĳ�ʼ������������Ϣ");
			return;
		}
		
		ComItex comItex = comItexMap.get(vchr.getStacid() + Constants.DTAG
				+ assisKey);
		String exsrKey = assisValue;

		// ������ã��������Ч��У�飺�����ҷ�ĩ��
		if (null != comItex.getValide()
				&& comItex.getValide().equals("1")) {
			if (prduDatas.containsKey(exsrKey)) {
			} else {
				logger.error("��ˮ:" + vchr.getSoursq() + "�����ķ�¼��ά��"
						+ comItex.getAcexna() + "��ֵ" + assisValue + "�����ڡ�");
				throw new AnalyseException("��ˮ:" + vchr.getSoursq()
						+ "�����ķ�¼֮��ά��" + comItex.getAcexna() + "��ֵ" + assisValue
						+ "�����ڡ�");
			}
		}else{
			if(logger.isDebugEnabled()){
				logger.debug("���ף�" + vchr.getStacid()
					+ "ά�ȡ�" + assisKey + "��δ����");
			}
		}
	}

	/**
	 * ��Ʊ����Ч�Լ��
	 * 
	 * @param vchr
	 * @return
	 */
	public static boolean isValide(GlaVoucher vchr) {
		if (null != vchr && vchr.getTranam().compareTo(BigDecimal.ZERO) == 0) {
			return false;
		}
		return true;
	}

	public static boolean checkBalanceOfGlaVchrs(List<GlaVoucher> vchrList) throws EngineRuntimeException{

		HashMap<String,TranamEntity> tranamMap = new HashMap<String,TranamEntity>();
		
		logger.debug("��ƽ����Ĵ�Ʊ������"+vchrList.size());
		
		//�����ڡ���ˮ�š����ֶԴ�Ʊ���з���
		List<List<GlaVoucher>> listVchrs = groupVchrs(vchrList);
		
		for(List<GlaVoucher> vchrListtemp : listVchrs){
			//�����˱�ҵ���������д�Ʊ
			for(GlaVoucher ent : vchrListtemp){
				
				logger.debug(ent.getCrcycd() + "," + ent.getTranam() + "," + ent.getAmntcd() + "," + ent.getItemcd() + "," + ent.getIoflag());
				
				//�����ֽ���ͳ�ƣ�ֻͳ�Ʊ��ڣ�
				if(!tranamMap.containsKey(ent.getCrcycd())){
					tranamMap.put(ent.getCrcycd(), new TranamEntity(ent.getCrcycd(),BigDecimal.ZERO,BigDecimal.ZERO));
				}
				
				if(ent.getIoflag().equals(Enumeration.IOFLAG.I.value)){
					if(ent.getAmntcd().equals(Constants.AMNTCD_DEBIT)){
						tranamMap.get(ent.getCrcycd()).plusDtranam(ent.getTranam());
					}else if(ent.getAmntcd().equals(Constants.AMNTCD_CREDIT)){
						tranamMap.get(ent.getCrcycd()).plusCtranam(ent.getTranam());
					}else{	
						String message = "��Χ��Ʊ�����ף�"+ent.getStacid()+"�ݡ���ˮ��"+ent.getSoursq()+"�ݡ���ţ�"+ent.getVchrsq()+"�ݵĽ��׷����"+ent.getAmntcd()+"�ݷǷ���";
						logger.error(message);
						throw new EngineRuntimeException(message);
					}
				}
			}
			//������Ƿ����
			Iterator<String> iterator  = tranamMap.keySet().iterator();
			String errmsg_head = "��齻�״�Ʊ����ƽ���������Χ��Ʊ�����ף�"+vchrListtemp.get(0).getStacid()+"�ݡ���ˮ��"+vchrListtemp.get(0).getSoursq()+"��";
			String errmsg_body = "";
			while(iterator.hasNext()){
				String key = iterator.next();
				TranamEntity entity = tranamMap.get(key);
				if(!DataCheckUtil.isEquals(entity.getdTranam(), entity.getcTranam())){
					errmsg_body = errmsg_body + "���֣�"+key+"�����ڿ�Ŀ�����ƽ���跽�ϼƣ�"+entity.getdTranam()+"�����ϼƣ�"+entity.getcTranam();
				}
			}
			
			//�������
			if(errmsg_body.length() > 0){
				logger.error(errmsg_head.concat(errmsg_body));
				throw new EngineRuntimeException(errmsg_head.concat(errmsg_body));
			}
		}
		
		return true;
	}

	public static boolean setClertgOfGlaVchrs(List<GlaVoucher> vchrList)
			throws EngineRuntimeException {

		logger.debug("�����������ǵĴ�Ʊ������" + vchrList.size());
		
		BigDecimal am_ZERO = new BigDecimal(0);

		Hashtable<String, BigDecimal> st = new Hashtable<String, BigDecimal>();

		if (null != vchrList && vchrList.size() > 0) {

			// �����˱�ҵ���������д�Ʊ
			for (GlaVoucher ent : vchrList) {
				
				// �����Ŀ��¼����Ϊ������
				if (ent.getIoflag().equals(Enumeration.IOFLAG.O.value)) {
					ent.setClertg(Enumeration.CLERTG.CLERTG_3.value);
				} else {
					BigDecimal am = ent.getTranam();
					String cd = Enumeration.Amntcd.D.value;
					if (ent.getAmntcd().equals(Enumeration.Amntcd.C.value)) {
						am = am_ZERO.subtract(ent.getTranam());
					}
					String key = ent.getStacid() + Constants.DTAG
							+ ent.getAcctbr() + Constants.DTAG
							+ ent.getCrcycd() + Constants.DTAG + cd;
					if (st.containsKey(key)) {
						BigDecimal a = st.get(key);
						a = a.add(am);
						st.put(key, a);
					} else {
						st.put(key, am);
					}
				}
			}
			int toClearCount = 0;
			for (String key : st.keySet()) {
				// System.out.println(st.get(key));
				if (st.get(key).compareTo(am_ZERO) != 0) {
					toClearCount = toClearCount + 1;
				}
			}

			if (toClearCount == 0) {
				for (GlaVoucher v : vchrList) {
					if (v.getIoflag().equals(Enumeration.IOFLAG.I.value)) {
						v.setClertg(Enumeration.CLERTG.CLERTG_3.value);
					}
				}
			}
		}
		return true;
	}
	
	     
 	/**
 	 * �����ڡ���ˮ�š����ֶԴ�Ʊ���з���
 	 * @Title: groupVchrs 
 	 * @date: 2018-3-12 ����11:26:01 
 	 * @param vchrResult  
 	 * @return: List<List<GlaVoucher>>
 	 */
 	public static List<List<GlaVoucher>> groupVchrs(List<GlaVoucher> vchrResult){
 		List<List<GlaVoucher>> listVchrs = new ArrayList<List<GlaVoucher>>();;
 		if (null != vchrResult && vchrResult.size() > 0) {
 			HashMap<String,List<GlaVoucher>> mapList = new HashMap<String,List<GlaVoucher>>();
 			for(GlaVoucher entityVchr : vchrResult){
 				String key = entityVchr.getSourdt()+"-$-"+entityVchr.getSoursq();
 				if(!mapList.containsKey(key)){
 					List<GlaVoucher> tmp = new ArrayList<GlaVoucher>();
 					mapList.put(key, tmp);
 				}
 				mapList.get(key).add(entityVchr);
 			}
 			
 			Iterator<String> keyList = mapList.keySet().iterator();
 			
 			while(keyList.hasNext()){
 				listVchrs.add(mapList.get(keyList.next()));
 			}
 			
 			logger.info("����"+vchrResult.get(0).getTranbr()+","+listVchrs.size()+"��ҵ��������"+vchrResult.size()+"�ʴ�Ʊ��");
 			
 		}
 		return listVchrs;
 	}	

	public static void confirmAssisInfo(GlaVoucher entity,
			Map<String, ComItex> itexs) {
		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_CENTCD)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_CENTCD).getValide()
						.equals("1")) {
			entity.setCentcd(entity.getCentcd());
		} else {
			entity.setCentcd(Constants.DEFAULT_VALUE_START);
		}
		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_PRSNCD)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_PRSNCD).getValide()
						.equals("1")) {
			entity.setPrsncd(entity.getPrsncd());
		} else {
			entity.setPrsncd(Constants.DEFAULT_VALUE_START);
		}
		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_CUSTCD)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_CUSTCD).getValide()
						.equals("1")) {
			entity.setCustcd(entity.getCustcd());
		} else {
			entity.setCustcd(Constants.DEFAULT_VALUE_START);
		}

		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_PRDUCD)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_PRDUCD).getValide()
						.equals("1")) {
			entity.setPrducd(entity.getPrducd());
		} else {
			entity.setPrducd(Constants.DEFAULT_VALUE_START);
		}

		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_PRLNCD)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_PRLNCD).getValide()
						.equals("1")) {
			entity.setPrlncd(entity.getPrlncd());
		} else {
			entity.setPrlncd(Constants.DEFAULT_VALUE_START);
		}

		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_ACCTNO)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_ACCTNO).getValide()
						.equals("1")) {
			entity.setAcctno(entity.getAcctno());
		} else {
			entity.setAcctno(Constants.DEFAULT_VALUE_START);
		}

		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_ASSIS0)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_ASSIS0).getValide()
						.equals("1")) {
			entity.setAssis0(entity.getAssis0());
		} else {
			entity.setAssis0(Constants.DEFAULT_VALUE_START);
		}
		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_ASSIS1)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_ASSIS1).getValide()
						.equals("1")) {
			entity.setAssis1(entity.getAssis1());
		} else {
			entity.setAssis1(Constants.DEFAULT_VALUE_START);
		}
		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_ASSIS2)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_ASSIS2).getValide()
						.equals("1")) {
			entity.setAssis2(entity.getAssis2());
		} else {
			entity.setAssis2(Constants.DEFAULT_VALUE_START);
		}
		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_ASSIS3)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_ASSIS3).getValide()
						.equals("1")) {
			entity.setAssis3(entity.getAssis3());
		} else {
			entity.setAssis3(Constants.DEFAULT_VALUE_START);
		}
		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_ASSIS4)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_ASSIS4).getValide()
						.equals("1")) {
			entity.setAssis4(entity.getAssis4());
		} else {
			entity.setAssis4(Constants.DEFAULT_VALUE_START);
		}
		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_ASSIS5)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_ASSIS5).getValide()
						.equals("1")) {
			entity.setAssis5(entity.getAssis5());
		} else {
			entity.setAssis5(Constants.DEFAULT_VALUE_START);
		}
		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_ASSIS6)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_ASSIS6).getValide()
						.equals("1")) {
			entity.setAssis6(entity.getAssis6());
		} else {
			entity.setAssis6(Constants.DEFAULT_VALUE_START);
		}
		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_ASSIS7)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_ASSIS7).getValide()
						.equals("1")) {
			entity.setAssis7(entity.getAssis7());
		} else {
			entity.setAssis7(Constants.DEFAULT_VALUE_START);
		}
		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_ASSIS8)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_ASSIS8).getValide()
						.equals("1")) {
			entity.setAssis8(entity.getAssis8());
		} else {
			entity.setAssis8(Constants.DEFAULT_VALUE_START);
		}
		if (itexs.containsKey(entity.getStacid() + Constants.DTAG
				+ Constants.ASSI_ASSIS9)
				&& itexs.get(
						entity.getStacid() + Constants.DTAG
								+ Constants.ASSI_ASSIS9).getValide()
						.equals("1")) {
			entity.setAssis9(entity.getAssis9());
		} else {
			entity.setAssis9(Constants.DEFAULT_VALUE_START);
		}
	}
}