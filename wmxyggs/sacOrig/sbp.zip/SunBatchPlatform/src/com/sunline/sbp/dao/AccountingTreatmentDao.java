package com.sunline.sbp.dao;

import java.util.List;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.core.bean.ExtdVSCmmdBean;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.GlsExtd;

/**
 * 
 * @author Zhangjin
 *
 */
public interface AccountingTreatmentDao {
	public List<GlaVoucher> processVectorTransaction(List<GlsExtd> entities) throws EngineRuntimeException;
	public List<GlaVoucher> processCmmdVectorTransaction(ExtdVSCmmdBean extdVSCmmdBean) throws EngineRuntimeException;
}
