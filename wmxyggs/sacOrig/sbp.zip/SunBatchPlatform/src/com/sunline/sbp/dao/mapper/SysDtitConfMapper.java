package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.SysDtitConf;

public interface SysDtitConfMapper {
	public SysDtitConf getConfInfo(@Param("stacid") int stacid , @Param("prodcd") String prodcd);
}
