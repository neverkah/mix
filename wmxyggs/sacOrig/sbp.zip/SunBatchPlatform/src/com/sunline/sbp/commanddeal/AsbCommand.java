package com.sunline.sbp.commanddeal;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.dao.mapper.AsbTranMapper;
import com.sunline.sbp.model.AsbTran;
import com.sunline.sbp.model.GlaVoucher;

/**
 * �ʲ�����
 * @author Hopechj
 *
 */
public class AsbCommand implements TranCommandObject {
	
	private AsbTran asbTran;
	private String dtitcd;
	private GlaVoucher glaVoucher;
	private AsbTranMapper asbTranMapper;
	
	public AsbCommand(String trandt , String transq){
		this.asbTran = new AsbTran();
		this.dtitcd = asbTran.getDtitcd();
	}
	
	public AsbCommand(){};
	
	public AsbCommand(AsbTran asbTran){
		this.asbTran = asbTran;
		this.dtitcd = asbTran.getDtitcd();
	}
	
	@Override
	public void initialize(String trandt , String transq ,String cmmdsq , String systid) throws AnalyseException{
		asbTran = asbTranMapper.selectEntity(trandt, transq ,cmmdsq , systid);
		if(null == asbTran){
			Logger.getLogger("�����ʲ���������").error("�����ڽ������ݣ����ڣ�" + trandt + "����ˮ��" + transq);
			throw new AnalyseException("�����ʲ��������ݣ������ڽ������ݣ����ڣ�" + trandt + "����ˮ��" + transq);
		}
	}
	
	@Override
	public void setVoucherInfo() throws AnalyseException {
		// TODO Auto-generated method stub
		if(null == this.asbTran){
			Logger.getLogger("�����ʲ���������").error("��ִ��ҵ����process֮ǰ�����ȳ�ʼ������");
			throw new AnalyseException("�����ʲ���������:��ִ��ҵ����process֮ǰ�����ȳ�ʼ������");
		}
		
		glaVoucher = new GlaVoucher();
		glaVoucher.setTrandt(asbTran.getTrandt());
		glaVoucher.setTranbr(asbTran.getTranbr());
		glaVoucher.setSourdt(asbTran.getTrandt());
		glaVoucher.setSoursq(asbTran.getTransq());
		glaVoucher.setSystid(asbTran.getSystid());
		glaVoucher.setStacid(asbTran.getStacid());
		glaVoucher.setToitem("");
		glaVoucher.setTranam(asbTran.getTranam());
		glaVoucher.setTranbl(BigDecimal.ZERO);
		glaVoucher.setTrantp(asbTran.getTrantp());
		//glaVoucher.setTrandt(trandt);
		//glaVoucher.setTransq(transq);
		glaVoucher.setTrantp(asbTran.getTrantp());
		glaVoucher.setUsercd(Enumeration.USERCD.ENGINE.value);
		//glaVoucher.setVchrsq(vchrsq);
		glaVoucher.setAcctbr(asbTran.getTranbr());
		glaVoucher.setAcctno("");
		glaVoucher.setAmntcd(asbTran.getAmntcd());
		glaVoucher.setCrcycd(asbTran.getCrcycd());
		glaVoucher.setItemcd(asbTran.getDtitcd());
		glaVoucher.setSmrytx(asbTran.getSmrytx());
		glaVoucher.setClertg(Enumeration.CLERTG.CLERTG_0.value);
		
		Logger.getLogger("").debug("====================prepare voucher Over!");
		
		//ProcessCommandDao processCommandService = (ProcessCommandDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(ProcessCommandDao.class);
		//processCommandService.processTransaction(glaVoucher);
	}

	@Override
	public String getTrprcd() {
		// TODO Auto-generated method stub
		return asbTran.getLnbltp();
	}

	@Override
	public String getDtitcd() {
		// TODO Auto-generated method stub
		return asbTran.getDtitcd();
	}

	public AsbTranMapper getAsbTranMapper() {
		return asbTranMapper;
	}

	public void setAsbTranMapper(AsbTranMapper asbTranMapper) {
		this.asbTranMapper = asbTranMapper;
	}
	
	public GlaVoucher getGlaVoucher(){
		return glaVoucher;
	}

	@Override
	public String postingSucc() {
		// TODO Auto-generated method stub
		String executeResult = "";
		try{
			asbTranMapper.updateBkfnstSucc(asbTran);
			executeResult = Constants.EXECUTE_SUCC;
		}catch(Exception ex){
			executeResult = "EXE9999";
		}
		return executeResult;
	}

	@Override
	public String getTrancd() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getStacid() throws AnalyseException {
		// TODO Auto-generated method stub
		return asbTran.getStacid();
	}

	@Override
	public void initialize(JSONObject jsonObject) throws AnalyseException {
		// TODO Auto-generated method stub
		asbTran = JSON.parseObject(jsonObject.toJSONString(), AsbTran.class);
	}

	@Override
	public String getTrandt() throws AnalyseException {
		// TODO Auto-generated method stub
		return asbTran.getTrandt();
	}

	@Override
	public String getSystid() throws AnalyseException {
		// TODO Auto-generated method stub
		return asbTran.getSystid();
	}

	@Override
	public String getTransq() throws AnalyseException {
		// TODO Auto-generated method stub
		return asbTran.getTransq();
	}

	@Override
	public String getCmmdsq() throws AnalyseException {
		// TODO Auto-generated method stub
		return null;
	}
}
