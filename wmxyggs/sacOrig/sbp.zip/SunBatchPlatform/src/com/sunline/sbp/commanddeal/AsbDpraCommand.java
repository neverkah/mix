package com.sunline.sbp.commanddeal;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.dao.mapper.AsbDpraMapper;
import com.sunline.sbp.model.AsbDpra;
import com.sunline.sbp.model.GlaVoucher;

/**
 * �ʲ��۾ɣ�̯����������ϸ
 * @author Hopechj
 *
 */
public class AsbDpraCommand implements TranCommandObject {
	
	private AsbDpraMapper asbDpraMapper;
	private AsbDpra command;
	private GlaVoucher glaVoucher;

	@Override
	public void initialize(String trandt, String transq , String cmmdsq , String systid) throws AnalyseException {
		// TODO Auto-generated method stub
		command = asbDpraMapper.selectEntity(trandt, transq,cmmdsq,systid);
		if(null == command){
			if( null == command){
				Logger.getLogger("").error("��ȡ�ʲ������۾�̯��ָ������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq);
				throw new AnalyseException("��ȡ�ʲ������۾�̯��ָ������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq);
			}
		}
	}

	@Override
	public void setVoucherInfo() throws AnalyseException {
		// TODO Auto-generated method stub
		glaVoucher = new GlaVoucher();
		glaVoucher.setAcctbr(command.getTranbr());
		glaVoucher.setAcctno("*");
		glaVoucher.setAmntcd(command.getAmntcd());
		glaVoucher.setAssis0("*");
		glaVoucher.setAssis1("*");
		glaVoucher.setAssis3("*");
		glaVoucher.setAssis4("*");
		glaVoucher.setAssis5("*");
		glaVoucher.setAssis6("*");
		glaVoucher.setAssis7("*");
		glaVoucher.setAssis8("*");
		glaVoucher.setAssis9("*");
		glaVoucher.setCentcd("*");
		glaVoucher.setCrcycd(command.getCrcycd());
		
		//����ֽ����� Ϊ�̶� 100101
		glaVoucher.setItemcd(command.getDtitcd());
		
		glaVoucher.setPrducd("*");
		glaVoucher.setPrlncd("*");
		glaVoucher.setPrsncd("*");
		glaVoucher.setSmrytx("�ʲ��۾�̯��");
		glaVoucher.setSourdt(command.getTrandt());
		glaVoucher.setSoursq(command.getTransq());
		glaVoucher.setSourst(command.getSystid());
		glaVoucher.setStacid(command.getStacid());
		glaVoucher.setSystid(command.getSystid());
		glaVoucher.setTranam(command.getTranam());
		glaVoucher.setTranbr(command.getTranbr());
		glaVoucher.setTrandt(command.getTrandt());
		glaVoucher.setTrantp(Enumeration.TRANTP.TRAN.value);
		glaVoucher.setUsercd(Enumeration.USERCD.ENGINE.value);
		glaVoucher.setClertg(Enumeration.CLERTG.CLERTG_0.value);
	}

	@Override
	public String getTrprcd() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDtitcd() {
		// TODO Auto-generated method stub
		return command.getDtitcd();
	}

	@Override
	public GlaVoucher getGlaVoucher() {
		// TODO Auto-generated method stub
		return glaVoucher;
	}

	public AsbDpraMapper getAsbDpraMapper() {
		return asbDpraMapper;
	}

	public void setAsbDpraMapper(AsbDpraMapper asbDpraMapper) {
		this.asbDpraMapper = asbDpraMapper;
	}

	@Override
	public String postingSucc() {
		// TODO Auto-generated method stub
		String executeResult;
		try{
			asbDpraMapper.postingUpdate(command);
			executeResult = Constants.EXECUTE_SUCC;
		}catch(Exception ex){
			executeResult = Constants.EXECUTE_FAIL;
		}
		return executeResult;
	}

	@Override
	public String getTrancd() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getStacid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getStacid();
	}

	@Override
	public void initialize(JSONObject jsonObject) throws AnalyseException {
		// TODO Auto-generated method stub
		command = JSON.parseObject(jsonObject.toJSONString(), AsbDpra.class);
	}

	@Override
	public String getTrandt() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTrandt();
	}

	@Override
	public String getSystid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getSystid();
	}

	@Override
	public String getTransq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTransq();
	}

	@Override
	public String getCmmdsq() throws AnalyseException {
		// TODO Auto-generated method stub
		return null;
	}

}
