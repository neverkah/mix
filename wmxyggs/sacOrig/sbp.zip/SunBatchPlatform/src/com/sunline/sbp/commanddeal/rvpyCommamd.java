package com.sunline.sbp.commanddeal;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.dao.mapper.DepositCommandMapper;
import com.sunline.sbp.model.DepositCommand;
import com.sunline.sbp.model.GlaVoucher;

/**
 * 
 * @���� ����ָ��
 * @���� ����ָ�gls_cmdd_rvpy��
 * @author liuchj@sunline.cn
 * @project ����ϵͳ�������
 * @data 2014��4��18��
 */
public class rvpyCommamd implements TranCommandObject {
	
	
	private DepositCommandMapper depositCommandMapper;
	private DepositCommand command;
	private GlaVoucher glaVoucher;
	
	private final Logger logger = Logger.getLogger(rvpyCommamd.class);

	@Override
	public void setVoucherInfo() {
		// TODO Auto-generated method stub
		glaVoucher = new GlaVoucher();
		glaVoucher.setAcctbr(command.getAcctbr());
		glaVoucher.setAcctno("*");
		glaVoucher.setAmntcd(command.getAmntcd());
		glaVoucher.setAssis0("*");
		glaVoucher.setAssis1("*");
		glaVoucher.setAssis3("*");
		glaVoucher.setAssis4("*");
		glaVoucher.setAssis5("*");
		glaVoucher.setAssis6("*");
		glaVoucher.setAssis7("*");
		glaVoucher.setAssis8("*");
		glaVoucher.setAssis9("*");
		glaVoucher.setCentcd("*");
		glaVoucher.setCrcycd(command.getCrcycd());
		
		glaVoucher.setItemcd(command.getDtitcd());
		glaVoucher.setPrducd("*");
		glaVoucher.setPrlncd("*");
		glaVoucher.setPrsncd("*");
		glaVoucher.setSmrytx(command.getSmrycd());
		glaVoucher.setSourdt(command.getTrandt());
		glaVoucher.setSoursq(command.getTransq());
		glaVoucher.setSourst(command.getSystid());
		glaVoucher.setStacid(command.getStacid());
		glaVoucher.setSystid(command.getSystid());
		glaVoucher.setTranam(command.getTranam());
		glaVoucher.setTranbr(command.getTranbr());
		glaVoucher.setTrandt(command.getTrandt());
		glaVoucher.setTrantp(command.getTrantp());
		glaVoucher.setUsercd(Enumeration.USERCD.ENGINE.value);
		glaVoucher.setClertg(Enumeration.CLERTG.CLERTG_0.value);
	}

	@Override
	public void initialize(String trandt, String transq , String cmmdsq, String systid) throws AnalyseException {
		// TODO Auto-generated method stub
		command = depositCommandMapper.selectEntity(trandt , transq , cmmdsq , systid);
		if( null == command){
			logger.error("��ȡ��������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq +",ָ����ˮ��" + cmmdsq);
			throw new AnalyseException("��ȡ��������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq+",ָ����ˮ��" + cmmdsq);
		}
	}

	@Override
	public String getTrprcd() {
		// TODO Auto-generated method stub
		return command.getBltype();
	}

	@Override
	public String getDtitcd() {
		// TODO Auto-generated method stub
		return command.getDtitcd();
	}

	@Override
	public GlaVoucher getGlaVoucher() {
		// TODO Auto-generated method stub
		return glaVoucher;
	}

	public DepositCommandMapper getDepositCommandMapper() {
		return depositCommandMapper;
	}

	public void setDepositCommandMapper(DepositCommandMapper depositCommandMapper) {
		this.depositCommandMapper = depositCommandMapper;
	}

	@Override
	public String postingSucc() {
		// TODO Auto-generated method stub
		String executeResult;
		try{
			depositCommandMapper.postingUpdate(command);
			executeResult = Constants.EXECUTE_SUCC;
		}catch(Exception ex){
			executeResult = Constants.EXECUTE_FAIL;
		}
		return executeResult;
	}

	@Override
	public String getTrancd() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getStacid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getStacid();
	}

	@Override
	public void initialize(JSONObject jsonObject) throws AnalyseException {
		// TODO Auto-generated method stub
		command = JSON.parseObject(jsonObject.toJSONString(), DepositCommand.class);
	}

	@Override
	public String getTrandt() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTrandt();
	}

	@Override
	public String getSystid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getSystid();
	}

	@Override
	public String getTransq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTransq();
	}

	@Override
	public String getCmmdsq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getRvpysq();
	}

}
