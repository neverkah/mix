package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * 
 * @���� ivt_busi��bean
 * @���� 
 * @author liuchj@sunline.cn
 * @project ����ϵͳ�������
 * @data 2014��4��12��
 */
public class IvestmentBusi {
	private int stacid;
	private String systid;
	private String bsnsdt;
	private String bsnssq;
	private String trandt;
	private String transq;
	private String subseq;
	private String tranbr;
	private String prcscd;
	private String prodcd;
	private String ivsttp;
	private String crcycd;
	private String bathid;
	public String getBathid() {
		return bathid;
	}
	public void setBathid(String bathid) {
		this.bathid = bathid;
	}
	/**
	 * Ӧ����Ϣ
	 */
	private BigDecimal mtccin;
	/**
	 * ��Ϣ�������
	 */
	private BigDecimal overam;
	private BigDecimal variam;
	private BigDecimal dwinam;
	private BigDecimal rcinam;
	private BigDecimal adinam;
	private BigDecimal favaam;
	private BigDecimal impaam;
	private String chtotp;
	private BigDecimal invtam;
	private BigDecimal acctam;
	private String loanp1;
	private String loanp2;
	private String loanp3;
	private String loanp4;
	private String loanp5;
	private String loanp6;
	private String loanp7;
	private String loanp8;
	private String loanp9;
	private String loanpa;
	private String clprod;
	
	private String  centcd ;
	private String  prsncd ;
	private String  custcd ;
	private String  prlncd ;
	private String  acctno ;
	private String  assis0 ;
	private String  assis1 ;
	private String  assis2 ;
	private String  assis3 ;
	private String  assis4 ;
	private String  assis5 ;
	private String  assis6 ;
	private String  assis7 ;
	private String  assis8 ;
	private String  assis9 ;
	
	
	public String getCentcd() {
		return centcd;
	}
	public void setCentcd(String centcd) {
		this.centcd = centcd;
	}
	public String getPrsncd() {
		return prsncd;
	}
	public void setPrsncd(String prsncd) {
		this.prsncd = prsncd;
	}
	public String getCustcd() {
		return custcd;
	}
	public void setCustcd(String custcd) {
		this.custcd = custcd;
	}
	public String getPrlncd() {
		return prlncd;
	}
	public void setPrlncd(String prlncd) {
		this.prlncd = prlncd;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getAssis0() {
		return assis0;
	}
	public void setAssis0(String assis0) {
		this.assis0 = assis0;
	}
	public String getAssis1() {
		return assis1;
	}
	public void setAssis1(String assis1) {
		this.assis1 = assis1;
	}
	public String getAssis2() {
		return assis2;
	}
	public void setAssis2(String assis2) {
		this.assis2 = assis2;
	}
	public String getAssis3() {
		return assis3;
	}
	public void setAssis3(String assis3) {
		this.assis3 = assis3;
	}
	public String getAssis4() {
		return assis4;
	}
	public void setAssis4(String assis4) {
		this.assis4 = assis4;
	}
	public String getAssis5() {
		return assis5;
	}
	public void setAssis5(String assis5) {
		this.assis5 = assis5;
	}
	public String getAssis6() {
		return assis6;
	}
	public void setAssis6(String assis6) {
		this.assis6 = assis6;
	}
	public String getAssis7() {
		return assis7;
	}
	public void setAssis7(String assis7) {
		this.assis7 = assis7;
	}
	public String getAssis8() {
		return assis8;
	}
	public void setAssis8(String assis8) {
		this.assis8 = assis8;
	}
	public String getAssis9() {
		return assis9;
	}
	public void setAssis9(String assis9) {
		this.assis9 = assis9;
	}
	public BigDecimal getAcctam() {
		return acctam;
	}
	public void setAcctam(BigDecimal acctam) {
		this.acctam = acctam;
	}
	private String status;
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getSubseq() {
		return subseq;
	}
	public void setSubseq(String subseq) {
		this.subseq = subseq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public String getIvsttp() {
		return ivsttp;
	}
	public void setIvsttp(String ivsttp) {
		this.ivsttp = ivsttp;
	}
	public BigDecimal getVariam() {
		return variam;
	}
	public void setVariam(BigDecimal variam) {
		this.variam = variam;
	}
	public BigDecimal getDwinam() {
		return dwinam;
	}
	public void setDwinam(BigDecimal dwinam) {
		this.dwinam = dwinam;
	}
	public BigDecimal getRcinam() {
		return rcinam;
	}
	public void setRcinam(BigDecimal rcinam) {
		this.rcinam = rcinam;
	}
	public BigDecimal getAdinam() {
		return adinam;
	}
	public void setAdinam(BigDecimal adinam) {
		this.adinam = adinam;
	}
	public BigDecimal getFavaam() {
		return favaam;
	}
	public void setFavaam(BigDecimal favaam) {
		this.favaam = favaam;
	}
	public BigDecimal getImpaam() {
		return impaam;
	}
	public void setImpaam(BigDecimal impaam) {
		this.impaam = impaam;
	}
	public String getChtotp() {
		return chtotp;
	}
	public void setChtotp(String chtotp) {
		this.chtotp = chtotp;
	}
	public BigDecimal getInvtam() {
		return invtam;
	}
	public void setInvtam(BigDecimal invtam) {
		this.invtam = invtam;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getBsnsdt() {
		return bsnsdt;
	}
	public void setBsnsdt(String bsnsdt) {
		this.bsnsdt = bsnsdt;
	}
	public String getBsnssq() {
		return bsnssq;
	}
	public void setBsnssq(String bsnssq) {
		this.bsnssq = bsnssq;
	}
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public BigDecimal getMtccin() {
		return mtccin;
	}
	public void setMtccin(BigDecimal mtccin) {
		this.mtccin = mtccin;
	}
	public BigDecimal getOveram() {
		return overam;
	}
	public void setOveram(BigDecimal overam) {
		this.overam = overam;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getLoanp1() {
		return loanp1;
	}
	public void setLoanp1(String loanp1) {
		this.loanp1 = loanp1;
	}
	public String getLoanp2() {
		return loanp2;
	}
	public void setLoanp2(String loanp2) {
		this.loanp2 = loanp2;
	}
	public String getLoanp3() {
		return loanp3;
	}
	public void setLoanp3(String loanp3) {
		this.loanp3 = loanp3;
	}
	public String getLoanp4() {
		return loanp4;
	}
	public void setLoanp4(String loanp4) {
		this.loanp4 = loanp4;
	}
	public String getLoanp5() {
		return loanp5;
	}
	public void setLoanp5(String loanp5) {
		this.loanp5 = loanp5;
	}
	public String getLoanp6() {
		return loanp6;
	}
	public void setLoanp6(String loanp6) {
		this.loanp6 = loanp6;
	}
	public String getLoanp7() {
		return loanp7;
	}
	public void setLoanp7(String loanp7) {
		this.loanp7 = loanp7;
	}
	public String getLoanp8() {
		return loanp8;
	}
	public void setLoanp8(String loanp8) {
		this.loanp8 = loanp8;
	}
	public String getLoanp9() {
		return loanp9;
	}
	public void setLoanp9(String loanp9) {
		this.loanp9 = loanp9;
	}
	public String getLoanpa() {
		return loanpa;
	}
	public void setLoanpa(String loanpa) {
		this.loanpa = loanpa;
	}
	public String getClprod() {
		return clprod;
	}
	public void setClprod(String clprod) {
		this.clprod = clprod;
	}
	
}
