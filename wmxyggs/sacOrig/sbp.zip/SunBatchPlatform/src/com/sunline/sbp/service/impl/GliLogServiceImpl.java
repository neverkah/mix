package com.sunline.sbp.service.impl;

import java.sql.Timestamp;

import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.dao.GliLogDao;
import com.sunline.sbp.service.GliLogService;

public class GliLogServiceImpl implements GliLogService {

	@Override
	public void insertGliMslg(String bussinessInfo, JSONObject gliMslgJSONObject, Timestamp recedt, Timestamp respdt,
			String executeMsg, String mstype) {
		GliLogDao glilogDao = (GliLogDao) ApplicationBeanFactory.getApplicationContextInstance().getBean(GliLogDao.class);
		// ��¼������־
		glilogDao.insertGliMslg(bussinessInfo, gliMslgJSONObject, recedt, respdt, executeMsg, mstype);

	}

}
