package com.sunline.sbp.model;

/**
 * ϵͳ�ӽ����������(sys_trcd)
 * @author Zhangjin
 *
 */
public class SysTrcd {
	public String trancd;
	public String Tranna;
	public String trprcd;
	public String enname;
	public String tramcd;
	public String intfcd;
	public String propif;
	public String relaif;
	public String desctx;
	public String vermod;
	public String module;
	public String projcd;
	
	public String getTrancd() {
		return trancd;
	}
	public void setTrancd(String trancd) {
		this.trancd = trancd;
	}
	public String getTranna() {
		return Tranna;
	}
	public void setTranna(String tranna) {
		Tranna = tranna;
	}
	public String getEnname() {
		return enname;
	}
	public void setEnname(String enname) {
		this.enname = enname;
	}
	public String getTramcd() {
		return tramcd;
	}
	public void setTramcd(String tramcd) {
		this.tramcd = tramcd;
	}
	public String getIntfcd() {
		return intfcd;
	}
	public void setIntfcd(String intfcd) {
		this.intfcd = intfcd;
	}
	public String getPropif() {
		return propif;
	}
	public void setPropif(String propif) {
		this.propif = propif;
	}
	public String getRelaif() {
		return relaif;
	}
	public void setRelaif(String relaif) {
		this.relaif = relaif;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
	public String getTrprcd() {
		return trprcd;
	}
	public void setTrprcd(String trprcd) {
		this.trprcd = trprcd;
	}
	
}
