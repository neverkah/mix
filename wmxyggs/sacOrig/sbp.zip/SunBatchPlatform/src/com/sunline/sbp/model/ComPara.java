package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * ϵͳ����(����com_para)
 * @author xiaotian
 *
 */
public class ComPara implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int stacid;
	private String parana;
	private String paravl;
	private String moducd;
	private String paralv;
	private String paratx;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getParana() {
		return parana;
	}
	public void setParana(String parana) {
		this.parana = parana;
	}
	public String getParavl() {
		return paravl;
	}
	public void setParavl(String paravl) {
		this.paravl = paravl;
	}
	public String getModucd() {
		return moducd;
	}
	public void setModucd(String moducd) {
		this.moducd = moducd;
	}
	public String getParalv() {
		return paralv;
	}
	public void setParalv(String paralv) {
		this.paralv = paralv;
	}
	public String getParatx() {
		return paratx;
	}
	public void setParatx(String paratx) {
		this.paratx = paratx;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
