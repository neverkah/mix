package com.sunline.sbp.commanddeal;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.dao.mapper.InacTranMapper;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.InacTran;

public class ClerCommand implements TranCommandObject {
	
private Logger logger = Logger.getLogger(ClerCommand.class);
	
	private InacTranMapper inacTranMapper;
	private InacTran command;
	private GlaVoucher glaVoucher;

	@Override
	public void initialize(String trandt, String transq, String cmmdsq , String systid) throws AnalyseException {
		// TODO Auto-generated method stub
		logger.debug("trandt:"+trandt+",transq:"+transq+",cmmdsq:"+cmmdsq);
		InacTran[] commands = inacTranMapper.selectEntity(trandt, transq , cmmdsq,systid);
		if(null != commands){
			if( commands.length == 1){
				command = commands[0];
				logger.debug("command.acctbr=" + command.getAcctbr());
			}else{
				logger.error("��ȡ�ڲ�����ָ������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq + ",ָ����ˮ��" + cmmdsq);
				throw new AnalyseException("��ȡ�ڲ�����ָ������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq + ",ָ����ˮ��" + cmmdsq);
			}
		}else{
			logger.error("��ȡ�ڲ�����ָ������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq+ ",ָ����ˮ��" + cmmdsq);
			throw new AnalyseException("��ȡ�ڲ�����ָ������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq+ ",ָ����ˮ��" + cmmdsq);
		}
	}

	@Override
	public void setVoucherInfo() {
		// TODO Auto-generated method stub
		glaVoucher = new GlaVoucher();
		glaVoucher.setAcctbr(command.getAcctbr());
		glaVoucher.setAcctno("*");
		glaVoucher.setAmntcd(command.getAmntcd());
		glaVoucher.setAssis0("*");
		glaVoucher.setAssis1("*");
		glaVoucher.setAssis3("*");
		glaVoucher.setAssis4("*");
		glaVoucher.setAssis5("*");
		glaVoucher.setAssis6("*");
		glaVoucher.setAssis7("*");
		glaVoucher.setAssis8("*");
		glaVoucher.setAssis9("*");
		glaVoucher.setCentcd("*");
		glaVoucher.setCrcycd(command.getCrcycd());
		
		//����ֽ����� Ϊ�̶� 100101
		glaVoucher.setItemcd(command.getDtitcd());
		
		glaVoucher.setPrducd("*");
		glaVoucher.setPrlncd("*");
		glaVoucher.setPrsncd("*");
		glaVoucher.setSmrytx("��������");
		glaVoucher.setSourdt(command.getTrandt());
		glaVoucher.setSoursq(command.getTransq());
		glaVoucher.setSourst(command.getSystid());
		glaVoucher.setStacid(command.getStacid());
		glaVoucher.setSystid(command.getSystid());
		glaVoucher.setTranam(command.getTranam());
		glaVoucher.setTranbr(command.getTranbr());
		glaVoucher.setTrandt(command.getTrandt());
		glaVoucher.setTrantp(command.getTrantp());
		glaVoucher.setUsercd(Enumeration.USERCD.ENGINE.value);
		//���㴫Ʊ
		glaVoucher.setClertg(Enumeration.CLERTG.CLERTG_4.value);
		glaVoucher.setClerod(command.getTransq());
		glaVoucher.setClerdt(command.getTrandt());
	}

	@Override
	public String getTrprcd() {
		// TODO Auto-generated method stub
		return Constants.TRPRCD_DEFAULT;
	}

	@Override
	public String getDtitcd() {
		// TODO Auto-generated method stub
		return command.getDtitcd();
	}

	@Override
	public GlaVoucher getGlaVoucher() {
		// TODO Auto-generated method stub
		return glaVoucher;
	}

	@Override
	public String postingSucc() throws AnalyseException {
		// TODO Auto-generated method stub
		String executeResult;
		try{
			inacTranMapper.postingUpdate(command);
			executeResult = Constants.EXECUTE_SUCC;
		}catch(Exception ex){
			executeResult = Constants.EXECUTE_FAIL;
		}
		return executeResult;
	}
	
	public InacTranMapper getInacTranMapper() {
		return inacTranMapper;
	}

	public void setInacTranMapper(InacTranMapper inacTranMapper) {
		this.inacTranMapper = inacTranMapper;
	}

	@Override
	public String getTrancd() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getStacid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getStacid();
	}

	@Override
	public String getTrandt() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTrandt();
	}

	@Override
	public String getSystid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getSystid();
	}

	@Override
	public String getTransq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTransq();
	}

	@Override
	public String getCmmdsq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getInacsq();
	}

	@Override
	public void initialize(JSONObject jsonObject) throws AnalyseException {
		// TODO Auto-generated method stub
		command = JSON.parseObject(jsonObject.toJSONString(), InacTran.class);
	}

}
