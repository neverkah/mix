package com.sunline.sbp.model;

/**
 * ϵͳ�ӽ��״��붨���(sys_trcd_detl)
 * @author Zhangjin
 *
 */

public class SysTrcdDetl {
	String dttrcd;
	String trancd;
	String prgptp;
	String prgpid;
	String tranna;
	String tmpltp;
	String tmplid;
	String sttlid;
	String enname;
	String desctx;
	String vermod;
	String module;
	String projcd;
	public String getDttrcd() {
		return dttrcd;
	}
	public void setDttrcd(String dttrcd) {
		this.dttrcd = dttrcd;
	}
	public String getTrancd() {
		return trancd;
	}
	public void setTrancd(String trancd) {
		this.trancd = trancd;
	}
	public String getPrgptp() {
		return prgptp;
	}
	public void setPrgptp(String prgptp) {
		this.prgptp = prgptp;
	}
	public String getPrgpid() {
		return prgpid;
	}
	public void setPrgpid(String prgpid) {
		this.prgpid = prgpid;
	}
	public String getTranna() {
		return tranna;
	}
	public void setTranna(String tranna) {
		this.tranna = tranna;
	}
	public String getTmpltp() {
		return tmpltp;
	}
	public void setTmpltp(String tmpltp) {
		this.tmpltp = tmpltp;
	}
	public String getTmplid() {
		return tmplid;
	}
	public void setTmplid(String tmplid) {
		this.tmplid = tmplid;
	}
	public String getSttlid() {
		return sttlid;
	}
	public void setSttlid(String sttlid) {
		this.sttlid = sttlid;
	}
	public String getEnname() {
		return enname;
	}
	public void setEnname(String enname) {
		this.enname = enname;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
}
