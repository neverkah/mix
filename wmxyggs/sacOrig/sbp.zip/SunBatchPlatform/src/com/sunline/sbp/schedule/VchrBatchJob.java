package com.sunline.sbp.schedule;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.sbp.application.FIAsyncConsumer;
import com.sunline.sbp.core.bean.ComBrchBean;
import com.sunline.sbp.core.bean.ComItemBean;
import com.sunline.sbp.core.bean.GlaAcctBean;
import com.sunline.sbp.core.bean.GlaGlisBean;
import com.sunline.sbp.core.bean.GlaVchrBean;
import com.sunline.sbp.core.bean.GlaVchrHelper;
import com.sunline.sbp.core.bean.SysAcctOpenBean;
import com.sunline.sbp.dao.mapper.AccountingItemMapper;
import com.sunline.sbp.dao.mapper.ComBrchMapper;
import com.sunline.sbp.dao.mapper.ComItexMapper;
import com.sunline.sbp.dao.mapper.GlaAcctMapper;
import com.sunline.sbp.dao.mapper.GlaGlisMapper;
import com.sunline.sbp.dao.mapper.GlaVoucherMapper;
import com.sunline.sbp.dao.mapper.SysAyncNodeMapper;
import com.sunline.sbp.dao.mapper.SysVchrErorMapper;
import com.sunline.sbp.model.AccountingItem;
import com.sunline.sbp.model.ComBrch;
import com.sunline.sbp.model.ComItex;
import com.sunline.sbp.model.GlaAcct;
import com.sunline.sbp.model.GlaGlis;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.SysAcctOpen;
import com.sunline.sbp.model.SysVchrEror;
import com.sunline.sbp.model.validation.GlaAcctValidateBean;
import com.sunline.sunbp.util.MyBatisUtil;

/**
 * ����ϵͳ�첽��Ϣ������
 * 
 * @author liuchj@sunline.cn
 * @Date 2014-5-17
 * 
 */
public class VchrBatchJob extends Thread{
	
	private final int BATCH_COUNT = 1000;

	private static final String DTAG = ".";

	private static Logger logger = Logger.getLogger(VchrBatchJob.class);

	private Hashtable<String, GlaGlis> glisCache = new Hashtable<String, GlaGlis>();
	private Hashtable<String, GlaVoucher> vchrsCache = new Hashtable<String, GlaVoucher>();

	private Vector<GlaVoucher> vchrBuffer = new Vector<GlaVoucher>();

	private static Hashtable<String, AccountingItem> itemCache = new Hashtable<String, AccountingItem>();
	private static Hashtable<String, ComBrch> brchCache = new Hashtable<String, ComBrch>();
	private static Hashtable<String, ComItex> itexCache = new Hashtable<String, ComItex>();

	private SqlSession sqlSession = MyBatisUtil
			.getSqlSessionFactory()
			.openSession(false);
	
	private List<GlaVoucher> vchrs = new ArrayList<GlaVoucher>();
	private int stacid;
	private String acctbr;
	private String pit;
	private String glisdt;
	private String nodeid;
	private String systid;
	
	String aynccd = "gla";
	
	public VchrBatchJob(int stacid,String acctbr, String pit, String glisdt , String nodeid, String systid){
		this.stacid = stacid;
		this.acctbr = acctbr;
		this.pit = pit;
		this.glisdt = glisdt;
		this.nodeid = nodeid;
		this.systid = systid;
	}

	public void initC() {
		// New session factory,ǿ�ҽ���ʹ�õ���
		AccountingItem[] items = sqlSession.getMapper(
				AccountingItemMapper.class).selectFullEntities(stacid);
		for (int i = 0; i < items.length; i++) {
			itemCache.put(getItemKey(items[i]), items[i]);
		}

		ComBrch[] brchs = sqlSession.getMapper(ComBrchMapper.class).getAll();
		for (int i = 0; i < brchs.length; i++) {
			brchCache.put(
					getBrchKey(brchs[i].getStacid(), brchs[i].getBrchcd()),
					brchs[i]);
		}
		
		ComItexMapper comItexMapper = sqlSession
				.getMapper(ComItexMapper.class);
		
		List<ComItex> itexs = comItexMapper.getAllEntites();
		for(ComItex entity:itexs){
			itexCache.put(entity.getStacid()+Constants.DTAG+entity.getAssimp(), entity);
		}
	}

	public void run() {

		if (itemCache.isEmpty()) {
			initC();
		}

		excute();
	}
	
	private void checkAndAccount(){
		logger.fatal("����:"+stacid+",����:"+acctbr+",��Ŀ��"+pit+"��������������������������"+vchrs.size());
		GlaVoucher vchr = null;
		try {
			for (int i = 0; i < vchrs.size(); i++) {

				vchr = vchrs.get(i);
				// ���׷���
				try {
					/*
					 * ��Ʊ���� Ŀ�ģ��������ύʧ��ʱ���л������ʹ���ģʽ
					 */
					
					addVchr(vchr);
					// ������ϢKey
					String glisKey = prepareData(vchr);
					// ���ˡ��˻�͸֧���
					checkAccoutOverDraft(glisKey, vchr);
					
					// ��������
					if ((i + 1) % BATCH_COUNT == 0 || i == vchrs.size() - 1) {
						Date d0 = new Date();
						toAccounting();
						Date da = new Date();
						logger.info("toAccounting��ʱ��"+(da.getTime() - d0.getTime())+"ms");
						targetVchrSuccBatch();
						Date db = new Date();
						logger.info("���´�Ʊ״̬��ʱ��"+(db.getTime() - da.getTime())+"ms");
						toSubmitBatch();
						Date dc = new Date();
						logger.info("�����ύ��ʱ��"+(dc.getTime() - db.getTime())+"ms");
					}

				} catch (Exception ex) {
					logger.error("�����ύʧ��:",ex);
					
					// ����ع�
					toRollbackBatch();

					// �Ի��洫Ʊ���е��ʴ�Ʊ����
					for (GlaVoucher _vchr : vchrBuffer) {
						try {
							//
							String glisKey = prepareData2(_vchr);
							// ����͸֧��鲢��¼
							checkAccoutOverDraft(glisKey, _vchr);
							// ��Ʊ����
							toAccounting2();
							//����״̬Ϊ�ѹ���
							targetVchrSucc(_vchr);
							
						} catch (AnalyseException ex1) {
							// ��ǵ��ʴ�Ʊ����ʧ��
							logger.error(ex1.getMessage(),ex1);
							toRollback();
							targetVchrFailed(_vchr,ex1.getMessage());
						} catch (Exception ex2) {
							// ��ǵ��ʴ�Ʊ����ʧ��
							logger.error(ex2.getMessage(),ex2);
							toRollback();
							targetVchrFailed(_vchr,"ϵͳ�쳣");
						} finally {
							// �����ύ
							toSubmit();
						}

					}
				} finally {
					
				}
			}
		} catch (Exception ex1) {
			logger.error(ex1);
		} finally {
			vchrs.clear();
		}
		logger.info("����:"+stacid+",����:"+acctbr+"��Ŀ��"+pit+"��������������������������"+vchrs.size()+"������������");
	}
	
	private void excute(){
		Connection cn = null;
		PreparedStatement vchrSt = null;
		ResultSet rs = null;
		
		
		
		logger.fatal("����:"+stacid+",����:"+acctbr+",��Ŀ:"+pit+"���˿�ʼ......");
		Date beginDate = new Date();
		
		try {
			cn = sqlSession.getConnection();
			vchrSt = cn.prepareStatement("select * from gla_vchr "
					+ "where stacid = ? and systid = ? and trandt = ? and acctbr = ? and itemcd like ? and transt in ('0','2') order by itemcd ");
			vchrSt.setFetchSize(2000);
			vchrSt.setInt(1, stacid);
			vchrSt.setString(2, systid);
			vchrSt.setString(3, glisdt);
			vchrSt.setString(4, acctbr);
			vchrSt.setString(5, pit);
			rs = vchrSt.executeQuery();
			
			int Count = 0;
			
			while(rs.next()){
				Count = Count + 1;
				GlaVoucher glaVoucher = new GlaVoucher();
				
				glaVoucher.setStacid(rs.getInt("stacid"));
				glaVoucher.setAcctbr(rs.getString("acctbr"));
				glaVoucher.setAcctno(rs.getString("acctno"));
				glaVoucher.setAmntcd(rs.getString("amntcd"));
				glaVoucher.setAssis0(rs.getString("assis0"));
				glaVoucher.setAssis1(rs.getString("assis1"));
				glaVoucher.setAssis2(rs.getString("assis2"));
				glaVoucher.setAssis3(rs.getString("assis3"));
				glaVoucher.setAssis4(rs.getString("assis4"));
				glaVoucher.setAssis5(rs.getString("assis5"));
				glaVoucher.setAssis6(rs.getString("assis6"));
				glaVoucher.setAssis7(rs.getString("assis7"));
				glaVoucher.setAssis8(rs.getString("assis8"));
				glaVoucher.setAssis9(rs.getString("assis9"));
				glaVoucher.setBearbl(rs.getBigDecimal("bearbl"));
				glaVoucher.setBeardn(rs.getString("beardn"));
				glaVoucher.setBlncdn(rs.getString("blncdn"));
				glaVoucher.setBrchsq(rs.getString("brchsq"));
				glaVoucher.setCentcd(rs.getString("centcd"));
				glaVoucher.setCentsq(rs.getString("centsq"));
				glaVoucher.setClerdt(rs.getString("clerdt"));
				glaVoucher.setClerod(rs.getString("clerod"));
				glaVoucher.setClertg(rs.getString("clertg"));
				glaVoucher.setCrcycd(rs.getString("crcycd"));
				glaVoucher.setCustcd(rs.getString("custcd"));
				glaVoucher.setExchcn(rs.getBigDecimal("exchcn"));
				glaVoucher.setExchus(rs.getBigDecimal("exchus"));
				glaVoucher.setIoflag(rs.getString("ioflag"));
				glaVoucher.setItemcd(rs.getString("itemcd"));
				glaVoucher.setPrducd(rs.getString("prducd"));
				glaVoucher.setPrlncd(rs.getString("prlncd"));
				glaVoucher.setPrsncd(rs.getString("prsncd"));
				glaVoucher.setSmrytx(rs.getString("smrytx"));
				glaVoucher.setSourac(rs.getInt("sourac"));
				glaVoucher.setSourdt(rs.getString("sourdt"));
				glaVoucher.setSoursq(rs.getString("soursq"));
				glaVoucher.setSourst(rs.getString("sourst"));
				glaVoucher.setSrvcsq(rs.getString("srvcsq"));
				glaVoucher.setSubsac(rs.getString("subsac"));
				glaVoucher.setSystid(rs.getString("systid"));
				glaVoucher.setToitem(rs.getString("toitem"));
				glaVoucher.setTranam(rs.getBigDecimal("tranam"));
				glaVoucher.setTranbl(rs.getBigDecimal("tranbl"));
				glaVoucher.setTranbr(rs.getString("tranbr"));
				glaVoucher.setTrandt(rs.getString("trandt"));
				//glaVoucher.setTrannm(rs.getInt("trannm"));
				glaVoucher.setTranno(rs.getInt("tranno"));
				glaVoucher.setTransq(rs.getString("transq"));
				glaVoucher.setTranst(rs.getString("transt"));
				glaVoucher.setTrantp(rs.getString("trantp"));
				glaVoucher.setUsercd(rs.getString("usercd"));
				glaVoucher.setVchrsq(rs.getString("vchrsq"));
				
				GlaVchrHelper.confirmAssisInfo(glaVoucher, itexCache);
				
				vchrs.add(glaVoucher);
				
				if(Count % 2000 == 0 ){
					Date endDate = new Date();
					logger.info("��ȡ������ʱ��"+(endDate.getTime() - beginDate.getTime())+"ms");
					checkAndAccount();
					beginDate = new Date();
					logger.info("����������ʱ��"+(beginDate.getTime() - endDate.getTime())+"ms");
				}
			}
			if(vchrs.size() > 0){
				checkAndAccount();
			}
			logger.fatal("����:"+stacid+",����:"+acctbr+",��Ŀ:"+pit+"���˽�������ʱ��"+(new Date().getTime()-beginDate.getTime())+"ms");
		}catch(Exception ex){
			logger.error(ex.getMessage(),ex);
		}finally{
			SysAyncNodeMapper sysAyncNodeMapper = sqlSession.getMapper(SysAyncNodeMapper.class);
			try{
				int result = sysAyncNodeMapper.deleteNode(aynccd,stacid, nodeid, glisdt, systid, acctbr, pit);
				if(result != 1){
					logger.error("�Ƴ��ڵ�����ʧ�ܡ��Ƴ�����"+result);
				}else{
					logger.info("delete nodeid:"+nodeid+",brch:"+acctbr+",pit:"+pit);
				}
				sqlSession.commit();
			}catch(Exception ex){
				logger.error("�Ƴ��ڵ������쳣:"+ex.getMessage(),ex);
			}
			
			if(null != rs){
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(null != vchrSt){
				try {
					vchrSt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if( null != cn){
				try {
					cn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			
			// ���ӹر�
			if (null != sqlSession) {
				logger.debug("���ӹر�");
				try{
					sqlSession.close();
				}catch(Exception ex){
					logger.error("�ر�sqlSession�쳣��");
				}
			}
		}
	}

	private void targetVchrFailed(GlaVoucher __vchr , String logmsg) {
		try {
			GlaVoucherMapper glaVoucherMapper = sqlSession
					.getMapper(GlaVoucherMapper.class);
			glaVoucherMapper.updateToError(__vchr);
			
			SysVchrErorMapper sysVchrErorMapper = sqlSession.getMapper(SysVchrErorMapper.class);
			SysVchrEror sysVchrEror = new SysVchrEror();
			sysVchrEror.setStacid(__vchr.getStacid());
			sysVchrEror.setSystid(__vchr.getSystid());
			sysVchrEror.setTrandt(__vchr.getTrandt());
			sysVchrEror.setTransq(__vchr.getTransq());
			sysVchrEror.setVchrsq(__vchr.getVchrsq());
			sysVchrEror.setLogmsg(logmsg);
			sysVchrErorMapper.insertEntity(sysVchrEror);
			
		} catch (Exception ex) {
			logger.error("��¼soursq:"+__vchr.getSoursq() + ",vchrsq:"+ __vchr.getVchrsq() + "����ʶΪʧ�ܣ�����ʧ�ܡ�",ex);
		}
	}
	/**
	 * //�����ύʱ���´�Ʊ����������Ŀ״̬
	 * @Title: targetVchrSuccBatch 
	 * @throws Exception
	 * @return: void
	 */
	private void targetVchrSuccBatch() throws Exception {
		GlaVoucherMapper glaVoucherMapper = sqlSession
				.getMapper(GlaVoucherMapper.class);
		
		//���ֻ������Ϊ1000
		int size = 1000;
		
		try{
			for(int idx = 0 ; idx < vchrBuffer.size() ;){
				size = 1000;
				if(idx + size > vchrBuffer.size() ){
					size = vchrBuffer.size() - idx;
				}
				
				Map<String,String> transqs = new HashMap<String,String>();
				List<String> transqList = new ArrayList<String>();
				for(int tidx = idx ; tidx < idx+size ; tidx++){
					if(!transqs.containsKey(vchrBuffer.get(tidx).getTransq())){
						transqs.put(vchrBuffer.get(tidx).getTransq(), "1");
						transqList.add(vchrBuffer.get(tidx).getTransq());
					}
					
				}
				
				int updateCount = glaVoucherMapper.updateToSuccBatch(vchrBuffer.subList(idx, idx+size), transqList ,vchrBuffer.get(idx).getStacid(), vchrBuffer.get(idx).getTrandt(),vchrBuffer.get(idx).getSystid(),vchrBuffer.get(idx).getAcctbr(),pit);

				if(updateCount != size){
					logger.error("���´�Ʊ״̬�쳣����������������Ϊ��"+size+"��ϵͳִ�и���������"+updateCount);
					throw new Exception("���´�Ʊ״̬�쳣����������������Ϊ��"+size+"��ϵͳִ�и���������"+updateCount);
				}
				idx = idx + size;
			}
		}catch(Exception ex){
			logger.error("��������Ʊ״̬��ʶΪ�ɹ�ʱ��ִ��ʧ�ܡ�",ex);
			throw new Exception(ex.getMessage(),ex);
		}
		
		for (GlaVoucher ivchr : vchrBuffer) {

			try {
				// ��Ʊ���˳ɹ�
				//���Ϊ��������
				//glaVoucherMapper.updateToSucc(ivchr);
				// ����״̬Ϊδʹ�ã�����»���Ϊ��ʹ��
				ComBrch brchEntity = getBrchFromBrchCache(ivchr.getStacid(),
						ivchr.getAcctbr());
				if (brchEntity.getUsedtp().equals("0")) {
					glaVoucherMapper.updateBrchToUsed(ivchr);
				}
				// //��Ŀ״̬Ϊδʹ�ã�����¿�ĿΪ��ʹ��
				AccountingItem itemEntity = getItemFromItemCache(
						ivchr.getStacid(), ivchr.getItemcd());
				if (itemEntity.getUsedtp().equals("0")) {
					glaVoucherMapper.updateItemToUsed(ivchr);
				}
			} catch (Exception ex) {
				logger.error(ivchr.getSoursq() + "," + ivchr.getVchrsq()
						+ "����ʶΪ�ɹ�������ʧ�ܡ�", ex);
				throw new Exception(ex.getMessage(), ex);
			}
		}
	}
	
	/**
	 * �����ύʱ���´�Ʊ����������Ŀ״̬
	 * @Title: targetVchrSucc 
	 * @param ivchr
	 * @return: void
	 */
	private void targetVchrSucc(GlaVoucher ivchr) throws Exception {
		GlaVoucherMapper glaVoucherMapper = sqlSession
				.getMapper(GlaVoucherMapper.class);
		try {
			//��Ʊ���˳ɹ�
			glaVoucherMapper.updateToSucc(ivchr);
			//����״̬Ϊδʹ�ã�����»���Ϊ��ʹ��
			ComBrch brchEntity = getBrchFromBrchCache(ivchr.getStacid(),ivchr.getAcctbr());
			if(brchEntity.getUsedtp().equals("0")){
				glaVoucherMapper.updateBrchToUsed(ivchr);
			}
			////����״̬Ϊδʹ�ã�����»���Ϊ��ʹ��
			AccountingItem itemEntity = getItemFromItemCache(ivchr.getStacid(),ivchr.getItemcd());
			if(itemEntity.getUsedtp().equals("0")){
				glaVoucherMapper.updateItemToUsed(ivchr);
			}
		} catch (Exception ex) {
			logger.error(ivchr.getSoursq() + "," + ivchr.getVchrsq()
					+ "����ʶΪ�ɹ�������ʧ�ܡ�",ex);
			throw new Exception(ex.getMessage(),ex);
		}
	}


	private String prepareData(GlaVoucher vchr) throws AnalyseException {
		
		String vchrKey = getVchrKey(vchr);

		if (vchrsCache.containsKey(vchrKey)) {
			GlaVoucher chr = vchrsCache.get(vchrKey);
			chr.setTranam(chr.getTranam().add(vchr.getTranam()));
			chr.setTrannm(chr.getTrannm() + vchr.getTrannm());
		} else {
			vchrsCache.put(vchrKey, GlaVchrBean.clone(vchr));
		}
		
		
		

		GlaGlis glis = GlaGlisBean.openGlis(
				getItemFromItemCache(vchr.getStacid(), vchr.getItemcd()), vchr);

		String glisKey = getGlisKey(glis);
		if (glisCache.containsKey(glisKey)) {
			// System.out.println("glis ����");
			
		} else {
			try{
				glis = sqlSession.getMapper(GlaGlisMapper.class)
						.getEntityLock(vchr);
			}catch(Exception exx){
				logger.error("��������ʧ�� infomation= stacid:" + vchr.getStacid() + ",acctdt:"
						+ vchr.getTrandt() + ",systid:" + vchr.getSystid() + ",brchcd:"
						+ vchr.getAcctbr() + ",itemcd:" + vchr.getItemcd() + ",crcycd:"
						+ vchr.getCrcycd(),exx);
				throw new AnalyseException("��������ʧ��",exx);
			}finally{
				
			}
			

			if (null == glis) {
				glis = GlaGlisBean.openGlis(
						getItemFromItemCache(vchr.getStacid(), vchr.getItemcd()),
						vchr);
				sqlSession.getMapper(GlaGlisMapper.class).insertEntity(glis);
			}else{
				//У�����ݺϷ���
				GlaGlisBean.checkProperty(glis);
			}
			glisKey = getGlisKey(glis);
			glisCache.put(glisKey, glis);
		}
		
		//���㽻�׽��ϼơ����׽����������
		GlaGlisBean.updateBalance(vchr, glisCache.get(glisKey), getItemFromItemCache(vchr.getStacid(), vchr.getItemcd()));
		
		return glisKey;
	}
	
private String prepareData2(GlaVoucher vchr) throws AnalyseException {
		
		String vchrKey = getVchrKey(vchr);

		if (vchrsCache.containsKey(vchrKey)) {
			GlaVoucher chr = vchrsCache.get(vchrKey);
			chr.setTranam(chr.getTranam().add(vchr.getTranam()));
			chr.setTrannm(chr.getTrannm() + vchr.getTrannm());
			
		} else {
			vchrsCache.put(vchrKey, GlaVchrBean.clone(vchr));
		}

		GlaGlis glis = GlaGlisBean.openGlis(
				getItemFromItemCache(vchr.getStacid(), vchr.getItemcd()), vchr);

		String glisKey = getGlisKey(glis);
		if (glisCache.containsKey(glisKey)) {
			// System.out.println("glis ����");
			
			
		} else {
			try{
				glis = sqlSession.getMapper(GlaGlisMapper.class)
						.getEntityLock(vchr);
			}catch(Exception ex){
				logger.error("�������������쳣��" + vchr.getItemcd(),ex);
				logger.error("stacid:" + vchr.getStacid() + ",acctdt:"
						+ vchr.getTrandt() + ",systid:" + vchr.getSystid() + ",brchcd:"
						+ vchr.getAcctbr() + ",itemcd:" + vchr.getItemcd() + ",crcycd:"
						+ vchr.getCrcycd());
				throw new AnalyseException("�������������쳣");
			}
			

			if (null == glis) {
				glis = GlaGlisBean.openGlis(
						getItemFromItemCache(vchr.getStacid(), vchr.getItemcd()),
						vchr);
				sqlSession.getMapper(GlaGlisMapper.class).insertEntity(glis);
			}else{
				//У�����ݺϷ���
				GlaGlisBean.checkProperty(glis);
			}

			glisCache.put(glisKey, glis);
		}
		
		GlaGlisBean.updateBalance(vchr, glisCache.get(glisKey), getItemFromItemCache(vchr.getStacid(), vchr.getItemcd()));
		
		return glisKey;
	}

	private void checkAccoutOverDraft(String glisKey, GlaVoucher _vchr) {
		if (glisCache.get(glisKey).getOnlnbl().compareTo(BigDecimal.valueOf(0)) < 0) {
			
			/*logger.error("������" +glisCache.get(glisKey).getBrchcd() + "����Ŀ:"
					+ glisCache.get(glisKey).getItemcd() + "͸֧");*/
			try{
				GlaGlisMapper glaGlisMapper = sqlSession
						.getMapper(GlaGlisMapper.class);
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("trandt", _vchr.getTrandt());
				map.put("transq", _vchr.getTransq());
				map.put("erortx", _vchr.getVchrsq() + "���ڣ�"+_vchr.getTrandt()+"������"+_vchr.getAcctbr()+"��Ŀ��"+_vchr.getItemcd()+"���"+glisCache.get(glisKey).getOnlnbl()+"����͸֧����¼���׷���:" + _vchr.getAmntcd()
						+ ",���׽�" + _vchr.getTranam());
				glaGlisMapper.insertErorTax(map);
			}catch(Exception ex){
				logger.error("�������˴�����־ʧ��"+ex.getMessage(),ex);
			}
			
		}
		logger.debug("͸֧���ɹ�");
	}

	private void toAccounting() throws AnalyseException {
		
		Iterator<String> vchrsIt = vchrsCache.keySet().iterator();
		
		while (vchrsIt.hasNext()) {

			GlaVoucher ve = vchrsCache.get(vchrsIt.next());
			
			GlaGlis glisInfo = GlaGlisBean.openGlis(
					getItemFromItemCache(ve.getStacid(), ve.getItemcd()), ve);

			String glisKey = getGlisKey(glisInfo);
			
			GlaGlis glise = glisCache.get(glisKey);
			
			AccountingItem itemEntity=null;
			ComBrch brchEntity = null;
			try{
				//��Ŀ������ʱ����
				 itemEntity = getItemFromItemCache(ve.getStacid(),ve.getItemcd());
				 ComItemBean.checkAccountingProperty(itemEntity);
	
				//��������ʱ����
				 brchEntity = getBrchFromBrchCache(ve.getStacid(),ve.getAcctbr());
				 ComBrchBean.checkAccoutingProperty(brchEntity);
			}catch (AnalyseException e) {
				throw new AnalyseException("��Ŀ���������Ϸ�:"+e);
			}finally{
				
			}
			
			//�������ݿ��������
			sqlSession.getMapper(GlaGlisMapper.class).updateEntity(glise);

			GlaAcctMapper glaAcctMapper = sqlSession
					.getMapper(GlaAcctMapper.class);

			List<GlaAcct> acctEntitys = glaAcctMapper
					.selectEntitiesByGlaVoucher(ve);

			GlaAcct acctEntity = null;
			if (null == acctEntitys || acctEntitys.isEmpty()) {
				acctEntity = openAcctcd(ve, itemEntity, brchEntity);
				
			} else if (acctEntitys.size() > 1) {
				logger.error("��ö�[" + acctEntitys.size() + "]���˻���Ϣ��ϵͳ���ݴ���");
				throw new AnalyseException("��ö�[" + acctEntitys.size()
						+ "]���˻���Ϣ��ϵͳ���ݴ���");
			} else {
				logger.debug("��ȡ"+acctEntitys.size()+"���˻���Ϣ�ɹ���" + acctEntitys.size());
				acctEntity = acctEntitys.get(0);

			}
			
			GlaAcctBean.updateAccountBalance(ve.getStacid(), ve.getSystid(),
					ve.getAcctbr(), ve.getItemcd(), ve.getCrcycd(), ve.getSubsac(),
					ve.getAmntcd(), ve.getTranam(), ve.getTransq(),
					itemEntity.getPomdtg(), ve.getSoursq(), ve.getTrandt(),
					itemEntity, acctEntity);

			try {
				int updateCount = glaAcctMapper.updateBalance(acctEntity.getAcctcd(),
						acctEntity.getOnlnbl(), acctEntity.getLstrsq(),
						acctEntity.getLstrdt(), acctEntity.getBlncdn());
				if(updateCount < 1){
					logger.error("��������"+updateCount+",δ�������˻��������˻�["+acctEntity.getAcctcd()+"]");
					throw new AnalyseException("δ�������˻��������˻�["+acctEntity.getAcctcd()+"]");
				}else{
					logger.debug("�˻�["+acctEntity.getAcctcd()+"]���ݿ�������ɹ���");
				}
			} catch (Exception ex) {
				logger.error("�����˻����ʧ�ܡ��˻���Ϣ���£�" + "acctno:" + acctEntity.getAcctcd() + ",onlnbl:"
						+ acctEntity.getOnlnbl() + ",lstrsq:"
						+ acctEntity.getLstrsq() + ",lstrdt:"
						+ acctEntity.getLstrdt() + ",blncdn:"
						+ acctEntity.getBlncdn());
				throw new AnalyseException("�����˻����ʧ�ܡ�",ex);
			}
		}

	}
	
	private void toAccounting2() throws AnalyseException {
		
		Iterator<String> vchrsIt = vchrsCache.keySet().iterator();
		
		while (vchrsIt.hasNext()) {

			GlaVoucher ve = vchrsCache.get(vchrsIt.next());
			
			GlaGlis glisInfo = GlaGlisBean.openGlis(
					getItemFromItemCache(ve.getStacid(), ve.getItemcd()), ve);

			String glisKey = getGlisKey(glisInfo);
			
			GlaGlis glise = glisCache.get(glisKey);

			AccountingItem itemEntity=null;
			ComBrch brchEntity = null;
			try{
			//��Ŀ������ʱ����
			 itemEntity = getItemFromItemCache(ve.getStacid(),ve.getItemcd());
			 ComItemBean.checkAccountingProperty(itemEntity);

			//��������ʱ����
			 brchEntity = getBrchFromBrchCache(ve.getStacid(),ve.getAcctbr());
			 ComBrchBean.checkAccoutingProperty(brchEntity);
			
			//������Ч��
			
			}catch (AnalyseException e) {
				throw new AnalyseException("��Ŀ���������Ϸ�:"+e);
			}
			
			try{
				sqlSession.getMapper(GlaGlisMapper.class).updateEntity(glise);
			}catch(Exception ex){
				logger.error("���˸����쳣",ex);
				throw new AnalyseException("glis update �쳣",ex);
			}

			GlaAcctMapper glaAcctMapper = sqlSession
					.getMapper(GlaAcctMapper.class);
			List<GlaAcct> acctEntitys = null;
			try{
				//�����˻���Ϣ
				acctEntitys = glaAcctMapper
						.selectEntitiesByGlaVoucher(ve);
			}catch(Exception ex){
				logger.error("selectEntitiesByGlaVoucher �쳣:",ex);
				throw new AnalyseException("selectEntitiesByGlaVoucher �쳣",ex);
			}
			

			GlaAcct acctEntity = null;
			if (null == acctEntitys || acctEntitys.isEmpty()) {
				acctEntity = openAcctcd(ve, itemEntity, brchEntity);
			} else if (acctEntitys.size() > 1) {
				logger.error("��ö�[" + acctEntitys.size() + "]���˻���Ϣ��ϵͳ���ݴ���");
				throw new AnalyseException("��ö�[" + acctEntitys.size()
						+ "]���˻���Ϣ��ϵͳ���ݴ���");
			} else {
				logger.info("��ȡ�˻���Ϣ�ɹ���" + acctEntitys.size());
				acctEntity = acctEntitys.get(0);
			}

			GlaAcctBean.updateAccountBalance(ve.getStacid(), ve.getSystid(),
					ve.getAcctbr(), ve.getItemcd(), ve.getCrcycd(), null,
					ve.getAmntcd(), ve.getTranam(), ve.getTransq(),
					itemEntity.getPomdtg(), ve.getSoursq(), ve.getTrandt(),
					itemEntity, acctEntity);

			try {
				int updateCount = glaAcctMapper.updateBalance(acctEntity.getAcctcd(),
						acctEntity.getOnlnbl(), acctEntity.getLstrsq(),
						acctEntity.getLstrdt(), acctEntity.getBlncdn());
				if(updateCount < 1){
					logger.error("δ�������˻��������˻�["+acctEntity.getAcctcd()+"]");
					throw new AnalyseException("δ�������˻��������˻�["+acctEntity.getAcctcd()+"]");
				}else{
					logger.debug("�˻�["+acctEntity.getAcctcd()+"]���ݿ�������ɹ���");
				}
			} catch (Exception ex) {
				logger.error("�����˻����ʧ�ܡ��˻���Ϣ���£�"+"�˺�:" + acctEntity.getAcctcd() + ",���:"
						+ acctEntity.getOnlnbl() + ",�������ˮ:"
						+ acctEntity.getLstrsq() + ",���������:"
						+ acctEntity.getLstrdt() + ",����:"
						+ acctEntity.getBlncdn()+ex);
				throw new AnalyseException("�����˻����ʧ�ܡ�",ex);
			}

		}
		
		logger.debug("�������ˡ��˻��ɹ�");

	}

	public GlaAcct openAcctcd(GlaVoucher ve, AccountingItem itemEntity,
			ComBrch brchEntity) throws AnalyseException {
		GlaAcct acctEntity = new GlaAcct();
		SysAcctOpen sysAcctOpen = GlaAcctBean.getAcctOpenInfo(ve.getStacid(),
				ve.getSystid(), ve.getAcctbr(), ve.getCrcycd(), ve.getItemcd());
		SysAcctOpen acctOpen = null;
			
		//��ȡ�˻����
		int acctcdsub;
		try{
			acctcdsub = SysAcctOpenBean
						.selectEntity(sysAcctOpen);
		}catch(Exception ex){
			logger.error("��ѯsysAcctOpenNew �쳣��");
			throw new AnalyseException("��ѯsysAcctOpenNew �쳣��",ex);
		}

		sysAcctOpen.setAorder(acctcdsub);
		acctOpen = sysAcctOpen;

		// TODO Auto-generated method stub
		logger.debug("�˻����...");
		int acctEntitiesLeng = 0;
		GlaAcctMapper glaAcctMapper = null;
		SqlSession sqlSession = null;
		try{
			//�������ύ
			sqlSession = MyBatisUtil
					.getSqlSessionFactory()
					.openSession(false);
			
			glaAcctMapper = sqlSession.getMapper(GlaAcctMapper.class);
			List<GlaAcct> acctEntitys = glaAcctMapper.selectEntitiesByGlaVoucher(ve);
			
			if(null != acctEntitys){
				acctEntitiesLeng = acctEntitys.size();
			}else{
				logger.fatal("����:"+ve.getStacid()+"��ϵͳ��"+ve.getSystid()+"������"+ve.getAcctbr()+"��Ŀ��"+ve.getItemcd()+"���֣�"+ve.getCrcycd()+"��Ŀ�ţ�"+ve.getSubsac()+"��δ��������");
			}
			
			//���δ���˻�
			if(acctEntitiesLeng >= 1){
				logger.error("ϵͳ���ݴ�������["+ve.getStacid()+"]��ϵͳ["+ve.getSystid()+"]����["+ve.getAcctbr()+"]��Ŀ["+ve.getItemcd()+"]��Ӧ����["+ve.getCrcycd()+"]�´��ڶ���˻���");
				throw new AnalyseException("ϵͳ���ݴ�������["+ve.getStacid()+"]��ϵͳ["+ve.getSystid()+"]����["+ve.getAcctbr()+"]��Ŀ["+ve.getItemcd()+"]��Ӧ����["+ve.getCrcycd()+"]�´��ڶ���˻���");
			}else if(acctEntitiesLeng == 0){
				logger.fatal("������Ҫ��������������Ϣ��" + acctOpen.toString());
				String acctcd = GlaAcctBean.getAcctcd(ve.getStacid(),ve.getSystid(),ve.getAcctbr(),ve.getCrcycd(),ve.getItemcd(),acctOpen.getAorder());
				
				//��Ч�Լ��
				GlaAcct entityAcct = null;
				try{
					entityAcct = glaAcctMapper.selectEntityByAccount(acctcd);
				}catch(Exception ex){
					logger.error("ȷ���˻�"+acctcd+"��Ϣʱϵͳ������");
					throw new AnalyseException("ȷ���˻���Ϣʱϵͳ������");
				}
				
				if(null != entityAcct ){
					logger.error("���������쳣:�˻�"+acctcd+"�Ѵ��ڣ�������Ϣ���󣡴�������Ϣ��" + acctOpen.toString());
					throw new AnalyseException("���������쳣:�˻�"+acctcd+"�Ѵ��ڣ�������������¼����:" + acctOpen.toString());
				}
				
				acctEntity = GlaAcctBean.generateAcctEntity(stacid,acctcd, itemEntity, brchEntity, ve);
				
				try{
					GlaAcctValidateBean.validate(acctEntity);
					int insertCount = glaAcctMapper.insertGlaAcct(acctEntity);
					//ִ�н��У��
					if(insertCount < 0){
						logger.error("����["+ve.getStacid()+"]���˻�["+acctEntity.getAcctno()+"]��Ϣ�������ݿ�ʧ�ܣ�");
						throw new AnalyseException("����["+ve.getStacid()+"]���˻�["+acctEntity.getAcctno()+"]��Ϣ�������ݿ�ʧ�ܣ�");
					}else if(insertCount == 1){
						logger.debug("����["+ve.getStacid()+"]���˻�["+acctEntity.getAcctno()+"]��Ϣ�������ݿ�ɹ���");
					}else{
						logger.error("ϵͳ�쳣������ϵ����Ա��");
						throw new AnalyseException("ϵͳ�쳣������ϵ����Ա��");
					}
					sqlSession.commit(true);
				}catch(Exception ex){
					logger.error("����˻���Ϣʱϵͳ�쳣��",ex);
					throw new AnalyseException("����˻���Ϣʱϵͳ�쳣��");
				}
				
				logger.debug("��ϵͳ["+ve.getSystid()+"]����["+ve.getAcctbr()+"]��Ŀ["+ve.getItemcd()+"]��Ӧ����["+ve.getCrcycd()+"]������Ϣ���ɳɹ�");
			}
			
		}catch(Exception ex){
			sqlSession.rollback();
			String msg = "��ȡ�˻�ʱϵͳ�쳣��"+ ex.getMessage() + ".systid="+ve.getSystid()+",brchcd="+ve.getAcctbr()+",itemcd="+ve.getItemcd()+",crcycd:"+ve.getCrcycd()+",subscd:" + ve.getSubsac();
			logger.error(msg);
			throw new AnalyseException(msg,ex);
		}finally{
			if(null != sqlSession){
				sqlSession.close();
			}
		}
		
		return acctEntity;

	}

	private void toSubmitBatch() {
		sqlSession.commit(true);
		sqlSession.clearCache();
		logger.info("�����ύ:" + vchrBuffer.size());
		glisCache.clear();
		vchrsCache.clear();
		dropVchrBuffer();
	}
	
	private void toSubmit() {
		sqlSession.commit(true);
		sqlSession.clearCache();
		logger.info("�����ύ.");
		glisCache.clear();
		vchrsCache.clear();
		dropVchrBuffer();
	}

	private void toRollbackBatch() {
		sqlSession.rollback(true);
		logger.info("�����ع�����:" + vchrBuffer.size());
		glisCache.clear();
		vchrsCache.clear();

	}
	
	private void toRollback() {
		sqlSession.rollback(true);
		logger.info("���ʻع�");
		glisCache.clear();
		vchrsCache.clear();

	}

	public void gcDeal() {
		if (null != sqlSession) {
			sqlSession.close();
		}
	}

	public static String getSysAcctOpenKey(SysAcctOpen entity) {
		return String.valueOf(entity.getStacid()).concat(DTAG)
				.concat(entity.getSystid()).concat(DTAG)
				.concat(entity.getBrchcd()).concat(DTAG)
				.concat(entity.getCrcycd()).concat(DTAG)
				.concat(entity.getItemcd());
	}

	/**
	 * STACID, ACCTDT, SYSTID, BRCHCD, ITEMCD, CRCYCD, GELDTP, ACCTNO, ASSIS0,
	 * ASSIS1, ASSIS2, ASSIS3, ASSIS4, ASSIS5, ASSIS6, ASSIS7, ASSIS8, ASSIS9
	 * 
	 * @param glaGlis
	 * @return
	 */
	private static String getGlisKey(GlaGlis glaGlis) {
		return String.valueOf(glaGlis.getStacid()).concat(DTAG)
				.concat(glaGlis.getAcctdt()).concat(DTAG)
				.concat(glaGlis.getSystid()).concat(DTAG)
				.concat(glaGlis.getBrchcd()).concat(DTAG)
				.concat(glaGlis.getItemcd()).concat(DTAG)
				.concat(glaGlis.getCrcycd()).concat(DTAG)
				.concat(glaGlis.getGeldtp()).concat(DTAG)
				.concat(glaGlis.getCentcd()).concat(DTAG)
				.concat(glaGlis.getPrsncd()).concat(DTAG)
				.concat(glaGlis.getCustcd()).concat(DTAG)
				.concat(glaGlis.getPrducd()).concat(DTAG)
				.concat(glaGlis.getPrlncd()).concat(DTAG)
				.concat(glaGlis.getAcctno()).concat(DTAG)
				.concat(glaGlis.getAssis0()).concat(DTAG)
				.concat(glaGlis.getAssis1()).concat(DTAG)
				.concat(glaGlis.getAssis2()).concat(DTAG)
				.concat(glaGlis.getAssis3()).concat(DTAG)
				.concat(glaGlis.getAssis4()).concat(DTAG)
				.concat(glaGlis.getAssis5()).concat(DTAG)
				.concat(glaGlis.getAssis6()).concat(DTAG)
				.concat(glaGlis.getAssis7()).concat(DTAG)
				.concat(glaGlis.getAssis8()).concat(DTAG)
				.concat(glaGlis.getAssis9());
	}

	/**
	 * STACID, SYSTID, TRANDT, TRANSQ, VCHRSQ
	 * 
	 * @param glaVoucher
	 * @return
	 */
	private static String getVchrKey(GlaVoucher glaVoucher) {
		return String.valueOf(glaVoucher.getStacid()).concat(DTAG)
				.concat(glaVoucher.getSystid()).concat(DTAG)
				.concat(glaVoucher.getTrandt()).concat(DTAG)
				.concat(glaVoucher.getAcctbr()).concat(DTAG)
				.concat(glaVoucher.getItemcd()).concat(DTAG)
				.concat(null==glaVoucher.getSubsac()?"":glaVoucher.getSubsac()).concat(DTAG)
				.concat(glaVoucher.getCrcycd()).concat(DTAG)
				.concat(glaVoucher.getCentcd()).concat(DTAG)
				.concat(glaVoucher.getPrsncd()).concat(DTAG)
				.concat(glaVoucher.getCustcd()).concat(DTAG)
				.concat(glaVoucher.getPrducd()).concat(DTAG)
				.concat(glaVoucher.getPrlncd()).concat(DTAG)
				.concat(glaVoucher.getAcctno()).concat(DTAG)
				.concat(glaVoucher.getTrantp()).concat(DTAG)
				.concat(glaVoucher.getAmntcd()).concat(DTAG)
				.concat(glaVoucher.getAssis0()).concat(DTAG)
				.concat(glaVoucher.getAssis1()).concat(DTAG)
				.concat(glaVoucher.getAssis2()).concat(DTAG)
				.concat(glaVoucher.getAssis3()).concat(DTAG)
				.concat(glaVoucher.getAssis4()).concat(DTAG)
				.concat(glaVoucher.getAssis5()).concat(DTAG)
				.concat(glaVoucher.getAssis6()).concat(DTAG)
				.concat(glaVoucher.getAssis7()).concat(DTAG)
				.concat(glaVoucher.getAssis8()).concat(DTAG)
				.concat(glaVoucher.getAssis9());
	}

	private static String getItemKey(AccountingItem item) {
		return String.valueOf(item.getStacid()).concat(DTAG)
				.concat(item.getItemcd());
	}

	@SuppressWarnings("unused")
	private static String getItemKey(int stacid, String itemcd) {
		return String.valueOf(stacid).concat(DTAG).concat(itemcd);
	}

	private static String getBrchKey(int stacid, String brchcd) {
		return String.valueOf(stacid).concat(DTAG).concat(brchcd);
	}

	public static void printTime() {
		Logger.getLogger(FIAsyncConsumer.class).debug(
				System.nanoTime() / 1000000L);
	}

	private void addVchr(GlaVoucher vchr) {
		vchrBuffer.add(vchr);
	}

	private void dropVchrBuffer() {
		vchrBuffer = new Vector<GlaVoucher>();
	}
	
	private ComBrch freshBrchCache(int stacid, String brchcd) throws AnalyseException{
		brchCache.clear();
		initC();
		return brchCache.get(String.valueOf(stacid)
				.concat(DTAG).concat(brchcd));
		
	}
	
	private ComBrch getBrchFromBrchCache(int stacid, String brchcd)
			throws AnalyseException {
		ComBrch brchInfo = brchCache.get(String.valueOf(stacid)
				.concat(DTAG).concat(brchcd));
		if (null == brchInfo && null == (brchInfo = freshBrchCache(stacid, brchcd))) {
			logger.error("����["+stacid+"]�´�Ʊ�����������["+brchcd+"]�������в�����");
			throw new AnalyseException("����["+stacid+"]�´�Ʊ�����������["+brchcd+"]�������в�����");
		}

		return brchInfo;
	}
	
	private AccountingItem freshItemCache(int stacid, String itemcd) throws AnalyseException{
		itemCache.clear();
		initC();
		return itemCache.get(String.valueOf(stacid)
				.concat(DTAG).concat(itemcd));
		
	}

	private AccountingItem getItemFromItemCache(int stacid, String itemcd)
			throws AnalyseException {
		AccountingItem itemInfo = itemCache.get(String.valueOf(stacid)
				.concat(DTAG).concat(itemcd));
		if (null == itemInfo && null == (itemInfo = freshItemCache(stacid, itemcd))) {
			logger.error("���ף�" + stacid + "�в����ڿ�Ŀ��" + itemcd);
			throw new AnalyseException("");
		}

		return itemInfo;
	}
}
