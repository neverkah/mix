package com.sunline.sbp.commanddeal;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.dao.mapper.MidTranMapper;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.MidTran;

/**
 * ��������������ϸ
 * @author Hopechj
 *
 */
public class MidCommand implements TranCommandObject {
	
	private MidTran midTran;
	private MidTranMapper midTranMapper;
	private GlaVoucher glaVoucher;
	
	private Logger logger = Logger.getLogger(MidCommand.class);

	@Override
	public void setVoucherInfo() {
		// TODO Auto-generated method stub
		glaVoucher = new GlaVoucher();
		glaVoucher.setTrandt(midTran.getTrandt());
		glaVoucher.setTranbr(midTran.getTranbr());
		glaVoucher.setSourdt(midTran.getTrandt());
		glaVoucher.setSourst(midTran.getSystid());
		glaVoucher.setSoursq(midTran.getTransq());
		glaVoucher.setSystid(midTran.getSystid());
		glaVoucher.setStacid(midTran.getStacid());
		glaVoucher.setToitem("");
		glaVoucher.setTranam(midTran.getTranam());
		glaVoucher.setTranbl(BigDecimal.ZERO);
		glaVoucher.setTrantp(Enumeration.TRANTP.TRAN.value);
		glaVoucher.setUsercd(Enumeration.USERCD.ENGINE.value);
		glaVoucher.setAcctbr(midTran.getAcctbr());
		glaVoucher.setAcctno("");
		glaVoucher.setAmntcd(midTran.getAmntcd());
		glaVoucher.setCrcycd(midTran.getCrcycd());
		glaVoucher.setItemcd(midTran.getDtitcd());
		glaVoucher.setSmrytx(midTran.getSmrytx());
		glaVoucher.setClertg(Enumeration.CLERTG.CLERTG_0.value);
	}

	@Override
	public void initialize(String trandt, String transq , String cmmdsq , String systid) throws AnalyseException {
		// TODO Auto-generated method stub
		logger.debug("�ӽ��ײ�ѯ���� : trandt=" + trandt + ",transq=" + transq + ",cmmdsq=" + cmmdsq);
		try{
			if(null == midTranMapper){
				logger.error("��ȡ�ӽ�������ϵͳ�쳣����������Ϊ��");
			}
			midTran = midTranMapper.selectEntity(trandt, transq , cmmdsq , systid);
		}catch(Exception ex){
			logger.error("��ȡ�ӽ�������ʱ��ϵͳ�쳣������");
			throw new AnalyseException("��ȡ�ӽ�������ϵͳ�쳣������",ex);
		}
		
		if(null == midTran){
			logger.error("�ӽ�������Ϊ��");
			throw new AnalyseException("�ӽ�������Ϊ�գ�����"+"trandt=" + trandt + ",transq=" + transq + ",cmmdsq=" + cmmdsq);
		}else{
			logger.debug("�ӽ������ݻ�ȡ�ɹ�");
		}
	}

	@Override
	public String getTrprcd() {
		// TODO Auto-generated method stub
		return Constants.TRPRCD_DEFAULT;
	}

	@Override
	public String getDtitcd() {
		// TODO Auto-generated method stub
		return midTran.getDtitcd();
	}

	@Override
	public GlaVoucher getGlaVoucher() {
		// TODO Auto-generated method stub
		return glaVoucher;
	}

	public MidTranMapper getMidTranMapper() {
		return midTranMapper;
	}

	public void setMidTranMapper(MidTranMapper midTranMapper) {
		this.midTranMapper = midTranMapper;
	}

	@Override
	public String postingSucc() throws AnalyseException {
		// TODO Auto-generated method stub
		String executeResult;
		try{
			midTranMapper.updateBkfnstSucc(midTran);
			executeResult = Constants.EXECUTE_SUCC;
		}catch(Exception ex){
			executeResult = "EXE9999";
			throw new AnalyseException("����ָ��Ϊ�ѹ���ʧ��",ex);
		}
		return executeResult;
	}

	@Override
	public String getTrancd() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getStacid() throws AnalyseException {
		// TODO Auto-generated method stub
		return midTran.getStacid();
	}

	@Override
	public void initialize(JSONObject jsonObject) throws AnalyseException {
		// TODO Auto-generated method stub
		midTran = JSON.parseObject(jsonObject.toJSONString(), MidTran.class);
	}

	@Override
	public String getTrandt() throws AnalyseException {
		// TODO Auto-generated method stub
		return midTran.getTrandt();
	}

	@Override
	public String getSystid() throws AnalyseException {
		// TODO Auto-generated method stub
		return midTran.getSystid();
	}

	@Override
	public String getTransq() throws AnalyseException {
		// TODO Auto-generated method stub
		return midTran.getTransq();
	}

	@Override
	public String getCmmdsq() throws AnalyseException {
		// TODO Auto-generated method stub
		return midTran.getMiddsq();
	}
	
}
