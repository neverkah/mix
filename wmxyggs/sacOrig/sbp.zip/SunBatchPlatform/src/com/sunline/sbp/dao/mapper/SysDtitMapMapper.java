package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.SysDtitMapBean;

public interface SysDtitMapMapper {
	public SysDtitMapBean[] selectDtit(SysDtitMapBean data);
}
