package com.sunline.sbp.model;

public class SysAyncNode {
	private String aynccd;
	private String nodeid;
	private int stacid;
	private String trandt;
	private String sourst;
	private String brchcd;
	private String pitncd;
	private String regiti;
	
	public String getRegiti() {
		return regiti;
	}
	public void setRegiti(String regiti) {
		this.regiti = regiti;
	}
	public String getAynccd() {
		return aynccd;
	}
	public void setAynccd(String aynccd) {
		this.aynccd = aynccd;
	}
	public String getNodeid() {
		return nodeid;
	}
	public void setNodeid(String nodeid) {
		this.nodeid = nodeid;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getSourst() {
		return sourst;
	}
	public void setSourst(String sourst) {
		this.sourst = sourst;
	}
	public String getBrchcd() {
		return brchcd;
	}
	public void setBrchcd(String brchcd) {
		this.brchcd = brchcd;
	}
	public String getPitncd() {
		return pitncd;
	}
	public void setPitncd(String pitncd) {
		this.pitncd = pitncd;
	}
	
	
}
