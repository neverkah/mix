package com.sunline.sbp.dao;

import java.util.List;

import com.sunline.sbp.model.ComBuln;
import com.sunline.sbp.model.ComCent;

public interface ComCentDao {
	public List<ComCent> getAllEntities();
}
