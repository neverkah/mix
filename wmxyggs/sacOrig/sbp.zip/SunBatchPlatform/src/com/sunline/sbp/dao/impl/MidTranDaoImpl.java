package com.sunline.sbp.dao.impl;

import com.sunline.sbp.dao.MidTranDao;
import com.sunline.sbp.dao.mapper.MidTranMapper;
import com.sunline.sbp.model.MidTran;

public class MidTranDaoImpl implements MidTranDao{
	
	private MidTranMapper midTranMapper;
	
	public MidTranMapper getMidTranMapper() {
		return midTranMapper;
	}

	public void setMidTranMapper(MidTranMapper midTranMapper) {
		this.midTranMapper = midTranMapper;
	}

	public void insert(MidTran midtran){
		//this.midTranMapper.insert(midtran);
	}
	
	public void update(MidTran midTran){
		this.midTranMapper.update(midTran);
	}
}
