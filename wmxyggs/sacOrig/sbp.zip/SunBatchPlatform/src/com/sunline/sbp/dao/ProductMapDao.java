package com.sunline.sbp.dao;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.ProductMap;

public interface ProductMapDao {
	public ProductMap[] getTempleteOfProduct(ProductMap productMap) throws EngineRuntimeException;
}
