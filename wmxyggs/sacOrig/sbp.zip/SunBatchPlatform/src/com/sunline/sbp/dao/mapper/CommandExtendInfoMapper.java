package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.CommandExtendInfo;

public interface CommandExtendInfoMapper {
	public CommandExtendInfo selectEntity(CommandExtendInfo entity);
}
