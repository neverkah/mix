package com.sunline.sbp.core.bean;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.model.AccountingItem;
import com.sunline.sbp.model.GlaGlis;
import com.sunline.sbp.model.GlaVoucher;

public class GlaGlisBean {
	
	private static final Logger logger = Logger.getLogger(GlaGlisBean.class);
	
	public static void updateBalance(GlaVoucher vchr , GlaGlis glisEntity , AccountingItem itemEntity) {
		// TODO Auto-generated method stub

		BigDecimal drctbl = new BigDecimal(0), crctbl = new BigDecimal(0), onlnbl = new BigDecimal(0);
		BigDecimal dtranam = new BigDecimal(0), ctranam = new BigDecimal(0);
		int dtranm = 0, ctranm = 0;
		String blncdn = null;
		BigDecimal devTranam = new BigDecimal(0);

		if (vchr.getAmntcd().equalsIgnoreCase(Constants.AMNTCD_DEBIT)) {
			dtranam = vchr.getTranam();
			dtranm = vchr.getTrannm();
		} else if (vchr.getAmntcd().equalsIgnoreCase(Constants.AMNTCD_CREDIT)) {
			ctranam = vchr.getTranam();
			ctranm = vchr.getTrannm();
		} else if(vchr.getAmntcd().equalsIgnoreCase(Enumeration.Amntcd.R.value)){
			dtranam = vchr.getTranam();
			dtranm = vchr.getTrannm();
		}else if(vchr.getAmntcd().equalsIgnoreCase(Enumeration.Amntcd.P.value)){
			ctranam = vchr.getTranam();
			ctranm = vchr.getTrannm();
		}

		/*
		 * ����Ŀ����ֱ���
		 */
		if (itemEntity.getItemdn().equalsIgnoreCase(Constants.AMNTCD_DEBIT)
				|| itemEntity.getItemdn().equalsIgnoreCase(Enumeration.Amntcd.R.value)) {
			drctbl = glisEntity.getDrctbl().add(dtranam).subtract(ctranam);
			onlnbl = drctbl;
			blncdn = itemEntity.getItemdn();
		} else if (itemEntity.getItemdn().equalsIgnoreCase(
				Constants.AMNTCD_CREDIT)
				|| itemEntity.getItemdn().equalsIgnoreCase(Enumeration.Amntcd.P.value)) {
			crctbl = glisEntity.getCrctbl().add(ctranam).subtract(dtranam);
			onlnbl = crctbl;
			blncdn = itemEntity.getItemdn();
		} else if (itemEntity.getItemdn().equalsIgnoreCase(Constants.AMNTCD_B)) {
			crctbl = glisEntity.getCrctbl().add(ctranam);
			drctbl = glisEntity.getDrctbl().add(dtranam);
			devTranam = dtranam.subtract(ctranam);

			if (glisEntity.getBlncdn().equals(Constants.AMNTCD_DEBIT)) {
				if ((glisEntity.getOnlnbl().add(devTranam).compareTo(BigDecimal.valueOf(0))) < 0) {
					blncdn = Constants.AMNTCD_CREDIT;
				} else {
					blncdn = Constants.AMNTCD_DEBIT;
				}
				onlnbl = glisEntity.getOnlnbl().add(devTranam).abs();
			} else {
				if (glisEntity.getOnlnbl().subtract(devTranam).compareTo(BigDecimal.ZERO) < 0) {
					blncdn = Constants.AMNTCD_DEBIT;
				} else {
					blncdn = Constants.AMNTCD_CREDIT;
				}
				onlnbl = glisEntity.getOnlnbl().subtract(devTranam).abs();
			}
		} else if (itemEntity.getItemdn().equalsIgnoreCase(Constants.AMNTCD_Z)) {
			devTranam = dtranam.subtract(ctranam);
			if (glisEntity.getBlncdn().equals(Constants.AMNTCD_DEBIT)) {
				if (glisEntity.getOnlnbl().add(devTranam).compareTo(BigDecimal.ZERO) < 0) {
					blncdn = Constants.AMNTCD_CREDIT;
				} else {
					blncdn = Constants.AMNTCD_DEBIT;
				}
				onlnbl = glisEntity.getOnlnbl().add(devTranam).abs();
			} else {
				if (glisEntity.getOnlnbl().subtract(devTranam).compareTo(BigDecimal.ZERO) < 0) {
					blncdn = Constants.AMNTCD_DEBIT;
				} else {
					blncdn = Constants.AMNTCD_CREDIT;
				}
				onlnbl = glisEntity.getOnlnbl().subtract(devTranam).abs();
			}
			if(blncdn.equals(Constants.AMNTCD_DEBIT)){
				drctbl = onlnbl;
				crctbl = BigDecimal.valueOf(0);
			}else{
				crctbl = onlnbl;
				drctbl = BigDecimal.valueOf(0);
			}
		}else{
			
		}
		
		//����跽�������Ľ��׽��ϼơ����ױ����ϼ�
		dtranam = dtranam.add(glisEntity.getDrtsam());
		ctranam = ctranam.add(glisEntity.getCrtsam());
		
		dtranm = dtranm + glisEntity.getDrtsnm();
		ctranm = ctranm + glisEntity.getCrtsnm();

		//����ֵ
		glisEntity.setDrtsam(dtranam);
		glisEntity.setCrtsam(ctranam);
		glisEntity.setDrtsnm(dtranm);
		glisEntity.setCrtsnm(ctranm);
		glisEntity.setDrctbl(drctbl);
		glisEntity.setCrctbl(crctbl);
		glisEntity.setBlncdn(blncdn);
		glisEntity.setOnlnbl(onlnbl);
		
		logger.debug("���˸��²����嵥:");
		logger.debug("Drtsam=" + glisEntity.getDrtsam());
		logger.debug("Crtsam=" + glisEntity.getCrtsam());
		logger.debug("Drtsnm=" + glisEntity.getDrtsam());
		logger.debug("Crtsnm=" + glisEntity.getCrtsnm());
		logger.debug("Drctbl=" + glisEntity.getDrctbl());
		logger.debug("Crctbl=" + glisEntity.getCrctbl());
		logger.debug("Blncdn=" + glisEntity.getBlncdn());
		logger.debug("Onlnbl=" + glisEntity.getOnlnbl());
	}
	
	public static GlaGlis openGlis(AccountingItem itemEntity, GlaVoucher vchr) {

		// ��ȡ��Ŀ����
		// String itemdn = itemEntity.getItemdn();
		String itemdn = itemEntity.getItemdn();

		// ��Ŀ����Ϊ�跽
		if (itemdn.equalsIgnoreCase(Constants.AMNTCD_CREDIT)) {
			itemdn = Constants.AMNTCD_CREDIT;
		} else if (itemdn.equalsIgnoreCase(Enumeration.Amntcd.R.value)) {
			itemdn = Enumeration.Amntcd.R.value;
		} else {
			itemdn = Constants.AMNTCD_DEBIT;
		}

		if (null == itemdn || itemdn.trim().length() == 0) {
			String message = "��Ŀ[" + itemEntity.getItemcd() + "]�����ȡʧ�ܣ�";
		}

		GlaGlis entity = new GlaGlis();
		entity.setStacid(vchr.getStacid());
		entity.setSystid(vchr.getSystid());
		entity.setAcctdt(vchr.getTrandt());
		entity.setBrchcd(vchr.getAcctbr());
		entity.setItemcd(vchr.getItemcd());
		entity.setCrcycd(vchr.getCrcycd());
		entity.setDrtsam(BigDecimal.ZERO);
		entity.setDrtsnm(0);
		entity.setCrtsam(BigDecimal.ZERO);
		entity.setCrtsnm(0);
		entity.setDrctbl(BigDecimal.ZERO);
		entity.setCrctbl(BigDecimal.ZERO);
		entity.setBlncdn(itemdn);
		entity.setOnlnbl(BigDecimal.ZERO);
		entity.setLastdn(itemdn);
		entity.setLastbl(BigDecimal.ZERO);
		entity.setGeldtp("D");
		entity.setCentcd(vchr.getCentcd());
		entity.setPrsncd(vchr.getPrsncd());
		entity.setCustcd(vchr.getCustcd());
		entity.setPrducd(vchr.getPrducd());
		entity.setPrlncd(vchr.getPrlncd());
		entity.setAcctno(vchr.getAcctno());
		entity.setAssis0(vchr.getAssis0());
		entity.setAssis1(vchr.getAssis1());
		entity.setAssis2(vchr.getAssis2());
		entity.setAssis3(vchr.getAssis3());
		entity.setAssis4(vchr.getAssis4());
		entity.setAssis5(vchr.getAssis5());
		entity.setAssis6(vchr.getAssis6());
		entity.setAssis7(vchr.getAssis7());
		entity.setAssis8(vchr.getAssis8());
		entity.setAssis9(vchr.getAssis9());

		return entity;
	}
	
	/**
	 * �������ԺϷ���У��
	 * @param glisEntity
	 * @throws AnalyseException
	 */
	public static void checkProperty(GlaGlis glisEntity) throws AnalyseException{
		//�쳣��Ϣ
		String message = "";
		//���򣨽衢�����ա������Ϸ���У��
		if(!(glisEntity.getBlncdn().equals(Enumeration.Amntcd.D.value)
				|| glisEntity.getBlncdn().equals(Enumeration.Amntcd.C.value)
				|| glisEntity.getBlncdn().equals(Enumeration.Amntcd.P.value)
				|| glisEntity.getBlncdn().equals(Enumeration.Amntcd.R.value))){
			message = "��ǰ���ˣ����ף�"+glisEntity.getStacid()+"�ݻ�����"+glisEntity.getBrchcd()+"�ݿ�Ŀ��"+glisEntity.getItemcd()+"�ݱ��֣�"+glisEntity.getCrcycd()+"�ݵ������"+glisEntity.getBlncdn()+"�ݷǷ�����ҵ���ֵ䲻����";
			logger.error(message);
			throw new AnalyseException(message);
		}
	}
	
}
