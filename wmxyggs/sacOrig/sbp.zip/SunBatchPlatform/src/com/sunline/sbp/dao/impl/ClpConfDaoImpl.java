package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.dao.ClpConfDao;
import com.sunline.sbp.dao.mapper.ClpConfMapper;
import com.sunline.sbp.model.ClpConf;

public class ClpConfDaoImpl implements ClpConfDao {
	
	private Logger logger = Logger.getLogger(ClpConfDaoImpl.class);
	
	ClpConfMapper clpConfMapper;

	@Override
	public ClpConf[] getEntitiesByOrder(int stacid , String clerod) throws AnalyseException {
		// TODO Auto-generated method stub
		ClpConf entity = new ClpConf();
		entity.setStacid(stacid);
		entity.setClerod(clerod);
		
		ClpConf[] copConfs = clpConfMapper.getEntites(entity);
		if(null == copConfs){
			String message = "ϵͳδ����˳��[]���������ͼ����Ϣ";
			logger.error(message);
			throw new AnalyseException(message);
		}
		
		return copConfs;
	}

	public ClpConfMapper getClpConfMapper() {
		return clpConfMapper;
	}

	public void setClpConfMapper(ClpConfMapper clpConfMapper) {
		this.clpConfMapper = clpConfMapper;
	}

	@Override
	public ClpConf[] getAllOrder(int stacid) {
		// TODO Auto-generated method stub
		ClpConf entity = new ClpConf();
		entity.setStacid(stacid);
		
		ClpConf[] copConfs = clpConfMapper.getEntites(entity);
		return copConfs;
	}
}
