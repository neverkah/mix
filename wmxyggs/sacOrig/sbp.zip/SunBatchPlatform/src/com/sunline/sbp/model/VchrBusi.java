package com.sunline.sbp.model;

public class VchrBusi {
	private int stacid;
	private String systid;
	private String trandt;
	private String vchrsq;
	private String transq;
	private String tranbr;
	private String acctbr;
	private String trantp;
	private String itemcd;
	private String acctno;
	private String smrycd;
	private String dscrtx;
	private String amntcd;
	private String crcycd;
	private double tranam;
	private String bkusid;
	private String ckbkus;
	private String manutg;
	private String imptdt;
	private String imptsq;
	private String bathid;
	
	public String getBathid() {
		return bathid;
	}
	public void setBathid(String bathid) {
		this.bathid = bathid;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getVchrsq() {
		return vchrsq;
	}
	public void setVchrsq(String vchrsq) {
		this.vchrsq = vchrsq;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public String getItemcd() {
		return itemcd;
	}
	public void setItemcd(String itemcd) {
		this.itemcd = itemcd;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getSmrycd() {
		return smrycd;
	}
	public void setSmrycd(String smrycd) {
		this.smrycd = smrycd;
	}
	public String getDscrtx() {
		return dscrtx;
	}
	public void setDscrtx(String dscrtx) {
		this.dscrtx = dscrtx;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public double getTranam() {
		return tranam;
	}
	public void setTranam(double tranam) {
		this.tranam = tranam;
	}
	public String getBkusid() {
		return bkusid;
	}
	public void setBkusid(String bkusid) {
		this.bkusid = bkusid;
	}
	public String getCkbkus() {
		return ckbkus;
	}
	public void setCkbkus(String ckbkus) {
		this.ckbkus = ckbkus;
	}
	public String getManutg() {
		return manutg;
	}
	public void setManutg(String manutg) {
		this.manutg = manutg;
	}
	public String getImptdt() {
		return imptdt;
	}
	public void setImptdt(String imptdt) {
		this.imptdt = imptdt;
	}
	public String getImptsq() {
		return imptsq;
	}
	public void setImptsq(String imptsq) {
		this.imptsq = imptsq;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	
	
}
