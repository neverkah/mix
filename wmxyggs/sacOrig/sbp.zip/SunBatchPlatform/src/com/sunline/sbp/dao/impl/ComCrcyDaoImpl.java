package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.dao.ComCrcyDao;
import com.sunline.sbp.model.ComCrcy;
import com.sunline.sbp.dao.mapper.ComCrcyMapper;

public class ComCrcyDaoImpl implements ComCrcyDao {
	
	private Logger logger = Logger.getLogger(ComCrcyDaoImpl.class);
	private ComCrcyMapper comCrcyMapper;

	@Override
	public ComCrcy getComCrcyByPrimKey(String crcycd)
			throws AnalyseException {
		// TODO Auto-generated method stub
		if(null == comCrcyMapper){
			logger.debug("comCrcyMapper δ��ʼ����");
			throw new AnalyseException("comCrcyMapper δ��ʼ����");
		}else{
			logger.debug("comCrcyMapper ��ʼ���ɹ���");
		}
		ComCrcy comCrcyEntity = comCrcyMapper.getComCrcyByPrimKey(crcycd);
		if(null == comCrcyEntity){
			logger.error("���ֱ�(com_crcy)�в����ڸñ���["+crcycd+"]");
			throw new AnalyseException("���ֱ�(com_crcy)�в����ڸñ���["+crcycd+"]");
		}else{
			logger.debug("��ȡ����["+crcycd+"]��Ϣ��ȡ�ɹ�");
		}
		return comCrcyEntity;
	}
	
	public ComCrcyMapper getComCrcyMapper() {
		return comCrcyMapper;
	}

	public void setComCrcyMapper(ComCrcyMapper comCrcyMapper) {
		this.comCrcyMapper = comCrcyMapper;
	}

}
