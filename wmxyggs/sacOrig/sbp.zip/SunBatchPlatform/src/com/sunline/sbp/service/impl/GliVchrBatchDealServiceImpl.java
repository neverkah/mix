package com.sunline.sbp.service.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.sunline.foundation.Constants;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.ServiceException;
import com.sunline.sbp.dao.impl.GlaVoucherDaoImpl;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.service.GliVchrBatchDealService;

/**
 * 
 * @author Zhangjin
 *
 */
public class GliVchrBatchDealServiceImpl implements GliVchrBatchDealService {
	
	private Logger logger = Logger.getLogger(GliVchrBatchDealServiceImpl.class);
	GlaVoucherDaoImpl glaVoucherDao;
	@Override
	public int vchrTransaction(List<List<GlaVoucher>> list , String trandt , String tranbr) throws ServiceException {
		// TODO Auto-generated method stub
		String message = Constants.EXECUTE_NULL;
		int count = 0;
		try {
			count = glaVoucherDao.insertEntitiesBatch(list, trandt, tranbr , list.get(0).get(0).getSourac());
			message = Constants.EXECUTE_SUCC;
		} catch (EngineRuntimeException e) {
			// TODO Auto-generated catch block
			message = e.getMessage();
			logger.error(e);
			throw new ServiceException(message,e);
		}catch(Exception e){
			message = e.getMessage();
			logger.error(message,e);
			throw new ServiceException("ϵͳ�쳣��" + message ,e);
		}
		
		return count;
	}
	public GlaVoucherDaoImpl getGlaVoucherDao() {
		return glaVoucherDao;
	}
	public void setGlaVoucherDao(GlaVoucherDaoImpl glaVoucherDao) {
		this.glaVoucherDao = glaVoucherDao;
	}
}
