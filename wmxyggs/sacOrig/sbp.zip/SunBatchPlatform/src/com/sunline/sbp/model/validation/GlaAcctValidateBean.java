package com.sunline.sbp.model.validation;

import org.apache.log4j.Logger;

import com.sunline.sbp.model.GlaAcct;

public class GlaAcctValidateBean {
	
	private static Logger logger = Logger.getLogger(GlaAcctValidateBean.class);
	
	public static boolean validate(GlaAcct acctEntity){
		
		logger.debug("�˻���Ϣ�Ϸ���У��...");
		
		logger.debug("acctcl:"+acctEntity.getAcctcl());
		logger.debug("Acctna:"+acctEntity.getAcctna());
		logger.debug("Acctcd:"+acctEntity.getAcctcd());
		logger.debug("Acctst:"+acctEntity.getAcctst());
		logger.debug("Blncdn:"+acctEntity.getBlncdn());
		logger.debug("Brchno:"+acctEntity.getBrchno());
		logger.debug("Closdt:"+acctEntity.getClosdt());
		logger.debug("Closus:"+acctEntity.getClosus());
		logger.debug("Cltrsq:"+acctEntity.getCltrsq());
		logger.debug("Crcycd:"+acctEntity.getCrcycd());
		logger.debug("Crhdbk:"+acctEntity.getCrhdbk());
		logger.debug("Drhdbk:"+acctEntity.getDrhdbk());
		logger.debug("Ioflag:"+acctEntity.getIoflag());
		logger.debug("Itemcd:"+acctEntity.getItemcd());
		logger.debug("Lastbl:"+acctEntity.getLastbl());
		logger.debug("Lastdn:"+acctEntity.getLastdn());
		logger.debug("Lastdt:"+acctEntity.getLastdt());
		logger.debug("Lstrdt:"+acctEntity.getLstrdt());
		logger.debug("Lstrsq:"+acctEntity.getLstrsq());
		logger.debug("Onlnbl:"+acctEntity.getOnlnbl());
		logger.debug("Openbr:"+acctEntity.getOpenbr());
		logger.debug("Opendt:"+acctEntity.getOpendt());
		logger.debug("Openus:"+acctEntity.getOpenus());
		logger.debug("Optrsq:"+acctEntity.getOptrsq());
		logger.debug("Pmodtg:"+acctEntity.getPmodtg());
		logger.debug("Subscd:"+acctEntity.getSubscd());
		logger.debug("Systid:"+acctEntity.getSystid());
		//�����˻���ά��Ϣ
		logger.debug("Centcd:"+acctEntity.getCentcd());
		logger.debug("Prsncd:"+acctEntity.getPrsncd());
		logger.debug("Custcd:"+acctEntity.getCustcd());
		logger.debug("Prducd:"+acctEntity.getPrducd());
		logger.debug("Prlncd:"+acctEntity.getPrlncd());
		logger.debug("Acctno:"+acctEntity.getAcctno());
		logger.debug("Assis0:"+acctEntity.getAssis0());
		logger.debug("Assis1:"+acctEntity.getAssis1());
		logger.debug("Assis2:"+acctEntity.getAssis2());
		logger.debug("Assis3:"+acctEntity.getAssis3());
		logger.debug("Assis4:"+acctEntity.getAssis4());
		logger.debug("Assis5:"+acctEntity.getAssis5());
		logger.debug("Assis6:"+acctEntity.getAssis6());
		logger.debug("Assis7:"+acctEntity.getAssis7());
		logger.debug("Assis8:"+acctEntity.getAssis8());
		logger.debug("Assis9:"+acctEntity.getAssis9());
		
		return true;
	}
}
