package com.sunline.sbp.model;

public class ComCent {
	private int stacid;
	private String brchcd;
	private String brchna;
	private String sprrcd;
	private int brchlv;
	private String detltg;
	private String usedtp;
	private String brchtp;
	private String typetg;
	private String lwmntg;
	private String cityno;
	private String brchsq;
	private String remark;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getBrchcd() {
		return brchcd;
	}
	public void setBrchcd(String brchcd) {
		this.brchcd = brchcd;
	}
	public String getBrchna() {
		return brchna;
	}
	public void setBrchna(String brchna) {
		this.brchna = brchna;
	}
	public String getSprrcd() {
		return sprrcd;
	}
	public void setSprrcd(String sprrcd) {
		this.sprrcd = sprrcd;
	}
	public int getBrchlv() {
		return brchlv;
	}
	public void setBrchlv(int brchlv) {
		this.brchlv = brchlv;
	}
	public String getDetltg() {
		return detltg;
	}
	public void setDetltg(String detltg) {
		this.detltg = detltg;
	}
	public String getUsedtp() {
		return usedtp;
	}
	public void setUsedtp(String usedtp) {
		this.usedtp = usedtp;
	}
	public String getBrchtp() {
		return brchtp;
	}
	public void setBrchtp(String brchtp) {
		this.brchtp = brchtp;
	}
	public String getTypetg() {
		return typetg;
	}
	public void setTypetg(String typetg) {
		this.typetg = typetg;
	}
	public String getLwmntg() {
		return lwmntg;
	}
	public void setLwmntg(String lwmntg) {
		this.lwmntg = lwmntg;
	}
	public String getCityno() {
		return cityno;
	}
	public void setCityno(String cityno) {
		this.cityno = cityno;
	}
	public String getBrchsq() {
		return brchsq;
	}
	public void setBrchsq(String brchsq) {
		this.brchsq = brchsq;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
}
