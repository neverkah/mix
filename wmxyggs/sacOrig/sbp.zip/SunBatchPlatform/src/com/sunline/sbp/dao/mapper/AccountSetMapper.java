package com.sunline.sbp.dao.mapper;

import java.util.List;

import com.sunline.sbp.model.AccountSet;

public interface AccountSetMapper {
	public AccountSet selectEntity(AccountSet stac);
	public List<AccountSet> selectEntityLinks(AccountSet stac);
	public AccountSet[] selectEntities();
	
}
