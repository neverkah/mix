package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * �ӿڶ���(sys_intf)
 * @author Zhangjin
 *
 */

public class SysIntf implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7271229179856442536L;
	String intfcd;
	String intftp;
	String intfnm;
	String enname;
	String desctx;
	String vermod;
	String module;
	String projcd;
	public String getIntfcd() {
		return intfcd;
	}
	public void setIntfcd(String intfcd) {
		this.intfcd = intfcd;
	}
	public String getIntftp() {
		return intftp;
	}
	public void setIntftp(String intftp) {
		this.intftp = intftp;
	}
	public String getIntfnm() {
		return intfnm;
	}
	public void setIntfnm(String intfnm) {
		this.intfnm = intfnm;
	}
	public String getEnname() {
		return enname;
	}
	public void setEnname(String enname) {
		this.enname = enname;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
	
}
