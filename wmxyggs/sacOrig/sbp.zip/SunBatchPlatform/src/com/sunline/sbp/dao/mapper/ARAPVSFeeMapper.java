package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.ArapVSAfeTran;

public interface ARAPVSFeeMapper {
	public void insertEntity();
	public void postingUpdate(ArapVSAfeTran entity);
	public ArapVSAfeTran selectEntity(@Param("trandt") String tradt , @Param("transq") String transq , @Param("cmmdsq") String cmmdsq , @Param("systid") String systid);
}
