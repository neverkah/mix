package com.sunline.sbp.service.impl;

import com.sunline.sbp.dao.impl.AsbBusiDaoImpl;
import com.sunline.sbp.model.AsbBusi;
import com.sunline.sbp.service.AsbBusiService;

/**
 * 
 * @author Zhangjin
 *
 */
public class AsbBusiServiceImpl implements AsbBusiService {
	
	private AsbBusiDaoImpl asbBusiDao;

	@Override
	public AsbBusi[] selectAsbBusi(AsbBusi entity) {
		// TODO Auto-generated method stub
		return asbBusiDao.selectBusi(entity);
	}

	public AsbBusiDaoImpl getAsbBusiDao() {
		return asbBusiDao;
	}

	public void setAsbBusiDao(AsbBusiDaoImpl asbBusiDao) {
		this.asbBusiDao = asbBusiDao;
	}
	
	
}
