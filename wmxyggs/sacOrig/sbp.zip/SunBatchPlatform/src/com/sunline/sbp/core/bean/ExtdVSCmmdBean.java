package com.sunline.sbp.core.bean;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSONObject;
import com.sunline.sbp.model.GlsExtd;

public class ExtdVSCmmdBean {
	private ArrayList<GlsExtd> extds;
	private List<JSONObject> cmmds;
	public ArrayList<GlsExtd> getExtds() {
		return extds;
	}
	public void setExtds(ArrayList<GlsExtd> extds) {
		this.extds = extds;
	}
	public List<JSONObject> getCmmds() {
		return cmmds;
	}
	public void setCmmds(List<JSONObject> cmmds) {
		this.cmmds = cmmds;
	}
	
	
}
