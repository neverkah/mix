package com.sunline.sbp.dao.impl;

import java.util.List;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.base.CommandFactory;
import com.sunline.sbp.commanddeal.TranCommandObject;
import com.sunline.sbp.core.bean.DtitInfoBean;
import com.sunline.sbp.core.bean.ExtdVSCmmdBean;
import com.sunline.sbp.core.bean.GlaVchrHelper;
import com.sunline.sbp.dao.AccountingTreatmentDao;
import com.sunline.sbp.dao.mapper.GlsExtdMapper;
import com.sunline.sbp.model.AccountingCode;
import com.sunline.sbp.model.AccountingItem;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.SysLndt;
import com.sunline.sunbp.util.CloneObjectUtil;

public class AccountingTreatmentDaoImpl implements
		AccountingTreatmentDao {
	
	private Logger logger = Logger.getLogger(AccountingTreatmentDaoImpl.class);

	private GlsExtdMapper glsExtdMapper;

	private SequenceFactoryDaoImpl sequenceFactoryDao;
	private AccountBalanceDaoImpl accountBalanceDao;
	private AccountingItemDaoImpl accountingItemDao;
	private SysLndtDaoImpl sysLndtDao;
	private AccountingCodeDaoImpl accountingCodeDao;

	private GlaVoucherDaoImpl glaVoucherDao;
	private ComExsrDaoImpl ComExsrDao;
	private ComItexDaoImpl ComItexDao;
	private ComBulnDaoImpl ComBulnDao;
	private ComCustDaoImpl comCustDao;
	private ComAcctDaoImpl comAcctDao;
	private ComPrsnDaoImpl comPrsnDao;
	private ComCentDaoImpl comCentDao;
	private SysProductDaoImpl sysProductDao;

	public void processTransaction(TranCommandObject tCommandObject,List<GlaVoucher> vchrList , GlsExtd dEntity,GlaVoucher vchr) throws EngineRuntimeException {

		// ��ȡ���˻���
		vchr.setAcctbr(getAcctbr(vchr));

		setCentCode(vchr);

		setPrsncCode(vchr);

		setCustCode(vchr);

		setPrduCode(vchr);

		setPrlnCode(vchr);

		setAcctno(vchr);
		
		/* ��ȡ�����Ŀ
		* 1��һ������£�ָ�����һ����¼��Ӧһ����¼
		* 2������ָ���Ҫ����Ϊһ�Է�¼���Ҵ˷�¼�ǹ̶��ģ�����ֻ����������һ��һ����
		* 3��ͨ��������������������Ŀ����˵����Ҫ����Ϊһ�Է�¼��
		*/
		DtitInfoBean[] dtitInfo = getItemCodeByDtitcd(tCommandObject,vchr);
		if(dtitInfo.length > 1){
			for(int i=1; i<dtitInfo.length; i++){
				
				logger.debug("���в��䴫Ʊ��Ŀ����");
				GlaVoucher vchr1 = CloneObjectUtil.clone(vchr);
				vchr1.setItemcd(dtitInfo[i].getItemcd());
				if(dtitInfo[i].getAmntcd().equals("00")){
					vchr1.setAmntcd(vchr.getAmntcd());
				}else{
					vchr1.setAmntcd(dtitInfo[i].getAmntcd());
				}
				
				vchr1.setIoflag(dtitInfo[i].getIoflag());
				
				if(dEntity.getCmmdtg().equals("CL")){
					vchr1.setSubsac(dEntity.getSubsac());
				}
				
				insertToTable(vchrList,vchr1);
				
			}
			vchr.setItemcd(dtitInfo[0].getItemcd());
			vchr.setIoflag(dtitInfo[0].getIoflag());
			if(!dtitInfo[0].getAmntcd().equals(vchr.getAmntcd())){
				if(!dtitInfo[0].getAmntcd().equals("00")){
					vchr.setAmntcd(dtitInfo[0].getAmntcd());
				}
			}
		}else if(dtitInfo.length == 1){
			logger.debug("���д�Ʊ��Ŀ����");
			vchr.setItemcd(dtitInfo[0].getItemcd());
			if(!dtitInfo[0].getAmntcd().equals("00")){
				vchr.setAmntcd(dtitInfo[0].getAmntcd());
			}
			vchr.setIoflag(dtitInfo[0].getIoflag());
		}

		if(dEntity.getCmmdtg().equals("CL")){
			vchr.setSubsac(dEntity.getSubsac());
		}
		
		// ����ƾ֤��¼
		insertToTable(vchrList,vchr);
		
	}
	
	private void insertToTable(List<GlaVoucher> vchrList , GlaVoucher vchr) throws AnalyseException{
		//printVchrInfo(vchr);
		//��Ʊ�Ϸ���У��
		GlaVchrHelper.checkValidate(vchr, null, 
				ComItexDao.getCacheData(),ComExsrDao.getCacheData(),
				ComBulnDao.getCacheData(),comCustDao.getCacheData(),
				comAcctDao.getCacheData(),comPrsnDao.getCacheData(),
				comCentDao.getCacheData(),sysProductDao.getCacheData());
		
		if(GlaVchrHelper.isValide(vchr)){
			vchrList.add(vchr);
		}
		
	}
	
	private void printVchrInfo(GlaVoucher vchr){
		logger.debug("��Ʊ��Ϣ��");
		logger.debug("vchr.stacid=" + vchr.getStacid());
		logger.debug("vchr.systid=" + vchr.getSystid());
		logger.debug("vchr.trandt=" + vchr.getTrandt());
		logger.debug("vchr.transq=" + vchr.getTransq());
		logger.debug("vchr.vchrsq=" + vchr.getVchrsq());
		logger.debug("vchr.tranbr=" + vchr.getTranbr());
		logger.debug("vchr.acctbr=" + vchr.getAcctbr());
		logger.debug("vchr.itemcd=" + vchr.getItemcd());
		logger.debug("vchr.crcycd=" + vchr.getCrcycd());
		logger.debug("vchr.ioflag=" + vchr.getIoflag());
		logger.debug("vchr.centcd=" + vchr.getCentcd());
		logger.debug("vchr.prsncd=" + vchr.getPrsncd());
		logger.debug("vchr.custcd=" + vchr.getCustcd());
		logger.debug("vchr.prducd=" + vchr.getPrducd());
		logger.debug("vchr.prlncd=" + vchr.getPrlncd());
		logger.debug("vchr.acctno=" + vchr.getAcctno());
		logger.debug("vchr.trantp=" + vchr.getTrantp());
		logger.debug("vchr.amntcd=" + vchr.getAmntcd());
		logger.debug("vchr.tranam=" + vchr.getTranam());
		logger.debug("vchr.tranbl=" + vchr.getTranbl());
		logger.debug("vchr.blncdn=" + vchr.getBlncdn());
		logger.debug("vchr.smrytx=" + vchr.getSmrytx());
		logger.debug("vchr.exchcn=" + vchr.getExchcn());
		logger.debug("vchr.EXCHUS=" + vchr.getExchus());
		logger.debug("vchr.usercd=" + vchr.getUsercd());
		logger.debug("vchr.sourdt=" + vchr.getSourdt());
		logger.debug("vchr.soursq=" + vchr.getSoursq());
		logger.debug("vchr.sourst=" + vchr.getSourst());
		logger.debug("vchr.SRVCSQ=" + vchr.getSrvcsq());
		logger.debug("vchr.bearbl=" + vchr.getBearbl());
		logger.debug("vchr.beardn=" + vchr.getBeardn());
		logger.debug("vchr.toitem=" + vchr.getToitem());
		logger.debug("vchr.tranno=" + vchr.getTranno());
	}

	public List<GlaVoucher> processVectorTransaction(List<GlsExtd> entities) throws EngineRuntimeException {

		//��ָ����ܵǼǲ��л�ȡ���ʻ���ҵ����Ϣ
		/*GlsExtd qentity = new GlsExtd();
		
		qentity.setTrandt(pEntity.getTrandt());
		qentity.setTransq(pEntity.getTransq());
		qentity.setSystid(pEntity.getSystid());
		
		GlsExtd[] entities = glsExtdMapper.selectEntities(pEntity);*/
		
		List<GlaVoucher> vchrList = new Vector<GlaVoucher>();
		TranCommandObject tCommandObject = null;
		GlaVoucher vchr = null;

		if (null != entities && entities.size() >= 1) {
			// ���ɽ�����ˮ2014-11-16
			/*String transq = sequenceFactoryDao.generateSequence(1, "transq",
					entities.get(0).getTranbr(), entities.get(0).getTrandt(), 1);*/
			String transq = "x";
			
			String cmmdtg = "";
			int count = 0;
			//��ʼ������ modify by zhanghong@sunline.cn
			//SysLndt lndt = new SysLndt();
			
			for (GlsExtd dEntity : entities) {
				//lndt.setStacid(dEntity.getStacid());
				count = 0;
				logger.debug("extd.subsac="+dEntity.getSubsac()+",cmmdsq="+dEntity.getCmmdsq()+"cmmdtg="+dEntity.getCmmdtg());
				if(dEntity.getCmmdtg().equals("CS")){
					cmmdtg = dEntity.getCmmdtg() + dEntity.getSubcmd();
				}else{
					cmmdtg = dEntity.getCmmdtg();
				}
				
				tCommandObject = CommandFactory.getBean(cmmdtg);
				tCommandObject.initialize(dEntity.getTrandt(), dEntity.getTransq(),dEntity.getCmmdsq(),dEntity.getSystid());
				
				if(count == 0){
					tCommandObject.setVoucherInfo();
					vchr = tCommandObject.getGlaVoucher();
					vchr.setTransq(transq);
					processTransaction(tCommandObject,vchrList,dEntity,vchr);
					
					//�ӽ�����Ϊ�ѹ���
					//modify by zhanghong@sunline.cn ����Ҫ����ָ��״̬���������
					//tCommandObject.postingSucc();
				}
				
			}
			
			// check balance
			GlaVchrHelper.checkBalanceOfGlaVchrs(vchrList);
			
			GlaVchrHelper.setClertgOfGlaVchrs(vchrList);
			
		} else {
			throw new EngineRuntimeException("ϵͳ����δ���ɽ�����ϸ");
		}
		
		return vchrList;
	}
	
	/**
	 * ָ���صķ�ʽ���ɴ�Ʊ��������ܣ�
	 * @param ecEntities
	 * @return
	 * @throws EngineRuntimeException
	 */
	public List<GlaVoucher> processCmmdVectorTransaction(ExtdVSCmmdBean ecEntities)  throws EngineRuntimeException {
		
		List<GlaVoucher> vchrList = new Vector<GlaVoucher>();
		TranCommandObject tCommandObject = null;
		GlaVoucher vchr = null;
		
		List<GlsExtd> entities = ecEntities.getExtds();
		List<JSONObject> cmmds = ecEntities.getCmmds();
		int i = 0;

		if (null != entities && entities.size() >= 1) {
			// ���ɽ�����ˮ2014-11-16
			/*String transq = sequenceFactoryDao.generateSequence(1, "transq",
					entities.get(0).getTranbr(), entities.get(0).getTrandt(), 1);*/
			String transq = "x";
			
			String cmmdtg = "";
			int count = 0;
			//��ʼ������ modify by zhanghong@sunline.cn
			//SysLndt lndt = new SysLndt();
			
			for (GlsExtd dEntity : entities) {
				//lndt.setStacid(dEntity.getStacid());
				count = 0;
				logger.debug("extd.subsac="+dEntity.getSubsac()+",cmmdsq="+dEntity.getCmmdsq()+"cmmdtg="+dEntity.getCmmdtg());
				if(dEntity.getCmmdtg().equals("CS")){
					cmmdtg = dEntity.getCmmdtg() + dEntity.getSubcmd();
				}else{
					cmmdtg = dEntity.getCmmdtg();
				}
				
				tCommandObject = CommandFactory.getBean(cmmdtg);
				//ֱ��ʹ��JSONObject����ָ��
				tCommandObject.initialize(cmmds.get(i++));
				
				if(count == 0){
					tCommandObject.setVoucherInfo();
					vchr = tCommandObject.getGlaVoucher();
					vchr.setTransq(transq);
					processTransaction(tCommandObject,vchrList,dEntity,vchr);
					
					//�ӽ�����Ϊ�ѹ���
					//modify by zhanghong@sunline.cn ����Ҫ����ָ��״̬���������
					//tCommandObject.postingSucc();
				}
				
			}
			
			// check balance
			GlaVchrHelper.checkBalanceOfGlaVchrs(vchrList);
			
			GlaVchrHelper.setClertgOfGlaVchrs(vchrList);

			
		} else {
			throw new EngineRuntimeException("ϵͳ����δ���ɽ�����ϸ");
		}
		
		return vchrList;
	}

	/**
	 * ���ݺ�������ȡ��Ŀ����
	 * 
	 * @return
	 * @throws EngineRuntimeException 
	 */
	private DtitInfoBean[] getItemCodeByDtitcd(TranCommandObject tCommandObject,GlaVoucher vchr) throws EngineRuntimeException {
		AccountingCode acct = new AccountingCode();
		
		SysLndt lndt = new SysLndt();
		lndt.setStacid(tCommandObject.getStacid());
		lndt.setDtitcd(tCommandObject.getDtitcd());
		if(tCommandObject.getTrancd() != null){
			lndt.setTrancd(tCommandObject.getTrancd());
		}else{
			lndt.setTrancd(".");
		}
		lndt.setLntype(tCommandObject.getTrprcd());
		SysLndt[] lndts = sysLndtDao.getDtitInfoOfLntype(lndt);
		
		if((null == lndts || lndts.length == 0)){
			logger.debug("��չ������Ϣ...����dtitcd:" + tCommandObject.getTrancd()+",����lntype:" + tCommandObject.getTrprcd());
			lndt.setDtitcd(".");
			if(tCommandObject.getTrancd() != null){
				lndt.setTrancd(tCommandObject.getTrancd());
			}else{
				lndt.setTrancd(".");
			}
			lndt.setLntype(tCommandObject.getTrprcd());
			lndts = sysLndtDao.getDtitInfoOfLntype(lndt);
		}
		
		DtitInfoBean[] dtitInfo = null;
			
			int idx = 0;
			DtitInfoBean dtitEntity = null;
			
			if( null != lndts && lndts.length > 0){
				
				logger.debug("�����������չ...");
				
				dtitInfo = new DtitInfoBean[lndts.length];
				
				for(SysLndt entity:lndts){
					
					dtitEntity = new DtitInfoBean();
					
					acct.setStacid(entity.getStacid());
					acct.setTypecd(tCommandObject.getDtitcd());
					acct.setTrprcd(entity.getDttype());
					AccountingCode acctInfo = accountingCodeDao.getItemCode(entity.getStacid(), tCommandObject.getDtitcd(), entity.getDttype());
					
					AccountingItem aentity = accountingItemDao.getEntityByPrimaryKey(acctInfo.getStacid(), acctInfo.getItemcd()) ;
                    
					dtitEntity.setItemcd(aentity.getItemcd());
					dtitEntity.setIoflag(aentity.getIoflag());
					dtitEntity.setAmntcd(entity.getAmntcd());
					dtitInfo[idx++] = dtitEntity;
				}
			}else{
				acct.setStacid(tCommandObject.getStacid());
				acct.setTypecd(tCommandObject.getDtitcd());
				acct.setTrprcd(tCommandObject.getTrprcd());
				logger.debug("�������["+tCommandObject.getDtitcd()+"]����["+tCommandObject.getTrprcd()+"]��ȡ��Ŀ...");
				AccountingCode accts = accountingCodeDao.getItemCode(tCommandObject.getStacid(), tCommandObject.getDtitcd(),tCommandObject.getTrprcd());
				logger.debug("ֱ�ӽ���������...");
				dtitInfo = new DtitInfoBean[1];

				dtitEntity = new DtitInfoBean();
				dtitEntity.setItemcd(accts.getItemcd());
				dtitEntity.setAmntcd(vchr.getAmntcd());
				logger.debug("��Ŀ���óɹ�");
				AccountingItem aentity = accountingItemDao.getEntityByPrimaryKey(accts.getStacid(), accts.getItemcd()) ;
				if(null != aentity){
					dtitEntity.setIoflag(aentity.getIoflag());
				}else{
					throw new EngineRuntimeException("��Ŀ["+accts.getItemcd()+"]������["+accts.getStacid()+"]�в�����");
				}
				dtitInfo[0] = dtitEntity;
			}
			
			logger.debug("������Ϣ��ȡ�ɹ�");
			return dtitInfo;

	}

	private void setCentCode(GlaVoucher vchr) {
		vchr.setCentcd(null == vchr.getCentcd() ? Constants.DEFAULT_VALUE_START
				: vchr.getCentcd());
		logger.debug("��������ֵΪ��" + vchr.getCentcd());
	}

	private void setPrsncCode(GlaVoucher vchr) {
		vchr.setPrsncd(null == vchr.getPrsncd() ? Constants.DEFAULT_VALUE_START
				: vchr.getPrsncd());
		logger.debug("�ͻ�����Ϊ��" + vchr.getPrsncd());
	}

	private void setCustCode(GlaVoucher vchr) {
		vchr.setCustcd(null == vchr.getCustcd() ? Constants.DEFAULT_VALUE_START
				: vchr.getCustcd());
		logger.debug("�ͻ�Ϊ��" + vchr.getCustcd());
	}

	private void setPrduCode(GlaVoucher vchr) {
		vchr.setPrducd(null == vchr.getPrducd() ? Constants.DEFAULT_VALUE_START
				: vchr.getPrducd());
		logger.debug("ά����Ϣ��ƷΪ��" + vchr.getPrducd());
	}

	private void setPrlnCode(GlaVoucher vchr) {
		vchr.setPrlncd(null == vchr.getPrlncd() ? Constants.DEFAULT_VALUE_START
				: vchr.getPrlncd());
		logger.debug("ά�Ȳ�Ʒ��Ϊ��" + vchr.getPrlncd());
	}

	private String getAcctbr(GlaVoucher vchr) {
		return vchr.getAcctbr();
	}

	private void setAcctno(GlaVoucher vchr) {
		vchr.setAcctno(null == vchr.getAcctno() ? Constants.DEFAULT_VALUE_START
				: vchr.getAcctno());
		logger.debug("ά���˻�Ϊ��" + vchr.getAcctno());
	}

	public GlsExtdMapper getGlsExtdMapper() {
		return glsExtdMapper;
	}

	public void setGlsExtdMapper(GlsExtdMapper glsExtdMapper) {
		this.glsExtdMapper = glsExtdMapper;
	}

	public SequenceFactoryDaoImpl getSequenceFactoryDao() {
		return sequenceFactoryDao;
	}

	public void setSequenceFactoryDao(SequenceFactoryDaoImpl sequenceFactoryDao) {
		this.sequenceFactoryDao = sequenceFactoryDao;
	}

	public AccountBalanceDaoImpl getAccountBalanceDao() {
		return accountBalanceDao;
	}

	public void setAccountBalanceDao(AccountBalanceDaoImpl accountBalanceDao) {
		this.accountBalanceDao = accountBalanceDao;
	}
	
	public GlaVoucherDaoImpl getGlaVoucherDao() {
		return glaVoucherDao;
	}

	public void setGlaVoucherDao(GlaVoucherDaoImpl glaVoucherDao) {
		this.glaVoucherDao = glaVoucherDao;
	}
	
	public AccountingItemDaoImpl getAccountingItemDao() {
		return accountingItemDao;
	}

	public void setAccountingItemDao(AccountingItemDaoImpl accountingItemDao) {
		this.accountingItemDao = accountingItemDao;
	}


	public SysLndtDaoImpl getSysLndtDao() {
		return sysLndtDao;
	}

	public void setSysLndtDao(SysLndtDaoImpl sysLndtDao) {
		this.sysLndtDao = sysLndtDao;
	}

	public AccountingCodeDaoImpl getAccountingCodeDao() {
		return accountingCodeDao;
	}

	public void setAccountingCodeDao(AccountingCodeDaoImpl accountingCodeDao) {
		this.accountingCodeDao = accountingCodeDao;
	}

	public ComExsrDaoImpl getComExsrDao() {
		return ComExsrDao;
	}

	public void setComExsrDao(ComExsrDaoImpl comExsrDao) {
		ComExsrDao = comExsrDao;
	}

	public ComItexDaoImpl getComItexDao() {
		return ComItexDao;
	}

	public void setComItexDao(ComItexDaoImpl comItexDao) {
		ComItexDao = comItexDao;
	}

	public ComBulnDaoImpl getComBulnDao() {
		return ComBulnDao;
	}

	public void setComBulnDao(ComBulnDaoImpl comBulnDao) {
		ComBulnDao = comBulnDao;
	}

	public ComCustDaoImpl getComCustDao() {
		return comCustDao;
	}

	public void setComCustDao(ComCustDaoImpl comCustDao) {
		this.comCustDao = comCustDao;
	}

	public ComAcctDaoImpl getComAcctDao() {
		return comAcctDao;
	}

	public void setComAcctDao(ComAcctDaoImpl comAcctDao) {
		this.comAcctDao = comAcctDao;
	}

	public ComPrsnDaoImpl getComPrsnDao() {
		return comPrsnDao;
	}

	public void setComPrsnDao(ComPrsnDaoImpl comPrsnDao) {
		this.comPrsnDao = comPrsnDao;
	}

	public ComCentDaoImpl getComCentDao() {
		return comCentDao;
	}

	public void setComCentDao(ComCentDaoImpl comCentDao) {
		this.comCentDao = comCentDao;
	}

	public SysProductDaoImpl getSysProductDao() {
		return sysProductDao;
	}

	public void setSysProductDao(SysProductDaoImpl sysProductDao) {
		this.sysProductDao = sysProductDao;
	}
}
