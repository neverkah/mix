package com.sunline.sbp.dao.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.model.GlbCler;

public interface GlaVoucherMapper {
	public void insertEntity(GlaVoucher vchr);
	
	public int insertEntitiesBatch(List<GlaVoucher> list);

	public int getNextSequence(GlaVoucher vchr);

	/**
	 * ���´�Ʊ����״̬clertgΪ������ 1
	 * @param stacid
	 * @param trandt
	 */
	public void updateClertgWait(@Param("stacid") int stacid,
			@Param("trandt") String trandt);
	/**
	 * ͳ������������մ�����ı��ڽ����������
	 * 
	 * @param stacid
	 * @param trandt
	 * @param clerBrch_headbank_Array  �����������Ļ�������
	 * @return
	 */
	public List<GlbCler> selectSumTranamByBrch(@Param("stacid") int stacid,
			@Param("trandt") String trandt , @Param("clerBrch_headbank") String[] clerBrch_headbank_Array);

	public void updateClearInfo(@Param("stacid") int stacid,
			@Param("trandt") String trandt, @Param("clerod") String clerod,
			@Param("clerdt") String clerdt);

	/**
	 * ��ʶ��Ʊ���˳ɹ�
	 * 
	 * @param entity
	 * @return
	 */
	public int updateToSucc(GlaVoucher entity);
	
	public int updateToSuccBatch(@Param("list") List<GlaVoucher> entity ,@Param("sqlist") List<String> transqList , @Param("stacid") int stacid , @Param("trandt") String trandt,@Param("systid") String systid,@Param("acctbr") String acctbr,@Param("pit") String pit);

	/**
	 * ��ʶ��Ʊ����ʧ��
	 * 
	 * @param entity
	 * @return
	 */
	public int updateToError(GlaVoucher entity);
	
	public List<Map<String,String>> getTranbrOfVchr(@Param("stacid") int stacid, @Param("trandt") String trandt);
	
	/**
	 * ��ȡ����ǰ10000����ˮ�Ĵ�Ʊ��ˮ��Ϣ
	 * @param stacid
	 * @param trandt
	 * @param acctbr
	 * @return
	 */
	public List<String> getHeadTranOfVchrs(@Param("stacid") int stacid,
			@Param("trandt") String trandt,@Param("acctbr") String acctbr);
	
	/**
	 * ������ˮ�Ż�ȡ��Ʊ��Ϣ
	 * @param stacid
	 * @param trandt
	 * @param acctbr
	 * @return
	 */
	public GlaVoucher[] getVchrsByTransq(@Param("stacid") int stacid,
			@Param("trandt") String trandt,@Param("acctbr") String acctbr, @Param("pit") String pit);
	
	
	/**
	 * ���¿�ĿΪ��ʹ��
	 * GliVoucherMapper.java
	 * TODO
	 * FZF
	 * ����3:37:47
	 * int
	 */
	public int updateItemToUsed(GlaVoucher entity);

	/**
	 * ���»���Ϊ��ʹ��
	 * GliVoucherMapper.java
	 * TODO
	 * FZF
	 * ����3:37:47
	 * int
	 */
	public int updateBrchToUsed(GlaVoucher entity);
	
	public int countVchrsBySour(GlaVoucher entity);
	
	public List<GlaVoucher> getVchrsBySour(@Param("stacid") int stacid , @Param("sourst") String bsnssy , @Param("sourdt") String bsnsdt , @Param("soursq") String bsnssq);
}
