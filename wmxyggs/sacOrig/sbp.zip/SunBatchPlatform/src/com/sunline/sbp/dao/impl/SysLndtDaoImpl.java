package com.sunline.sbp.dao.impl;

import java.util.Hashtable;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.core.bean.CacheTargetBean;
import com.sunline.sbp.dao.SysLndtDao;
import com.sunline.sbp.dao.mapper.SysLndtMapper;
import com.sunline.sbp.model.SysLndt;

public class SysLndtDaoImpl implements SysLndtDao {
	
	SysLndtMapper sysLndtMapper;
	private Logger logger = Logger.getLogger(SysLndtDaoImpl.class);
	
	private static Hashtable<String,SysLndt[]> sysLndtCache = new Hashtable<String,SysLndt[]>();

	@Override
	public SysLndt[] getDtitInfoOfLntype(SysLndt lndt) throws AnalyseException {
		// TODO Auto-generated method stub
		if(lndt.getStacid() == 0 || null == lndt.getDtitcd() || null == lndt.getTrancd()
				|| null == lndt.getLntype()){
			String message = "������ͺ���ֽ�����ݲ�ѯ����������:"+
					"stacid:"+lndt.getStacid()+",dtitcd:" + lndt.getDtitcd()+",trancd:" + lndt.getTrancd()+",lntype:" + lndt.getLntype();
			logger.error(message);
			throw new AnalyseException(message);
		}
		
		String key = String.valueOf(lndt.getStacid()).concat("-").concat(lndt.getDtitcd()).concat("-").concat(lndt.getTrancd()).concat("-").concat(lndt.getLntype());
		
		int isFresh = CacheTargetBean.getCacheTarget("lndtCache");
		
		if(isFresh == 1){
			synchronized(this){
				if(CacheTargetBean.getCacheTarget("lndtCache") == 1){
					sysLndtCache.clear();
					CacheTargetBean.updateCacheTarget("lndtCache");
				}
			}
		}
		
		if(sysLndtCache.containsKey(key)){
			return sysLndtCache.get(key);
		}else{
			SysLndt[] lndts = sysLndtMapper.getEntities(lndt);
			sysLndtCache.put(key, lndts);
			return lndts;
		}
	}
	
	public int countDtitInfoOfLntype(SysLndt lndt) throws AnalyseException {
		// TODO Auto-generated method stub
		if(lndt.getStacid() == 0 || null == lndt.getTrancd()
				|| null == lndt.getLntype()){
			String message = "������ͺ���ֽ�����ݲ�ѯ����������:"+
					"stacid:"+lndt.getStacid()+",trancd:" + lndt.getTrancd()+",lntype:" + lndt.getLntype();
			logger.error(message);
			throw new AnalyseException(message);
		}
		int count = sysLndtMapper.countEntities(lndt);
		return count;
	}

	public SysLndtMapper getSysLndtMapper() {
		return sysLndtMapper;
	}

	public void setSysLndtMapper(SysLndtMapper sysLndtMapper) {
		this.sysLndtMapper = sysLndtMapper;
	}
}
