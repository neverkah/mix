package com.sunline.sbp.dao;

import java.util.ArrayList;

import com.sunline.foundation.EngineRuntimeException;

public interface SequenceFactoryDao {
	public ArrayList<String> generateSequence(int Stacid, String Sqnocd, String Brchcd,
			String Sqnodt, int Sqnonm) throws EngineRuntimeException;
}
