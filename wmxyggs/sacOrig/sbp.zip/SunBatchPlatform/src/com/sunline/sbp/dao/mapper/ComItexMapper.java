package com.sunline.sbp.dao.mapper;

import java.util.List;

import com.sunline.sbp.model.ComItex;

public interface ComItexMapper {
	public List<ComItex> getAllEntites();
}
