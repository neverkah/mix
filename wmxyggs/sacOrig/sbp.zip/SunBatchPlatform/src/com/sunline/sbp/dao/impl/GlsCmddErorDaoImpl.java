package com.sunline.sbp.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.dao.GlsCmddErorDao;
import com.sunline.sbp.dao.mapper.GlsCmddErorMapper;
import com.sunline.sbp.model.GlsCmddEror;


public class GlsCmddErorDaoImpl implements GlsCmddErorDao {
	
	private Logger logger = Logger.getLogger(GlsCmddErorDaoImpl.class);
	private GlsCmddErorMapper glscmdderorMapper;
	
	public void insert(GlsCmddEror glscmdderor) throws AnalyseException{
		try{
			if(null != glscmdderor.getErortx() ){
				if(glscmdderor.getErortx().length() > 255){
					glscmdderor.setErortx(glscmdderor.getErortx().substring(0,255));
				}
			}else{
				glscmdderor.setErortx("no log");
			}
			glscmdderorMapper.insertEntity(glscmdderor);
		}catch(Exception ex){
			logger.error("���������Ϣʧ�ܡ���������Ϣ��"+glscmdderor.getTrandt()+","+glscmdderor.getTransq()+","+glscmdderor.getErortx());
			logger.error(ex);
			throw new AnalyseException("��������¼ʧ�ܣ�",ex);
		}
		logger.debug("���������Ϣ�ɹ���");
		
	}
	
	public void insertBatch(List<GlsCmddEror> glscmdderors) throws AnalyseException{
		try{
			for(GlsCmddEror entity : glscmdderors){
				if(null != entity.getErortx() ){
					if(entity.getErortx().length() > 255){
						entity.setErortx(entity.getErortx().substring(0,255));
					}
				}else{
					entity.setErortx("no log");
				}
			}
			
			glscmdderorMapper.insertEntities(glscmdderors);
		}catch(Exception ex){
			logger.error("���������Ϣʧ�ܡ��������¼����"+glscmdderors.size()+ex);
			throw new AnalyseException("��������¼ʧ�ܣ�",ex);
		}
		logger.debug("���������Ϣ�ɹ���");
		
	}

	public GlsCmddErorMapper getGlsCmddErorMapper() {
		return glscmdderorMapper;
	}

	public void setGlsCmddErorMapper(GlsCmddErorMapper glsCmddErorMapper) {
		this.glscmdderorMapper = glsCmddErorMapper;
	}
	
	
}
