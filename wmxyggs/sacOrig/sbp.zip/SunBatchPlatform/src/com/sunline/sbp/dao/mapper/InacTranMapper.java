package com.sunline.sbp.dao.mapper;

import org.apache.ibatis.annotations.Param;

import com.sunline.sbp.model.InacTran;

public interface InacTranMapper {
	public void insertEntity(InacTran entity);
	public InacTran[] selectEntity(@Param("trandt") String trandt , @Param("transq") String transq, @Param("cmmdsq") String cmmdsq , @Param("systid") String systid);
	public void postingUpdate(InacTran entity);
}
