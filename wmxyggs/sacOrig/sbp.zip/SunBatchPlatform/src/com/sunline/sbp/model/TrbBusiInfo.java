package com.sunline.sbp.model;

import java.math.BigDecimal;

public class TrbBusiInfo {
	private int stacid;
	private String systid;
	private String trandt;
	private String transq;
	private String vchrsq;
	private String tranbr;
	private String custcd;
	private String acctbr;
	private String typecd;
	private String prcscd;
	private String vatxrt;
	private String crcycd;
	private String crcyiv;
	private BigDecimal tranam;
	private BigDecimal vatxam;
	private BigDecimal pricam;
	private String trstat;
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getVchrsq() {
		return vchrsq;
	}
	public void setVchrsq(String vchrsq) {
		this.vchrsq = vchrsq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getCustcd() {
		return custcd;
	}
	public void setCustcd(String custcd) {
		this.custcd = custcd;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getTypecd() {
		return typecd;
	}
	public void setTypecd(String typecd) {
		this.typecd = typecd;
	}
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public String getVatxrt() {
		return vatxrt;
	}
	public void setVatxrt(String vatxrt) {
		this.vatxrt = vatxrt;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getCrcyiv() {
		return crcyiv;
	}
	public void setCrcyiv(String crcyiv) {
		this.crcyiv = crcyiv;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public BigDecimal getVatxam() {
		return vatxam;
	}
	public void setVatxam(BigDecimal vatxam) {
		this.vatxam = vatxam;
	}
	public BigDecimal getPricam() {
		return pricam;
	}
	public void setPricam(BigDecimal pricam) {
		this.pricam = pricam;
	}
	public String getTrstat() {
		return trstat;
	}
	public void setTrstat(String trstat) {
		this.trstat = trstat;
	}
}
