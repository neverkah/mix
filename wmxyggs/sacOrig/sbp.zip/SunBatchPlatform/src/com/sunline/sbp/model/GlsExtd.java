package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * ָ����ܱ�
 * @author Zhangjin
 *
 */

public class GlsExtd {
	private int stacid;
	private String systid;
	private String trandt;
	private String transq;
	private int sortno;
	private String cmmdtg;
	private String subcmd;
	private String cmmdsq;
	private String bsnssq;
	private String amntcd;
	private String trantp;
	private String crcycd;
	private BigDecimal tranam;
	private String acctid;
	private String acctno;
	private String subsac;
	private String dttrcd;
	private String prcscd;
	private String tranbr;
	private String cmbktg;
	private int dttrno;
	private String blchtp;
	private String bkfnst;
	
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public int getSortno() {
		return sortno;
	}
	public void setSortno(int sortno) {
		this.sortno = sortno;
	}
	public String getCmmdtg() {
		return cmmdtg;
	}
	public void setCmmdtg(String cmmdtg) {
		this.cmmdtg = cmmdtg;
	}
	public String getSubcmd() {
		return subcmd;
	}
	public void setSubcmd(String subcmd) {
		this.subcmd = subcmd;
	}
	public String getCmmdsq() {
		return cmmdsq;
	}
	public void setCmmdsq(String cmmdsq) {
		this.cmmdsq = cmmdsq;
	}
	public String getAmntcd() {
		return amntcd;
	}
	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public String getAcctid() {
		return acctid;
	}
	public void setAcctid(String acctid) {
		this.acctid = acctid;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getSubsac() {
		return subsac;
	}
	public void setSubsac(String subsac) {
		this.subsac = subsac;
	}
	public String getDttrcd() {
		return dttrcd;
	}
	public void setDttrcd(String dttrcd) {
		this.dttrcd = dttrcd;
	}
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getCmbktg() {
		return cmbktg;
	}
	public void setCmbktg(String cmbktg) {
		this.cmbktg = cmbktg;
	}
	public int getDttrno() {
		return dttrno;
	}
	public void setDttrno(int dttrno) {
		this.dttrno = dttrno;
	}
	public String getBlchtp() {
		return blchtp;
	}
	public void setBlchtp(String blchtp) {
		this.blchtp = blchtp;
	}
	public String getBkfnst() {
		return bkfnst;
	}
	public void setBkfnst(String bkfnst) {
		this.bkfnst = bkfnst;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getBsnssq() {
		return bsnssq;
	}
	public void setBsnssq(String bsnssq) {
		this.bsnssq = bsnssq;
	}
	
	
}
