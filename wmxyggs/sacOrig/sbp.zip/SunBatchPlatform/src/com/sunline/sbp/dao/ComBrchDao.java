package com.sunline.sbp.dao;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.model.ComBrch;

public interface ComBrchDao {
	public ComBrch getBrchInfoByKey(int stacid , String brchcd) throws AnalyseException;
}
