package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.core.bean.GlaAcctBean;
import com.sunline.sbp.dao.SysAcctOpenDao;
import com.sunline.sbp.dao.mapper.SysAcctOpenMapper;
import com.sunline.sbp.model.SysAcctOpen;

public class SysAcctOpenDaoImpl implements SysAcctOpenDao {

	SysAcctOpenMapper sysAcctOpenMapper;
	private Logger logger = Logger.getLogger(SysAcctOpenDaoImpl.class);

	@Override
	public SysAcctOpen selectEntity(SysAcctOpen entity) throws AnalyseException {
		// TODO Auto-generated method stub
		if (0 == entity.getStacid() || null == entity.getSystid()
				|| null == entity.getBrchcd() || null == entity.getCrcycd()
				|| null == entity.getItemcd()) {
			logger.error("�������Ϸ�:" + entity.toString());
			throw new AnalyseException("�������Ϸ�:" + entity.toString());
		}

		/*String acctnoPx = GlaAcctBean.getAcctnoPx(entity.getStacid(),entity.getSystid(),
				entity.getBrchcd(), entity.getCrcycd(), entity.getItemcd());

		String aorder = sysAcctOpenMapper.getMaxSubAcct(entity.getSystid(),
				entity.getBrchcd(), entity.getCrcycd(), acctnoPx);
		entity.setAorder(aorder);*/
		sysAcctOpenMapper.selectEntity(entity);
		return entity;
	}

	public void updateOrder(SysAcctOpen entity) throws AnalyseException {
		// TODO Auto-generated method stub
		if (0 == entity.getStacid() || null == entity.getSystid()
				|| null == entity.getBrchcd() || null == entity.getCrcycd()
				|| null == entity.getItemcd()) {
			logger.error("�������Ϸ�:" + entity.toString());
			throw new AnalyseException("�������Ϸ�:" + entity.toString());
		}

		sysAcctOpenMapper.updateOrder(entity);
	}

	public void insertAcctnoOpenInfo(SysAcctOpen entity)
			throws AnalyseException {
		// TODO Auto-generated method stub
		if (0 == entity.getStacid() || null == entity.getSystid()
				|| null == entity.getBrchcd() || null == entity.getCrcycd()
				|| null == entity.getItemcd()) {
			logger.error("�������Ϸ�:" + entity.toString());
			throw new AnalyseException("�������Ϸ�:" + entity.toString());
		}

		sysAcctOpenMapper.insertAcctnoOpenInfo(entity);

	}

	public SysAcctOpenMapper getSysAcctOpenMapper() {
		return sysAcctOpenMapper;
	}

	public void setSysAcctOpenMapper(SysAcctOpenMapper sysAcctOpenMapper) {
		this.sysAcctOpenMapper = sysAcctOpenMapper;
	}

}
