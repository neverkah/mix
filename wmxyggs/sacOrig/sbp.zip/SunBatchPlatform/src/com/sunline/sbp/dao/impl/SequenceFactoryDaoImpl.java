package com.sunline.sbp.dao.impl;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.Enumeration;
import com.sunline.foundation.ServiceException;
import com.sunline.foundation.tools.StringUtil;
import com.sunline.sbp.dao.SequenceFactoryDao;
import com.sunline.sbp.dao.mapper.SequenceDefineMapper;
import com.sunline.sbp.dao.mapper.SequenceInformationMapper;
import com.sunline.sbp.model.SequenceDefine;
import com.sunline.sbp.model.SequenceInformation;

public class SequenceFactoryDaoImpl implements SequenceFactoryDao {
	
	private Logger logger = Logger.getLogger(SequenceFactoryDaoImpl.class);
	
	private SequenceDefineMapper sequenceDefineMapper;
	private SequenceInformationMapper sequenceInformationMapper;
	private Hashtable<String , Queue<Integer>> casheQueue = new Hashtable<String , Queue<Integer>>();
	//private Queue<Integer> sequenceQueue = null;
	final private int INIT_LENGTH = 20000;
	
	/**
	 * �������
	 * @throws EngineRuntimeException 
	 * @throws AnalyseException 
	 * 
	 */
	public ArrayList<String> generateSequence(int Stacid, String sqnocd, String brchcdT,
			String sqnodt, int Sqnonm) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		
		String brchcd = brchcdT;
		
		SequenceInformation insertMaxInfo = null;
		SequenceInformation updateMaxInfo = null;
		
		SequenceDefine entity = new SequenceDefine();
		entity.setSqnocd(sqnocd);
		
		String seqgenedate = sqnodt;
		
		entity = sequenceDefineMapper.selectEntity(entity);
		if(null == entity){
			logger.error("ϵͳδ������ˮ����:" + sqnocd);
			throw new AnalyseException("ϵͳδ������ˮ���ͣ�" + sqnocd);
		}
		
		if(entity.getRptmtp().equalsIgnoreCase("N")){
			seqgenedate = "20140101";
		}else if(entity.getRptmtp().equalsIgnoreCase("M")){
			seqgenedate = seqgenedate.substring(0, 6).concat("01");
		}else if(entity.getRptmtp().equalsIgnoreCase("Y")){
			seqgenedate = seqgenedate.substring(0, 4).concat("0101");
		}
		
		if(entity.getSqnorg().equals("1")){
			logger.debug("����ȫ�н�����ˮ����");
			brchcd = "000000";
		}
		
		String threadName = Thread.currentThread().getName();
		threadName = threadName.substring(threadName.lastIndexOf("-")+1);
		
		threadName = "000" + threadName;
		
		brchcd = brchcd + threadName.substring(threadName.length() - 3);
		
		
		SequenceInformation sequenceMaxInformation = new SequenceInformation();
		sequenceMaxInformation.setStacid(Stacid);
		sequenceMaxInformation.setSqnocd(sqnocd);
		sequenceMaxInformation.setBrchcd(brchcd);
		sequenceMaxInformation.setSqnodt(seqgenedate);
		
		//��ȡ��ˮֵ
		SequenceInformation sequInfo = getSequenceInformationNew(sequenceMaxInformation);
		int beginIdx = sequInfo.getMaxisq();
		if(sequInfo.getMaxisq() == 0){
			insertMaxInfo = sequInfo;
			insertMaxInfo.setMaxisq(Sqnonm+1);
		}else{
			sequInfo.setMaxisq(sequInfo.getMaxisq() + Sqnonm);
			updateMaxInfo = sequInfo;
		}
		
		String prefixStr = getPrefix(entity.getPrfxtp(), entity, brchcd);
		
		ArrayList<String> seqList = new ArrayList<String>();
		for(int id = 1 ; id <= Sqnonm ; id++){
			String sequence = prefixStr
					+ StringUtil.numberLpad(beginIdx + id,
							entity.getSqnolt() - prefixStr.length(), "0");
			seqList.add(sequence);
			
			if(sequence.length() != entity.getSqnolt()){
				String message = "ϵͳ���ɵ���ˮ["+sqnocd+"]�ĳ���["+sequence.length()+"]�붨�峤��["+entity.getSqnolt()+"]��һ�£���ˮ���ɴ���";
				logger.error(message);
				throw new AnalyseException(message);
			}
		}
		
		int updateResult = updateEntity(updateMaxInfo);
		int insertResult = insertEntity(insertMaxInfo);
		
		logger.debug("updateResult=" + updateResult + ",insertResult=" + insertResult);
		
		/*// ����У��
		if ((insertResult + updateResult) != 1) {
				throw new EngineRuntimeException(
								"ϵͳ�쳣����ˮ��Ϣ��������stacid,tranbr,trandt,sqnocd=" + Stacid
										+ "," + brchcd + "," + sqnodt + ","
										+ Enumeration.SQNOCD.TRANSQ.value);
		}*/
		
		logger.debug("����"+entity.getSqnona()+"��ˮ�ɹ�����ˮ�ţ�" + seqList.toString());
		return seqList;

	}

	private String getPrefix(String prefixType, SequenceDefine entity,
			String brchcd) {
		String prefiex = "";
		if (prefixType.equalsIgnoreCase("1")
				|| prefixType.equalsIgnoreCase("3")) {
			prefiex = brchcd;

		} else if (prefixType.equalsIgnoreCase("2")) {
			prefiex = brchcd;
		}
		return prefiex;
	}
	
	private SequenceInformation getSequenceInformation(SequenceInformation sqMaxInformation) throws EngineRuntimeException{
		
		SequenceInformation sequInfo = sequenceInformationMapper.selectEntityByLock(sqMaxInformation);
		
		if( !casheQueue.containsKey(getSequID(sqMaxInformation)) || casheQueue.get(getSequID(sqMaxInformation)).isEmpty()){
			init(sqMaxInformation,sequInfo);
		}
		
		sqMaxInformation.setMaxisq(casheQueue.get(getSequID(sqMaxInformation)).poll());
		
		//��ǰδ������ˮʱ��Ĭ�Ϸ���1���ҽ���ˮ��Ϣ���еǼ�
		return sqMaxInformation;
	}
	
	private SequenceInformation getSequenceInformationNew(SequenceInformation sqMaxInformation) throws EngineRuntimeException{
		
		SequenceInformation sequInfo = sequenceInformationMapper.selectEntityByLock(sqMaxInformation);
		if(null == sequInfo){
			sequInfo = sqMaxInformation;
		}
		
		//��ǰδ������ˮʱ��Ĭ�Ϸ���1���ҽ���ˮ��Ϣ���еǼ�
		return sequInfo;
	}
	
	private void init(SequenceInformation sqMaxInformation,SequenceInformation sequInfo) throws EngineRuntimeException {
		// ��ѯ��ˮ��¼��Ϣ
		/*SequenceInformation sequInfo = sequenceInformationMapper
				.selectEntityByLock(sqMaxInformation);*/
		
		if(!casheQueue.containsKey(getSequID(sqMaxInformation))){
			//��ʼ��
			casheQueue.put(getSequID(sqMaxInformation), new LinkedList<Integer>());
		}
		
		int maxSequ = 0;
		if(null == sequInfo){
			
			sqMaxInformation.setMaxisq(INIT_LENGTH);
			try {
				logger.debug("��������["+sqMaxInformation.getBrchcd()+"]��ˮ["+sqMaxInformation.getSqnocd()+"]��¼");
				sequenceInformationMapper.insertEntity(sqMaxInformation);
			} catch (Exception ex) {
				logger.error(sqMaxInformation.getSqnocd() +"��ˮ��Ϣ�Ǽǳ�����" + ex.getMessage());
				throw new EngineRuntimeException(ex);
			}
		}else{
			maxSequ = sequInfo.getMaxisq();
			// ��ˮ��¼������
			sequenceInformationMapper.increaseMaxisq(
								sqMaxInformation.getSqnocd(), sqMaxInformation.getBrchcd(),
								sqMaxInformation.getSqnodt(), INIT_LENGTH);
		}
		
		//��һ�����������
		for(int i = 1 ; i<= INIT_LENGTH ; i++){
			casheQueue.get(getSequID(sqMaxInformation)).offer(i + maxSequ);
		}
		
	}
	
	private String getSequID(SequenceInformation sqMaxInformation){
		return String.valueOf(sqMaxInformation.getStacid()).concat(sqMaxInformation.getBrchcd()).concat(sqMaxInformation.getSqnocd()).concat(sqMaxInformation.getSqnodt());
		
	}

	public SequenceDefineMapper getSequenceDefineMapper() {
		return sequenceDefineMapper;
	}

	public void setSequenceDefineMapper(SequenceDefineMapper sequenceDefineMapper) {
		this.sequenceDefineMapper = sequenceDefineMapper;
	}

	public SequenceInformationMapper getSequenceInformationMapper() {
		return sequenceInformationMapper;
	}

	public void setSequenceInformationMapper(
			SequenceInformationMapper sequenceInformationMapper) {
		this.sequenceInformationMapper = sequenceInformationMapper;
	}

	public int updateEntity(SequenceInformation updateMaxInfo) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		if(null != updateMaxInfo){
			return sequenceInformationMapper.updateEntity(updateMaxInfo);
		}
		return 0;
	}

	public int insertEntity(SequenceInformation insertMaxInfo) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		if(null != insertMaxInfo){
			try{
				return sequenceInformationMapper.insertEntity(insertMaxInfo);
			}catch(Exception ex){
				String errorMsg = "������ˮ�Ǻ�ʧ�ܡ�[���ף����������ڣ���ˮ����]��" + insertMaxInfo.getStacid()+","+insertMaxInfo.getBrchcd()+","+insertMaxInfo.getSqnodt()+","+insertMaxInfo.getSqnocd()+","+insertMaxInfo.getMaxisq();
				logger.error(errorMsg,ex);
				throw new EngineRuntimeException(errorMsg,ex);
			}
		}
		return 0;
	}
}
