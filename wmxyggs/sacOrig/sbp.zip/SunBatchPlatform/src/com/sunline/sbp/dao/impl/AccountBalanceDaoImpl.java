package com.sunline.sbp.dao.impl;

import java.math.BigDecimal;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.core.bean.GlaGlisBean;
import com.sunline.sbp.dao.AccountBalanceDao;
import com.sunline.sbp.dao.mapper.GlaGlisMapper;
import com.sunline.sbp.model.AccountingItem;
import com.sunline.sbp.model.GlaGlis;
import com.sunline.sbp.model.GlaVoucher;

public class AccountBalanceDaoImpl implements AccountBalanceDao {
	
	private GlaGlisMapper glaGlisMapper;
	private AccountingItemDaoImpl accountingItemDao;
	private AccountingItem itemEntity;
	
	Logger logger = Logger.getLogger(AccountBalanceDaoImpl.class);
	
	@Override
	public void updateBalance(GlaVoucher vchr) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		logger.debug("׼�����¿�Ŀ���...");
		itemEntity = accountingItemDao.getEntityByPrimaryKey(vchr.getStacid(), vchr.getItemcd());
		
		HashMap<String,String> map = new HashMap<String,String>();
		//��ȡ���
		GlaGlis glisEntity = getItemBalance(vchr);
		
		GlaGlisBean.updateBalance(vchr, glisEntity, itemEntity);
		
		//͸֧���
		if(itemEntity.getPomdtg().equalsIgnoreCase("0") && glisEntity.getOnlnbl().compareTo(BigDecimal.ZERO) == -1){
			vchr.setTranam(vchr.getTranam().negate());
			map.put("trandt", vchr.getSourdt());
			map.put("transq", vchr.getSoursq());
			map.put("erortx", "����"+itemEntity.getStacid()+"�п�Ŀ" + itemEntity.getItemcd()+"������͸֧��");
			glaGlisMapper.insertErorTax(map);
			//GlaGlisBean.updateBalance(vchr, glisEntity, itemEntity);
			//throw new EngineRuntimeException("����"+itemEntity.getStacid()+"�п�Ŀ" + itemEntity.getItemcd()+"������͸֧��");
		}else{
			
		}
		
		try {
			glaGlisMapper.updateEntity(glisEntity);
		} catch (Exception e) {
			e.printStackTrace();
			throw new EngineRuntimeException("�����������ʧ�ܡ�",e);
		}
		
	}
	
	@Override
	public GlaGlis getItemBalance(GlaVoucher vchr) throws AnalyseException{
		
		logger.debug("��ȡ��Ŀ���...");
		GlaGlis glisEntity = glaGlisMapper.getEntityLock(vchr);
		
		//��ʼ�����
		if(null == glisEntity){
			logger.debug("��Ŀ��������׼���¿������Ϣ...");
			glisEntity = GlaGlisBean.openGlis(itemEntity, vchr);
			glaGlisMapper.insertEntity(glisEntity);
		}else{
			//���ݺϷ���У��
			GlaGlisBean.checkProperty(glisEntity);
		}
		return glisEntity;
	}

	public GlaGlisMapper getGlaGlisMapper() {
		return glaGlisMapper;
	}

	public void setGlaGlisMapper(GlaGlisMapper glaGlisMapper) {
		this.glaGlisMapper = glaGlisMapper;
	}

	public AccountingItemDaoImpl getAccountingItemDao() {
		return accountingItemDao;
	}

	public void setAccountingItemDao(AccountingItemDaoImpl accountingItemDao) {
		this.accountingItemDao = accountingItemDao;
	}
	
}
