package com.sunline.sbp.dao.impl.rule;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.HashMap;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.DataObjectUtil;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.Enumeration;
import com.sunline.foundation.TranamInfoEntity;
import com.sunline.sbp.base.RuleBeanObject;
import com.sunline.sbp.core.bean.IntfDataCheck;
import com.sunline.sbp.dao.impl.SystemInterfaceDaoImpl;
import com.sunline.sbp.dao.mapper.GlsExtdMapper;
import com.sunline.sbp.dao.mapper.InvestmentTranMapper;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.InvestmentTran;
import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;
import com.sunline.sbp.model.SysIomp;

public class IvtTranRule implements RuleBeanObject {

	private Logger logger = Logger.getLogger(IvtTranRule.class);

	private InvestmentTran command = new InvestmentTran();
	private InvestmentTranMapper investmentTranMapper;
	private GlsExtdMapper glsExtdMapper;

	SystemInterfaceDaoImpl sysIntfDao;

	private GlsExtd extd;

	private HashMap<String, Object> pdata;
	private SysIomp[] iopms;
	private SysIntf sysIntf;
	private SysIntfDetl[] intfDetl;

	@Override
	public void setMapOfInIntf(final SysIntf sysIntf, final SysIomp[] iopms,
			final SysIntfDetl[] detls) {
		// TODO Auto-generated method stub
		this.iopms = iopms;
		this.sysIntf = sysIntf;
		this.intfDetl = detls;
	}

	@Override
	public String initialize(HashMap<String, Object> data) throws AnalyseException {
		// TODO Auto-generated method stub
		
		logger.debug("���� initialize");
		logger.debug(data.toString());
		pdata = (HashMap<String , Object>)data.clone();
		
		if(null != iopms){
			for(SysIomp entity : iopms){
				logger.debug("����ӳ�䴦����ʼ...");
				if(!entity.getMapkey().equalsIgnoreCase(entity.getFtokey())){
					if(null == data.get(entity.getMapkey())){
						logger.error("������������"+entity.getMapkey());
						throw new AnalyseException("������������"+entity.getMapkey());
					}else{
						logger.debug(entity.getMapkey() + "."+data.get(entity.getMapkey())+"to" + entity.getFtokey());
					}
					pdata.put(entity.getFtokey(), data.get(entity.getMapkey()));
				}
			}
		}else{
			logger.debug("δ��������ӳ�䡣");
		}
		
		if(!sysIntf.getIntfcd().equals("*") && null != intfDetl){
			logger.debug("�ӿ�����У�鿪ʼ...");
			IntfDataCheck.validate(sysIntf, intfDetl, pdata);
		}
		
		try {
			BeanUtils.populate(command, pdata);
			logger.debug("ָ��������ݶ���������!");
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			throw new AnalyseException(e.getMessage());
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			throw new AnalyseException(e.getMessage());
		}
		
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public String check() throws EngineRuntimeException {
		String isValidate = Constants.EXECUTE_SUCC;
		// TODO Auto-generated method stub
		if (null == sysIntfDao) {
			logger.error("Ͷ�� sysIntfDao δ��ʼ��");
		}
		// sysIntfDao.checkValidate(sysIntf,data);

		logger.debug("������Ϣ���ɶ�����Ч�Լ��");
		logger.debug("stacid=" + command.getStacid());
		logger.debug("systid=" + command.getSystid());
		logger.debug("trandt=" + command.getTrandt());
		logger.debug("transq=" + command.getTransq());
		logger.debug("ivetsq=" + command.getIvetsq());
		logger.debug("tranbr=" + command.getTranbr());
		logger.debug("acctbr=" + command.getAcctbr());
		logger.debug("crcycd=" + command.getCrcycd());
		logger.debug("amntcd=" + command.getAmntcd());
		logger.debug("tranam=" + command.getTranam());
		logger.debug("lnbltp=" + command.getLnbltp());
		logger.debug("dtitcd=" + command.getDtitcd());
		if (command.getTranam().abs().compareTo(BigDecimal.ZERO) == 0) {
			logger.error("Ͷ�ʽ��׵Ľ��׽���Ϊ0");
			isValidate = Constants.EXECUTE_FAIL;
			throw new EngineRuntimeException("���׽���Ϊ0");
		}

		return isValidate;
	}

	@Override
	public GlsExtd execute(int orderCount) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		logger.debug("����ָ�����¼�������ӻ���ָ���¼");

		try {
			//investmentTranMapper.insertEntity(command);
		} catch (Exception ex) {
			logger.error("����ָ�����¼����");
			logger.error(ex.getStackTrace());
			throw new EngineRuntimeException("����ָ�����¼����", ex);
		}

		extd = new GlsExtd();
		extd.setStacid(command.getStacid());
		extd.setSystid(command.getSystid());
		extd.setTrandt(command.getTrandt());
		extd.setTranbr(command.getTranbr());
		extd.setTransq(command.getTransq());
		extd.setSortno(orderCount);
		extd.setCmmdtg(Constants.COMMAND_IDENTITY_IV);
		extd.setTrantp(Enumeration.TRANTP.TRAN.value);
		extd.setAmntcd(command.getAmntcd());
		extd.setCrcycd(command.getCrcycd());
		extd.setTranam(command.getTranam());
		extd.setCmmdsq(command.getIvetsq());

		return extd;
	}

	@Override
	public TranamInfoEntity getTranamInfo() {
		// TODO Auto-generated method stub
		return new TranamInfoEntity(command.getAmntcd(), command.getTranam());
	}

	public GlsExtdMapper getGlsExtdMapper() {
		return glsExtdMapper;
	}

	public void setGlsExtdMapper(GlsExtdMapper glsExtdMapper) {
		this.glsExtdMapper = glsExtdMapper;
	}

	public InvestmentTranMapper getInvestmentTranMapper() {
		return investmentTranMapper;
	}

	public void setInvestmentTranMapper(
			InvestmentTranMapper investmentTranMapper) {
		this.investmentTranMapper = investmentTranMapper;
	}

	public SystemInterfaceDaoImpl getSysIntfDao() {
		return sysIntfDao;
	}

	public void setSysIntfDao(SystemInterfaceDaoImpl sysIntfDao) {
		this.sysIntfDao = sysIntfDao;
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JSONObject getCmmd() {
		// TODO Auto-generated method stub
		return (JSONObject)JSON.toJSON(command);
	}

}
