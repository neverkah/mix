package com.sunline.sbp.dao.impl;

import com.sunline.sbp.dao.UnityBusiProcessDao;
import com.sunline.sbp.dao.mapper.CommandExtendInfoMapper;
import com.sunline.sbp.dao.mapper.UnityBusiResponseMapper;
import com.sunline.sbp.model.CommandExtendInfo;

public class UnityBusiProcessDaoImpl implements UnityBusiProcessDao {
	
	private UnityBusiResponseMapper unityBusiResponseMapper;
	private CommandExtendInfoMapper commandExtendInfoMapper;

	@Override
	public void markingBusiSuccTransaction(String prcscd, String trandt, String transq) {
		// TODO Auto-generated method stub
		CommandExtendInfo comminfo = new CommandExtendInfo();
		comminfo.setPrcscd(prcscd);
		comminfo = commandExtendInfoMapper.selectEntity(comminfo);
		unityBusiResponseMapper.busiSuccUpdate(comminfo.getTablna(), trandt, transq);
	}

	public UnityBusiResponseMapper getUnityBusiResponseMapper() {
		return unityBusiResponseMapper;
	}

	public void setUnityBusiResponseMapper(
			UnityBusiResponseMapper unityBusiResponseMapper) {
		this.unityBusiResponseMapper = unityBusiResponseMapper;
	}

	public CommandExtendInfoMapper getCommandExtendInfoMapper() {
		return commandExtendInfoMapper;
	}

	public void setCommandExtendInfoMapper(
			CommandExtendInfoMapper commandExtendInfoMapper) {
		this.commandExtendInfoMapper = commandExtendInfoMapper;
	}
	
	
	
}
