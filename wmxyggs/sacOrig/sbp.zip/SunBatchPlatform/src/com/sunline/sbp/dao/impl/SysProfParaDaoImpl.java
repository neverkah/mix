package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.dao.SysProfParaDao;
import com.sunline.sbp.dao.mapper.SysProfParaMapper;
import com.sunline.sbp.model.ProfParamer;

public class SysProfParaDaoImpl implements SysProfParaDao {
	
	private Logger logger = Logger.getLogger(SysProfParaDaoImpl.class);
	
	private SysProfParaMapper sysProfParaMapper;

	@Override
	public ProfParamer[] getProfParamers(ProfParamer profParamer) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		ProfParamer[] ProfParamers = sysProfParaMapper.getProfParamers(profParamer);
		if(null == ProfParamers){
			logger.error("��ȡProParaʧ�ܣ�" + profParamer.getProftp());
			throw new EngineRuntimeException("��ȡProParaʧ�ܣ�" + profParamer.getProftp());
		}
		return ProfParamers;
	}

	public SysProfParaMapper getSysProfParaMapper() {
		return sysProfParaMapper;
	}

	public void setSysProfParaMapper(SysProfParaMapper sysProfParaMapper) {
		this.sysProfParaMapper = sysProfParaMapper;
	}
	
	
}
