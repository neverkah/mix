package com.sunline.sbp.dao;

import com.sunline.sbp.model.DepBusi;

public interface DepBusiDao {
	public DepBusi[] getEntities(DepBusi entity);
}
