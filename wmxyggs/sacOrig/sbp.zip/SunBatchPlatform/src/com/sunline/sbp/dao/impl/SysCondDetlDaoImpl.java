package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.dao.SysCondDetlDao;
import com.sunline.sbp.dao.mapper.SysCondDetlMapper;
import com.sunline.sbp.model.SysCond;
import com.sunline.sbp.model.SysCondDetl;

public class SysCondDetlDaoImpl implements SysCondDetlDao {
	
	private SysCondDetlMapper sysCondDetlMapper;
	private Logger logger = Logger.getLogger(SysCondDetlDao.class);

	@Override
	public SysCondDetl[] getDetailOfCond(SysCond cond) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		SysCondDetl[] condDetls = sysCondDetlMapper.getDetailOfCond(cond);
		if(null == condDetls || condDetls.length == 0){
			logger.error("������"+cond.getCondcd()+"δ������ϸ");
			throw new EngineRuntimeException("����"+cond.getCondna()+"δ������ϸ");
		}else{
			logger.debug("������"+cond.getCondcd()+"ȫ�Ļ�ȡ�ɹ���");
		}
		return condDetls;
	}
	
	public SysCondDetlMapper getSysCondDetlMapper() {
		return sysCondDetlMapper;
	}

	public void setSysCondDetlMapper(SysCondDetlMapper sysCondDetlMapper) {
		this.sysCondDetlMapper = sysCondDetlMapper;
	}

	@Override
	public boolean excuteCondition(SysCondDetl condDetl) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
