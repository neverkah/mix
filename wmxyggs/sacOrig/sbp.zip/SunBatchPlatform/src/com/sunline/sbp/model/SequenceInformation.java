package com.sunline.sbp.model;

/**
 * ͳһ��ˮ����(com_mxsq)
 * @author Zhangjin
 *
 */

public class SequenceInformation {
	private int stacid;
	private String sqnocd;
	private String brchcd;
	private String sqnodt;
	private int maxisq;
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getSqnocd() {
		return sqnocd;
	}
	public void setSqnocd(String sqnocd) {
		this.sqnocd = sqnocd;
	}
	public String getBrchcd() {
		return brchcd;
	}
	public void setBrchcd(String brchcd) {
		this.brchcd = brchcd;
	}
	public String getSqnodt() {
		return sqnodt;
	}
	public void setSqnodt(String sqnodt) {
		this.sqnodt = sqnodt;
	}
	public int getMaxisq() {
		return maxisq;
	}
	public void setMaxisq(int maxisq) {
		this.maxisq = maxisq;
	}
}
