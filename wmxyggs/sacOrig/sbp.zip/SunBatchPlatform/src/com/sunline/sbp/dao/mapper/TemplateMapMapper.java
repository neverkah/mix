package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.TempleteMap;

public interface TemplateMapMapper {
	public TempleteMap[] getTempleteMaps(TempleteMap tmap);
}
