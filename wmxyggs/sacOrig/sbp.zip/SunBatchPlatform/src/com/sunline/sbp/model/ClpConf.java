package com.sunline.sbp.model;

public class ClpConf {
	private int stacid;
	private String clerod;
	private String brchcd;
	private String brchtp;
	private String clerty;
	private String clerbr;
	private String crcycd;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getClerod() {
		return clerod;
	}
	public void setClerod(String clerod) {
		this.clerod = clerod;
	}
	public String getBrchcd() {
		return brchcd;
	}
	public void setBrchcd(String brchcd) {
		this.brchcd = brchcd;
	}
	public String getBrchtp() {
		return brchtp;
	}
	public void setBrchtp(String brchtp) {
		this.brchtp = brchtp;
	}
	public String getClerty() {
		return clerty;
	}
	public void setClerty(String clerty) {
		this.clerty = clerty;
	}
	public String getClerbr() {
		return clerbr;
	}
	public void setClerbr(String clerbr) {
		this.clerbr = clerbr;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
}
