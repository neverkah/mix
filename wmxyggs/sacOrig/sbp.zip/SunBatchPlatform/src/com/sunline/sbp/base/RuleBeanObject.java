package com.sunline.sbp.base;

import java.util.HashMap;

import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.TranamInfoEntity;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;
import com.sunline.sbp.model.SysIomp;

public interface RuleBeanObject {
	
	/**
	 * ��������ӿ�ӳ��
	 * @param ruleid
	 */
	public void setMapOfInIntf(final SysIntf sysIntf , final SysIomp[] iopms ,final SysIntfDetl[] detls);
	
	/**
	 * ��ʼ�����������ġ���������ҵ��ִ�еĶ���
	 * @param data
	 * @return
	 * @throws AnalyseException 
	 */
	public String initialize(HashMap<String , Object> idata) throws AnalyseException;
	
	/**
	 * ҵ�����ĺϷ��Լ��
	 * @return
	 * @throws EngineRuntimeException 
	 */
	public String check() throws EngineRuntimeException;
	
	/**
	 * ִ��ҵ��
	 * @return
	 * @throws AnalyseException 
	 * @throws EngineRuntimeException 
	 */
	public GlsExtd execute(int orderCount) throws EngineRuntimeException;
	
	/**
	 * ��ȡ���׷��򡢽��׽��
	 * @return
	 */
	public TranamInfoEntity getTranamInfo();
	
	public HashMap<String,Object> getData();
	
	public JSONObject getCmmd();
}
