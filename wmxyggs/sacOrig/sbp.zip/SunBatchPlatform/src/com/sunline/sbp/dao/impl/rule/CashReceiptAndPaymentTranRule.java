package com.sunline.sbp.dao.impl.rule;

import java.math.BigDecimal;
import java.util.HashMap;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.DataObjectUtil;
import com.sunline.foundation.Enumeration;
import com.sunline.foundation.TranamInfoEntity;
import com.sunline.sbp.base.RuleBeanObject;
import com.sunline.sbp.dao.mapper.CashReceiptAndPaymentMapper;
import com.sunline.sbp.dao.mapper.GlsExtdMapper;
import com.sunline.sbp.model.CashReceiptAndPayment;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;
import com.sunline.sbp.model.SysIomp;

/**
 * �ֽ��ո�ָ��
 * @author Hopechj
 *
 */

public class CashReceiptAndPaymentTranRule implements RuleBeanObject {
	
	private CashReceiptAndPaymentMapper cashReceiptAndPaymentMapper;
	private CashReceiptAndPayment command;
	private GlsExtdMapper glsExtdMapper;
	private GlsExtd extd;
	private HashMap<String , Object> data;
	private SysIomp[] iopms;
	private SysIntf sysIntf;
	private SysIntfDetl[] intfDetl;
	
	@Override
	public void setMapOfInIntf(final SysIntf sysIntf , final SysIomp[] iopms ,final SysIntfDetl[] detls) {
		// TODO Auto-generated method stub
		this.iopms = iopms;
		this.sysIntf = sysIntf;
		this.intfDetl = detls;
	}

	@Override
	public String initialize(HashMap<String , Object> data) throws AnalyseException {
		// TODO Auto-generated method stub
		command = new CashReceiptAndPayment();
		//�ֽ��׵�����������ǽ��׻���
		command.setAcctbr(DataObjectUtil.getHashMapStr(data,"tranbr").toString());
		command.setAmntcd(DataObjectUtil.getHashMapStr(data,"amntcd").toString());
		//command.setBkfnst(DataObjectUtil.getHashMapStr(data,"bkfnst").toString());
		command.setBookus(DataObjectUtil.getHashMapStr(data,"bookus","$").toString());
		command.setCkbkus(DataObjectUtil.getHashMapStr(data,"ckbkus","$").toString());
		command.setCorrtg(DataObjectUtil.getHashMapStr(data,"corrtg","0").toString());
		command.setCrcycd(DataObjectUtil.getHashMapStr(data,"crcycd").toString());
		command.setCsbxno(DataObjectUtil.getHashMapStr(data,"csbxno").toString());
		command.setCsbxtp(DataObjectUtil.getHashMapStr(data,"csbxtp").toString());
		command.setCsiosq(DataObjectUtil.getHashMapStr(data,"cmmdsq").toString());
		command.setProdcd(DataObjectUtil.getHashMapStr(data,"prodcd").toString());
		command.setSystid(DataObjectUtil.getHashMapStr(data,"systid").toString());
		command.setTranam(BigDecimal.valueOf(Double.parseDouble(DataObjectUtil.getHashMapStr(data,"tranam").toString())));
		command.setTranbr(DataObjectUtil.getHashMapStr(data,"tranbr").toString());
		command.setTrandt(DataObjectUtil.getHashMapStr(data,"trandt").toString());
		command.setTransq(DataObjectUtil.getHashMapStr(data,"transq").toString());
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public String check() {
		// TODO Auto-generated method stub
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public GlsExtd execute(int orderCount) {
		// TODO Auto-generated method stub
		//cashReceiptAndPaymentMapper.insertEntity(command);

		extd = new GlsExtd();
		extd.setStacid(command.getStacid());
		extd.setSystid(command.getSystid());
		extd.setTrandt(command.getTrandt());
		extd.setTranbr(command.getTranbr());
		extd.setTransq(command.getTransq());
		extd.setSortno(orderCount);
		extd.setCmmdtg(Constants.COMMAND_IDENTITY_CS);
		extd.setAmntcd(command.getAmntcd());
		extd.setTrantp(Enumeration.TRANTP.CASH.value);
		extd.setCrcycd(command.getCrcycd());
		extd.setTranam(command.getTranam());
		
		return extd;
	}

	@Override
	public TranamInfoEntity getTranamInfo() {
		// TODO Auto-generated method stub
		return new TranamInfoEntity(command.getAmntcd(),command.getTranam());
	}

	public CashReceiptAndPaymentMapper getCashReceiptAndPaymentMapper() {
		return cashReceiptAndPaymentMapper;
	}

	public void setCashReceiptAndPaymentMapper(
			CashReceiptAndPaymentMapper cashReceiptAndPaymentMapper) {
		this.cashReceiptAndPaymentMapper = cashReceiptAndPaymentMapper;
	}

	public GlsExtdMapper getGlsExtdMapper() {
		return glsExtdMapper;
	}

	public void setGlsExtdMapper(GlsExtdMapper glsExtdMapper) {
		this.glsExtdMapper = glsExtdMapper;
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return data;
	}

	@Override
	public JSONObject getCmmd() {
		// TODO Auto-generated method stub
		return (JSONObject)JSON.toJSON(command);
	}
	
}
