package com.sunline.sbp.dao.impl;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.dao.TmapTranDao;
import com.sunline.sbp.dao.mapper.TmapTranMapper;
import com.sunline.sbp.model.SysTmapTran;

public class TmapTranDaoImpl implements TmapTranDao {
	
	private TmapTranMapper tmapTranMapper;
	private Logger logger = Logger.getLogger(TmapTranDaoImpl.class);
	
	private HashMap<String , SysTmapTran[]> cacheData = new HashMap<String , SysTmapTran[]>();


	private SysTmapTran[] fetchTmapTrans(SysTmapTran sysTmapTran) throws EngineRuntimeException{
		// TODO Auto-generated method stub
		if(null == tmapTranMapper){
			logger.debug("tmapTranMapper���ó���");
			throw new AnalyseException("tmapTranMapper���ó���");
		}
		SysTmapTran[] sysTmapTrans = tmapTranMapper.getTmapsOfTran(sysTmapTran);
		if(null == sysTmapTrans){
			logger.debug("��ǰ����δ���÷�������");
		}
		return sysTmapTrans;
	}
	
	@Override
	public SysTmapTran[] getTmapTrans(SysTmapTran sysTmapTran) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		String key = String.valueOf(sysTmapTran.getStacid()).concat("-")
				.concat(sysTmapTran.getPrcscd().concat("-"))
				.concat(sysTmapTran.getDttrcd().concat("-"))
				.concat(sysTmapTran.getProjcd());
		SysTmapTran[] sysTmapTrans = null;
		if(!cacheData.containsKey(key) || true){
			sysTmapTrans = fetchTmapTrans(sysTmapTran);
			if(null != sysTmapTrans){
				cacheData.put(key, sysTmapTrans);
			}
		}else{
			logger.debug("fetch cache ok");
			sysTmapTrans = cacheData.get(key);
		}
		
		return sysTmapTrans;
	}

	public TmapTranMapper getTmapTranMapper() {
		return tmapTranMapper;
	}

	public void setTmapTranMapper(TmapTranMapper tmapTranMapper) {
		this.tmapTranMapper = tmapTranMapper;
	}
	
	

}
