package com.sunline.sbp.dao;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.GlaGlis;
import com.sunline.sbp.model.GlaVoucher;

public interface AccountBalanceDao {
	public void updateBalance(GlaVoucher vchr) throws EngineRuntimeException;
	public GlaGlis getItemBalance(GlaVoucher vchr) throws EngineRuntimeException;
}
