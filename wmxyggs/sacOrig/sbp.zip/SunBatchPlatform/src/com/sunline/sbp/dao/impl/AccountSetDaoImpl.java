package com.sunline.sbp.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.dao.AccountSetDao;
import com.sunline.sbp.dao.mapper.AccountSetMapper;
import com.sunline.sbp.model.AccountSet;

public class AccountSetDaoImpl implements AccountSetDao {
	
	private Logger logger = Logger.getLogger(AccountSetDao.class);
	private AccountSetMapper accountSetMapper;

	@Override
	public String getTrandt(int stacid) throws AnalyseException {
		// TODO Auto-generated method stub
		AccountSet stac = new AccountSet();
		stac.setStacid(stacid);
		stac = accountSetMapper.selectEntity(stac);
		if(null == stac){
			logger.error("����[" +  stacid + "]������");
			throw new AnalyseException("����[" +  stacid + "]������");
		}else{
			logger.debug("����["+stacid+"]����������["+stac.getGlisdt()+"]��ȡ�ɹ���");
			return stac.getGlisdt();
		}
		
	}
	
	@Override
	public List<AccountSet> getStacLinks(int stacid) throws AnalyseException {
		// TODO Auto-generated method stub
		List<AccountSet> stacLinks = null;
		AccountSet stac = new AccountSet();
		stac.setStacid(stacid);
		stacLinks = accountSetMapper.selectEntityLinks(stac);
		if(null == stacLinks || stacLinks.isEmpty() || stacLinks.size() < 1){
			logger.error("����[" +  stacid + "]������");
			throw new AnalyseException("����[" +  stacid + "]������");
		}else{
			logger.debug("����["+stacid+"]��ȡ�ɹ���");
			return stacLinks;
		}
	}

	public AccountSetMapper getAccountSetMapper() {
		return accountSetMapper;
	}

	public void setAccountSetMapper(AccountSetMapper accountSetMapper) {
		this.accountSetMapper = accountSetMapper;
	}
}
