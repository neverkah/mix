package com.sunline.sbp.commanddeal;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.dao.mapper.CashReceiptAndPaymentMapper;
import com.sunline.sbp.model.CashReceiptAndPayment;
import com.sunline.sbp.model.GlaVoucher;

/**
 * �ֽ��ո�ָ��
 * @author Hopechj
 *
 */

public class CashIOCommand implements TranCommandObject {
	
	private CashReceiptAndPaymentMapper cashReceiptAndPaymentMapper;
	private CashReceiptAndPayment command;
	private GlaVoucher glaVoucher;
	
	private final String CS_PRE = "CSTP";

	@Override
	public void initialize(String trandt, String transq , String cmmdsq, String systid) throws AnalyseException {
		// TODO Auto-generated method stub
		command = cashReceiptAndPaymentMapper.selectEntity(trandt, transq , cmmdsq,systid);
		if(null == command){
			if( null == command){
				Logger.getLogger("").error("��ȡ�ֽ��ո�ָ������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq);
				throw new AnalyseException("��ȡ�ֽ��ո�ָ������ʧ�ܣ�" + "�������ڣ�" + trandt + ",������ˮ��" + transq);
			}
		}
	}

	@Override
	public void setVoucherInfo() {
		// TODO Auto-generated method stub
		glaVoucher = new GlaVoucher();
		glaVoucher.setAcctbr(command.getAcctbr());
		glaVoucher.setAcctno("*");
		//������ϢϢʱ�Ǵ���
		glaVoucher.setAmntcd(command.getAmntcd());
		glaVoucher.setAssis0("*");
		glaVoucher.setAssis1("*");
		glaVoucher.setAssis3("*");
		glaVoucher.setAssis4("*");
		glaVoucher.setAssis5("*");
		glaVoucher.setAssis6("*");
		glaVoucher.setAssis7("*");
		glaVoucher.setAssis8("*");
		glaVoucher.setAssis9("*");
		glaVoucher.setCentcd("*");
		glaVoucher.setCrcycd(command.getCrcycd());
		
		//����ֽ����� Ϊ�̶� 100101
		glaVoucher.setItemcd("100101");
		
		glaVoucher.setPrducd("*");
		glaVoucher.setPrlncd("*");
		glaVoucher.setPrsncd("*");
		glaVoucher.setSmrytx("�ֽ��ո�");
		glaVoucher.setSourdt(command.getTrandt());
		glaVoucher.setSoursq(command.getTransq());
		glaVoucher.setSourst(command.getSystid());
		glaVoucher.setStacid(command.getStacid());
		glaVoucher.setSystid(command.getSystid());
		glaVoucher.setTranam(command.getTranam());
		glaVoucher.setTranbr(command.getTranbr());
		glaVoucher.setTrandt(command.getTrandt());
		glaVoucher.setTrantp(Enumeration.TRANTP.CASH.value);
		glaVoucher.setUsercd(Enumeration.USERCD.ENGINE.value);
		glaVoucher.setClertg(Enumeration.CLERTG.CLERTG_0.value);
	}

	@Override
	public String getTrprcd() {
		// TODO Auto-generated method stub
		return Constants.TRPRCD_DEFAULT;
	}

	@Override
	public String getDtitcd() {
		// TODO Auto-generated method stub
		return CS_PRE.concat(command.getCsbxtp());
	}

	@Override
	public GlaVoucher getGlaVoucher() {
		// TODO Auto-generated method stub
		return glaVoucher;
	}

	public CashReceiptAndPaymentMapper getCashReceiptAndPaymentMapper() {
		return cashReceiptAndPaymentMapper;
	}

	public void setCashReceiptAndPaymentMapper(
			CashReceiptAndPaymentMapper cashReceiptAndPaymentMapper) {
		this.cashReceiptAndPaymentMapper = cashReceiptAndPaymentMapper;
	}

	@Override
	public String postingSucc() {
		// TODO Auto-generated method stub
		String executeResult;
		try{
			cashReceiptAndPaymentMapper.postingUpdate(command);
			executeResult = Constants.EXECUTE_SUCC;
		}catch(Exception ex){
			executeResult = Constants.EXECUTE_FAIL;
		}
		return executeResult;
	}

	@Override
	public String getTrancd() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getStacid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getStacid();
	}

	@Override
	public void initialize(JSONObject jsonObject) throws AnalyseException {
		// TODO Auto-generated method stub
		command = JSON.parseObject(jsonObject.toJSONString(), CashReceiptAndPayment.class);
	}

	@Override
	public String getTrandt() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTrandt();
	}

	@Override
	public String getSystid() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getSystid();
	}

	@Override
	public String getTransq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getTransq();
	}

	@Override
	public String getCmmdsq() throws AnalyseException {
		// TODO Auto-generated method stub
		return command.getCsiosq();
	}
	
	
}
