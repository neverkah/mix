package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.dao.ComBrchDao;
import com.sunline.sbp.dao.mapper.ComBrchMapper;
import com.sunline.sbp.model.ComBrch;

public class ComBrchDaoImpl implements ComBrchDao {
	
	private Logger logger = Logger.getLogger(ComBrchDaoImpl.class);
	
	ComBrchMapper comBrchMapper;

	@Override
	public ComBrch getBrchInfoByKey(int stacid, String brchcd) throws AnalyseException {
		// TODO Auto-generated method stub
		if(null == comBrchMapper){
			logger.debug("comBrchMapper δ��ʼ����");
			throw new AnalyseException("ϵͳ�쳣");
		}else{
			logger.debug("comBrchMapper ��ʼ���ɹ���");
		}
		ComBrch brchEntity = comBrchMapper.getEntityByPrimKey(stacid,brchcd);
		if(null == brchEntity){
			logger.error("����["+stacid+"]�в����ڻ���["+brchcd+"]");
			throw new AnalyseException("����["+stacid+"]�в����ڻ���["+brchcd+"]");
		}else{
			logger.debug("����["+stacid+"]�л���["+brchcd+"]��Ϣ��ȡ�ɹ�");
		}
		return brchEntity;
	}

	public ComBrchMapper getComBrchMapper() {
		return comBrchMapper;
	}

	public void setComBrchMapper(ComBrchMapper comBrchMapper) {
		this.comBrchMapper = comBrchMapper;
	}
	
	
}
