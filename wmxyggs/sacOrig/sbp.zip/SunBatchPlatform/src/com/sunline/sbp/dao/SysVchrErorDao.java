package com.sunline.sbp.dao;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.model.SysVchrEror;

public interface SysVchrErorDao {
	public void insert(SysVchrEror glscmdderor) throws AnalyseException;
}
