package com.sunline.sbp.application;

import static com.sunline.sbp.application.Help.initMetaConfig;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.XADataSource;
import javax.transaction.TransactionManager;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;

import oracle.jdbc.xa.client.OracleXADataSource;

import com.alibaba.fastjson.JSON;
import com.atomikos.icatch.jta.UserTransactionManager;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.application.XACallback;
import com.sunline.sbp.application.XATransactionTemplate;
import com.sunline.sbp.dao.ExtdDao;
import com.sunline.sbp.model.GlsExtd;
import com.taobao.metamorphosis.Message;
import com.taobao.metamorphosis.client.XAMessageSessionFactory;
import com.taobao.metamorphosis.client.XAMetaMessageSessionFactory;
import com.taobao.metamorphosis.client.producer.XAMessageProducer;

public class CommandProducer {

    private static XAMessageSessionFactory getXAMessageSessionFactory() throws Exception {
        return new XAMetaMessageSessionFactory(initMetaConfig());
    }

    private static XADataSource getXADataSource() throws SQLException {
        final OracleXADataSource oracleXADataSource = new OracleXADataSource();
        oracleXADataSource.setURL("jdbc:oracle:thin:@172.32.5.189:1521:oradev3");
        oracleXADataSource.setUser("sungldb");
        oracleXADataSource.setPassword("sungldb");
        //oracleXADataSource.setPreparedStatementCacheSize(20);
        return oracleXADataSource;
    }


    public static void main(final String[] args) throws Exception {
    	
        final TransactionManager tm = new UserTransactionManager();

        final String topic = "gl-vchr";
        final XAMessageSessionFactory xasf = getXAMessageSessionFactory();
        final XADataSource xads = getXADataSource();

        final XATransactionTemplate template = new XATransactionTemplate(tm, xads, xasf);
        
        template.publishTopic(topic);
        
        GlsExtd[] entities = fetch("20141002");

        for ( GlsExtd entity : entities ) {
            final String message = JSON.toJSONString(entity);
            
            try {
                template.executeCallback(new XACallback() {
                    public Object execute(final Connection conn, final XAMessageProducer producer) throws Exception {
                    	
                    	Logger logger = Logger.getLogger(CommandProducer.class);
                    	
                    	JSONObject jsonObject = JSON.parseObject(message);
                    	
                        final PreparedStatement pstmt = conn.prepareStatement("update gls_extd set bkfnst = 'i' where trandt = ? and transq = ? and sortno = ? and bkfnst = '0'");
                        // ���ݿ�msg����Ϊnull�����Գ��Խ�����setString����null�����۲�ع�����
                        logger.debug(jsonObject.getString("trandt"));
                        logger.debug(jsonObject.getString("transq"));
                        logger.debug(jsonObject.getString("sortno"));
                        pstmt.setString(1, jsonObject.getString("trandt"));
                        pstmt.setString(2, jsonObject.getString("transq"));
                        pstmt.setString(3, jsonObject.getString("sortno"));
                        if (pstmt.executeUpdate() <= 0) {
                            throw new RuntimeException("update status to oracle failed");
                        }
                        pstmt.close();
                        if (!producer.sendMessage(new Message(topic, message.getBytes())).isSuccess()) {
                            throw new RuntimeException("send message failed");
                        }
                        
                        return null;
                    }
                });

            }
            catch (final Exception e) {
                e.printStackTrace();
            }
        }
    }


    private static GlsExtd[] fetch(String trandt) throws IOException {
    	Logger.getLogger(CommandProducer.class).debug("Type message to send:");
        
        ExtdDao analyseCenter = (ExtdDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(ExtdDao.class);
        return analyseCenter.selectEntities(trandt);
        //JSONObject jsonObject = JSONObject.fromObject(entities[1]);
        //return jsonObject.toString();
    }

}
