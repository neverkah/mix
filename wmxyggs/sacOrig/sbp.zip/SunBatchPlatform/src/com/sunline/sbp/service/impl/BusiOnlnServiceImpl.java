package com.sunline.sbp.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import org.apache.log4j.Logger;
import org.springframework.transaction.UnexpectedRollbackException;

import com.sunline.foundation.Constants;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.ServiceException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.foundation.tools.StringUtil;
import com.sunline.sbp.core.bean.ExtdVSCmmdBean;
import com.sunline.sbp.dao.AccountSetDao;
import com.sunline.sbp.dao.AccountingTreatmentDao;
import com.sunline.sbp.dao.AnalyseCenterDao;
import com.sunline.sbp.dao.GlaVoucherDao;
import com.sunline.sbp.datamerger.BusiDecisionMaker;
import com.sunline.sbp.datamerger.BusinessObject;
import com.sunline.sbp.model.AccountSet;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.service.BusiOnlnService;

/**
 * 
 * @author liuchj@sunline.cn
 *
 */
public class BusiOnlnServiceImpl implements BusiOnlnService{
	
	Logger logger = Logger.getLogger(BusiOnlnServiceImpl.class);

	@Override
	public String busiTransaction(JSONObject jsonObject) throws ServiceException {
    	
    	BusinessObject businessObject;
    	AnalyseCenterDao analyseCenter;
    	AccountSetDao accountSetDao;
    	
    	String message = Constants.EXECUTE_NULL;
    	ArrayList<BusinessObject> businessArray= new ArrayList<BusinessObject>();
    	try{
    		//���ɹ鼯���ݶ���
        	businessObject = BusiDecisionMaker.createBusiness(jsonObject);
        	businessArray.add(businessObject);
        	accountSetDao = (AccountSetDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AccountSetDao.class);
        	
        	//��׼��
        	List<AccountSet> stacLinks = accountSetDao.getStacLinks(businessObject.getStacid());
        	for(AccountSet entity : stacLinks){
        		if(null != entity.getMusctg()
        				&& entity.getMusctg().equals("Y") 
        				&& entity.getMuscid() == businessObject.getStacid()){
        			//���ú�������
        			businessObject.setStacid(entity.getStacid());
        		}
        		
        		analyseCenter = (AnalyseCenterDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AnalyseCenterDao.class);
        		
        		ExtdVSCmmdBean extdVSCmmdBean = analyseCenter.dealBusiEntityV2Transaction(businessArray);
            	
            	//���׷���
            	AccountingTreatmentDao ap = (AccountingTreatmentDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AccountingTreatmentDao.class);
            	
            	List<GlaVoucher> vchrResult = ap.processCmmdVectorTransaction(extdVSCmmdBean);
        		
            	GlaVoucherDao voucherDao = (GlaVoucherDao) ApplicationBeanFactory
        				.getApplicationContextInstance().getBean(GlaVoucherDao.class);
            	
            	//���洫Ʊ
        		if (null != vchrResult && vchrResult.size() > 0) {
        			List<List<GlaVoucher>> listVchrs = new ArrayList<List<GlaVoucher>>();
        			listVchrs.add(vchrResult);
        			voucherDao.insertEntitiesBatch(listVchrs,vchrResult.get(0).getTrandt(),vchrResult.get(0).getTranbr(),businessObject.getStacid());
        		}
        	}
        	
        	
    		
    		message = Constants.EXECUTE_SUCC;
    		
    	}catch(UnexpectedRollbackException ex){
    		message = Constants.EXECUTE_EXCEPTION + ":ϵͳ�ع��쳣" + ex.getMessage();
    		logger.error(message,ex);
    		throw new ServiceException(message,ex);
    	}catch(EngineRuntimeException rex){
    		message = Constants.EXECUTE_FAIL + ":����ʧ��" + rex.getMessage();
    		logger.error(message,rex);
    		throw new ServiceException(message,rex);
    	}catch(Exception eex){
    		message = Constants.EXECUTE_EXCEPTION + ":ϵͳ�쳣" + eex.getMessage();
    		logger.error(message,eex);
    		throw new ServiceException(message,eex);
    	}
    	
    	return message;
	}

	@Override
	public String busiBatchTransaction(JSONArray jsonArray)
			throws ServiceException {
    	
    	ArrayList<BusinessObject> businessArray;
    	AccountSetDao accountSetDao;
    	
    	String message = Constants.EXECUTE_NULL;
    	
    	String trandt = null;
    	String transq = null;
    	String brchcd = null;
    	
    	int stacid = 0;
    	
    	try{
    		//���ɹ鼯���ݶ���
    		businessArray = new ArrayList<BusinessObject>();
    		for(int id = 0 ; id < jsonArray.size() ; id++){
    			businessArray.add(BusiDecisionMaker.createBusiness(jsonArray.getJSONObject(id)));
    		}
        	
    		//ȡ������Ϣ
        	if(businessArray.size() > 0){
        		trandt = businessArray.get(0).getBsnsdt();
        		transq = businessArray.get(0).getBsnssq();
        		stacid = businessArray.get(0).getStacid();
        	}
        	accountSetDao = (AccountSetDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AccountSetDao.class);
        	List<AccountSet> stacLinks = accountSetDao.getStacLinks(stacid);
        	for(AccountSet entity : stacLinks){
        		if(null != entity.getStacmt()
        				&& entity.getStacmt().equals("1") 
        				&& entity.getLinkid() == stacid){
        			//���ù�������
        			for(BusinessObject bo : businessArray){
            			bo.setStacid(entity.getStacid());
            		}
        		}
        		
        		excuteDeal(businessArray,trandt,transq,stacid);
        	}
        	
    		message = Constants.EXECUTE_SUCC;
    		
    	}catch(Exception eex){
    		message = Constants.EXECUTE_EXCEPTION + ":ϵͳ�쳣" + eex.getMessage() + "!��ˮ��:" + transq + ",����=" + brchcd + ",����=" + trandt;
    		logger.error(message,eex);
    		throw new ServiceException(message,eex);
    	}
    	
    	return message;
	}
	
	@Override
	public String busiSingleTransaction(JSONArray jsonArray) throws ServiceException {
    	
    	ArrayList<BusinessObject> businessArray;
    	AccountSetDao accountSetDao;
    	
    	String message = Constants.EXECUTE_NULL;
    	
    	String trandt = null;
    	String transq = null;
    	String brchcd = null;
    	
    	int stacid = 0;
    	
    	try{
    		//���ɹ鼯���ݶ���
    		businessArray = new ArrayList<BusinessObject>();
    		for(int id = 0 ; id < jsonArray.size() ; id++){
    			businessArray.add(BusiDecisionMaker.createBusiness(jsonArray.getJSONObject(id)));
    		}
        	
    		//ȡ������Ϣ
        	if(businessArray.size() > 0){
        		trandt = businessArray.get(0).getBsnsdt();
        		transq = businessArray.get(0).getBsnssq();
        		stacid = businessArray.get(0).getStacid();
        	}
        	
        	for(BusinessObject object : businessArray){
        		if( !object.getBsnsdt().equals(trandt)
        				|| !object.getBsnssq().equals(transq)){
        			throw new EngineRuntimeException("��ǰ���õ��ǵ�����ˮ�������񣬵����ݲ��ǵ���ҵ��");
        		}
        	}
        	
        	accountSetDao = (AccountSetDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AccountSetDao.class);
        	List<AccountSet> stacLinks = accountSetDao.getStacLinks(stacid);
        	for(AccountSet entity : stacLinks){
        		if(null != entity.getStacmt()
        				&& entity.getStacmt().equals("1") 
        				&& entity.getLinkid() == stacid){
        			//���ù�������
        			for(BusinessObject bo : businessArray){
            			bo.setStacid(entity.getStacid());
            		}
        		}
        		
        		excuteSingleDeal(businessArray,trandt,transq,stacid);
        	}
        	
    		message = Constants.EXECUTE_SUCC;
    		
    	}catch(Exception eex){
    		message = Constants.EXECUTE_EXCEPTION + ":ϵͳ�쳣" + eex.getMessage() + "!��ˮ��:" + transq + ",����=" + brchcd + ",����=" + trandt;
    		logger.error(message,eex);
    		throw new ServiceException(message,eex);
    	}
    	
    	return message;
	}
	
	private void excuteDeal(ArrayList<BusinessObject> businessArray , String trandt , String transq , int stacid) throws ServiceException{
    	
    	String message = Constants.EXECUTE_NULL;

    	String brchcd = null;
    	
    	try{
    		
        	List<GlaVoucher> vchrResult = parse(businessArray);
        	saveVchrs(vchrResult, stacid);
    		
    	}catch(UnexpectedRollbackException ex){
    		message = Constants.EXECUTE_EXCEPTION + ":ϵͳ�ع��쳣" + ex.getMessage() + "!��ˮ��:" + transq + ",����=" + brchcd + ",����=" + trandt;
    		logger.error(message,ex);
    		throw new ServiceException(message,ex);
    	}catch(EngineRuntimeException rex){
    		//�ظ�����ʱ���϶�Ϊ�ɹ�
    		if(rex.getMessage().startsWith("EXE9000:")){
    			message = Constants.EXECUTE_SUCC;
    			logger.error(message,rex);
    		}else{
    			message = Constants.EXECUTE_FAIL + ":����ʧ��" + rex.getMessage() + "!��ˮ��:" + transq + ",����=" + brchcd + ",����=" + trandt;
        		logger.error(message,rex);
        		throw new ServiceException(message,rex);
    		}
    		
    	}catch(Exception eex){
    		message = Constants.EXECUTE_EXCEPTION + ":ϵͳ�쳣" + eex.getMessage() + "!��ˮ��:" + transq + ",����=" + brchcd + ",����=" + trandt;
    		logger.error(message,eex);
    		throw new ServiceException(message,eex);
    	}
	
	}
	
private void excuteSingleDeal(ArrayList<BusinessObject> businessArray , String trandt , String transq , int stacid) throws ServiceException{
    	
    	String message = Constants.EXECUTE_NULL;

    	String brchcd = null;
    	
    	try{
    		
        	List<GlaVoucher> vchrResult = parse(businessArray);
        	saveVchrOne(vchrResult, stacid);
    		
    	}catch(UnexpectedRollbackException ex){
    		message = Constants.EXECUTE_EXCEPTION + ":ϵͳ�ع��쳣" + ex.getMessage() + "!��ˮ��:" + transq + ",����=" + brchcd + ",����=" + trandt;
    		logger.error(message,ex);
    		throw new ServiceException(message,ex);
    	}catch(EngineRuntimeException rex){
    		//�ظ�����ʱ���϶�Ϊ�ɹ�
    		if(rex.getMessage().startsWith("EXE9000:")){
    			message = Constants.EXECUTE_SUCC;
    			logger.error(message,rex);
    		}else{
    			message = Constants.EXECUTE_FAIL + ":����ʧ��" + rex.getMessage() + "!��ˮ��:" + transq + ",����=" + brchcd + ",����=" + trandt;
        		logger.error(message,rex);
        		throw new ServiceException(message,rex);
    		}
    		
    	}catch(Exception eex){
    		message = Constants.EXECUTE_EXCEPTION + ":ϵͳ�쳣" + eex.getMessage() + "!��ˮ��:" + transq + ",����=" + brchcd + ",����=" + trandt;
    		logger.error(message,eex);
    		throw new ServiceException(message,eex);
    	}
	
	}
	
	private void saveVchrs(List<GlaVoucher> vchrResult , int stacid) throws EngineRuntimeException{
		//���洫Ʊ
    	GlaVoucherDao voucherDao = (GlaVoucherDao) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(GlaVoucherDao.class);
    	
		if (null != vchrResult && vchrResult.size() > 0) {
			List<List<GlaVoucher>> listVchrs = new ArrayList<List<GlaVoucher>>();
			
			//busi��������
			HashMap<String,List<GlaVoucher>> mapList = new HashMap<String,List<GlaVoucher>>();
			for(GlaVoucher entityVchr : vchrResult){
				String key = entityVchr.getSourdt()+"-$-"+entityVchr.getSoursq();
				if(!mapList.containsKey(key)){
					List<GlaVoucher> tmp = new ArrayList<GlaVoucher>();
					mapList.put(key, tmp);
				}
				mapList.get(key).add(entityVchr);
			}
			
			Iterator<String> keyList = mapList.keySet().iterator();
			
			while(keyList.hasNext()){
				listVchrs.add(mapList.get(keyList.next()));
			}
			
			logger.fatal(listVchrs.size()+"��ҵ��������"+vchrResult.size()+"�ʴ�Ʊ��");
			
			voucherDao.insertEntitiesBatch(listVchrs,vchrResult.get(0).getTrandt(),vchrResult.get(0).getTranbr(),stacid);
		}
		
	}
	
	private void saveVchrOne(List<GlaVoucher> vchrResult , int stacid) throws EngineRuntimeException{
		//���洫Ʊ
    	GlaVoucherDao voucherDao = (GlaVoucherDao) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(GlaVoucherDao.class);
    	
		if (null != vchrResult && vchrResult.size() > 0) {
			voucherDao.insertEntity(vchrResult);
		}
		
	}
	
	private List<GlaVoucher> parse(ArrayList<BusinessObject> businessArray) throws EngineRuntimeException{
		AnalyseCenterDao analyseCenter;
		List<GlaVoucher> vchrResult = null;
		try{
			analyseCenter = (AnalyseCenterDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AnalyseCenterDao.class);
	    	
	    	ExtdVSCmmdBean extdVSCmmdBean = analyseCenter.dealBusiEntityV2Transaction(businessArray);
	    	
	    	//���׷���
	    	AccountingTreatmentDao ap = (AccountingTreatmentDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AccountingTreatmentDao.class);
	    	
	    	vchrResult = ap.processCmmdVectorTransaction(extdVSCmmdBean);
		}catch(EngineRuntimeException erex){
			logger.error(erex.getMessage(),erex);
			throw new EngineRuntimeException(erex);
		}catch(Exception ex){
			logger.error("ϵͳ�쳣��"+ex.getMessage(),ex);
			ex.printStackTrace();
			throw new EngineRuntimeException(ex);
		}
    	
    	return vchrResult;
	}
	
	
	@Override
	public List<GlaVoucher> busiParsePreview(JSONArray jsonArray)
			throws ServiceException {
    	
    	ArrayList<BusinessObject> businessArray;
    	AccountSetDao accountSetDao;
    	
    	String message = Constants.EXECUTE_NULL;
    	
    	String trandt = null;
    	String transq = null;
    	String brchcd = null;
    	
    	int stacid = 0;
    	
    	List<GlaVoucher> vchrs = new ArrayList<GlaVoucher>();
    	
    	try{
    		//���ɹ鼯���ݶ���
    		businessArray = new ArrayList<BusinessObject>();
    		for(int id = 0 ; id < jsonArray.size() ; id++){
    			businessArray.add(BusiDecisionMaker.createBusiness(jsonArray.getJSONObject(id)));
    		}
        	
    		//ȡ������Ϣ
        	if(businessArray.size() > 0){
        		trandt = businessArray.get(0).getBsnsdt();
        		transq = businessArray.get(0).getBsnssq();
        		stacid = businessArray.get(0).getStacid();
        	}
        	
        	accountSetDao = (AccountSetDao)ApplicationBeanFactory.getApplicationContextInstance().getBean(AccountSetDao.class);
        	List<AccountSet> stacLinks = accountSetDao.getStacLinks(stacid);
        	
        	for(AccountSet entity : stacLinks){
        		if(null != entity.getStacmt()
        				&& entity.getStacmt().equals("1") 
        				&& entity.getLinkid() == stacid){
        			//���ù�������
        			for(BusinessObject bo : businessArray){
            			bo.setStacid(entity.getStacid());
            		}
        		}
        		vchrs.addAll(parse(businessArray));
        	}
    		
    	}catch(Exception eex){
    		message = Constants.EXECUTE_EXCEPTION + ":ϵͳ�쳣" + eex.getMessage() + "!��ˮ��:" + transq + ",����=" + brchcd + ",����=" + trandt;
    		logger.error(message,eex);
    		throw new ServiceException(message,eex);
    	}
    	
    	return vchrs;
	}
	
	@Override
	public List<GlaVoucher> queryVchrs(JSONObject jsonObject) throws ServiceException {
		// TODO Auto-generated method stub
		
		int stacid = jsonObject.getIntValue("stacid");
		String bsnssq = jsonObject.getString("bsnssq");
		String bsnsdt = jsonObject.getString("bsnsdt");
		String bsnssy = jsonObject.getString("bsnssy");
		
		List<GlaVoucher> list = null;
		
		try{
			
			if(stacid == 0){
				throw new Exception("����stacid����Ϊ��");
			}
			
			if(!StringUtil.isNotNull(bsnssq)){
				throw new Exception("������ˮbsnssq����Ϊ��");
			}
			
			if(!StringUtil.isNotNull(bsnsdt)){
				throw new Exception("��������bsnsdt����Ϊ��");
			}
			
			if(!StringUtil.isNotNull(bsnssy)){
				throw new Exception("ҵ��ϵͳbsnssy����");
			}
			
			GlaVoucherDao voucherDao = (GlaVoucherDao) ApplicationBeanFactory
    				.getApplicationContextInstance().getBean(GlaVoucherDao.class);
			
			list = voucherDao.getVouchersByBsns(stacid, bsnssy, bsnsdt, bsnssq);
			
		}catch(Exception ex){
			logger.error(ex.getMessage(),ex);
		}
		
		return list;
	}
}
