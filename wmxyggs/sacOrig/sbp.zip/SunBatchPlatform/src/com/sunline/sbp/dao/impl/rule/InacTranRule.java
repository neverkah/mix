package com.sunline.sbp.dao.impl.rule;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.TranamInfoEntity;
import com.sunline.sbp.base.RuleBeanObject;
import com.sunline.sbp.core.bean.IntfDataCheck;
import com.sunline.sbp.dao.impl.SystemInterfaceDaoImpl;
import com.sunline.sbp.dao.mapper.GlsExtdMapper;
import com.sunline.sbp.dao.mapper.InacTranMapper;
import com.sunline.sbp.model.GlsExtd;
import com.sunline.sbp.model.InacTran;
import com.sunline.sbp.model.SysIntf;
import com.sunline.sbp.model.SysIntfDetl;
import com.sunline.sbp.model.SysIomp;

public class InacTranRule implements RuleBeanObject {
	
	private Logger logger = Logger.getLogger(InacTranRule.class);
	
	private InacTran command = new InacTran();
	private InacTranMapper inacTranMapper;
	private GlsExtdMapper glsExtdMapper;
	private GlsExtd extd;
	private SystemInterfaceDaoImpl sysIntfDaoImpl;
	
	private HashMap<String , Object> pdata = new HashMap<String , Object>();
	private SysIomp[] iopms;
	private SysIntf sysIntf;
	private SysIntfDetl[] intfDetl;
	
	@Override
	public void setMapOfInIntf(final SysIntf sysIntf , final SysIomp[] iopms ,final SysIntfDetl[] detls) {
		// TODO Auto-generated method stub
		this.iopms = iopms;
		this.sysIntf = sysIntf;
		this.intfDetl = detls;
	}

	@SuppressWarnings("unchecked")
	@Override
	public String initialize(final HashMap<String , Object> data) throws AnalyseException {
		// TODO Auto-generated method stub
		logger.debug("���� initialize");
		logger.debug(data.toString());
		pdata = (HashMap<String , Object>)data.clone();
		if(null != iopms){
			for(SysIomp entity : iopms){
				logger.debug("����ӳ�䴦����ʼ...");
				if(!entity.getMapkey().equalsIgnoreCase(entity.getFtokey())){
					if(null == data.get(entity.getMapkey())){
						logger.error("������������"+entity.getMapkey());
						throw new AnalyseException("������������"+entity.getMapkey());
					}else{
						logger.debug(entity.getMapkey() + "."+data.get(entity.getMapkey())+"to" + entity.getFtokey());
					}
					pdata.put(entity.getFtokey(), data.get(entity.getMapkey()));
				}
			}
		}else{
			logger.debug("δ��������ӳ�䡣");
		}
		
		logger.debug(" ����ӳ���" +data.toString());
		
		String typecd = pdata.get("typecd").toString();
		String trprcd = "";
		if(null != pdata.get("trprcd")){
			trprcd = pdata.get("trprcd").toString();
		}
		
		pdata.put("dtitcd", typecd.concat(trprcd));
		
		//�ڲ��ʽ�����ʱ�������˻�
		
		if(!sysIntf.getIntfcd().equals("*") && null != intfDetl){
			logger.debug("�ӿ�����У�鿪ʼ...");
			IntfDataCheck.validate(sysIntf, intfDetl, pdata);
		}
		
		logger.debug("inacsq=" + pdata.get("inacsq"));
		
		try {
			BeanUtils.populate(command, pdata);
			logger.debug("ָ��������ݶ���������!");
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			throw new AnalyseException(e.getMessage());
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			throw new AnalyseException(e.getMessage());
		}
		
		/*command.setStacid(Integer.parseInt(DataObjectUtil.getHashMapStr(data,"stacid").toString()));
		command.setInacsq(DataObjectUtil.getHashMapStr(data,"inacsq").toString());
		command.setCrcycd(DataObjectUtil.getHashMapStr(data,"crcycd").toString());
		command.setDtitcd(DataObjectUtil.getHashMapStr(data,"dtitcd").toString());
		command.setTranam(Double.parseDouble(DataObjectUtil.getHashMapStr(data,"tranam","0").toString()));
		command.setSystid(DataObjectUtil.getHashMapStr(data,"systid").toString());
		command.setTranbr(DataObjectUtil.getHashMapStr(data,"tranbr").toString());
		command.setAmntcd(DataObjectUtil.getHashMapStr(data,null==mdata.get("amntcd")?"amntcd":mdata.get("amntcd")).toString());
		command.setTrandt(DataObjectUtil.getHashMapStr(data,"trandt").toString());
		command.setTransq(DataObjectUtil.getHashMapStr(data,"transq").toString());
		command.setTrantp(DataObjectUtil.getHashMapStr(data,"trantp").toString());
		command.setAcctbr(DataObjectUtil.getHashMapStr(data,"acctbr").toString());
		command.setAcctno("*");*/
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public String check() throws EngineRuntimeException {
		// TODO Auto-generated method stub
		//sysIntfDaoImpl.checkValidate(sysIntf,data);
		return Constants.EXECUTE_SUCC;
	}

	@Override
	public GlsExtd execute(int orderCount) {
		// TODO Auto-generated method stub
		
		inacTranMapper.insertEntity(command);
		
		//glsExtdMapper.insertEntity(command.getSystid(),command.getTrandt(),command.getTransq(),orderCount,Constants.COMMAND_IDENTITY_IN,command.getAmntcd(),command.getCrcycd(),command.getTranam());
		
		extd = new GlsExtd();
		extd.setStacid(command.getStacid());
		extd.setSystid(command.getSystid());
		extd.setTrandt(command.getTrandt());
		extd.setTranbr(command.getTranbr());
		extd.setTransq(command.getTransq());
		extd.setSortno(orderCount);
		extd.setCmmdtg(Constants.COMMAND_IDENTITY_IA);
		extd.setAmntcd(command.getAmntcd());
		extd.setCrcycd(command.getCrcycd());
		extd.setTranam(command.getTranam());
		extd.setCmmdsq(command.getInacsq());
		
		if(null != pdata.get("subsac")){
			extd.setSubsac(pdata.get("subsac").toString());
		}
		
		return extd;
	}

	@Override
	public TranamInfoEntity getTranamInfo() {
		// TODO Auto-generated method stub
		return new TranamInfoEntity(command.getAmntcd(),command.getTranam());
	}

	public GlsExtdMapper getGlsExtdMapper() {
		return glsExtdMapper;
	}

	public void setGlsExtdMapper(GlsExtdMapper glsExtdMapper) {
		this.glsExtdMapper = glsExtdMapper;
	}

	public InacTranMapper getInacTranMapper() {
		return inacTranMapper;
	}

	public void setInacTranMapper(InacTranMapper inacTranMapper) {
		this.inacTranMapper = inacTranMapper;
	}

	public SystemInterfaceDaoImpl getSysIntfDaoImpl() {
		return sysIntfDaoImpl;
	}

	public void setSysIntfDaoImpl(SystemInterfaceDaoImpl sysIntfDaoImpl) {
		this.sysIntfDaoImpl = sysIntfDaoImpl;
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JSONObject getCmmd() {
		// TODO Auto-generated method stub
		return (JSONObject)JSON.toJSON(command);
	}

}
