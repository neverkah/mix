package com.sunline.sbp.dao;

public interface UnityBusiProcessDao {
	public void markingBusiSuccTransaction(String busicl , String trandt , String transq);
}
