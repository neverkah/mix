package com.sunline.sbp.dao.impl;

import java.util.Hashtable;
import java.util.List;

import com.sunline.foundation.Constants;
import com.sunline.sbp.dao.ComPrsnDao;
import com.sunline.sbp.dao.mapper.ComPrsnMapper;
import com.sunline.sbp.model.ComPrsn;

public class ComPrsnDaoImpl implements ComPrsnDao {
	
	private ComPrsnMapper comPrsnMapper;
	
	private int initail = 0;
	
	/**
	 * ȫ��Ϣ����
	 */
	private static Hashtable<String,ComPrsn> prsnDatas = new Hashtable<String,ComPrsn>();

	@Override
	public List<ComPrsn> getAllEntities() {
		// TODO Auto-generated method stub
		List<ComPrsn> tableData = comPrsnMapper.getAllEntities();
		for(ComPrsn entity : tableData){
			prsnDatas.put(entity.getStacid()+Constants.DTAG+entity.getPrsncd(), entity);
		}
		return tableData;
	}
	
	public Hashtable<String,ComPrsn> getCacheData(){
		if(initail == 0){
			synchronized(this) {
				if(initail == 0){
					getAllEntities();
					initail = 1;
				}
			}
		}
		return prsnDatas;
	}
	
	public boolean frushCache(){
		prsnDatas.clear();
		getAllEntities();
		return true;
	}

	public ComPrsnMapper getComPrsnMapper() {
		return comPrsnMapper;
	}

	public void setComPrsnMapper(ComPrsnMapper comPrsnMapper) {
		this.comPrsnMapper = comPrsnMapper;
	}
	
}
