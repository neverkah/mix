package com.sunline.sbp.dao.impl;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.dao.SysVchrErorDao;
import com.sunline.sbp.dao.mapper.SysVchrErorMapper;
import com.sunline.sbp.model.SysVchrEror;


public class SysVchrErorDaoImpl implements SysVchrErorDao {
	
	private Logger logger = Logger.getLogger(SysVchrErorDaoImpl.class);
	private SysVchrErorMapper sysvchrerorMapper;
	
	public void insert(SysVchrEror sysvchreror) throws AnalyseException{
		try{
			if(null != sysvchreror.getLogmsg() ){
				if(sysvchreror.getLogmsg().length() > 1000){
					sysvchreror.setLogmsg(sysvchreror.getLogmsg().substring(0,1000));
				}
			}else{
				sysvchreror.setLogmsg("no log");
			}
			sysvchrerorMapper.insertEntity(sysvchreror);
		}catch(Exception ex){
			logger.error("���������Ϣʧ�ܡ���������Ϣ��"+sysvchreror.getTrandt()+","+sysvchreror.getVchrsq()+","+sysvchreror.getLogmsg());
			logger.error(ex);
			throw new AnalyseException("��������¼ʧ�ܣ�",ex);
		}
		logger.debug("���������Ϣ�ɹ���");
	}

	public SysVchrErorMapper getSysVchrErorMapper() {
		return sysvchrerorMapper;
	}

	public void setSysVchrErorMapper(SysVchrErorMapper sysvchrerorMapper) {
		this.sysvchrerorMapper = sysvchrerorMapper;
	}
	
	
}
