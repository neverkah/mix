package com.sunline.sbp.dao;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.TempleteMap;

public interface TempleteMapDao {
	public TempleteMap[] getTempleteMaps(TempleteMap templeteMap) throws EngineRuntimeException;
}
