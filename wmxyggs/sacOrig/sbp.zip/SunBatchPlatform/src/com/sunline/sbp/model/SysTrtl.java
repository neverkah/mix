package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * ϵͳ���׷�����(sys_trtl)
 * @author Zhangjin
 *
 */

public class SysTrtl implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1073418848495676742L;
	private int stacid;
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	String prcscd;
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public int getSortno() {
		return sortno;
	}
	public void setSortno(int sortno) {
		this.sortno = sortno;
	}
	public String getTrancd() {
		return trancd;
	}
	public void setTrancd(String dttrcd) {
		this.trancd = dttrcd;
	}
	public String getMaintg() {
		return maintg;
	}
	public void setMaintg(String maintg) {
		this.maintg = maintg;
	}
	public int getTrgpid() {
		return trgpid;
	}
	public void setTrgpid(int trgpid) {
		this.trgpid = trgpid;
	}
	public String getCondcd() {
		return condcd;
	}
	public void setCondcd(String condcd) {
		this.condcd = condcd;
	}
	public String getTrcond() {
		return trcond;
	}
	public void setTrcond(String trcond) {
		this.trcond = trcond;
	}
	public String getChrgtg() {
		return chrgtg;
	}
	public void setChrgtg(String chrgtg) {
		this.chrgtg = chrgtg;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
	int sortno;
	String trancd;
	String maintg;
	int trgpid;
	String condcd;
	String trcond;
	String chrgtg;
	String vermod;
	String module;
	String projcd;
}
