/*
 * (C) 2007-2012 Alibaba Group Holding Limited.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * Authors:
 *   wuhua <wq163@163.com> , boyan <killme2008@gmail.com>
 */
package com.sunline.sbp.application;

import static com.sunline.sbp.application.Help.initMetaConfig;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;

import com.taobao.metamorphosis.Message;
import com.taobao.metamorphosis.client.MessageSessionFactory;
import com.taobao.metamorphosis.client.MetaMessageSessionFactory;
import com.taobao.metamorphosis.client.producer.MessageProducer;
import com.taobao.metamorphosis.client.producer.SendResult;


/**
 * ��Ϣ������
 * 
 * @author boyan
 * @Date 2011-5-17
 * 
 */
public class FIProducer {
	static int msgcount = 0;
	private static Logger logger = Logger.getLogger(FIProducer.class);
    public static void main(final String[] args) throws Exception {
        // New session factory,ǿ�ҽ���ʹ�õ���
        final MessageSessionFactory sessionFactory = new MetaMessageSessionFactory(initMetaConfig());
        // create producer,ǿ�ҽ���ʹ�õ���
        final MessageProducer producer = sessionFactory.createProducer();
        // publish topic
        final String topic = "gl-busi";
        producer.publish(topic);
        
        FileInputStream fis=null;
        try {
        	fis = new FileInputStream("E:\\sungl\\QA_TEST\\entity_busi.txt");
        } catch (FileNotFoundException e) {
        		// TODO Auto-generated catch block
        		e.printStackTrace();
        }

        final InputStreamReader ireader = new InputStreamReader(fis); 
        final BufferedReader reader = new BufferedReader(ireader);
        String line = null;
        long beginT = System.nanoTime();
        while ((line = readLine(reader)) != null) {
            // send message
            final SendResult sendResult = producer.sendMessage(new Message(topic, line.getBytes()));
            // check result
            if (!sendResult.isSuccess()) {
            	logger.debug("Send message failed,error message:" + sendResult.getErrorMessage());
            }
            else {
                //logger.debug(msgcount + " Send message successfully,sent to " + sendResult.getPartition());
            }
        }
        long endT = System.nanoTime();
        logger.debug("�ϼƷ��ͺ�ʱ" + (endT-beginT)/1000000L + "ms");
        reader.close();
        fis.close();
    }

    private static String readLine(final BufferedReader reader) throws IOException {
    	++msgcount;
        return reader.readLine();
    }
}