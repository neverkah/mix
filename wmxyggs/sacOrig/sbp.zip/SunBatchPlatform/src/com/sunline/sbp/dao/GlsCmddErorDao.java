package com.sunline.sbp.dao;

import java.util.List;

import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.model.GlsCmddEror;

public interface GlsCmddErorDao {
	public void insert(GlsCmddEror glscmdderor) throws AnalyseException;
	public void insertBatch(List<GlsCmddEror> list) throws AnalyseException;
}
