package com.sunline.sbp.service;

import java.util.List;

import com.sunline.foundation.ServiceException;
import com.sunline.sbp.model.GlaVoucher;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public interface BusiOnlnService {
	/**
	 * ������ˮ����
	 * @param jsonObject
	 * @return
	 * @throws ServiceException
	 */
	public String busiTransaction(JSONObject jsonObject) throws ServiceException;
	
	/**
	 * 
	 * @param jsonArray
	 * @return
	 * @throws ServiceException
	 */
	public String busiBatchTransaction(JSONArray jsonArray) throws ServiceException;
	
	/**
	 * 
	 * @param jsonArray
	 * @return
	 * @throws ServiceException
	 */
	public String busiSingleTransaction(JSONArray jsonArray) throws ServiceException;
	
	/**
	 * ������ˮ����ƾ֤Ԥ��
	 * @param jsonArray
	 * @return
	 * @throws ServiceException
	 */
	public List<GlaVoucher> busiParsePreview(JSONArray jsonArray) throws ServiceException;
	
	/**
	 * ���ݽ�����ˮ��Ϣ��ѯ���ɵĻ�ƴ�Ʊ
	 * @return
	 * @throws ServiceException
	 */
	public List<GlaVoucher> queryVchrs(JSONObject jsonObject) throws ServiceException;
}
