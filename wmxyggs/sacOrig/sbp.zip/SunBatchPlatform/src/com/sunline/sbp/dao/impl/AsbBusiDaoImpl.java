package com.sunline.sbp.dao.impl;

import com.sunline.sbp.dao.AsbBusiDao;
import com.sunline.sbp.dao.mapper.AsbBusiMapper;
import com.sunline.sbp.model.AsbBusi;

public class AsbBusiDaoImpl implements AsbBusiDao {
	
	private AsbBusiMapper asbBusiMapper;
	
	@Override
	public AsbBusi[] selectBusi(AsbBusi entity) {
		// TODO Auto-generated method stub
		return asbBusiMapper.selectBusi(entity);
	}

	public AsbBusiMapper getAsbBusiMapper() {
		return asbBusiMapper;
	}

	public void setAsbBusiMapper(AsbBusiMapper asbBusiMapper) {
		this.asbBusiMapper = asbBusiMapper;
	}

	@Override
	public void excuteSucc(AsbBusi entity) {
		// TODO Auto-generated method stub
		asbBusiMapper.executeSucc(entity);
	}
	
	
}
