package com.sunline.sbp.dao.mapper;

import com.sunline.sbp.model.ProcessTemplateMap;

public interface ProcessTemplateMapMapper {
	public ProcessTemplateMap[] getTemplMapPrcs(ProcessTemplateMap processTemplateMap);
}
