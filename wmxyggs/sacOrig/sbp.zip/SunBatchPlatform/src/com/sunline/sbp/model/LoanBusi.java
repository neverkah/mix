package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * ����ҵ��Ԫ����
 * @���� 
 * @���� ���ݱ���loan_busi
 * @author liuchj@sunline.cn
 * @project ����ϵͳ�������
 * @data 2014��4��18��
 */
public class LoanBusi {
	private int stacid;
	private String systid;
	private String trandt;
	private String transq;
	private int serino;
	private String bsnssq;
	private String tranbr;
	private String acctbr;
	private String prcscd;
	private String prodcd;
	private String trantp;
	private String crcycd;
	private String bathid;
	public String getBathid() {
		return bathid;
	}
	public void setBathid(String bathid) {
		this.bathid = bathid;
	}
	
	/**
	 * �黹������Ϣ���
	 */
	private String custcd;
	private String status;
	private String loanp1;
	private String loanp2;
	private String loanp3;
	private String loanp4;
	private String loanp5;
	private String loanp6;
	private String loanp7;
	private String loanp8;
	private String loanp9;
	private String loanpa;
	
	private BigDecimal tranam;//���׽��
	private String trprcd;//�������
	private String evetdn;//�¼�����
	
	
	private String centcd;// '�������� ';
	private String prsncd;// 'ְԱ ';
	private String prlncd;// '��Ʒ�� ';
	private String acctno;// '�˻� ';
	private String assis0;// '��������0���Զ��壩';
	private String assis1;// '��������1���Զ��壩';
	private String assis2;// '��������2���Զ��壩';
	private String assis3;// '��������3���Զ��壩';
	private String assis4;// '��������4���Զ��壩';
	private String assis5;// '��������5���Զ��壩';
	private String assis6;// '��������6���Զ��壩';
	private String assis7;// '��������7���Զ��壩';
	private String assis8;// '��������8���Զ��壩';
	private String assis9;// '��������9���Զ��壩';
	
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getPrcscd() {
		return prcscd;
	}
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	public String getTrantp() {
		return trantp;
	}
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public String getLoanp1() {
		return loanp1;
	}
	public void setLoanp1(String loanp1) {
		this.loanp1 = loanp1;
	}
	public String getLoanp2() {
		return loanp2;
	}
	public void setLoanp2(String loanp2) {
		this.loanp2 = loanp2;
	}
	public String getLoanp3() {
		return loanp3;
	}
	public void setLoanp3(String loanp3) {
		this.loanp3 = loanp3;
	}
	public String getLoanp4() {
		return loanp4;
	}
	public void setLoanp4(String loanp4) {
		this.loanp4 = loanp4;
	}
	public String getLoanp5() {
		return loanp5;
	}
	public void setLoanp5(String loanp5) {
		this.loanp5 = loanp5;
	}
	public String getLoanp6() {
		return loanp6;
	}
	public void setLoanp6(String loanp6) {
		this.loanp6 = loanp6;
	}
	public String getBsnssq() {
		return bsnssq;
	}
	public void setBsnssq(String bsnssq) {
		this.bsnssq = bsnssq;
	}
	public String getCustcd() {
		return custcd;
	}
	public void setCustcd(String custcd) {
		this.custcd = custcd;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getLoanp7() {
		return loanp7;
	}
	public void setLoanp7(String loanp7) {
		this.loanp7 = loanp7;
	}
	public String getLoanp8() {
		return loanp8;
	}
	public void setLoanp8(String loanp8) {
		this.loanp8 = loanp8;
	}
	public String getLoanp9() {
		return loanp9;
	}
	public void setLoanp9(String loanp9) {
		this.loanp9 = loanp9;
	}
	public String getLoanpa() {
		return loanpa;
	}
	public void setLoanpa(String loanpa) {
		this.loanpa = loanpa;
	}
	public int getSerino() {
		return serino;
	}
	public void setSerino(int serino) {
		this.serino = serino;
	}
	
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public String getTrprcd() {
		return trprcd;
	}
	public void setTrprcd(String trprcd) {
		this.trprcd = trprcd;
	}
	public String getEvetdn() {
		return evetdn;
	}
	public void setEvetdn(String evetdn) {
		this.evetdn = evetdn;
	}
	public String getCentcd() {
		return centcd;
	}
	public void setCentcd(String centcd) {
		this.centcd = centcd;
	}
	public String getPrsncd() {
		return prsncd;
	}
	public void setPrsncd(String prsncd) {
		this.prsncd = prsncd;
	}
	public String getPrlncd() {
		return prlncd;
	}
	public void setPrlncd(String prlncd) {
		this.prlncd = prlncd;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getAssis0() {
		return assis0;
	}
	public void setAssis0(String assis0) {
		this.assis0 = assis0;
	}
	public String getAssis1() {
		return assis1;
	}
	public void setAssis1(String assis1) {
		this.assis1 = assis1;
	}
	public String getAssis2() {
		return assis2;
	}
	public void setAssis2(String assis2) {
		this.assis2 = assis2;
	}
	public String getAssis3() {
		return assis3;
	}
	public void setAssis3(String assis3) {
		this.assis3 = assis3;
	}
	public String getAssis4() {
		return assis4;
	}
	public void setAssis4(String assis4) {
		this.assis4 = assis4;
	}
	public String getAssis5() {
		return assis5;
	}
	public void setAssis5(String assis5) {
		this.assis5 = assis5;
	}
	public String getAssis6() {
		return assis6;
	}
	public void setAssis6(String assis6) {
		this.assis6 = assis6;
	}
	public String getAssis7() {
		return assis7;
	}
	public void setAssis7(String assis7) {
		this.assis7 = assis7;
	}
	public String getAssis8() {
		return assis8;
	}
	public void setAssis8(String assis8) {
		this.assis8 = assis8;
	}
	public String getAssis9() {
		return assis9;
	}
	public void setAssis9(String assis9) {
		this.assis9 = assis9;
	}
	
}
