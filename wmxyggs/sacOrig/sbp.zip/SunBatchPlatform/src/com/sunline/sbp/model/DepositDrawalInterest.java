package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * ���Ӧ����Ϣ����ָ��
 * @author Hopechj
 *
 */
public class DepositDrawalInterest {
	private int stacid;
	private String systid;
	private String trandt;
	private String cainsq;
	private String transq;
	private String tranbr;
	private String acctbr;
	private String dtitcd;
	private String crcycd;
	private BigDecimal lastbl;
	private BigDecimal tranam;
	private BigDecimal onlnbl;
	private String bkfnst;
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getCainsq() {
		return cainsq;
	}
	public void setCainsq(String cainsq) {
		this.cainsq = cainsq;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getAcctbr() {
		return acctbr;
	}
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	public String getDtitcd() {
		return dtitcd;
	}
	public void setDtitcd(String dtitcd) {
		this.dtitcd = dtitcd;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getLastbl() {
		return lastbl;
	}
	public void setLastbl(BigDecimal lastbl) {
		this.lastbl = lastbl;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public BigDecimal getOnlnbl() {
		return onlnbl;
	}
	public void setOnlnbl(BigDecimal onlnbl) {
		this.onlnbl = onlnbl;
	}
	public String getBkfnst() {
		return bkfnst;
	}
	public void setBkfnst(String bkfnst) {
		this.bkfnst = bkfnst;
	}
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	
	

}
