package com.sunline.sbp.model;

import java.math.BigDecimal;

/**
 * ƾ֤�����ָ��gls_trcm_dcio
 * @author Zhangjin
 *
 */

public class VoucherInVSOut {
	private int stacid;
	private String systid;
	private String trandt;
	private String dciosq;
	private String transq;
	private String tranbr;
	private String dcmttp;
	private String csbxno;
	private String brchcd;
	private String csbxtp;
	private String rcpytg;
	private BigDecimal tranam;
	private String smrycd;
	private String bookus;
	private String ckbkus;
	private String corrtg;
	private String prodcd;
	private String bkfnst;
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getTrandt() {
		return trandt;
	}
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	public String getDciosq() {
		return dciosq;
	}
	public void setDciosq(String dciosq) {
		this.dciosq = dciosq;
	}
	public String getTransq() {
		return transq;
	}
	public void setTransq(String transq) {
		this.transq = transq;
	}
	public String getTranbr() {
		return tranbr;
	}
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	public String getDcmttp() {
		return dcmttp;
	}
	public void setDcmttp(String dcmttp) {
		this.dcmttp = dcmttp;
	}
	public String getCsbxno() {
		return csbxno;
	}
	public void setCsbxno(String csbxno) {
		this.csbxno = csbxno;
	}
	public String getRcpytg() {
		return rcpytg;
	}
	public void setRcpytg(String rcpytg) {
		this.rcpytg = rcpytg;
	}
	public BigDecimal getTranam() {
		return tranam;
	}
	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}
	public String getSmrycd() {
		return smrycd;
	}
	public void setSmrycd(String smrycd) {
		this.smrycd = smrycd;
	}
	public String getBookus() {
		return bookus;
	}
	public void setBookus(String bookus) {
		this.bookus = bookus;
	}
	public String getCkbkus() {
		return ckbkus;
	}
	public void setCkbkus(String ckbkus) {
		this.ckbkus = ckbkus;
	}
	public String getCorrtg() {
		return corrtg;
	}
	public void setCorrtg(String corrtg) {
		this.corrtg = corrtg;
	}
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public String getBrchcd() {
		return brchcd;
	}
	public void setBrchcd(String brchcd) {
		this.brchcd = brchcd;
	}
	public String getCsbxtp() {
		return csbxtp;
	}
	public void setCsbxtp(String csbxtp) {
		this.csbxtp = csbxtp;
	}
	public String getBkfnst() {
		return bkfnst;
	}
	public void setBkfnst(String bkfnst) {
		this.bkfnst = bkfnst;
	}
}
