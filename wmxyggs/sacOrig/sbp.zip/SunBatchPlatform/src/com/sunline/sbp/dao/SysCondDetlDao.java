package com.sunline.sbp.dao;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.model.SysCond;
import com.sunline.sbp.model.SysCondDetl;

public interface SysCondDetlDao {
	public SysCondDetl[] getDetailOfCond(SysCond cond) throws EngineRuntimeException;
	public boolean excuteCondition(SysCondDetl condDetl);
}
