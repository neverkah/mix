package com.sunline.sbp.model;

import java.io.Serializable;

/**
 * ҵ��ģ�����ӳ���(sys_tmap)
 * @author Zhangjin
 *
 */
public class TempleteMap implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3055522259100460027L;
	private String tmpltp;
	private String tmplid;
	private String sortno;
	private String condcd;
	private String proftp;
	private String profid;
	private String retact;
	private String trantg;
	private String mpcdin;
	private String mpcdot;
	private String desctx;
	private String vermod;
	private String module;
	private String projcd;
	public String getTmpltp() {
		return tmpltp;
	}
	public void setTmpltp(String tmpltp) {
		this.tmpltp = tmpltp;
	}
	public String getTmplid() {
		return tmplid;
	}
	public void setTmplid(String tmplid) {
		this.tmplid = tmplid;
	}
	public String getSortno() {
		return sortno;
	}
	public void setSortno(String sortno) {
		this.sortno = sortno;
	}
	public String getCondcd() {
		return condcd;
	}
	public void setCondcd(String condcd) {
		this.condcd = condcd;
	}
	public String getProftp() {
		return proftp;
	}
	public void setProftp(String proftp) {
		this.proftp = proftp;
	}
	public String getProfid() {
		return profid;
	}
	public void setProfid(String profid) {
		this.profid = profid;
	}
	public String getRetact() {
		return retact;
	}
	public void setRetact(String retact) {
		this.retact = retact;
	}
	public String getTrantg() {
		return trantg;
	}
	public void setTrantg(String trantg) {
		this.trantg = trantg;
	}
	public String getMpcdin() {
		return mpcdin;
	}
	public void setMpcdin(String mpcdin) {
		this.mpcdin = mpcdin;
	}
	public String getMpcdot() {
		return mpcdot;
	}
	public void setMpcdot(String mpcdot) {
		this.mpcdot = mpcdot;
	}
	public String getDesctx() {
		return desctx;
	}
	public void setDesctx(String desctx) {
		this.desctx = desctx;
	}
	public String getVermod() {
		return vermod;
	}
	public void setVermod(String vermod) {
		this.vermod = vermod;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getProjcd() {
		return projcd;
	}
	public void setProjcd(String projcd) {
		this.projcd = projcd;
	}
	
	

}
