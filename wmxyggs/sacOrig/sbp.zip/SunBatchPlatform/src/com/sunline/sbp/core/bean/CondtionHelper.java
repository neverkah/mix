package com.sunline.sbp.core.bean;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Stack;

import org.apache.log4j.Logger;

import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.tools.StringUtil;
import com.sunline.sbp.model.SysCondDetl;

/**
 * 
 * @���� ��������
 * @���� 
 * @author liuchj@sunline.cn
 * @project ����ϵͳ�������
 * @data 2014��4��3��
 */
public class CondtionHelper {
	
	
	/**
	 * 
	 * @param detls
	 * @param data
	 * @return
	 */
	public static boolean excute(SysCondDetl[] detls , HashMap<String,Object> data) throws EngineRuntimeException{

		Logger logger = Logger.getLogger(CondtionHelper.class);
		logger.debug("��ʼ������������...");
		logger.debug("��������" + data.toString());
		boolean result = false;
		Stack<String> stack = new Stack<String>();
		
		for(SysCondDetl detl : detls){
			String fildcd = detl.getFildcd();
			String cmptyp = detl.getCmptyp();
			String cmpcod = detl.getCmpcod();
			
			//�����Ž�
			if(StringUtil.isNotNull(detl.getLadstr())){
				stack.push(detl.getLadstr());
			}
			
			
			if(cmptyp.equalsIgnoreCase("C")){
				String fildValue = "";
				if(null != data.get(fildcd)){
					fildValue = data.get(fildcd).toString();
				}else{
					logger.error("��ǰ�ӽ���������������" + fildcd + "��");
				}
				if(cmpcod.equals("=")){
					result = fildValue.equalsIgnoreCase(detl.getCmpval()) ? true : false;
				}else if(cmpcod.equals(">")){
					result = fildValue.compareToIgnoreCase(detl.getCmpval()) > 0 ? true:false;
				}else if(cmpcod.equals("<")){
					result = fildValue.compareToIgnoreCase(detl.getCmpval()) < 0 ? true:false;
				}else if(cmpcod.equals(">=")){
					result = fildValue.compareToIgnoreCase(detl.getCmpval()) >= 0 ? true:false;
				}else if(cmpcod.equals("<=")){
					result = fildValue.compareToIgnoreCase(detl.getCmpval()) <= 0 ? true:false;
				}else if(cmpcod.equals("<>")){
					result = fildValue.compareToIgnoreCase(detl.getCmpval()) != 0 ? true:false;
				}else if(cmpcod.equals("IN")){
					result = detl.getCmpval().indexOf(",".concat(fildValue).concat(",")) >= 0 ? true:false;
				}else if(cmpcod.equals("ISNOTNULL")){
					result = null != fildValue && fildValue.trim().length() > 0 ? true : false;
				}else if(cmpcod.equals("ISNULL")){
					result = null == fildValue || fildValue.trim().length() == 0 ? true : false;
				}else if(cmpcod.equals("NI")){
					result = detl.getCmpval().indexOf(",".concat(fildValue).concat(",")) < 0 ? true:false;
				}else{
					result = Integer.parseInt(detl.getNulret()) == 0 ? false : true;
				}
			}else if(cmptyp.equalsIgnoreCase("N")){
				String fildValueByString = null;
				if(null != data.get(fildcd)){
					fildValueByString = data.get(fildcd).toString();
				}else{
					logger.error("�������в����ڣ�" + fildcd);
				}

				String compValueByString = detl.getCmpval();

				double fildValue = 0 , compValue = 0;
				if(data.containsKey(fildcd) && ((data.get(fildcd) instanceof Double) || (data.get(fildcd) instanceof Float) || (data.get(fildcd) instanceof Integer) || (data.get(fildcd) instanceof Long) || (data.get(fildcd) instanceof BigDecimal))){
					try {
						if(data.get(fildcd) instanceof BigDecimal){
							fildValue =new BigDecimal(data.get(fildcd).toString()).doubleValue();
						}else{
							fildValue = (Double)data.get(fildcd);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						throw new EngineRuntimeException(e);
					}
				}
				
				if(StringUtil.isNumeric(compValueByString)){
					compValue = Float.parseFloat(compValueByString);
				}
				logger.debug("���Ƚ�ֵfildValue:"+fildValue);
				logger.debug("�Ƚ�ֵcompValue:"+compValue);
				if(cmpcod.equals("=")){
					result = Math.abs(fildValue - compValue) < 0.000001 ? true : false;
				}else if(cmpcod.equals(">")){
					result = fildValue - compValue > 0 ? true:false;
				}else if(cmpcod.equals("<")){
					result = fildValue - compValue < 0 ? true:false;
				}else if(cmpcod.equals(">=")){
					result = fildValue - compValue >= 0 ? true:false;
				}else if(cmpcod.equals("<=")){
					result = fildValue - compValue <= 0 ? true:false;
				}else if(cmpcod.equals("<>")){
					result = Math.abs(fildValue - compValue) > 0.000001 ? true:false;
				}else{
					result = Integer.parseInt(detl.getNulret()) ==0 ? false : true;
				}
			}
			
			stack.push(result?"true":"false");
			if(StringUtil.isNotNull(detl.getRadstr())){
				stack.push(detl.getRadstr());
			}
			stack.push(detl.getOprcod());
		}
		
		//���ս��ȥ���������ӷ�
		if(isSymbol(stack.peek())){
			stack.pop();
		}
		
		logger.debug(stack.toString());
		
		return cu(stack);
	}
	
	private static boolean isLeft(String element){
		return element.equalsIgnoreCase("(")?true:false;
	}
	
	private static boolean isRight(String element){
		return element.equalsIgnoreCase(")")?true:false;
	}
	
	//�Ƿ������
	private static boolean isSymbol(String element){
		return element.equalsIgnoreCase("OR") || element.equalsIgnoreCase("AND");
	}
	
	//�Ƿ����㵥λ
	private static boolean isUnit(String element){
		return element.equalsIgnoreCase("true") || element.equalsIgnoreCase("false");
	}
	
	public static boolean cu(Stack<String> stack){
		Stack<String> ing = new Stack<String>();
		while(!stack.isEmpty() && stack.size() >=3){
			if(stack.peek().equals(")")){
				
				String last = stack.pop();
				String second = stack.pop();
				String third = stack.pop();
				if(last.equals(")") && (second.equalsIgnoreCase("true") || second.equalsIgnoreCase("false"))
						&& third.equals("(")){
					stack.push(second);
					while(!ing.isEmpty()){
						stack.push(ing.pop());
					}
				}else{
					stack.push(third);
					stack.push(second);
					ing.push(last);
				}
			}else if(isUnit(stack.peek())){
				String last = stack.pop();
				String second = stack.pop();
				String third = stack.pop();
				if(isUnit(last) && isSymbol(second) && isUnit(third)){
					stack.push(unitOperate(last,second,third));
					
					while(!ing.isEmpty()){
						stack.push(ing.pop());
					}
				}else if(isLeft(last) && isUnit(second) && isRight(third)){
					stack.push(symbolOperate(last,second,third));
					while(!ing.isEmpty()){
						stack.push(ing.pop());
					}
				}else{
					ing.push(last);
					stack.push(third);
					stack.push(second);
				}
			}else if(isSymbol(stack.peek())){
				String last = stack.pop();
				ing.push(last);
			}
		}
		
		return stack.pop().equalsIgnoreCase("true")?true:false;
		
	}
	
	private static String unitOperate(String a , String operator , String b){
		boolean resultBoolean = false;
		boolean aBoolean = a.equalsIgnoreCase("true")?true:false;
		boolean bBoolean = b.equalsIgnoreCase("true")?true:false;
		if(operator.equalsIgnoreCase("AND")){
			resultBoolean = aBoolean && bBoolean;
		}else{
			resultBoolean = aBoolean || bBoolean;
		}
		
		return resultBoolean?"true":"false";
	}
	
	private static String symbolOperate(String a , String unit , String b){
		boolean resultBoolean = false;
		boolean aBoolean = a.equalsIgnoreCase("(")?true:false;
		boolean bBoolean = b.equalsIgnoreCase(")")?true:false;
		if(aBoolean && bBoolean && ( unit.equalsIgnoreCase("true") || unit.equalsIgnoreCase("false"))){
			resultBoolean = unit.equalsIgnoreCase("true")?true:false;
		}else{
			resultBoolean = false;
		}
		
		return resultBoolean?"true":"false";
	}
}
