package com.sunline.onln.application.provider;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.sunline.foundation.Constants;
import com.sunline.foundation.ServiceException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.onln.service.CommandBatchGlService;
import com.sunline.sbp.dao.GlsTranDao;
import com.sunline.sbp.model.GlsTran;
import com.sunline.sbp.service.CommandTranService;


public class CommandBatchGlServiceImpl implements CommandBatchGlService {
	
	private Logger logger = Logger.getLogger(CommandBatchGlServiceImpl.class);
	
	private final int bathNum = 1000;
	
	@Override
	public String brchBatchTransaction(int stacid, String brchcd , String trandt , String systid)
			throws ServiceException {
		// TODO Auto-generated method stub
		
		CommandTranService commandTranService = (CommandTranService) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(CommandTranService.class);
		
		GlsTranDao tranDao = (GlsTranDao) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(GlsTranDao.class);
		
		List<GlsTran> trans = tranDao.getWithBrch(stacid,trandt,brchcd,systid);
		
		logger.info("����["+stacid+"]����ϵͳ["+systid+"]����["+brchcd+"]��������["+trandt+"]����ˮ������������" + trans.size());
		
		List<GlsTran> tranPart = new ArrayList<GlsTran>();
		
		for(int i = 0 ; i < trans.size(); i++){
			tranPart.add(trans.get(i));
			if((i+1) % bathNum == 0 || i == trans.size() -1){
				try {
					commandTranService.goBatTransaction(tranPart);
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					String msg = "������ˮ����������" + e.getMessage();
					logger.error(msg, e);
				}catch(Exception e1){
					String msg = "������ˮ�����쳣��";
					logger.error(msg, e1);
				}finally{
					logger.info("����["+brchcd+"]������ˮ"+tranPart.size()+"����ɡ�");
					tranPart.clear();
				}
			}
		}
		return Constants.EXECUTE_SUCC;
	}
}
