package com.sunline.onln.application.provider;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.foundation.ServiceException;
import com.sunline.onln.service.BusiGLService;
import com.sunline.sbp.common.GliMslgUtil;
import com.sunline.sbp.model.GlaVoucher;
import com.sunline.sbp.service.BusiOnlnService;

/**
 * ���ܣ�ʵʱƾ֤��������
 * ����������ҵ����ˮ�����ɻ�Ʒ�¼
 * @author liuchj@sunline.cn
 *
 */
public class BusiGLServiceImpl implements BusiGLService {
	
	Logger logger = Logger.getLogger(BusiGLServiceImpl.class);
	
	BusiOnlnService busiOnlnService = null;

	@Override
	public String busiTransaction(String bussinessInfo) {
		// TODO Auto-generated method stub
		JSONObject jsonObject = null;
    	String executeMsg = Constants.EXECUTE_NULL;
    	// ������־
    	String paerlg = "";
    	// ���Ľ���״̬
    	String pastau = "";
    	logger.debug("������ˮ��Ϣ��---------------------------------------");
    	logger.debug(bussinessInfo);
    	// ���ձ���ʱ��
		Timestamp recedt = new Timestamp(System.currentTimeMillis());

    	try{
    		jsonObject = JSONObject.parseObject(bussinessInfo);
    	}catch(Exception ex){
    		logger.error("ҵ����ˮ��ʽ����");
    		logger.error(bussinessInfo);
    		executeMsg = "ҵ����ˮ��ʽ����";
    		paerlg = "ҵ����ˮ��ʽ����";
    	}
		
			
    	logger.debug("תΪJSONObject֮��" + jsonObject);
    	try{
    		executeMsg = busiOnlnService.busiTransaction(jsonObject);
    		//����״̬Ϊ�ɹ�
    		pastau = Enumeration.Status.S.value;
    	}catch(ServiceException exe){
    		executeMsg = exe.getMessage();
    		paerlg = exe.getMessage();
    		// ����״̬Ϊʧ��
    		pastau = Enumeration.Status.F.value;
    		logger.error(executeMsg,exe);
    	}catch(Exception ex){
    		executeMsg = "ϵͳ�쳣";
    		paerlg = ex.getMessage();
    		// ����״̬Ϊʧ��
    		pastau = Enumeration.Status.F.value;
    		logger.error(executeMsg,ex);
    	}finally{
    		logger.debug("//~������ˮ��Ϣ��---------------------------------------");
    		Timestamp respdt   = new Timestamp(System.currentTimeMillis());
    		// ��¼ʵʱ������־
    		GliMslgUtil.writeLog(bussinessInfo, jsonObject, recedt, respdt, executeMsg,Enumeration.Mstype.JYLS.value);
    	}
		return executeMsg;
	}
	
	@Override
	public String busiTransactionSingle(String tranMessage) {
		// TODO Auto-generated method stub
		JSONArray jsonArray = null;
    	String executeMsg = Constants.EXECUTE_NULL;
    	logger.fatal("������ˮ��Ϣ��---------------------------------------");
    	logger.fatal("MESSAGE MD5=>"+DigestUtils.md5Hex(tranMessage));
    	try{
    		//jsonArray = JSONArray.fromObject(tranMessage);
    		jsonArray = JSONArray.parseArray(tranMessage);
    	}catch(Exception ex){
    		logger.error("ҵ����ˮ��ʽ���󣺷�JSON���ݸ�ʽ");
    		logger.error(tranMessage);
    		executeMsg = "ҵ����ˮ��ʽ����";
    	}
    	try{
    		executeMsg = busiOnlnService.busiSingleTransaction(jsonArray);
    	}catch(ServiceException exe){
    		executeMsg = exe.getMessage();
    		logger.error(executeMsg,exe);
    	}catch(Exception ex){
    		executeMsg = "ϵͳ�쳣";
    		logger.error(executeMsg,ex);
    	}finally{
    		logger.fatal("//~������ˮ��Ϣ��---------------------------------------");
    	}
		return executeMsg;
	}

	@Override
	public String busiTransactionBatch(String tranMessage) {
		// TODO Auto-generated method stub
		JSONArray jsonArray = null;
    	String executeMsg = Constants.EXECUTE_NULL;
    	logger.debug("������ˮ��Ϣ��---------------------------------------");
    	logger.fatal("MESSAGE MD5=>"+DigestUtils.md5Hex(tranMessage));
    	try{
    		//jsonArray = JSONArray.fromObject(tranMessage);
    		jsonArray = JSONArray.parseArray(tranMessage);
    	}catch(Exception ex){
    		logger.error("ҵ����ˮ��ʽ���󣺷�JSON���ݸ�ʽ");
    		logger.error(tranMessage);
    		executeMsg = "ҵ����ˮ��ʽ����";
    	}
    	try{
    		executeMsg = busiOnlnService.busiBatchTransaction(jsonArray);
    	}catch(ServiceException exe){
    		executeMsg = exe.getMessage();
    		logger.error(executeMsg,exe);
    	}catch(Exception ex){
    		executeMsg = "ϵͳ�쳣";
    		logger.error(executeMsg,ex);
    	}finally{
    		logger.debug("//~������ˮ��Ϣ��---------------------------------------");
    	}
		return executeMsg;
	}
	
	@Override
	public String busiParsePreview(String tranMessage) {
		// TODO Auto-generated method stub
		JSONArray jsonArray = null;
    	String executeMsg = Constants.EXECUTE_NULL;
    	HashMap<String,Object> response = new HashMap<String,Object>();
    	List<GlaVoucher> listVouchers = new ArrayList<GlaVoucher>();
    	logger.debug("������ˮ��Ϣ��---------------------------------------");
    	logger.debug(tranMessage);
    	try{
    		jsonArray = JSONArray.parseArray(tranMessage);
    	}catch(Exception ex){
    		logger.error("ҵ����ˮ��ʽ���󣺷�JSON���ݸ�ʽ");
    		logger.error(tranMessage);
    		executeMsg = "ҵ����ˮ��ʽ����";
    	}
    	
    	try{
    		listVouchers = busiOnlnService.busiParsePreview(jsonArray);
    		response.put("vchrs", listVouchers);
    	}catch(ServiceException exe){
    		response.put("errcode", Constants.EXECUTE_FAIL);
    		executeMsg = exe.getMessage();
    		response.put("errmsg", executeMsg);
    		logger.error(executeMsg,exe);
    	}catch(Exception ex){
    		response.put("errmsg", Constants.EXECUTE_EXCEPTION);
    		executeMsg = "ϵͳ�쳣";
    		response.put("errmsg", "ϵͳ�쳣");
    		logger.error(executeMsg,ex);
    	}finally{
    		logger.debug("//~������ˮ��Ϣ��---------------------------------------");
    	}
		return JSONObject.toJSONString(response);
	}
	
	@Override
	public String busiFetchVchr(String bussinessInfo) {
		// TODO Auto-generated method stub
		JSONObject jsonObject = null;
		List<GlaVoucher> list = null;
		Map<String,Object> msgMap = new HashMap<String,Object>();
		String errcode = Constants.QUERY_BUSI_PARSE_EXCEPTION;
		String errmsg = "";
    	logger.debug("������Ϣ��---------------------------------------");
    	logger.debug(bussinessInfo);
    	try{
    		jsonObject = JSONObject.parseObject(bussinessInfo);
    	}catch(Exception ex){
    		logger.error("ҵ����ˮ��ʽ����");
    		logger.error(bussinessInfo);
    		return "�������ݸ�ʽ����";
    	}
    	
    	logger.debug("תΪJSONObject֮��" + jsonObject);
    	
    	try{
    		list = busiOnlnService.queryVchrs(jsonObject);
    		
    		if(null != list && list.size() > 0){
    			errcode = Constants.QUERY_BUSI_PARSE_SUCC;
    			msgMap.put("vchrs", JSONObject.parseArray(JSONObject.toJSONString(list), HashMap.class));
    		}else{
    			errcode = Constants.QUERY_BUSI_PARSE_FAIL;
    		}
    		
    	}catch(ServiceException exe){
    		errmsg = exe.getMessage();
    		logger.error(errmsg,exe);
    	}catch(Exception ex){
    		errmsg = "ϵͳ�쳣";
    		logger.error(errmsg,ex);
    	}finally{
    		logger.debug("//~������Ϣ---------------------------------------");
    	}
    	msgMap.put("errcode", errcode);
    	msgMap.put("errmsg", errmsg);
    	
    	
    	JSONObject.toJSONString(list);
    	
		return JSONObject.toJSONString(msgMap);
	}

	public BusiOnlnService getBusiOnlnService() {
		return busiOnlnService;
	}

	public void setBusiOnlnService(BusiOnlnService busiOnlnService) {
		this.busiOnlnService = busiOnlnService;
	}
}
