package com.sunline.onln.service;

import com.sunline.foundation.ServiceException;

public interface CommandBatchGlService {
	public String brchBatchTransaction(int stacid, String brchcd , String trandt , String systid) throws ServiceException;
}
