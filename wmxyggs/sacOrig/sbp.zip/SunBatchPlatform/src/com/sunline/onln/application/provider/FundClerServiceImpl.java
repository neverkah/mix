package com.sunline.onln.application.provider;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.Constants;
import com.sunline.foundation.ServiceException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.onln.service.FundClerService;
import com.sunline.sbp.service.FundClearingService;
import com.sunline.sbp.service.impl.FundClearingServiceImpl;

public class FundClerServiceImpl implements FundClerService {
	
	private Logger logger = Logger.getLogger(FundClearingServiceImpl.class);
	
	FundClearingServiceImpl fundClearingService;
	
	private String executeMsg;

	@Override
	public String running(String bussinessInfo) {
		
		JSONObject jsonObject = null;
		int stacid = 0;
		try{
    		jsonObject = JSONObject.parseObject(bussinessInfo);
    		stacid = jsonObject.getIntValue("stacid");
    		logger.debug("������������:" + stacid);
    	}catch(Exception ex){
    		logger.error("ҵ����ˮ��ʽ����");
    		logger.error(bussinessInfo);
    		executeMsg = "ҵ����ˮ��ʽ����";
    	}
		
		try{
			
			FundClearingService fundClerService = (FundClearingService)ApplicationBeanFactory.getApplicationContextInstance().getBean(FundClearingService.class);
			fundClerService.runningTransaction(stacid);
			
    		executeMsg = Constants.EXECUTE_SUCC;
    	}catch(ServiceException exe){
    		logger.error(exe);
    		executeMsg = exe.getMessage();
    	}catch(Exception ex){
    		logger.error(ex);
    		executeMsg = "ϵͳ�쳣";
    	}finally{
    		logger.debug("//~������ˮ��Ϣ��---------------------------------------");
    	}
		return executeMsg;
	}

	public FundClearingServiceImpl getFundClearingService() {
		return fundClearingService;
	}

	public void setFundClearingService(FundClearingServiceImpl fundClearingService) {
		this.fundClearingService = fundClearingService;
	}
	
	
}
