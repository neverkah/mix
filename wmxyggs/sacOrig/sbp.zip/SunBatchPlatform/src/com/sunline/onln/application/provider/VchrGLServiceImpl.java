package com.sunline.onln.application.provider;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.sunline.foundation.Constants;
import com.sunline.foundation.Enumeration;
import com.sunline.foundation.ServiceException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.onln.service.VchrGLService;
import com.sunline.sbp.common.GliMslgUtil;
import com.sunline.sbp.service.GliVchrPassService;

public class VchrGLServiceImpl implements VchrGLService {
	
	private Logger logger = Logger.getLogger(VchrGLServiceImpl.class);

	@Override
	public String vchrTransaction(String vchrEntity) {
		// ���ձ���ʱ��
		Timestamp recedt = new Timestamp(System.currentTimeMillis());
		// ���ر���ʱ��
		Timestamp respdt = null;
		JSONArray jsonArray = null;
    	String executeMsg = Constants.EXECUTE_NULL;
    	try{
    		jsonArray = JSON.parseArray(vchrEntity);
    	}catch(Exception ex){
    		executeMsg = Constants.EXECUTE_DATA_EXCEPTION + ";" + ex.getMessage();
    		logger.error(executeMsg,ex);
    		 respdt   = new Timestamp(System.currentTimeMillis());
     		//��¼ʵʱ������־
     		GliMslgUtil.writeLog(vchrEntity, null, recedt, respdt,  executeMsg,Enumeration.Mstype.CPLS.value);
     		return executeMsg;
    	}finally{
    		logger.debug("vchr message:" + vchrEntity);
    		logger.debug("vchr message###########");
    	}
    	try{
    		GliVchrPassService gliVchrPassService = (GliVchrPassService)ApplicationBeanFactory.getApplicationContextInstance().getBean(GliVchrPassService.class);
    		gliVchrPassService.vchrTransaction(jsonArray);
    		executeMsg = Constants.EXECUTE_SUCC;
    	}catch(ServiceException ex){
    		executeMsg = Constants.EXECUTE_FAIL + ";" + ex.getMessage();
    		logger.error(executeMsg,ex);
    	}catch(Exception ex){
    		executeMsg = Constants.EXECUTE_EXCEPTION + ";" + ex.getMessage();
    		logger.error(executeMsg,ex);
    	}finally{
    		 respdt   = new Timestamp(System.currentTimeMillis());
    		//��¼ʵʱ������־
    		GliMslgUtil.writeLog(vchrEntity, jsonArray.getJSONObject(0), recedt, respdt,  executeMsg,Enumeration.Mstype.CPLS.value);
    	}
    	
    
		return executeMsg;
	}

}
