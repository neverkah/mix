package com.sunline.onln.service;

public interface VchrGLService {
	public String vchrTransaction(String vchrEntity);
}
