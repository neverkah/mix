package com.sunline.onln.application.provider;

import java.util.Hashtable;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.Constants;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.sbp.dao.AccountingItemDao;
import com.sunline.sbp.model.AccountingItem;

public class TestItem {
	public static void main(String[] args){
		AccountingItemDao glstrandao = (AccountingItemDao) ApplicationBeanFactory
				.getApplicationContextInstance().getBean(
						AccountingItemDao.class);
		
		try {
			Hashtable<String,AccountingItem> itemDatas = new Hashtable<String,AccountingItem>();
			AccountingItem[] tableDatas = glstrandao.getEntitiesOfTable(1);
			for(AccountingItem tableData : tableDatas){
				itemDatas.put(String.valueOf(1).concat(Constants.MIDTQG).concat(tableData.getItemcd()), tableData);
			}
			String itemcd = "20110501";
			AccountingItem itemInfo = itemDatas.get(String.valueOf(1).concat(Constants.MIDTQG).concat(itemcd));
			
			if(null == itemInfo){
				System.out.println("not find");
			}
			
		} catch (AnalyseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
}
