package com.sunline.onln.application.provider;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sunline.onln.service.BusiGLService;


public class Consumer {
	
	static int id = 0;
	
	private static Logger logger = Logger.getLogger(Consumer.class);
	
	public static void main(String[] args) throws Exception {
		
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:ApplicationContext-consumer.xml"});
        context.start();
 
        BusiGLService demoService = (BusiGLService)context.getBean("busiService"); // ��ȡԶ�̷������
        
        	FileInputStream fis=null;
            try {
            	fis = new FileInputStream("E:\\sungl\\QA_TEST\\busi_1.txt");
            } catch (FileNotFoundException e) {
            		// TODO Auto-generated catch block
            		e.printStackTrace();
            }

            final InputStreamReader ireader = new InputStreamReader(fis); 
            final BufferedReader reader = new BufferedReader(ireader);
            String line = null;
            //while ((line = reader.readLine()) != null) {
            while (id < 10) {
            	String hello = demoService.busiTransaction(getMess()); // ִ��Զ�̷���
            	logger.debug( hello ); // ��ʾ���ý��
            }
        
    }
	
	private static String getMess(){
		id = id + 1;
		String msd = "{\"asetno\":\"1\",\"asettp\":\"010001\",\"busiType\":\"010001\",\"crcycd\":\"01\",\"devvvl\":0,\"dpravl\":0,\"inchvl\":1,\"incmvl\":0,\"outtvl\":0,\"prcscd\":\"asbreg\",\"publvl\":0,\"smrytx\":\"�̶��ʲ�����\",\"status\":\"0\",\"systid\":\"fi\",\"tobrch\":\"\",\"tranbr\":\"010001\",\"trandt\":\"20121221\",\"transq\":\"01"+id+"\",\"trantp\":\"TR\"}";
		return msd;
	}
}
