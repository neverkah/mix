package com.sunline.onln.service;

public interface BusiGLService {
	public String busiTransaction(String tranMessage);
	public String busiTransactionSingle(String tranMessage);
	public String busiTransactionBatch(String tranMessage);
	public String busiParsePreview(String tranMessage);
	public String busiFetchVchr(String tranMessage);
}
