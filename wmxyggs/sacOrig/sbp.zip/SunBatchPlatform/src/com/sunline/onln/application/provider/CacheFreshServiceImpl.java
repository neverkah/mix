package com.sunline.onln.application.provider;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.ServiceException;
import com.sunline.foundation.tools.ApplicationBeanFactory;
import com.sunline.onln.service.CacheFreshService;
import com.sunline.sbp.service.CacheFreshAction;

/**
 * ���ܣ�ʵʱƾ֤��������
 * ����������ҵ����ˮ�����ɻ�Ʒ�¼
 * @author liuchj@sunline.cn
 *
 */
public class CacheFreshServiceImpl implements CacheFreshService {
	
	Logger logger = Logger.getLogger(CacheFreshServiceImpl.class);

	@Override
	public String fresh(String bussinessInfo) {
		// TODO Auto-generated method stub
		JSONObject jsonObject = null;
    	String executeMsg = "FAIL";
    	logger.debug("������ˮ��Ϣ��---------------------------------------");
    	logger.debug(bussinessInfo);
    	try{
    		jsonObject = JSONObject.parseObject(bussinessInfo);
    	}catch(Exception ex){
    		logger.error("ҵ����ˮ��ʽ����");
    		logger.error(bussinessInfo);
    		executeMsg = "ҵ����ˮ��ʽ����";
    	}
    	try{
    		CacheFreshAction frechCacheService = (CacheFreshAction)ApplicationBeanFactory.getApplicationContextInstance().getBean(CacheFreshAction.class);
    		executeMsg = frechCacheService.operate(jsonObject);
    	}catch(ServiceException exe){
    		executeMsg = exe.getMessage();
    		logger.error(executeMsg,exe);
    	}catch(Exception ex){
    		executeMsg = "ϵͳ�쳣";
    		logger.error(executeMsg,ex);
    	}finally{
    		logger.debug("//~������ˮ��Ϣ��---------------------------------------");
    	}
		return executeMsg;
	}

}
