package com.sunline.onln.service;

public interface FundClerService {
	public String running(String message);
}
