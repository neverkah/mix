package com.sunline.onln.service;

public interface CacheFreshService {
	public String fresh(String jsonMessage);
}
