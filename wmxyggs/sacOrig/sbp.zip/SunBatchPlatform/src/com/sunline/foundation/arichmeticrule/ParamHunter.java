package com.sunline.foundation.arichmeticrule;

import java.util.ArrayList;
import java.util.HashMap;

import com.sunline.foundation.AnalyseException;

public class ParamHunter implements RuleArichmeticObject{
	private HashMap<String , Object> dataContext;
	private HashMap<String , Object> newData = new HashMap<String,Object>();

	@Override
	public void initialize(HashMap<String, Object> data) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calculate(ArrayList<Object> destination,
			ArrayList<Object> source) throws AnalyseException {
		// TODO Auto-generated method stub
		newData.put("clerBrch_headbank", "000002");
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return newData;
	}

}
