package com.sunline.foundation;

import java.lang.reflect.Field;
import java.util.HashMap;

public class ObjectToHashMap {
	public static HashMap<String , Object> convert(Object beanObject){
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		Field[] fields = beanObject.getClass().getDeclaredFields();
		
		//˽�г�Ա����
		for (Field field : fields) {
			Object objVal = null;
			field.setAccessible(true);
			try {
				objVal = field.get(beanObject);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (objVal != null) {
				hashMap.put(field.getName(), objVal);
			}
		}
		
		return hashMap;

	}
}
