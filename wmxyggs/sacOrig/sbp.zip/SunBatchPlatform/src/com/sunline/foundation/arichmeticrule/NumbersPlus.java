package com.sunline.foundation.arichmeticrule;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.DataObjectUtil;
import com.sunline.foundation.tools.StringUtil;

public class NumbersPlus implements RuleArichmeticObject {

	private HashMap<String, Object> dataContext;
	private HashMap<String, Object> newData = new HashMap<String, Object>();
	Logger logger = Logger.getLogger(NumbersPlus.class);

	@Override
	public void initialize(HashMap<String, Object> data) {
		// TODO Auto-generated method stub
		this.dataContext = data;
		logger.debug("");
	}

	@Override
	public void calculate(ArrayList<Object> destination,
			ArrayList<Object> source) throws AnalyseException {
		// TODO Auto-generated method stub
		
		logger.debug("���������ϵĲ�����:" + source.toString());
		BigDecimal sum = new BigDecimal(0);
		
		for(Object keyObject : source){
			Object value = DataObjectUtil.getHashMapStr(dataContext, keyObject.toString());
			if (!StringUtil.isNumeric(value.toString())) {
				if (!(value instanceof Double)
						|| (value instanceof Float)
						|| (value instanceof Long) || (value instanceof Integer)) {
					logger.error("������" + keyObject.toString() + "="
							+ value
							+ "��Ϊ����");
					throw new AnalyseException("������"
							+ keyObject.toString() + "="
							+ value
							+ "��Ϊ����");
				}
			}else{
				sum = sum.add(DataObjectUtil.getBigDecimalValue(dataContext, keyObject.toString()));
			}
		}

		if (destination.size() != 1) {
			logger.error("���������ֻ������һ����" + destination.toString());
			throw new AnalyseException("���������ֻ������һ����" + destination.toString());
		} else {
			logger.debug("���������:" + destination.toString());
		}

		logger.debug("��ֵ֮����������" + sum);
		newData.put(destination.get(0).toString(), sum);
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return newData;
	}

}
