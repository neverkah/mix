package com.sunline.foundation.arichmeticrule;

import java.util.ArrayList;
import java.util.HashMap;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.DataObjectUtil;

public class ConactParameter implements RuleArichmeticObject {
	
	private HashMap<String , Object> dataContext;
	private HashMap<String , Object> newData = new HashMap<String , Object>();
	
	@Override
	public void initialize(HashMap<String, Object> data) {
		// TODO Auto-generated method stub
		this.dataContext = data;
	}

	@Override
	public void calculate(ArrayList<Object> destination,
			ArrayList<Object> source) throws AnalyseException {
		// TODO Auto-generated method stub
		String newString = "";
		for(Object object : source){
			Object value = DataObjectUtil.getHashMapStr(dataContext, object.toString());
			newString = newString.concat(value.toString());
		}
		newData.put(destination.get(0).toString(), newString);
		
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return newData;
	}

}
