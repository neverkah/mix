package com.sunline.foundation.arichmeticrule;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

public class SetParameter implements RuleArichmeticObject{
	
	private HashMap<String , Object> dataContext;
	private HashMap<String , Object> newData = new HashMap<String,Object>();
	
	private Logger logger = Logger.getLogger(SetParameter.class);
	
	@Override
	public void initialize(final HashMap<String, Object> data) {
		// TODO Auto-generated method stub
		this.dataContext = data;
	}

	@Override
	public void calculate(ArrayList<Object> destination,
			ArrayList<Object> source) {
		// TODO Auto-generated method stub
		
		for(int index = 0 ; index < destination.size() ; index++){
			String desStr = destination.get(index).toString();
			newData.put(desStr, source.get(index));
			logger.debug(desStr + "��ֵ["+dataContext.get(desStr)+"]����Ϊ" + source.get(index).toString());
		}
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return newData;
	}

}
