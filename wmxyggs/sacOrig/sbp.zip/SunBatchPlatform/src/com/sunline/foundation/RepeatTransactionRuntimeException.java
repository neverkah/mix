package com.sunline.foundation;

public class RepeatTransactionRuntimeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public RepeatTransactionRuntimeException(){
		super();
	}
	
	public RepeatTransactionRuntimeException(String msg){
		super(msg);
	}
}
