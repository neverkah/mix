package com.sunline.foundation;

import org.apache.log4j.Logger;

import com.sunline.foundation.tools.StringUtil;

public class ProductGenerator {
	public static String getProductCode(String trprcd , String asettp){
		
		Logger logger = Logger.getLogger(ProductGenerator.class);
		
		logger.debug("׼��������Ϣ typecd=" + asettp + ",trprcd=" + trprcd);
		
		String dtitcd = null;
		
		if(StringUtil.isNotNull(trprcd) && StringUtil.isNotNull(asettp)){
			dtitcd = asettp.concat(trprcd);
			logger.debug("���ɺ������ɹ���dtitcd=" + dtitcd);
			return dtitcd;
		}else{
			if( !StringUtil.isNotNull(trprcd)){
				logger.error("::::: ҵ���������Ϊ��trprcd=" + trprcd);
			}
			if(!StringUtil.isNotNull(asettp)){
				logger.error("::::: ���Ͳ���Ϊ��asettp=" + asettp);
			}
			
			try {
				throw new AnalyseException("���ɺ������ʧ��");
			} catch (AnalyseException e) {
				// TODO Auto-generated catch block
				logger.error(e.getStackTrace());
			}
			return null;
		}
		
	}
}
