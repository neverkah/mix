package com.sunline.foundation;

public class ProfParaGenerator {

}
