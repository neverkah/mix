package com.sunline.foundation.arichmeticrule;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.sbp.dao.impl.ComCrcyDaoImpl;
import com.sunline.sbp.dao.impl.SysDtitConfDaoImpl;
import com.sunline.sbp.dao.impl.TxpTypeCfgDaoImp;
import com.sunline.sbp.model.ComCrcy;
import com.sunline.sbp.model.SysDtitConf;
import com.sunline.sbp.model.TxpTypeCfg;
import com.sunline.sbp.model.TxpTypeOpen;


public class GLPriceTaxSeparatedRule implements RuleArichmeticObject{
	
	private HashMap<String , Object> dataContext;
	private HashMap<String , Object> newData = new HashMap<String,Object>();
	
	private Logger logger = Logger.getLogger(GLPriceTaxSeparatedRule.class);
	
	private TxpTypeCfgDaoImp txtpMapImp;
	private SysDtitConfDaoImpl sysDtitConfDao;
	private ComCrcyDaoImpl comCrcyDao;
	
	@Override
	public void initialize(final HashMap<String, Object> data) {
		// TODO Auto-generated method stub
		this.dataContext = data;
	}

	@Override
	public void calculate(ArrayList<Object> destination,
			ArrayList<Object> source) {
		// TODO Auto-generated method stub
		int stacid = (Integer)dataContext.get("stacid");
		String prodcd = (String)dataContext.get("prodcd");
		String loanp1 = (String)dataContext.get("loanp1");
		String loanp2 = (String)dataContext.get("loanp2");
		String loanp3 = (String)dataContext.get("loanp3");
		String loanp4 = (String)dataContext.get("loanp4");
		String loanp5 = (String)this.dataContext.get("loanpa");
	    String loanp6 = (String)this.dataContext.get("loanp7");
	    String loanp7 = "*"; String loanp8 = "*"; String loanp9 = "*"; String loanpa = "*";
		try {
			
			SysDtitConf confINfo = sysDtitConfDao.getProdcdProperties(stacid, prodcd);
			if(confINfo.getProdp1().equals("0")){
				loanp1 = "*";
			}
			if(confINfo.getProdp2().equals("0")){
				loanp2 = "*";
			}
			if(confINfo.getProdp3().equals("0")){
				loanp3 = "*";
			}
			if(confINfo.getProdp4().equals("0")){
				loanp4 = "*";
			}
			TxpTypeOpen[] txptypeopens = txtpMapImp.getTxpTypeOpen(stacid);
			for(TxpTypeOpen entity:txptypeopens){
				if(entity.getPropcd().equals("prodp1")){
					loanp1 = "*";
				}
				if(entity.getPropcd().equals("prodp2")){
					loanp2 = "*";
				}
				if(entity.getPropcd().equals("prodp3")){
					loanp3 = "*";
				}
				if(entity.getPropcd().equals("prodp4")){
					loanp4 = "*";
				}
				if(entity.getPropcd().equals("prodp5")){
					loanp5 = "*";
				}
				if(entity.getPropcd().equals("prodp6")){
					loanp6 = "*";
				}
				if(entity.getPropcd().equals("prodp7")){
					loanp7 = "*";
				}
				if(entity.getPropcd().equals("prodp8")){
					loanp8 = "*";
				}
				if(entity.getPropcd().equals("prodp9")){
					loanp9 = "*";
				}
				if(entity.getPropcd().equals("prodpa")){
					loanpa = "*";
				}
			}
			TxpTypeCfg txtpmap = txtpMapImp.getEntityByPrimaryKey(stacid,prodcd,loanp1,loanp2,loanp3,loanp4,loanp5,loanp6,loanp7,loanp8,loanp9,loanpa);
			if(null == txtpmap){
				newData.put("opracd","*");
				newData.put("inout","*");
			}else{
				if (txtpmap != null) {
					String inout = txtpmap.getTaxvtg(); //���������ʾ
					String opracd = txtpmap.getOpracd();//���붯��
					BigDecimal vatxrt = txtpmap.getVatxrt();//˰��
					String typecd = txtpmap.getTypecd(); //˰Ŀ
					String catxtp = txtpmap.getCatxtp(); //��˰��ʽ��S�����׼�˰��N��һ���˰��
					String exeptg = txtpmap.getExeptg(); //Ӧ˰��־��0����˰�ʣ�1���ǣ�N����˰��*����Ч����������������
					BigDecimal tranam = (BigDecimal)dataContext.get("captam");
					BigDecimal vat = new BigDecimal(1.0d + vatxrt.doubleValue() / 100) ;
					BigDecimal price = new BigDecimal(0);
					BigDecimal vatxam = new BigDecimal(0);
					/*if(!inout.isEmpty()){
						price = tranam.divide(vat, 2, BigDecimal.ROUND_HALF_UP);
						vatxam = tranam.subtract(price);
					}*/
					//modify by zhangdq ����С��λ�Ĵ���������Ԫ���ܳ���С��
					if(!inout.isEmpty()){
						String crcycd = (String)this.dataContext.get("crcycd");//����
						ComCrcy comCrcyInfo = this.comCrcyDao.getComCrcyByPrimKey(crcycd);
						int crcydg = comCrcyInfo.getCrcydg();//����С��λ
						price = tranam.divide(vat, crcydg, BigDecimal.ROUND_HALF_UP);
						vatxam = tranam.subtract(price);
					}
					newData.put("price",price);
					newData.put("vatxam",vatxam);
					newData.put("txtpcd",typecd);
					newData.put("exeptg",exeptg);
					newData.put("inout",inout);
					newData.put("vatxrt",vatxrt);
					newData.put("nwtrpr","NI00"); //����˰��ֵ�������ԣ�
					newData.put("opracd",opracd);
					newData.put("catxtp",catxtp);
				}
			}
		} catch (AnalyseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (EngineRuntimeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return newData;
	}
	
	public SysDtitConfDaoImpl getSysDtitConfDao() {
		return sysDtitConfDao;
	}

	public void setSysDtitConfDao(SysDtitConfDaoImpl sysDtitConfDao) {
		this.sysDtitConfDao = sysDtitConfDao;
	}
	
	public ComCrcyDaoImpl getComCrcyDao() {
		return comCrcyDao;
	}

	public void setComCrcyDao(ComCrcyDaoImpl comCrcyDao) {
		this.comCrcyDao = comCrcyDao;
	}
	
	public TxpTypeCfgDaoImp getTxpTypeCfgDao() {
		return txtpMapImp;
	}

	public void setTxpTypeCfgDao(TxpTypeCfgDaoImp txpTypeCfgDao) {
		this.txtpMapImp = txpTypeCfgDao;
	}
	
}
