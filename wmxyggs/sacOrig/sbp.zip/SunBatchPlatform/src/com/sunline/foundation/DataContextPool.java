package com.sunline.foundation;

import java.util.HashMap;

public class DataContextPool {
	private HashMap<String , Object> dataContext = null;
	
	public void initialize(HashMap<String , Object> data){
		dataContext = data;
	}
	
	public HashMap<String , Object> getDataContext() throws AnalyseException{
		if (null != dataContext){
			return dataContext;
		}else{
			throw new AnalyseException("����������δ��ʼ��");
		}
	}
	
}
