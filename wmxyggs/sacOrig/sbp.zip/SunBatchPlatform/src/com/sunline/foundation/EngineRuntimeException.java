package com.sunline.foundation;

public class EngineRuntimeException extends ServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public EngineRuntimeException(String message){
		super(message);
	}
	
	public EngineRuntimeException(String message , Throwable throwable){
		super(message,throwable);
	}
	
	public EngineRuntimeException(Throwable throwable){
		super(throwable);
	}

}
