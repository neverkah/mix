package com.sunline.foundation.tools;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * ���ù���(Spring)
 * @author Hopechj
 *
 */
public class ApplicationBeanFactory {
	
	final static String[] config = new String[]{"classpath:ApplicationContext.xml"};
	
	private static Logger logger = Logger.getLogger(ApplicationBeanFactory.class);
	
	private static ApplicationContext applicationContext = null;

	private ApplicationBeanFactory(){};
	
	public static ApplicationContext getApplicationContextInstance() {
		if(null == applicationContext){
			try{
				applicationContext = new ClassPathXmlApplicationContext(config);
			}catch(RuntimeException rex){
				logger.error(rex);
				throw new RuntimeException();
			}catch(Exception ex){
				logger.error(ex);
			}
		}
		return applicationContext;
	}
	
	public static Object getBean(String beanid){
		return applicationContext.getBean(beanid);
	}
}
