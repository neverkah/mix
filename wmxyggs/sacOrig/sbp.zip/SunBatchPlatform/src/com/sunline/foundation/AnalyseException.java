package com.sunline.foundation;

public class AnalyseException extends EngineRuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AnalyseException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	public AnalyseException(String message , Throwable throwable){
		super(message,throwable);
	}
	
	public AnalyseException(Throwable throwable){
		super(throwable);
	}

}
