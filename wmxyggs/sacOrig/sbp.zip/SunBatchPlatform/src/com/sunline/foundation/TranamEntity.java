package com.sunline.foundation;

import java.math.BigDecimal;

public class TranamEntity {
	/**
	 * ����
	 */
	private String crcycd;
	
	/**
	 * �跽���˽��
	 */
	private BigDecimal dTranam;
	
	/**
	 * �������˽��
	 */
	private BigDecimal cTranam;
	
	public TranamEntity(String crcycd,BigDecimal dTranam,BigDecimal cTranam){
		this.crcycd = crcycd;
		this.dTranam = dTranam;
		this.cTranam = cTranam;
	}

	public String getCrcycd() {
		return crcycd;
	}

	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}

	public BigDecimal getdTranam() {
		return dTranam;
	}

	public void setdTranam(BigDecimal dTranam) {
		this.dTranam = dTranam;
	}

	public BigDecimal getcTranam() {
		return cTranam;
	}

	public void setcTranam(BigDecimal cTranam) {
		this.cTranam = cTranam;
	}
	
	public void plusDtranam(BigDecimal dTranam){
		this.dTranam = this.dTranam.add(dTranam);
	}
	
	public void plusCtranam(BigDecimal cTranam){
		this.cTranam = this.cTranam.add(cTranam);
	}
}
