package com.sunline.foundation;

public class TranVchrException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1745769980810833774L;

	public TranVchrException(String message){
		super(message);
	}
	
	public TranVchrException(String message , Throwable throwable){
		super(message,throwable);
	}
	
	public TranVchrException(Throwable throwable){
		super(throwable);
	}
}
