package com.sunline.foundation.arichmeticrule;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.tools.ApplicationBeanFactory;

/**
 * ������򹤳�
 * @author Hopechj
 *
 */
public class RuleArichmeticGenerator {
	
	private static Logger logger = Logger.getLogger(RuleArichmeticGenerator.class);
	
	public static RuleArichmeticObject generateObject(String beanID) throws AnalyseException{
		
		RuleArichmeticObject ruleObject = null;
		logger.debug("׼����ö���" + beanID + ".....");
		if (beanID.equalsIgnoreCase("cloneProp")) {

			try {
				ruleObject = (CloneProperty) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
				throw new AnalyseException("��ȡ" + beanID + "ʧ��",ex);
				
			}
		}else if(beanID.equalsIgnoreCase("appendParam")){
			try {
				ruleObject = (AppendParameter) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
				throw new AnalyseException("��ȡ" + beanID + "ʧ��",ex);
			}
		}else if(beanID.equalsIgnoreCase("setParam")){
			try {
				ruleObject = (SetParameter) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
				throw new AnalyseException("��ȡ" + beanID + "ʧ��",ex);
			}
		}else {
			try {
				ruleObject = (RuleArichmeticObject) ApplicationBeanFactory
						.getApplicationContextInstance().getBean(beanID);
			} catch (Exception ex) {
				logger.error("��ȡ" + beanID + "ʧ��");
				throw new AnalyseException("��ȡ" + beanID + "ʧ��",ex);
			}
			//logger.error("�����������ʧ�ܣ�" + beanID + "δע�ᡣ");
		}
		return ruleObject;
	
	}
}
