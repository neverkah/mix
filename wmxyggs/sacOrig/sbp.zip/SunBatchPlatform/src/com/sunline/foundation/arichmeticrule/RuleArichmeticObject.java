package com.sunline.foundation.arichmeticrule;

import java.util.ArrayList;
import java.util.HashMap;

import com.sunline.foundation.AnalyseException;

/**
 * 
 * @author Hopechj
 *
 */
public interface RuleArichmeticObject {
	public void initialize(final HashMap<String , Object> data);
	public void calculate( ArrayList<Object> destination , ArrayList<Object> source) throws AnalyseException;
	public HashMap<String , Object> getData();
}
