package com.sunline.foundation.arichmeticrule;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.sunline.foundation.AnalyseException;
import com.sunline.foundation.tools.StringUtil;

public class TwoNumberMul implements RuleArichmeticObject{
	
	private HashMap<String , Object> dataContext;
	private HashMap<String , Object> newData = new HashMap<String , Object>();
	Logger logger = Logger.getLogger(TwoNumberMul.class);

	@Override
	public void initialize(HashMap<String, Object> data) {
		// TODO Auto-generated method stub
		this.dataContext = data;
	}
	@Override
	public void calculate(ArrayList<Object> destination, ArrayList<Object> source) throws AnalyseException {
		// TODO Auto-generated method stub
		if(source.size() != 2){
			logger.error("������ȫ��" + source.toString());
			throw new AnalyseException("������ȫ��" + source.toString());
		}else{
			logger.debug("����:" + source.toString());
			if( !StringUtil.isNumeric(dataContext.get(source.get(0).toString()).toString())){
				if(!((dataContext.get(source.get(0)) instanceof Double) || (dataContext.get(source.get(0)) instanceof Float) || (dataContext.get(source.get(0)) instanceof Long) || (dataContext.get(source.get(0)) instanceof Integer))){
					logger.error("������" + source.get(0).toString()+ "=" + dataContext.get(source.get(0).toString()).toString() + "��Ϊ����");
					throw new AnalyseException("������" + source.get(0).toString()+ "=" + dataContext.get(source.get(0).toString()).toString() + "��Ϊ����");
				}
			}
			
			if( !StringUtil.isNumeric(dataContext.get(source.get(1).toString()).toString())){
				if( !((dataContext.get(source.get(1)) instanceof Double) || (dataContext.get(source.get(1)) instanceof Float) || (dataContext.get(source.get(1)) instanceof Long) || (dataContext.get(source.get(1)) instanceof Integer))){
					logger.error("������" + source.get(1).toString() + "=" + dataContext.get(source.get(1).toString()).toString() + "��Ϊ����");
					throw new AnalyseException("������" + source.get(1).toString() + "=" + dataContext.get(source.get(1).toString()).toString() + "��Ϊ����");
				}
			}
			
		}
		
		if(destination.size() != 1){
			logger.error("���������ֻ������һ����" + source.toString());
			throw new AnalyseException("���������ֻ������һ����" + source.toString());
		}else{
			logger.debug("���������:" + destination.toString());
		}
		
		BigDecimal param1 =new  BigDecimal(dataContext.get(source.get(0).toString()).toString());
		BigDecimal param2 =new  BigDecimal(dataContext.get(source.get(1).toString()).toString());
		param1 = param1.multiply(param2);
		String result = String.format("%.2f",param1);
		logger.debug("��ֵ�˻���������" + result);
		newData.put(destination.get(0).toString(),new  BigDecimal(result));
	}

	@Override
	public HashMap<String, Object> getData() {
		// TODO Auto-generated method stub
		return newData;
	}

}
