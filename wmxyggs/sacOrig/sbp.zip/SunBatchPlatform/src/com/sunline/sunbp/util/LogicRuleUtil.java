package com.sunline.sunbp.util;

/**
 * �߼��������
 * @author liuchj
 *
 */

public class LogicRuleUtil {
	
	/**
	 * 
	 */
	public String IfThenLese(double valueA ,String operator, double valueB ,double thenValue , double elseValue){
		if(operator.equals(">")){
			return "";
		}
		return null;
	}
}
