package com.sunline.sunbp.test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sunline.foundation.ServiceException;
import com.sunline.sbp.service.CacheFreshAction;


public class InnertTestCacheFrushService {
public static void main(String[] args) {
        //context.start();
		String result = "";
		CacheFreshAction cacheService;
        String bussinessInfo="{\"name\":\"itemCache\"}";
		try {
			JSONObject jsonObject = JSON.parseObject(bussinessInfo);

			ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:bpApplicationContext.xml"});
        	
			cacheService = (CacheFreshAction)context.getBean(CacheFreshAction.class);
			System.out.println(cacheService.operate(jsonObject));
        	
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //ִ��Զ�̷���
        System.out.println(result);
	}
}
