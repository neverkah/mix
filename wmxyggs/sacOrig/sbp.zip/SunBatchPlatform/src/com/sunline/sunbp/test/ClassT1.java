package com.sunline.sunbp.test;

import java.math.BigDecimal;

public class ClassT1 {
	private BigDecimal a1;

	public BigDecimal getA1() {
		return a1;
	}

	public void setA1(BigDecimal a1) {
		this.a1 = a1;
	}
	
}
