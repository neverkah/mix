package com.sunline.sunbp.util;


import com.sunline.foundation.AnalyseException;
import com.sunline.sbp.base.RuleBeanObject;
import com.sunline.sbp.model.SysBean;

public class RuleBeanUtil {
	
	public static RuleBeanObject getBeanByName(SysBean bean) throws AnalyseException {
		
		RuleBeanObject ruleBeanObject = null;
		String message = "��ȡ����["+bean.getBeanna()+"]�ɹ�!";
		try {
			Class cl = Class.forName(bean.getBeanna());
			Object o = cl.newInstance();
			ruleBeanObject = (RuleBeanObject) o;

		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			message = "��"+bean.getBeanna()+"ʵ����ʧ�ܣ�";
			throw new AnalyseException(message);
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			message = "��"+bean.getBeanna()+"����������ʹ��public��";
			throw new AnalyseException(message);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			message = "ϵͳδ������"+bean.getBeanna()+"��";
			throw new AnalyseException(message);
		} // ��������̬��������
		
		return ruleBeanObject;
	}
	
	private RuleBeanUtil(){}
}
