package com.sunline.sunbp.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sunline.foundation.ServiceException;

import com.sunline.sbp.service.FundClearingService;

public class InnertTestFundClearingService {
	public static void main(String[] args){
		//context.start();
		String result = "";
	    FundClearingService service;
		try {
			ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:bpApplicationContext.xml"});
	    	
			service = (FundClearingService)context.getBean(FundClearingService.class);
			result = service.runningTransaction(1);

		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //ִ��Զ�̷���
	    System.out.println(result);
	}
    
}
