package com.sunline.sunbp.test;

public class TrackTime {
	static private  long bT = System.nanoTime();
	
	public static void printExecuteTime(String targ){
		long eT = System.nanoTime();
		System.out.println(targ + "......" +(eT - bT)/1000000L);
		bT = eT;
	}
}
