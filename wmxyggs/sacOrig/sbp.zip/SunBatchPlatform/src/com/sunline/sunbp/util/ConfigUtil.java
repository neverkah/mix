package com.sunline.sunbp.util;

import java.util.Properties;

import org.apache.log4j.Logger;

import com.alibaba.dubbo.common.utils.ClassHelper;

/**
 * ��ȡ�����������ļ�
 * @���� 
 * @���� 
 * @author liuchj@sunline.cn
 * @project ����ϵͳ�������
 * @data 2014��10��7��
 */
public class ConfigUtil {
	
	private static Properties props = new Properties();
	
	private static Logger logger = Logger.getLogger(ConfigUtil.class);
	
	public static String getPropertiesValue(String key){
		if(props.isEmpty()){
			init();
		}
		return props.containsKey(key)?props.getProperty(key).toString().trim():null;
	}
	
	private static void init(){
			try {
				props.load(ClassHelper.getClassLoader().getResourceAsStream("init.properties"));
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				logger.error("Faild to load init.properties");
			}
	}
}
