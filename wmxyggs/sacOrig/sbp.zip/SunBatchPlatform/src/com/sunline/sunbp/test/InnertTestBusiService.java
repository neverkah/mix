package com.sunline.sunbp.test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sunline.foundation.ServiceException;
import com.sunline.sbp.service.BusiOnlnService;


public class InnertTestBusiService {
public static void main(String[] args) {
        //context.start();
		String result = "";
        BusiOnlnService busiOnlnService;
        String bussinessInfo="{\"prodcd\":\"1111\",\"typecd\":\"1000010118\",\"status\":\"0\",\"crcycd\":\"01\",\"captam\":\"10000\",\"systid\":\"90\",\"prcscd\":\"irbadd\",\"dwinam\":\"0\",\"trandt\":\"20131004\",\"rebfam\":\"1000\",\"tranbr\":\"6510001\",\"transq\":\"6510999000000529\"}";
		try {
			JSONObject jsonObject = JSON.parseObject(bussinessInfo);

			ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:bpApplicationContext.xml"});
        	
			busiOnlnService = (BusiOnlnService)context.getBean(BusiOnlnService.class);
        	busiOnlnService.busiTransaction(jsonObject);
        	
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //ִ��Զ�̷���
        System.out.println(result);
	}
}
