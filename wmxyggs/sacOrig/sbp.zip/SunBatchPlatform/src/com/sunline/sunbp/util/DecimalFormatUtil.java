package com.sunline.sunbp.util;

import java.text.DecimalFormat;

public class DecimalFormatUtil {
	
	public static String format(double f){
		DecimalFormat df = new DecimalFormat("#.00");
		return df.format(f);
	}
}
