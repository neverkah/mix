package com.sunline.sunbp.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sunline.onln.service.BusiGLService;

public class TestForLR {
	public TestForLR(){
		
	}
	public void toRun(String transq){
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:ApplicationContext-consumer.xml"});
		BusiGLService demoService = (BusiGLService)context.getBean("busiService"); // ��ȡԶ�̷������
		int id = 3;
		String busimsg = null;
		if(id%2 == 1){
    		busimsg = "{\"systid\":\"fi\",\"trandt\":\"20121221\",\"transq\":\""+transq+"\",\"tranbr\":\"01002\",\"asetno\":\"*\",\"prcscd\":\"asdpra\",\"asettp\":\"010001\",\"inchvl\":0,\"dpravl\":1,\"trantp\":\"TR\",\"smrytx\":\"�̶��ʲ��۾�\",\"crcycd\":\"01\"}";
    	}else if(id%2 == 0){
    		busimsg = "{\"asetno\":\"1\",\"asettp\":\"010001\",\"crcycd\":\"01\",\"devvvl\":0,\"dpravl\":0,\"inchvl\":1,\"incmvl\":0,\"outtvl\":0,\"prcscd\":\"asbreg\",\"publvl\":0,\"smrytx\":\"�̶��ʲ�����\",\"status\":\"0\",\"systid\":\"fi\",\"tobrch\":\"\",\"tranbr\":\"010001\",\"trandt\":\"20121221\",\"transq\":\""+transq+"\",\"trantp\":\"TR\"}";
    	}
		long bT = System.nanoTime();
        String result = demoService.busiTransaction(busimsg); // ִ��Զ�̷���
        long eT = System.nanoTime();
        System.out.println("......"+(eT - bT)/1000000L);
        System.out.println(result);
	}
	
	public static void main(String[] args){
		//long bT = System.nanoTime();
		TestForLR tlr = new TestForLR();
		
		tlr.toRun("000100001");
		//long eT = System.nanoTime();
		//System.out.println("......"+(eT - bT)/1000000L);
	}
}
