package com.sunline.sunbp.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Tmain {
	public static void main1(String[] args){
		Connection conn = null;
		PreparedStatement prest = null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String o_url = "jdbc:oracle:thin:@10.22.20.12:1521:UATDEMODB";
			String userName = "uat_sunfi";
			String password = "uat_sunfi";
			conn = DriverManager.getConnection(o_url, userName, password);
			String sql = "INSERT into adlogs(ip,website,yyyymmdd,mhour,object_id"
					+ ",C6,C7,C8,C9,CA,CB,CC,CD,CE,CF,CG,CH,CI,CJ,CK"
					+ ",CL,CM,CN,CO,CP,CQ,CR,CS,CT,CU,CV,CW,CX,CY,CZ) VALUES(?,?,?,?,?,?"
					+ ",?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			prest = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
			int size = 4000;
		      for(int x = 0; x < size; x++){
		         prest.setString(1, "192.168.1.1");
		         prest.setString(2, "localhost");
		         prest.setString(3, "20081009");
		         prest.setInt(4, 8);
		         prest.setString(5, "11111111");
		         prest.setString(6, "C6666666612312312321");
		         prest.setString(7, "C6666666612312312323");
		         prest.setString(8, "C6666666612312312333");
		         prest.setString(9, "C6666666612312321312");
		         prest.setString(10, "C6666666612312313123");
		         prest.setString(11, "C6666666612312312323");
		         prest.setString(12, "C6666666612312312333");
		         prest.setString(13, "C6666666612312312322");
		         prest.setString(14, "C6666666612323331231");
		         prest.setString(15, "C6666666612333333333");
		         prest.setString(16, "C6666666612323232333");
		         prest.setString(17, "C6666666612312333333");
		         prest.setString(18, "C6666666612312333333");
		         prest.setString(19, "C6666666612312313332");
		         prest.setString(20, "C6666666612312312333");
		         prest.setString(21, "C6666666612312312313");
		         prest.setString(22, "C6666666612312313132");
		         prest.setString(23, "C6666666612312312322");
		         prest.setString(24, "C6666666612312312312");
		         prest.setString(25, "C6666666612312313123");
		         prest.setString(26, "C6666666612333333331");
		         prest.setString(27, "C6666666612312313133");
		         prest.setString(28, "C6666666612312312311");
		         prest.setString(29, "C6666666612312312322");
		         prest.setString(30, "C6666666612312313222");
		         prest.setString(31, "C6666666612312312322");
		         prest.setString(32, "C6666666612312312312");
		         prest.setString(33, "C6666666622222222222");
		         prest.setString(34, "C6666666677777777777");
		         prest.setString(35, "C6666666668888888888");
		         prest.addBatch();
		      }
		      int[] count = prest.executeBatch();
		      conn.commit();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			if(null != prest){
				try {
					prest.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			if(null != conn){
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	
	public static void main(String[] args){
		Connection conn = null;
		PreparedStatement prest = null;
		StringBuilder MyStringBuilder = null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String o_url = "jdbc:oracle:thin:@10.22.20.12:1521:UATDEMODB";
			String userName = "ks_sungl";
			String password = "ks_sungl";
			conn = DriverManager.getConnection(o_url, userName, password);
			MyStringBuilder = new StringBuilder("INSERT into adlogs(ip,website,yyyymmdd,mhour,object_id"
					+ ",C6,C7,C8,C9,CA,CB,CC,CD,CE,CF,CG,CH,CI,CJ,CK"
					+ ",CL,CM,CN,CO,CP,CQ,CR,CS,CT,CU,CV,CW,CX,CY,CZ,C10,C11,C12,C13,C14,C15) ");
			
			int size = 5000;
		      for(int x = 0; x < size; x++){
		    	  MyStringBuilder.append(" select ");
			    	 MyStringBuilder.append("'192.168.1.1'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'localhost'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'20081009'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append(8);
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'11111111'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312321'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312323'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312333'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312321312'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312313123'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312323'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312333'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312322'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612323331231'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612333333333'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612323232333'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312333333'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312333333'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312313332'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312333'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312313'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312313132'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312322'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312312'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312313123'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612333333331'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312313133'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312311'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312322'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312313222'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312322'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666612312312312'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666622222222222'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666677777777777'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666668888888888'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666668888888888'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666668888888888'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666668888888888'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666668888888888'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666668888888888'");
			    	 MyStringBuilder.append(",");
			    	 MyStringBuilder.append("'C6666666668888888888'");
		    	 MyStringBuilder.append(" from dual ");
		    	 if(x < size -1){
		    		 MyStringBuilder.append(" union all ");
		    	 }
		    	 
		      }
		      prest = conn.prepareStatement(MyStringBuilder.toString(),ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
		      prest.execute();
		      conn.commit();
		      //System.out.println(MyStringBuilder.toString());
		}catch(Exception ex){
			System.out.println(MyStringBuilder.toString());
			ex.printStackTrace();
		}finally{
			if(null != prest){
				try {
					prest.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			if(null != conn){
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
}
