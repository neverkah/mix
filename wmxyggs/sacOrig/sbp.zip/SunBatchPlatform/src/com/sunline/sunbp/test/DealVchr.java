package com.sunline.sunbp.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunline.foundation.Constants;
import com.sunline.onln.service.VchrGLService;
import com.sunline.sbp.model.GliVchr;

public class DealVchr {
	public static void go(String args){
		
		String busimsg = args;
		
		//busimsg = "{\"acctbr\":\"00101\",\"acctno\":\"\",\"amntcd\":\"D\",\"assis0\":\"\",\"assis1\":\"\",\"assis2\":\"\",\"assis3\":\"\",\"assis4\":\"\",\"assis5\":\"\",\"assis6\":\"\",\"assis7\":\"\",\"assis8\":\"\",\"assis9\":\"\",\"centcd\":\"\",\"crcycd\":\"01\",\"custcd\":\"\",\"exchcn\":0,\"exchus\":0,\"itemcd\":\"304103\",\"prcscd\":\"unacct\",\"prducd\":\"\",\"prlncd\":\"\",\"prsncd\":\"\",\"smrytx\":\"\",\"sourdt\":\"\",\"soursq\":\"\",\"sourst\":\"\",\"stacid\":0,\"toitem\":\"\",\"tranam\":12.9,\"tranbr\":\"00101\",\"trandt\":\"20130501\",\"trannm\":1,\"transq\":\"00101100\",\"transt\":\"0\",\"trantp\":\"TR\",\"usercd\":\"0000\",\"vchrsq\":\"0010101\"}";
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:ApplicationContext-consumer.xml"});
        //context.start();
		VchrGLService demoService = (VchrGLService)context.getBean("vchrService"); // ��ȡԶ�̷������
        String result = demoService.vchrTransaction(busimsg); //ִ��Զ�̷���
        System.out.println(result);
	}
	
	public static void main(String[] args){
		GliVchr vchr = new GliVchr();
		vchr.setAcctbr("0501001");
		vchr.setTranam(11);
		vchr.setAmntcd(Constants.AMNTCD_DEBIT);
		vchr.setCrcycd("01");
		vchr.setItemcd("66021301");
		vchr.setSourdt("20140325");
		vchr.setSoursq("990001");
		vchr.setSoursq("01");
		vchr.setStacid(1);
		vchr.setTrantp("0");
		vchr.setVchrsq("1");
		vchr.setSoursq("01");
		vchr.setTranbr("0501001");
		vchr.setTrandt("20130325");
		System.out.println(JSON.toJSONString(vchr));
		go(JSON.toJSONString(vchr));
	}
}
