package com.sunline.sunbp.util;

import com.sunline.sbp.model.GlaVoucher;

public class CloneObjectUtil {
	public static GlaVoucher clone(GlaVoucher entity){
		GlaVoucher cloneObject = new GlaVoucher();
		cloneObject.setAcctbr(entity.getAcctbr());
		cloneObject.setAcctno(entity.getAcctno());
		cloneObject.setAssis0(entity.getAssis0());
		cloneObject.setAssis1(entity.getAssis1());
		cloneObject.setAssis2(entity.getAssis2());
		cloneObject.setAssis3(entity.getAssis3());
		cloneObject.setAssis4(entity.getAssis4());
		cloneObject.setAssis5(entity.getAssis5());
		cloneObject.setAssis6(entity.getAssis6());
		cloneObject.setAssis7(entity.getAssis7());
		cloneObject.setAssis8(entity.getAssis8());
		cloneObject.setAssis9(entity.getAssis9());
		cloneObject.setCentcd(entity.getCentcd());
		cloneObject.setCrcycd(entity.getCrcycd());
		cloneObject.setCustcd(entity.getCustcd());
		cloneObject.setPrducd(entity.getPrducd());
		cloneObject.setPrlncd(entity.getPrlncd());
		cloneObject.setPrsncd(entity.getPrsncd());
		cloneObject.setSmrytx(entity.getSmrytx());
		cloneObject.setSourdt(entity.getSourdt());
		cloneObject.setSoursq(entity.getSoursq());
		cloneObject.setSourst(entity.getSourst());
		cloneObject.setSrvcsq(entity.getSrvcsq());
		cloneObject.setStacid(entity.getStacid());
		cloneObject.setSystid(entity.getSystid());
		cloneObject.setTranam(entity.getTranam());
		
		cloneObject.setTranbr(entity.getTranbr());
		cloneObject.setTrandt(entity.getTrandt());
		cloneObject.setTranno(entity.getTranno());
		cloneObject.setTransq(entity.getTransq());
		cloneObject.setTrantp(entity.getTrantp());
		cloneObject.setUsercd(entity.getUsercd());
		cloneObject.setClertg(entity.getClertg());
		return cloneObject;
	}
}
