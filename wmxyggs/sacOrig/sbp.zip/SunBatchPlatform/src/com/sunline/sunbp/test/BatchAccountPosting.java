package com.sunline.sunbp.test;

import com.sunline.sbp.schedule.VchrBatchJob;
import com.sunline.sbp.schedule.VchrBatchTranPool;

public class BatchAccountPosting {
	
	
	
	public static void main(String[] args) {
		
		
		new VchrBatchJob(1,"9999888","1".concat("%"),"20180202","2","90").run();
		//new VchrBatchJob(1,"9999888","6".concat("%"),"20180202","2","90").run();
		
	}
	
}
