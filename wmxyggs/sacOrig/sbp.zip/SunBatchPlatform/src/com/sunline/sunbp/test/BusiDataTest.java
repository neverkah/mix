package com.sunline.sunbp.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.sunline.onln.application.provider.BusiGLServiceImpl;
import com.sunline.sbp.service.BusiOnlnService;

public class BusiDataTest {

	/**
	 * @param args
	 *            ����ʱ�����ApplicationContext.xml ��mian ���������ݿ�����
	 */
	public static void main(String[] args) {
		String driverName = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@127.0.0.1:1521/orcl";
		String user = "sungl";
		String password = "sungl";

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			Class.forName(driverName);
			conn = DriverManager.getConnection(url, user, password);
//			String sql = " select *  from loan_busi where stacid = '1' and trandt = '20170724' and (transq='000000022' or transq='000000023' or transq='000000021')";
			String sql = " select *  from loan_busi where BATHID= '20170725003' ";


			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			String jsonString = resultSetToJson(rs);

			String bussinessInfo = jsonString;

			BusiOnlnService busiOnlnService = null;

			String result = "";

			/*try {*/
				// JSONObject jsonObject = JSON.parseObject(bussinessInfo);
				JSONArray jsonArray = JSON.parseArray(bussinessInfo);

				ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
						new String[] { "classpath:ApplicationContext.xml" });

				/*busiOnlnService = (BusiOnlnService) context
						.getBean(BusiOnlnService.class);
				// busiOnlnService.busiTransaction(jsonObject);

				result = busiOnlnService.busiBatchTransaction(jsonArray);*/
				
				BusiGLServiceImpl test = (BusiGLServiceImpl)context.getBean(BusiGLServiceImpl.class);
				result = test.busiTransactionBatch(bussinessInfo);
			/*} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} */// ִ��Զ�̷���
			System.out.println(result);

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	private static String resultSetToJson(ResultSet rs) throws SQLException {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		// ��ȡ����
		ResultSetMetaData metaData = rs.getMetaData();
		int columnCount = metaData.getColumnCount();
		// ����ResultSet�е�ÿ������
		while (rs.next()) {
			// ����ÿһ��
			HashMap<String, String> dataMap = new HashMap<String, String>();
			for (int i = 1; i <= columnCount; i++) {
				String columnName = metaData.getColumnLabel(i);
				String value = rs.getString(columnName);
				dataMap.put(columnName.toLowerCase(), value);
			}
			dataList.add(dataMap);
		}
		return JSON.toJSONString(dataList,
				SerializerFeature.DisableCircularReferenceDetect);

	}
}
