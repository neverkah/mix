package com.sunline.sunbp.test;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.sunline.foundation.Constants;
import com.sunline.foundation.EngineRuntimeException;
import com.sunline.foundation.Enumeration;
import com.sunline.sbp.core.bean.GlaGlisBean;
import com.sunline.sbp.core.bean.GlaVchrHelper;
import com.sunline.sbp.model.AccountingItem;
import com.sunline.sbp.model.GlaGlis;
import com.sunline.sbp.model.GlaVoucher;

public class Main {
	
	public static void main(String[] args) throws UnsupportedEncodingException{
		
		GlaVoucher vchr = new GlaVoucher(); 
		GlaGlis glisEntity = new GlaGlis();
		AccountingItem itemEntity = new AccountingItem();
		
		glisEntity.setStacid(1);
		glisEntity.setSystid("00");
		glisEntity.setAcctdt("20140101");
		glisEntity.setItemcd("100101");
		glisEntity.setBrchcd("1280007");
		glisEntity.setBlncdn(Enumeration.Amntcd.D.value);
		glisEntity.setDrtsam(BigDecimal.valueOf(0));
		glisEntity.setCrtsam(BigDecimal.valueOf(0));
		glisEntity.setOnlnbl(BigDecimal.valueOf(10000000230034.45));
		glisEntity.setDrctbl(BigDecimal.valueOf(10000000230034.45));
		
		vchr.setStacid(1);
		vchr.setAcctbr("1280007");
		vchr.setAmntcd(Enumeration.Amntcd.D.value);
		vchr.setIoflag("I");
		vchr.setItemcd("100101");
		vchr.setSourdt("20140101");
		vchr.setSoursq("00000001");
		vchr.setSourst("00");
		vchr.setSrvcsq("1");
		vchr.setTranam(BigDecimal.valueOf(67834241000234.05));
		vchr.setTranbr("1280007");
		vchr.setTrandt("20140101");
		vchr.setTrannm(1);
		vchr.setTransq("01000001");
		vchr.setTrantp(Enumeration.TRANTP.CASH.value);
		vchr.setUsercd("DD");
		vchr.setVchrsq("1");
		
		itemEntity.setStacid(1);
		itemEntity.setItemcd("100101");
		itemEntity.setDetltg("1");
		itemEntity.setIoflag("I");
		itemEntity.setItemdn(Enumeration.Amntcd.D.value);
	    itemEntity.setUsedtp("1");


		
		GlaGlisBean.updateBalance(vchr, glisEntity, itemEntity);
		System.out.println(glisEntity.getOnlnbl());
		
		/*SqlSession sql = MyBatisUtil.getSqlSessionFactory().openSession();
		GlaGlisMapper glisMapper = sql.getMapper(GlaGlisMapper.class);
		
		GlaVoucher vchr1 = new GlaVoucher(); 
		vchr1.setStacid(1);
		vchr1.setAcctbr("0507009");
		vchr1.setItemcd("20110501");
		vchr1.setSystid("00");
		vchr1.setTranbr("0507009");
		vchr1.setTrandt("20141222");
		vchr1.setCrcycd("01");
		GlaGlis en = glisMapper.getEntityLock(vchr1);
		if(null == en){
			System.out.println("null");
		}
		System.out.println(en.getOnlnbl().add(en.getCrctbl()));
		sql.commit(true);
		sql.close();*/
		
		/*SequenceInformation df = new SequenceInformation();
		System.out.println(df.getMaxisq());
		
		SysVchrErorUtil.writeLog("xx", "df", "df", "df", "xx");*/
		
		GlaVoucher vchr1 = new GlaVoucher(); 
		vchr1.setStacid(1);
		vchr1.setAcctbr("0507009");
		vchr1.setItemcd("20110501");
		vchr1.setSystid("00");
		vchr1.setTranbr("0507009");
		vchr1.setTrandt("20141222");
		vchr1.setCrcycd("01");
		vchr1.setTranam(new BigDecimal(67.1002));
		vchr1.setAmntcd(Constants.AMNTCD_DEBIT);
		vchr1.setIoflag(Enumeration.IOFLAG.I.value);
		
		GlaVoucher vchr2 = new GlaVoucher(); 
		vchr2.setStacid(1);
		vchr2.setAcctbr("0507009");
		vchr2.setItemcd("20110501");
		vchr2.setSystid("00");
		vchr2.setTranbr("0507009");
		vchr2.setTrandt("20141222");
		vchr2.setCrcycd("01");
		vchr2.setAmntcd(Constants.AMNTCD_CREDIT);
		vchr2.setIoflag(Enumeration.IOFLAG.I.value);
		vchr2.setTranam(new BigDecimal(67.101));
		
		List<GlaVoucher> vchrList = new ArrayList<GlaVoucher>();
		vchrList.add(vchr1);
		vchrList.add(vchr2);
		
		try {
			System.out.print(GlaVchrHelper.checkBalanceOfGlaVchrs(vchrList));
		} catch (EngineRuntimeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
}
