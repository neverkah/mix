package com.sunline.sunbp.test;

import java.util.ArrayList;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sunline.foundation.tools.StringUtil;
import com.sunline.onln.service.BusiGLService;

public class MutiThreadDealVchrs extends Thread{
	static int isendCount = 20;
	static int threadCount = 100;
	int sendCount;
    String name;
    public MutiThreadDealVchrs(int x, String n) {
    	sendCount = x;
        name = n;
    }
    public void run() {
    	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:ApplicationContext-consumer.xml"});
        //context.start();
        BusiGLService demoService = (BusiGLService)context.getBean("busiService"); // ��ȡԶ�̷������
        
        int id = 1 ;
        ArrayList<Long> staticTime = new ArrayList<Long>();
        Long exeTime = new Long(0);
        String busimsg = null;
        while(id <= sendCount) {
            try {
            	if(id%2 == 1){
            		busimsg = "{\"systid\":\"FI\",\"trandt\":\"20121221\",\"transq\":\""+name+StringUtil.numberLpad(id, 5, "0")+"\",\"tranbr\":\"01002\",\"asetno\":\"*\",\"prcscd\":\"asdpra\",\"asettp\":\"010001\",\"inchvl\":0,\"dpravl\":1,\"trantp\":\"TR\",\"smrytx\":\"�̶��ʲ��۾�\",\"crcycd\":\"01\"}";
            	}else if(id%2 == 0){
            		busimsg = "{\"asetno\":\"1\",\"asettp\":\"010001\",\"crcycd\":\"01\",\"devvvl\":0,\"dpravl\":0,\"inchvl\":1,\"incmvl\":0,\"outtvl\":0,\"prcscd\":\"asbreg\",\"publvl\":0,\"smrytx\":\"�̶��ʲ�����\",\"status\":\"0\",\"systid\":\"FI\",\"tobrch\":\"\",\"tranbr\":\"010001\",\"trandt\":\"20121221\",\"transq\":\""+name+StringUtil.numberLpad(id, 5, "0")+"\",\"trantp\":\"TR\"}";
            	}
            	long bT = System.nanoTime();
                	String result = demoService.busiTransaction(busimsg); // ִ��Զ�̷���
                	long eT = System.nanoTime();
                	staticTime.add((eT - bT)/1000000L);
                	System.out.println(name + "......"+id + ":" +result);
                	id = id + 1;
            } catch(Exception e) {
                System.out.println(e);
            }
        }
        for(Long il : staticTime){
        	exeTime = exeTime + il;
        }
        System.out.println("ҵ��ϵͳ��"+name+"������ҵ�������" + staticTime.size() + ",������������Ϲ���ʱ��" + exeTime + ",ƽ�����ʺ�ʱ��" + exeTime/staticTime.size() + "ms");
    }
    static public void main(String args[]) {
    	for(int icount = 1 ; icount <= threadCount ; icount++){
    		String id = StringUtil.numberLpad(icount, 2, "0");
    		new MutiThreadProd(isendCount, id).start();
    	}
    }
}
