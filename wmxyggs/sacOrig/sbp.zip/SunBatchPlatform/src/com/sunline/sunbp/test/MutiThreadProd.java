package com.sunline.sunbp.test;

import java.util.ArrayList;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sunline.foundation.tools.StringUtil;
import com.sunline.onln.service.BusiGLService;

public class MutiThreadProd extends Thread{
	static int isendCount = 1;
	static int threadCount = 1;
	int sendCount;
    String name;
    public MutiThreadProd(int x, String n) {
    	sendCount = x;
        name = n;
    }
    public void run() {
    	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:ApplicationContext-consumer.xml"});
        //context.start();
        BusiGLService demoService = (BusiGLService)context.getBean("busiService"); // ��ȡԶ�̷������
        
        int id = 1 ;
        ArrayList<Long> staticTime = new ArrayList<Long>();
        Long exeTime = new Long(0);
        String busimsg = null;
        while(id <= sendCount) {
            try {
            	if(id%2 == 1){
            		//busimsg = "{\"systid\":\"01\",\"trandt\":\"20121221\",\"transq\":\""+name+StringUtil.numberLpad(id, 5, "0")+"\",\"tranbr\":\"01002\",\"asetno\":\"*\",\"prcscd\":\"asdpra\",\"asettp\":\"1601\",\"inchvl\":0,\"dpravl\":1,\"trantp\":\"TR\",\"smrytx\":\"�̶��ʲ��۾�\",\"crcycd\":\"01\"}";
            		busimsg = "{\"prodcd\":\"1101\",\"acctam\":\"1000010.43\",\"adinam\":0,\"chtotp\":\"\",\"dwinam\":\"10.1\",\"favaam\":0,\"impaam\":0,\"invtam\":0,\"ivsttp\":\"01\",\"prcscd\":\"ivtreg\",\"rcinam\":0,\"status\":\"\",\"subseq\":\"1\",\"systid\":\"01\",\"tranbr\":\"01002\",\"bsnsdt\":\"20130325\",\"bsnssq\":\"99100000009\",\"variam\":\"1000000.33\",\"crcycd\":\"01\"}";
            	}else if(id%2 == 0){
            		busimsg = "{\"asetno\":\"1\",\"asettp\":\"1601\",\"crcycd\":\"01\",\"devvvl\":0,\"dpravl\":0,\"inchvl\":1,\"incmvl\":0,\"outtvl\":0,\"prcscd\":\"asbreg\",\"publvl\":0,\"smrytx\":\"�̶��ʲ�����\",\"status\":\"0\",\"systid\":\"01\",\"tobrch\":\"\",\"tranbr\":\"010001\",\"trandt\":\"20121221\",\"transq\":\""+name+StringUtil.numberLpad(id, 5, "0")+"\",\"trantp\":\"TR\"}";
            	}
            	long bT = System.nanoTime();
                	String result = demoService.busiTransaction(busimsg); // ִ��Զ�̷���
                	long eT = System.nanoTime();
                	staticTime.add((eT - bT)/1000000L);
                	System.out.println(result);
                	id = id + 1;
            } catch(Exception e) {
                System.out.println(e);
            }
        }
        for(Long il : staticTime){
        	exeTime = exeTime + il;
        }
        System.out.println("ҵ��ϵͳ��"+name+"������ҵ�������" + staticTime.size() + ",������������Ϲ���ʱ��" + exeTime + ",ƽ�����ʺ�ʱ��" + exeTime/staticTime.size() + "ms");
    }
    static public void main(String args[]) {
    	for(int icount = 1 ; icount <= threadCount ; icount++){
    		String id = StringUtil.numberLpad(icount, 2, "0");
    		new MutiThreadProd(isendCount, id).start();
    	}
    }
}
