package com.sunline.sunbp.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sunline.foundation.ServiceException;
import com.sunline.onln.service.CommandGLService;

public class TestCommandAccounting {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"classpath:ApplicationContext-consumer.xml"});
        //context.start();
		CommandGLService demoService = (CommandGLService)context.getBean("cmmdService"); // ��ȡԶ�̷������
        String result = "";
		try {
			result = demoService.commandTransaction(1, "00", "20140402", "211030000078");
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //ִ��Զ�̷���
        System.out.println(result);
	}
}
