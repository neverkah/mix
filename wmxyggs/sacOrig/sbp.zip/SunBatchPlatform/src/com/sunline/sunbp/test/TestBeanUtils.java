package com.sunline.sunbp.test;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

import org.apache.commons.beanutils.BeanUtils;

import com.sunline.sbp.model.InacTran;

public class TestBeanUtils {
	public static void main(String[] args) throws IllegalAccessException, InvocationTargetException{
		InacTran tran = new InacTran();
		HashMap<String,Object> map = new HashMap<String, Object>();
		map.put("amntcd", 123.89);
		map.put("acctbr", "050002");
		BeanUtils.populate(tran, map);
		
		System.out.println(tran.getAmntcd());
		System.out.println(tran.getAcctbr());
	}
}
