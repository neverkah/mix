package com.sunline.sunfe.base;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.sunfe.util.StringUtils;
public class PftpAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.pftp.";
	Log log = new Log("PftpAction");
	
	/**
	 * ��ѯҵ����� & queryPftpListPage
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void queryPftpListPage() throws BimisException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("proftp", StringUtils.repalceCharecter(hashmap.get("proftp")));
			hashmap.put("vermod", "0");
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryPftplistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			log.logError(e);
		}
		
	}
	
	/**
	 * ���ݹ�������proftp���ҹ���������Ϣ
	 */
	public void queryPftpById()  //06����id��  �� ��¼
	{
		try 
		{
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String proftp = req.getReqDataStr("proftp");
			hashmap.put("proftp", proftp);
			hashmap.put("vermod", "0");
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryPftpById", hashmap);	
            req.addRspData(e.removeContent());        //���ؽ����װ	
            Element templateEle = commonDao.queryByNamedSql(MYBATIS_NS+"queryProfByproftp",hashmap);
            req.addRspData("Results2",templateEle.removeContent());   //���ؽ����װ
		} catch (Exception e) {
			log.logError(e);
		}
	 }	
	/**
	 * ���ݹ�������proftp���ҹ�����Ϣ
	 */
	public void queryProfByproftplistPage()  //06����id��  �� ��¼
	{
		try 
		{
			HashMap<String, String> hashmap = new HashMap<String, String>();			 
			String proftp = req.getReqDataStr("proftp");
			String pageNo = req.getReqDataStr("pageNum");
			String profna = req.getReqDataStr("profna");
			proftp = StringUtils.repalceCharecter(proftp);

			if (StringUtils.isNotEmpty(pageNo)) {
				req.setReqPageNo(Integer.parseInt(pageNo));
			}
			hashmap.put("proftp", proftp);
			hashmap.put("profna", profna);
			hashmap.put("vermod", "0");
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryProfByproftplistPage",req.getReqPageInfo(), hashmap);	
			req.addRspData(e.removeContent());        //���ؽ����װ	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	/**
	 * ����ҵ����� & addPftp
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void addPftp() throws JDOMException{
		try {
			HashMap<String, String> hashmap =(HashMap<String, String>) req.getReqDataMap(); //��
			HashMap<String, String> hashmap2 = new HashMap<String, String>(); //��
			commonDao.beginTransaction();
			
			List<String> profid_list = req.getReqDataTexts("profid");
			List<String> profna_list = req.getReqDataTexts("profna");
			List<String> efctdt_list = req.getReqDataTexts("efctdt");
			List<String> inefdt_list = req.getReqDataTexts("inefdt");
			List<String> pdesctx_list = req.getReqDataTexts("pdesctx");
//			List<String> penname_list = req.getReqDataTexts("penname");
			
			//�ж��Ƿ��Ѵ��ڹ�������
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistPftp", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "ҵ����������Ѵ��ڣ�");
					return;
				}
			}
			 commonDao.insertByNamedSql(MYBATIS_NS+"addPftp",hashmap);
			
			if(profid_list.size()!=0 && profid_list!=null){
				for(int i=0;i<profid_list.size();i++){
					   hashmap2.clear();
					   String profid = profid_list.get(i);
					   if(!"".equals(profid)&&profid!=null){
						   hashmap2.put("profid", profid);
						   hashmap2.put("vermod", "0");
						   hashmap2.put("module", hashmap.get("module"));
						   hashmap2.put("projcd", hashmap.get("projcd"));
						   hashmap2.put("proftp", hashmap.get("proftp"));
						   hashmap2.put("profna", profna_list.get(i));
						   hashmap2.put("efctdt", efctdt_list.get(i));
						   hashmap2.put("inefdt", inefdt_list.get(i));
//						   hashmap2.put("enname", penname_list.get(i));
						   hashmap2.put("desctx", pdesctx_list.get(i));
						 //�����ֶ���profid���ж�,�Ƿ����д��ڵĽӿ���ϸ����
							List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistProf", hashmap2);
							if(sumList!=null && sumList.size()>0) {
								Map sumMap = (HashMap)sumList.get(0);
								int sum = Integer.valueOf(sumMap.get("CC").toString());
								if(sum > 0) {
									req.addRspData("retCode", "300");
									req.addRspData("retMessage", "����ID ["+profid+"] �Ѵ��ڣ�");
									return;
								}
							}
						   commonDao.insertByNamedSql(MYBATIS_NS+"insertProf", hashmap2);
					   }
				 }   
			  }
				   ResultUtils.setRspData(req, "200",  "�����ɹ�", "pftp_main", "closeCurrent", "");
				   commonDao.commitTransaction();
			} catch (BimisException e) {
					commonDao.rollBack();
				   ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
				   log.logError(e);
			}		
	}
	
	/**
	 * �޸�ҵ�����������Ϣ & updatePftp
	 * @throws JDOMException 
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public void updatePftp() throws JDOMException{
  
	try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			HashMap<String, String> hashmap2 = new HashMap<String, String>();
			HashMap<String, String> hashmap3 = new HashMap<String, String>();
			commonDao.beginTransaction();
			String proftp = req.getReqDataStr("proftp");//ҵ���������
			String pftpna = req.getReqDataStr("pftpna");//������������
			String proccd = req.getReqDataStr("proccd");//���̶���
			String enname = req.getReqDataStr("enname");//Ӣ������
			String desctx = req.getReqDataStr("desctx");//˵��
			String vermod = req.getReqDataStr("vermod");//�汾ģʽ
			String module = req.getReqDataStr("module");//ģ��
			String projcd = req.getReqDataStr("projcd");//��Ŀ���
			
			List<String> profid_list = req.getReqDataTexts("profid");
			List<String> profna_list = req.getReqDataTexts("profna");
			List<String> efctdt_list = req.getReqDataTexts("efctdt");
			List<String> inefdt_list = req.getReqDataTexts("inefdt");
			List<String> pdesctx_list = req.getReqDataTexts("pdesctx");
			List<String> penname_list = req.getReqDataTexts("penname");
			
			hashmap.put("proftp", proftp);
			hashmap.put("pftpna", pftpna.trim());
			hashmap.put("proccd", proccd);
			hashmap.put("enname", enname.trim());
			hashmap.put("desctx", desctx.trim());
			hashmap.put("vermod", vermod);
			hashmap.put("module", module);
			hashmap.put("projcd", projcd);	
		    commonDao.updateByNamedSql(MYBATIS_NS+"updatePftp", hashmap);	//����ҵ���������
		    hashmap.put("vermod", "0");	
		    commonDao.insertByNamedSql(MYBATIS_NS+"addPftp",hashmap);
		    
		    commonDao.updateByNamedSql(MYBATIS_NS+"updateProf", hashmap);
		    hashmap3.put("proftp", proftp);
		    
		    if(profid_list.size()!=0 && profid_list!=null){
				for(int i=0;i<profid_list.size();i++){
					   hashmap2.clear();
					   String profid = profid_list.get(i);
					   if(!"".equals(profid)&&profid!=null){
						   hashmap2.put("profid", profid);
						   hashmap2.put("vermod", "0");
						   hashmap2.put("module", module);
						   hashmap2.put("projcd", projcd);
						   hashmap2.put("proftp", proftp);
						   hashmap2.put("profna", profna_list.get(i));
						   hashmap2.put("efctdt", efctdt_list.get(i));
						   hashmap2.put("inefdt", inefdt_list.get(i));
						   hashmap2.put("enname", penname_list.get(i));
						   hashmap2.put("desctx", pdesctx_list.get(i));
						 //�����ֶ���profid���ж�,�Ƿ����д��ڵĽӿ���ϸ����
							List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistProf", hashmap2);
							if(sumList!=null && sumList.size()>0) {
								Map sumMap = (HashMap)sumList.get(0);
								int sum = Integer.valueOf(sumMap.get("CC").toString());
								if(sum > 0) {
									commonDao.rollBack();
									req.addRspData("retCode", "300");
									req.addRspData("retMessage", "����ID�Ѵ��ڣ�");
									return;
								}
							}
						   commonDao.insertByNamedSql(MYBATIS_NS+"insertProf", hashmap2);
					   }
				 }   
			  }
				   ResultUtils.setRspData(req, "200",  "�����ɹ�", "pftp_main", "closeCurrent", "");
				   commonDao.commitTransaction();
			} catch (BimisException e) {
					commonDao.rollBack();
					log.logError(e);
				   ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			}	
	}
	
	/**
	 * ɾ��ҵ�������Ϣ & deletePftp
	 * @throws JDOMException 
	 */
	public void deletePftp() throws JDOMException{
		try {
			List<String> proftpList = req.getReqDataTexts("proftps");
			if (proftpList != null && proftpList.size() > 0) {
				commonDao.beginTransaction();
				HashMap<String, List<String>> hashmap = new HashMap<String, List<String>>();
				hashmap.put("proftpList", proftpList);
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteProf", hashmap);
				commonDao.deleteByNamedSql(MYBATIS_NS+"deletePftp", hashmap);
				}
				commonDao.commitTransaction();
				   ResultUtils.setRspData(req, "200",  "�����ɹ�", "pftp_main", "", "");

		   } catch (BimisException e) {
				commonDao.rollBack();
			   ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "pftp_main", "", "");
		 }
	}
}
