package com.sunline.sunfe.busidata;

import java.util.HashMap;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.StringUtil;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.SessionParaUtils;

/**
 * ���˵Ǽǲ������� 
 * @ClassName: GlaChkBookAction 
 * @author: FZF
 * @date: 2017-9-5 ����5:19:36
 */
public class GlaChkBookAction extends Actor{
	
	private final static String GlaChkBook_MYBATIS = "com.sunline.sunfe.mybatis.glaChkBook.";
	
	@SuppressWarnings("unchecked")
	public void getglaChkBookList() throws JDOMException, BimisException{
		HashMap<String,String> param = (HashMap<String, String>) req.getReqDataMap();
		String satcid = SessionParaUtils.getStacid();
		param.put("stacid", satcid);
		String glisdt = PubUtil.getGlisdt(Integer.parseInt(satcid));
		if(StringUtil.isNullOrEmpty(param.get("acctdt"))){
			param.put("acctdt", glisdt);
		}
		Element e = commonDao.queryByNamedSqlWithPage
				(GlaChkBook_MYBATIS+"getglaChkBooklistPage", req.getReqPageInfo(), param);
		req.addRspData(e.removeContent());
	}
}
