package com.sunline.sunfe.glisfund;

import java.util.Map;

import org.jdom.Element;

import com.sunline.jraf.services.Actor;
import com.sunline.suncm.util.SessionParaUtils;

public class GlisFundSearchActor extends Actor{
	
	
	public void queryFmbCntr() throws Exception {
		
		Map<String, Object> paramMap = req.getReqDataMap();
		paramMap.put("stacid", Integer.valueOf(SessionParaUtils.getStacid()));
		Element e = commonDao.queryByNamedSqlWithPage("com.sunline.sunfe.mybatis.fmbcntr.queryFmbCntrlistPage", req.getReqPageInfo(),paramMap);
		req.addRspData(e.removeContent());
		
		 
		
	}
	
	
	
	
	
	
	

}
