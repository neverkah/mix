package com.sunline.sunfe.core.bean;

import java.util.HashMap;
import java.util.Map;

import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.JrafSession;
import com.sunline.suncm.util.StringUtils;

/**
 * @ClassName: FmpItemConfigBean
 * @Description: �ڲ��ʽ��Ŀ���ñ����Ĳ�����
 * @author: huangzhongjie
 * @date: 2018��1��17�� ����4:05:06
 */
public class FmpItemConfigBean {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static String getFmpItemConfigByPrimaryKey(int stacid, String brchtp, String fundtp) {
		CommonDao commonDao = new CommonDao(JrafSession.getCurrentRootSession());
		Map mapParam = new HashMap();
		mapParam.put("stacid", stacid);
		mapParam.put("brchtp", brchtp);
		mapParam.put("fundtp", fundtp);

		Map mapFmpItemConfig = commonDao.getSqlSession().selectOne("com.sunline.sunfe.mybatis.fmpitemconfig.queryFmpItemConfigByPk", mapParam);

		return StringUtils.toString(mapFmpItemConfig.get("itemcd"));
	}

}
