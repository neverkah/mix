package com.sunline.sunfe.base;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.jraf.util.StringUtil;
import com.sunline.suncm.util.SessionParaUtils;

public class VchrTmplActor extends Actor {
	// ����sql�������ռ�
	private static final String VHCRTMPL = "com.sunline.sunfe.mybatis.vchrtmpl.";

	Log log = new Log("IntfAction");

	/*
	 * ��ҳ��ѯ
	 */

	@SuppressWarnings("unchecked")
	public void VchrTmplList() throws Exception {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		hashMap = req.getReqDataMap();
		hashMap.put("stacid", SessionParaUtils.getStacid());
		Element e = commonDao.queryByNamedSqlWithPage(VHCRTMPL
				+ "vchrtmpllistPage", req.getReqPageInfo(), hashMap);
		req.addRspData(e.removeContent());
	}
	
	/*
	 * ��ѯ����
	 */

	@SuppressWarnings("unchecked")
	public void getVchrTmpl() throws Exception {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		hashMap = req.getReqDataMap();
		hashMap.put("stacid", SessionParaUtils.getStacid());
		Element e = commonDao.queryByNamedSqlWithPage(VHCRTMPL
				+ "getVchrTmpl", req.getReqPageInfo(), hashMap);
		req.addRspData(e.removeContent());
	}

	/*
	 * ��ѯȫ��
	 */
	@SuppressWarnings("unchecked")
	public void queryVchrTmpl() throws Exception {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		hashMap = req.getReqDataMap();
		hashMap.clear();
		req.setReqPageNo(1);
		req.setReqPageSize(20);
		hashMap.put("varitp", "1");
		hashMap.put("stacid", SessionParaUtils.getStacid());
		Element e1 = commonDao.queryByNamedSql(VHCRTMPL
				+ "vchrtmpllistPage", hashMap);
		req.addRspData("Results1", e1.removeContent());
	}

	/*
	 * ����ɾ��
	 */
	@SuppressWarnings("rawtypes")
	public void delVchrTmpl() throws Exception, JDOMException {
		Map<String, Object> hashMap = new HashMap<String, Object>();
	
		List<?> parampList = req.getReqDataTexts("paramp");
		if ((parampList != null) && (parampList.size() > 0)) {
			commonDao.beginTransaction();
			for (int i = 0; i < parampList.size(); i++) {
				hashMap.put("varicd", parampList.get(i).toString());
				hashMap.put("stacid",SessionParaUtils.getStacid());
				List sumList = commonDao.queryByNamedSqlForList(VHCRTMPL
						+ "checkVchrTmpl", hashMap);
				if (sumList.size() > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "����ɾ���̶�������������飡");
					return;
				}
				

				//�ж��Ƿ���ʹ�� gla_vchr gla_vchr_h
				hashMap.put("param", "*");
				Element e1= commonDao.queryByNamedSql(VHCRTMPL+"checktmplvhcr", hashMap);
				int count1 = Integer.parseInt(e1.getChild("Record").getChildText("count"));
				
				Element e2= commonDao.queryByNamedSql(VHCRTMPL+"checktmplvhcrh", hashMap);
				int count2 = Integer.parseInt(e2.getChild("Record").getChildText("count"));
				if((count1+count2)>0){
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "��������Ϊ"+parampList.get(i)+"�������Ѿ�������ƺ�����������ɾ����");
					return;
					
				}
				
				
				//ɾ��tmplͬʱɾ��Iomp
				int counttmpl = commonDao.deleteByNamedSql(
						VHCRTMPL + "delVchrTmpl", hashMap);
				int countiomp = commonDao.deleteByNamedSql(
						VHCRTMPL + "delVchrIomp", hashMap);
				if ((counttmpl+countiomp) == 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "��" + (i + 1) + "����¼ɾ��ʧ��");
					commonDao.rollBack();
					return;
				}
			}
			commonDao.commitTransaction();
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "ɾ���ɹ���");
		} else {
			//�ж��Ƿ���ʹ�� gla_vchr gla_vchr_h
			String varicd = req.getReqDataStr("varicd");
			hashMap.put("varicd",varicd);
			hashMap.put("stacid",SessionParaUtils.getStacid());
			
			
			hashMap.put("param", "*");
			Element e1= commonDao.queryByNamedSql(VHCRTMPL+"checktmplvhcr", hashMap);
			int count1 = Integer.parseInt(e1.getChild("Record").getChildText("count"));
			
			Element e2= commonDao.queryByNamedSql(VHCRTMPL+"checktmplvhcrh", hashMap);
			int count2 = Integer.parseInt(e2.getChild("Record").getChildText("count"));
			if((count1+count2)>0){
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "���������Ѿ�������ƺ�����������ɾ����");
				return;
				
			}
			//ɾ��tmplͬʱɾ��Iomp
			int counttmpl = commonDao.deleteByNamedSql(
					VHCRTMPL + "delVchrTmpl", hashMap);
			int countiomp = commonDao.deleteByNamedSql(
					VHCRTMPL + "delVchrIomp", hashMap);
			if ((counttmpl+countiomp) == 0) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "ɾ��ʧ��");
				commonDao.rollBack();
				return;
			}
			
			req.addRspData("retCode", "200");// ��Ӧ����
			req.addRspData("retMessage", "�����ɹ�");// ��Ӧ��Ϣ
			req.addRspData("navTabId", "vchrtmpl_list");// ��תҳ�棬Ŀǰ��֧��navTabId����ҳ��
		}
	}

	/*
	 * ����
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void InsertVchrTmpl() throws Exception, JDOMException {
		try {
			HashMap<String,String> data = (HashMap<String, String>) req.getReqDataMap();
			List<String> varicds = req.getReqDataTexts("varicd");
			List<String> varicds_1 = req.getReqDataTexts("varicd_1");
			String stacid = SessionParaUtils.getStacid();
			commonDao.beginTransaction();
			for (Iterator iterator = varicds.iterator(); iterator.hasNext();) {
				 String varicd = ( String) iterator.next();
				 HashMap<String,String> comitex = new HashMap<>();
				 comitex.put("stacid", stacid);
				 comitex.put("assimp", varicd);
				 comitex.put("acexcd", data.get(varicd+"_acexcd"));
				 comitex.put("acexna", data.get(varicd+"_busina"));
				 comitex.put("desctx", data.get(varicd+"_desctx"));
				 if( StringUtil.isNullOrEmpty(data.get(varicd+"_valide"))){
					 comitex.put("valide", "0");
				 }else{
					 comitex.put("valide", "1");
				 }
				 commonDao.updateByNamedSql(VHCRTMPL+"updateComItex", comitex);
			}
			for (Iterator iterator = varicds_1.iterator(); iterator.hasNext();) {
				 String string = (String) iterator.next();
				 HashMap<String,String> vchrtmpl = new HashMap<>();
				 vchrtmpl.put("stacid", stacid);
				 vchrtmpl.put("varicd", string);
				 vchrtmpl.put("detner", data.get(string+"_detner"));
				 vchrtmpl.put("varitp", "1");
				 commonDao.updateByNamedSql(VHCRTMPL+"updateVchrTmplDetner", vchrtmpl);
			}
			commonDao.commitTransaction();
			req.addRspData("retCode", "200");// ��Ӧ����
			req.addRspData("retMessage", "�����ɹ�");// ��Ӧ��Ϣ
			req.addRspData("callbackType", "closeCurrent");// �ص���������,"closeCurrent"��ʾ�رյ�ǰҳ��
			req.addRspData("navTabId", "vchrtmpl_list");// ��תҳ�棬Ŀǰ��֧��navTabId����ҳ��
		} catch (BimisException e) {
			commonDao.rollBack();
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ�ܣ�");
			log.logError(e);
		}
	}
	
	/*
	 * �޸�
	 */
	@SuppressWarnings("unchecked")
	public void updateVchrTmpl() throws Exception, JDOMException {
		HashMap<String, String> hashMap = (HashMap<String, String>) req.getReqDataMap();
		hashMap.put("stacid", SessionParaUtils.getStacid());
		
		/*
		 * ������
		 
		String updaid = SessionParaUtils.getUsercd();//
		String updati = DatetimeUtil.getNow(DatetimeUtil.DATE_FORMAT_YMD);// ����ʱ��
		
		hashMap.put("updaid", updaid);
		hashMap.put("updati", updati);*/
		
		
		int count = commonDao.updateByNamedSql(VHCRTMPL + "updateVchrTmplDetl",hashMap);
		if(count==0){
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ�ܣ�");
		}
		req.addRspData("retCode", "200");
		req.addRspData("retMessage", "�����ɹ���");
		req.addRspData("callbackType", "closeCurrent");// �ص���������,"closeCurrent"��ʾ�رյ�ǰҳ��
		req.addRspData("navTabId", "vchrtmpl_list");// ��תҳ�棬Ŀǰ��֧��navTabId����ҳ��
	}
	
	/*
	 * ͣ���ж�
	 */

	@SuppressWarnings("unused")
	public void checkUse() throws Exception {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		String varicd = req.getReqDataStr("varicd");
			
		//�ж��Ƿ���ʹ�� gla_vchr gla_vchr_h
		hashMap.put("stacid", SessionParaUtils.getStacid());
		hashMap.put("varicd", varicd);
		hashMap.put("param", "*");
		
		
		Element e1= commonDao.queryByNamedSql(VHCRTMPL+"checktmplvhcr", hashMap);
		int count1 = Integer.parseInt(e1.getChild("Record").getChildText("count"));
		
		Element e2= commonDao.queryByNamedSql(VHCRTMPL+"checktmplvhcrh", hashMap);
		int count2 = Integer.parseInt(e2.getChild("Record").getChildText("count"));
		//����Ѿ�����¼���򷵻���ʾ����ͣ��
		if((count1+count2)>0){
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "������ά�����Ѿ�������ƺ�����������ͣ�ã�");
			return;
			
		}else{//���û�����ɷ�¼����ɾ����ص�vchr_iomp, sys_iomp �� ftokey ֵΪ��ά����ֵ������
			
			int countvchr = commonDao.deleteByNamedSql(
					VHCRTMPL + "delVchrIomp", hashMap);
			
			int countsys = commonDao.deleteByNamedSql(
					VHCRTMPL + "delSysIomp", hashMap);
			
			req.addRspData("retCode", "200");// ��Ӧ����
		}
	}
	
	/**
	 * ���¶�ά�������
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void updateComItexOrdeid() throws JDOMException{
		try {
			HashMap<String,String> data = (HashMap<String, String>) req.getReqDataMap();
			data.put("stacid", SessionParaUtils.getStacid());
			commonDao.updateByNamedSql(VHCRTMPL+"UpdateComItexOrdeidByordeid", data);
			commonDao.updateByNamedSql(VHCRTMPL+"UpdateComItexOrdeid", data);
			req.addRspData("retCode", "200");
		} catch (BimisException e) {
			commonDao.rollBack();
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ�ܣ�");
			log.logError(e);
		}
	}
}
