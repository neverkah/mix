package com.sunline.sunfe.entity;

import java.math.BigDecimal;

/**
 * 
 * @author Hopechj
 *
 */
public class TranamInfoEntity {
		private String amntcd;
		private BigDecimal tranam;
		
		public TranamInfoEntity(String amntcd , BigDecimal tranam){
			this.amntcd = amntcd;
			this.tranam = tranam;
		}
		
		public String getAmntcd() {
			return amntcd;
		}
		public void setAmntcd(String amntcd) {
			this.amntcd = amntcd;
		}
		public BigDecimal getTranam() {
			return tranam;
		}
		public void setTranam(BigDecimal tranam) {
			this.tranam = tranam;
		}
		
}
