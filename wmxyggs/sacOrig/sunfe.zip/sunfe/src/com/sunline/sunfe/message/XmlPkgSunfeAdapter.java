package com.sunline.sunfe.message;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.xpath.XPath;

import com.sunline.jraf.util.JDomUtil;
import com.sunline.sundp.gw.base.adapter.AbstractAdapter;
import com.sunline.sundp.gw.base.convert.ConvertorFactory;
import com.sunline.sundp.gw.base.exception.SendException;
import com.sunline.sundp.gw.base.ltts.PackHead;
import com.sunline.sundp.gw.base.util.AdapterUtil;
import com.sunline.sundp.gw.base.util.Constants;
import com.sunline.sundp.gw.base.util.ConvertorUtil;
import com.sunline.sundp.gw.base.util.PropList;
import com.sunline.sundp.gw.base.util.SenderUtil;
import com.sunline.sundp.gw.base.util.StringUtil;
import com.sunline.sunfe.message.head.PackHeadSunfe;

/**
 * @ClassName: XmlPkgJcAdapter
 * @Description: xml����������
 * @author: huangzhongjie
 * @date: 2017��11��13�� ����2:17:26
 */

public class XmlPkgSunfeAdapter extends AbstractAdapter {

	private final static Logger logger = Logger.getLogger(XmlPkgSunfeAdapter.class);

	/**
	 * Field����ת����
	 */
	private ConvertorFactory factory;

	/**
	 * ����ģ����������ȡ��Ӧ������������Ϣ��
	 */
	private String moduleName;

	/**
	 * ������
	 */
	private String prcscd = "";

	/**
	 * �Է�������
	 */
	private String toprcscd = "";

	private String userid = "";

	private String sessionid = "";

	private Document xmlDoc = null;

	private String charSet;

	public XmlPkgSunfeAdapter() {

	}

	public void initialize(String listenerType) {
		prcscd = "";
		toprcscd = "";
		factory = AdapterUtil.getConvertorFactory(listenerType);
		moduleName = (String) AdapterUtil.getModuleNames().get(listenerType);
	}

	public String getModuleName() {
		return moduleName;
	}

	public String getPrcscd() {
		return prcscd;
	}

	public void setPacketOut(String msgStr) {
		String xmlStr = msgStr.substring(PackHead.getPackHeadLength());
		if (isValiade(xmlStr)) {
			packagingBody = xmlStr;
			Element prcscdEle = null;
			try {
				prcscdEle = (Element) XPath.selectSingleNode(xmlDoc, "/transaction/body/request/prcscd");
			} catch (JDOMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (null != prcscdEle) {
				prcscd = prcscdEle.getValue();
			}
			if (null == prcscd || prcscd.trim().length() == 0) {
				try {
					throw new Exception("���յı�����Ϣ�����������루prcscd��");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public Object getPacketOut() {
		return packagingBody;
	}

	public void setPacketIn(String ret, Hashtable sendParams) {

		packagingBody = ret;

		byte[] packet = null;
		String headprcscd = sendParams.containsKey("headprcscd") ? sendParams.get("headprcscd").toString() : "";
		String userid = sendParams.containsKey("userid") ? sendParams.get("userid").toString() : "";
		String sessionid = sendParams.containsKey("sessionid") ? sendParams.get("sessionid").toString() : "";
		String charSet = sendParams.containsKey("charSet") ? sendParams.get("charSet").toString() : "utf-8";
		String isrequest = sendParams.containsKey("isrequest") ? sendParams.get("isrequest").toString() : "1";
		String bsnsdt = sendParams.containsKey("trandt") ? sendParams.get("trandt").toString() : "";

		this.charSet = charSet;

		byte[] head = null;
		try {
			PackHeadSunfe.setCharSet(charSet);
			head = PackHeadSunfe.getLttsPackBySunfrs(ret, prcscd, userid, "", bsnsdt);

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			String sHead = new String(head, charSet);
			logger.debug("head ==== " + sHead);
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		try {
			packetIn = (new String(head, charSet)).concat(ret);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	public void setPackagingHead(Hashtable sendParams) {
		String headprcscd = sendParams.containsKey("headprcscd") ? sendParams.get("headprcscd").toString() : "";
		String userid = sendParams.containsKey("userid") ? sendParams.get("userid").toString() : "";
		String sessionid = sendParams.containsKey("sessionid") ? sendParams.get("sessionid").toString() : "";
		String charSet = sendParams.containsKey("charSet") ? sendParams.get("charSet").toString() : "utf-8";
		try {
			PackHead.setCharSet(charSet);
			packagingHead = PackHead.getLttsPack(packagingBody.toString(), headprcscd, userid, sessionid);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Object packagingHead(Hashtable initPara) {
		return null;
	}

	/**
	 * �Դ���Ĵ���
	 */
	public Object processError(Exception e) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if (e instanceof SendException) {
			map.put("result", ((SendException) e).getResultCode());
		} else {
			map.put("result", Constants.RST_SYS_ERR);
		}
		map.put("erorcd", "FAIL");
		map.put("erortx", e.getMessage());

		return map;
	}

	/**
	 * ��ԴMap����XML����ת��ΪĿ��Map��ѭ���ֶ����ֶ���+_+��ű�ʾ,��itemcd_1
	 */
	public Object processIn(Element reqElement, Map inputMap, Hashtable sendParams) throws Exception {

		List fields = reqElement.getChildren("Field");

		Document packBuf = null; // �Ե�һ���ڵ��cnvtna�������ڵ�
		if (fields.size() > 0) {
			Element firstEle = (Element) fields.get(0);
			String rootName = ConvertorUtil.convertString(firstEle.getAttribute("cnvtna").getValue()); // ������/��ͷ��
			rootName = rootName.substring(1, rootName.indexOf("/", 1)); // ʾ��/root/prcscd
																		// ��ȡ
																		// root
			packBuf = JDomUtil.getDocument("<" + rootName + "/>");

		}

		packFields(packBuf, fields, inputMap, "", 0);

		if (null == prcscd || "".equals(prcscd.trim())) {
			throw new Exception("�����벻��ΪNull");
		}

		sendParams.put("prcscd", prcscd);
		sendParams.put("toprcscd", toprcscd);
		sendParams.put("userid", userid);
		sendParams.put("sessionid", sessionid);

		String ret = JDomUtil.toXML(packBuf, sendParams.get("charSet").toString(), false);
		this.setPacketIn(ret, sendParams);
		return packetIn;
	}

	/**
	 * ��ԴMap����XML����ת��ΪĿ��Map��ѭ���ֶ����ֶ���+_+��ű�ʾ,��itemcd_1
	 */
	public Object processIn(Element reqElement, Map inputMap, Hashtable sendParams, String listenerType) throws Exception {
		List fields = reqElement.getChildren("Field");

		Document packBuf = null; // �Ե�һ���ڵ��cnvtna�������ڵ�
		if (fields.size() > 0) {
			Element firstEle = (Element) fields.get(0);
			String rootName = ConvertorUtil.convertString(firstEle.getAttribute("cnvtna").getValue()); // ������/��ͷ��
			rootName = rootName.substring(1, rootName.indexOf("/", 1)); // ʾ��/root/prcscd
																		// ��ȡ
																		// root
			packBuf = JDomUtil.getDocument("<" + rootName + "/>");
		}

		packFields(packBuf, fields, inputMap, "", 0);

		if (null == prcscd || "".equals(prcscd.trim())) {
			throw new Exception("�����벻��ΪNull");
		}

		sendParams.put("prcscd", prcscd);
		sendParams.put("toprcscd", toprcscd);
		sendParams.put("userid", userid);
		sendParams.put("sessionid", sessionid);
		sendParams.put("trandt", inputMap.get("trandt"));

		Hashtable initParams = SenderUtil.getParamsConfig(listenerType);
		String ret = JDomUtil.toXML(packBuf, (String) initParams.get("charSet"), false);
		this.setPacketIn(ret);
		return ret;
	}

	/**
	 * ������Map����XML����ת��Ϊ��׼Map
	 */
	public Object processOut(Object packet, Element rspElement) throws Exception {
		StringBuffer sbuf = new StringBuffer(((String) packet).substring(PackHead.getPackHeadLength()));

		List fields = rspElement.getChildren("Field");
		Document pkg = null;
		if (isValiade(sbuf.toString())) {
			pkg = JDomUtil.getDocument(sbuf.toString().trim());
		}

		Map<String, Object> map = copyResFields(pkg, fields, "", 0);
		map.put("result", "0");

		this.setPacketOut(pkg);
		return map;
	}

	/**
	 * ���ɱ���
	 * 
	 * @param buf
	 *            StringBuffer
	 * @param fields
	 *            List
	 * @param inputMap
	 *            Map ����Map
	 * @param parentName
	 *            String �����ڵ�����
	 * @param level
	 *            index �������
	 */
	private void packFields(Document buf, List fields, Map inputMap, String parentName, int index) {
		for (int i = 0; i < fields.size(); i++) {
			Element field = (Element) fields.get(i);
			packField(buf, field, inputMap, parentName, index);
		}
	}

	/**
	 * ���ĸ�ʽת��
	 * 
	 * @param buf
	 *            StringBuffer
	 * @param field
	 *            Element
	 * @param inputMap
	 *            Map
	 * @param parentName
	 *            String �����ڵ�����
	 * @param level
	 *            index �������
	 */
	private void packField(Document buf, Element field, Map inputMap, String parentName, int index) {
		String name = field.getAttribute("name").getValue();
		String cnvtna = field.getAttribute("cnvtna").getValue(); // ת������
		int maxlen = Integer.parseInt(StringUtil.getEmptyDefault(field.getAttributeValue("maxlen"), "0")); // ��󳤶�

		if (null == field.getAttribute("multi")) {
			String value = String.valueOf(inputMap.get(name));
			if (null == value || "null" == value) { // ��ȡĬ��ֵ
				value = field.getAttributeValue("defaultval");
			}
			if (Constants.PRCSCD.equals(name)) {
				this.prcscd = value;
			} else if (Constants.TOPRCSCD.equals(name)) {
				this.toprcscd = value;
			} else if ("usidsession".equals(name)) {
				this.userid = value;
				return;
			} else if ("sessionid".equals(name)) {
				this.sessionid = value;
				return;
			}

			// ����ת��ʾ��
			String fieldType = field.getAttribute("type").getValue();

			// ����ת��
			String tmpVal = (String) factory.getConvertor(fieldType).pack(value, field);
			if (tmpVal != null && tmpVal.length() > maxlen) {
				tmpVal = tmpVal.substring(0, maxlen);
			}

			// ѭ���ֶδ���
			if (null != parentName && !"".equals(parentName)) {
				if (index > 0) {
					cnvtna = parentName + "_" + index + "/" + cnvtna;
					;
				} else {
					cnvtna = parentName + "/" + cnvtna;
				}
			}
			putNode(buf, cnvtna, tmpVal);

		} else {

			// List fields = field.getChild("Record").getChildren("Field");
			List fields = null;
			int size = 0;
			if (null != field.getChild("Record")) {
				fields = field.getChild("Record").getChildren("Field");
				PropList pList = (PropList) inputMap.get(name);
				Map recordMap = null;
				/*
				 * DeBug System.out.println("cnvtna is "+cnvtna);
				 * if(pList==null){
				 * System.out.println("pList is null and name is "+name); }else{
				 * System.out.println("pList is not null and name is "+name); }
				 */
				putNode(buf, cnvtna + "_listnm", String.valueOf(pList.size())); // ��vclist_listnm
				for (int i = 0; i < pList.size(); i++) {
					recordMap = (Map) pList.get(i);
					packFields(buf, fields, recordMap, cnvtna, i + 1);
				}
				size = pList.size();
			} else {
				/*
				 * fields = new ArrayList(); fields.add(field);
				 * 
				 * ArrayList pList = new ArrayList(); if( inputMap.get(name)
				 * instanceof List){ pList = (ArrayList)inputMap.get(name);
				 * 
				 * // Map recordMap = new HashMap(); /*DeBug
				 * System.out.println("cnvtna is "+cnvtna); if(pList==null){
				 * System.out.println("pList is null and name is "+name); }else{
				 * System.out.println("pList is not null and name is "+name); }
				 */
				/*
				 * putNode(buf ,cnvtna +"_listnm",String.valueOf(pList.size()));
				 * //��vclist_listnm for(int i=0; i< pList.size(); i++){
				 * //recordMap.put(name, pList.get(i).toString());
				 * //packFields(buf,fields,recordMap,cnvtna,i + 1); putNode(buf
				 * ,cnvtna+"_"+(i+1),pList.get(i).toString()); } size =
				 * pList.size();}
				 */
			}

			// �ָ�ѭ���ֶε�����
			Element ele;
			String eleName = cnvtna.substring(cnvtna.lastIndexOf("/") + 1);
			for (int i = 0; i < size; i++) {
				try {
					ele = JDomUtil.createPath(buf, cnvtna + "_" + String.valueOf(i + 1));
					if (ele != null) {
						ele.setName(eleName);
					}
				} catch (JDOMException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * ���ɱ���
	 * 
	 * @param Document
	 *            buf
	 * @param name
	 *            String
	 * @param value
	 *            String
	 */
	private void putNode(Document buf, String name, String value) {
		try {
			Element childNode = JDomUtil.createPath(buf, ConvertorUtil.convertString(name));
			if (childNode != null) {
				childNode.setText(ConvertorUtil.convertStringByParam(value, ""));
			}
		} catch (JDOMException e) {
			e.printStackTrace();
		}
	}

	/**
	 * ��������
	 * 
	 * @param sbuf
	 *            String
	 * @param fields
	 *            List
	 * @param parentName
	 *            String
	 */
	private Map<String, Object> copyResFields(Document pkg, List fields, String parentName, int index) {
		Map<String, Object> outMap = new HashMap<String, Object>();

		PropList outpList = null;
		Map<String, Object> recordMap = new HashMap<String, Object>();
		for (int i = 0; i < fields.size(); i++) {
			Element field = (Element) fields.get(i);

			if (null == field.getAttribute("multi")) {
				setResOutVal(pkg, field, parentName, index, outMap);
			} else {
				// String name = field.getAttribute("name").getValue();
				String cnvtna = field.getAttribute("cnvtna").getValue(); // ת������
				int listnm;
				try {
					listnm = XPath.selectNodes(pkg, cnvtna).size();
				} catch (JDOMException e) {
					listnm = 0;
					e.printStackTrace();
				}
				if (0 == listnm) {
					return outMap;
				}
				outpList = new PropList();
				outMap.put(field.getAttribute("name").getValue(), outpList);

				List fieldList = field.getChild("Record").getChildren("Field");

				for (int j = 0; j < listnm; j++) {
					recordMap = copyResFields(pkg, fieldList, cnvtna, j + 1);
					outpList.add(recordMap);
				}
			}
		}

		return outMap;
	}

	private void setResOutVal(Document pkg, Element field, String parentName, int index, Map<String, Object> outMap) {
		if (null == pkg || null == field || null == outMap) {
			return;
		}

		String fieldName = field.getAttribute("name").getValue();
		String name = field.getAttribute("cnvtna").getValue(); // ת������
		if (null != parentName && !"".equals(parentName)) {
			name = parentName + "/" + name;
		}

		Element valEle = null;
		try {
			if (index > 0) {
				List nodes = XPath.selectNodes(pkg, name);
				valEle = (Element) nodes.get(index - 1);
			} else {
				valEle = (Element) XPath.selectSingleNode(pkg, name);
			}
		} catch (JDOMException e) {
			e.printStackTrace();
		}

		String fieldType = "", value = "", tmpVal = "";

		if (valEle == null) {
			String defaultval = field.getAttributeValue("defaultval");
			if (null != field.getAttribute("if")) {

				String ifval = tranIF(pkg, field, parentName, index);
				if (null != ifval) {
					defaultval = ifval;
				}
				/*
				 * List ifList = field.getChildren("If"); Element ifField =
				 * null; String ifcnvtna ="",ifcnvtva=""; Object ifobj = null;
				 * for(int m=0; m<ifList.size(); m++){ ifField =
				 * (Element)ifList.get(m); ifcnvtna =
				 * ifField.getAttribute("cnvtna").getValue(); //ת������ if(null !=
				 * parentName && !"".equals(parentName)){ ifcnvtna = parentName
				 * + "/" + ifcnvtna; } try { ifobj = XPath.selectNodes(pkg,
				 * ifcnvtna).get(index); value = ((Element)ifobj).getText(); }
				 * catch (JDOMException e) { e.printStackTrace(); } fieldType =
				 * ifField.getAttribute("type").getValue();
				 * 
				 * //����ת�� tmpVal =
				 * (String)factory.getConvertor(fieldType).unPack
				 * (value,ifField); ifcnvtva =
				 * ifField.getAttribute("cnvtva").getValue(); //����ֵ if(tmpVal !=
				 * null && tmpVal.equals(ifcnvtva)){ defaultval =
				 * ifField.getText(); } }
				 */}
			outMap.put(fieldName, defaultval); // Ĭ��ֵ
			return;
		}

		fieldType = field.getAttribute("type").getValue();
		value = valEle.getText();
		// ����ת��
		tmpVal = (String) factory.getConvertor(fieldType).unPack(value, field);

		outMap.put(fieldName, tmpVal);
	}

	private String tranIF(Document pkg, Element field, String parentName, int index) {

		String fieldType = "", value = "", tmpVal = "", defaultval = "";

		List ifList = field.getChildren("If");
		Element ifField = null;
		String ifcnvtna = "", ifcnvtva = "";
		Object ifobj = null;
		for (int m = 0; m < ifList.size(); m++) {
			ifField = (Element) ifList.get(m);
			ifcnvtna = ifField.getAttribute("cnvtna").getValue(); // ת������
			if (null != parentName && !"".equals(parentName)) {
				ifcnvtna = parentName + "/" + ifcnvtna;
			}
			try {
				List ifLists = XPath.selectNodes(pkg, ifcnvtna);

				if (null == ifLists || ifLists.size() == 0) {
					return null;
				} else {
					ifobj = ifLists.get(index);
					value = ((Element) ifobj).getText();
				}

			} catch (JDOMException e) {
				e.printStackTrace();
			}
			fieldType = ifField.getAttribute("type").getValue();

			// ����ת��
			tmpVal = (String) factory.getConvertor(fieldType).unPack(value, ifField);
			ifcnvtva = ifField.getAttribute("cnvtva").getValue(); // ����ֵ
			if (tmpVal != null && tmpVal.equals(ifcnvtva)) {
				defaultval = ifField.getText();
			}
		}
		return defaultval;
	}

	private boolean isValiade(String xmlStr) {
		logger.debug("XmlPkgSunfeAdapter isValiade  parameter" + xmlStr);
		xmlStr= xmlStr.trim();
		boolean valiade = false;
		try {
			xmlDoc = JDomUtil.getDocument(xmlStr);
			valiade = true;
		} catch (Exception ex) {
			logger.error("Error XML String:" + xmlStr);
			ex.printStackTrace();
		}
		return valiade;
	}

}
