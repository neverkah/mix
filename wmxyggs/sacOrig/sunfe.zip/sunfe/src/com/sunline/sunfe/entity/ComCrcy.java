package com.sunline.sunfe.entity;

/**
 * 
 * @ClassName: ComCrcy 
 * @Description: ����com_crcy����Ӧ��java bean
 * @author: zhangdq
 * @date: 2017-5-23 ����10:47:37
 */
public class ComCrcy {
	private String crcycd  ;//���ִ���      
	private String crcyna  ;//��������      
	private String crcyen  ;//�������ִ��� 
	private String crcysg  ;//���ַ���      
	private int crcydg     ;//����С��λ    
	private int crcycg     ;//��������λ    
	private String dibstg  ;//�����־      
	private String usabtg  ;//���ñ�־      
	private int cysgdg     ;//�ֶ���ϢС��λ
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public String getCrcyna() {
		return crcyna;
	}
	public void setCrcyna(String crcyna) {
		this.crcyna = crcyna;
	}
	public String getCrcyen() {
		return crcyen;
	}
	public void setCrcyen(String crcyen) {
		this.crcyen = crcyen;
	}
	public String getCrcysg() {
		return crcysg;
	}
	public void setCrcysg(String crcysg) {
		this.crcysg = crcysg;
	}
	public int getCrcydg() {
		return crcydg;
	}
	public void setCrcydg(int crcydg) {
		this.crcydg = crcydg;
	}
	public int getCrcycg() {
		return crcycg;
	}
	public void setCrcycg(int crcycg) {
		this.crcycg = crcycg;
	}
	public String getDibstg() {
		return dibstg;
	}
	public void setDibstg(String dibstg) {
		this.dibstg = dibstg;
	}
	public String getUsabtg() {
		return usabtg;
	}
	public void setUsabtg(String usabtg) {
		this.usabtg = usabtg;
	}
	public int getCysgdg() {
		return cysgdg;
	}
	public void setCysgdg(int cysgdg) {
		this.cysgdg = cysgdg;
	}

}
