package com.sunline.sunfe.schedule;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.services.JrafSession;
import com.sunline.suncm.bean.Glibalg;
import com.sunline.suncm.util.PubUtil;
import com.sunline.sundp.datamanager.DatafileManager;
import com.sunline.sundp.entity.GliImpBean;
import com.sunline.sundp.entity.GloImdtBean;
import com.sunline.sundp.util.Enumeration;
import com.sunline.sundp.util.StringUtils;
import com.taobao.pamirs.schedule.IScheduleTaskDealSingle;
import com.taobao.pamirs.schedule.TaskItemDefine;

/**
 * ���ݹ���ƽ̨��־��¼ ��¼ÿ�����ε��ļ��������������
 * 
 * @author huangzhongjie
 * 
 */
public class GliLogExecuter extends Actor implements IScheduleTaskDealSingle<Object> {
	private static Log log = LogFactory.getLog(GliLogExecuter.class);

	private String MYBATIS_NS_DATAMANAGER = "com.sunline.sundp.mybatis.dataFileManager.";
	public final static String IMPORT_ING = "0";// ж��δ���
	public final static String IMPORT_COMPLETED = "1";// ж�����
	public final static String IMPORT_FAILED = "2";// ж��ʧ��

	@Override
	public List<Object> selectTasks(String taskParameter, String ownSign, int taskItemNum, List<TaskItemDefine> taskItemList,
			int eachFetchDataNum) throws Exception {
		log.debug("......start GliLogExecuter selectTasks......");
		HashMap<String, String> map = StringUtils.String2Map(taskParameter);
		String stacid = map.get("stacid");
		List<Object> list = new ArrayList<Object>();

		log.debug("......end GliLogExecuter selectTasks......");
		ReturnData returnData = new ReturnData();
		returnData.setStacid(stacid);
		list.add(returnData);

		return list;

	}

	@Override
	public Comparator<Object> getComparator() {
		return null;
	}

	/**
	 * 
	 */
	@Override
	public boolean execute(Object task, String ownSign) throws Exception {
		ReturnData returnData = (ReturnData) task;

		JrafSession jrafSession = DatafileManager.getJrafSession(null);
		try {
			CommonDao commonDao = new CommonDao(jrafSession);
			logMain(returnData, commonDao);
		} finally {
			DatafileManager.closeConnection(jrafSession);
		}

		return true;
	}

	private void logMain(ReturnData returnData, CommonDao commonDao) throws Exception, BimisException {
		String curdate = PubUtil.getGlisdt(Integer.parseInt(returnData.getStacid()));

		HashMap hashMap = new HashMap();
		hashMap.put("batcdt", curdate);
		hashMap.put("stacid", returnData.getStacid());
		log.debug("......GliLogExecuter execute...... batcdt = " + curdate);
		List<Glibalg> lstGliBalg = commonDao.getSqlSession().selectList(MYBATIS_NS_DATAMANAGER + "qryGliBalgByBatcdt", hashMap);
		log.debug("......GliLogExecuter execute...... lstGliBalg.size = " + lstGliBalg.size());
		for (Glibalg glibalg : lstGliBalg) {

			HashMap hashMapUpdGliBalg = new HashMap();
			hashMapUpdGliBalg.put("bathid", glibalg.getBathid());

			HashMap hashMapQry = new HashMap();
			hashMapQry.put("bathid", glibalg.getBathid());
			// ����״̬
			String pastau = glibalg.getPastau();

			// step1.1 begin-----------
			// �ӱ�׼�ӿڱ�loan_busi��ͨ�����κŻ�ȡ���ν������

			if (!Enumeration.Status.S.value.equals(glibalg.getPastau())) {
				// �����ɹ�����
				hashMapQry.put("status", Enumeration.Status.S.value);
				// ������ˮ����
				Integer pasunm = commonDao.getSqlSession().selectOne(MYBATIS_NS_DATAMANAGER + "qryGliBalgNmByBathidStatus",
						hashMapQry);
				if (pasunm == 0) {
					// �����ˮ����
					pasunm = commonDao.getSqlSession().selectOne(MYBATIS_NS_DATAMANAGER + "qryGliBalgNmByBathidStatusKj",
							hashMapQry);
				}

				// ����ʧ������
				hashMapQry.put("status", Enumeration.Status.F.value);
				// ������ˮ����
				Integer pafanm = commonDao.getSqlSession().selectOne(MYBATIS_NS_DATAMANAGER + "qryGliBalgNmByBathidStatus",
						hashMapQry);
				if (pafanm == 0) {
					// �����ˮ����
					pafanm = commonDao.getSqlSession().selectOne(MYBATIS_NS_DATAMANAGER + "qryGliBalgNmByBathidStatusKj",
							hashMapQry);
				}

				hashMapUpdGliBalg.put("pasunm", pasunm);
				hashMapUpdGliBalg.put("pafanm", pafanm);
				// ����״̬
				pastau = getPastau(pafanm, pasunm, glibalg.getDatanm());
				hashMapUpdGliBalg.put("pastau", pastau);

				// ����gli_balg���Ľ������
				commonDao.updateByNamedSql(MYBATIS_NS_DATAMANAGER + "updGliBalgPa", hashMapUpdGliBalg);

				// ����glo_imdt status
				String status = "";
				if (Enumeration.Status.O.value.equals(pastau)) {
					status = Enumeration.ImdtStatus.PAO.value;
				} else if (Enumeration.Status.S.value.equals(pastau)) {
					status = Enumeration.ImdtStatus.PAS.value;
				} else if (Enumeration.Status.F.value.equals(pastau)) {
					status = Enumeration.ImdtStatus.PAF.value;
				}
				if (StringUtils.isNotEmpty(status)) {
					hashMapUpdGliBalg.put("status", status);
					commonDao.updateByNamedSql(MYBATIS_NS_DATAMANAGER + "updGloImdtStatusABybathid", hashMapUpdGliBalg);
				}

				// step1.1 end-----------
			}

			if (!Enumeration.Status.S.value.equals(glibalg.getEnstau())) {
				// step1.2 begin-----------
				// ������׼�ӿڱ�loan_busi����Ʊ��gla_vchr�в�ѯ�������
				// ���˳ɹ�����
				hashMapQry.put("transt", Enumeration.Status.S.value);
				// ������ˮ����
				Integer ensunm = commonDao.getSqlSession().selectOne(MYBATIS_NS_DATAMANAGER + "qryGlaVchrByBathidTranst",
						hashMapQry);
				if (ensunm == 0) {
					// �����ˮ����
					ensunm = commonDao.getSqlSession().selectOne(MYBATIS_NS_DATAMANAGER + "qryGlaVchrByBathidTranstKj",
							hashMapQry);
				}
				hashMapUpdGliBalg.put("ensunm", ensunm);

				// ����ʧ������
				hashMapQry.put("transt", Enumeration.Status.F.value);
				// ������ˮ����
				Integer enfanm = commonDao.getSqlSession().selectOne(MYBATIS_NS_DATAMANAGER + "qryGlaVchrByBathidTranst",
						hashMapQry);
				if (enfanm == 0) {
					// �����ˮ����
					enfanm = commonDao.getSqlSession().selectOne(MYBATIS_NS_DATAMANAGER + "qryGlaVchrByBathidTranstKj",
							hashMapQry);
				}
				hashMapUpdGliBalg.put("enfanm", enfanm);

				// δ��ʼ�������� transt = '0'
				hashMapQry.put("transt", Enumeration.Status.NS.value);
				Integer ennsnm = commonDao.getSqlSession().selectOne(MYBATIS_NS_DATAMANAGER + "qryGlaVchrByBathidTranst",
						hashMapQry);
				if (ennsnm == 0) {
					ennsnm = commonDao.getSqlSession().selectOne(MYBATIS_NS_DATAMANAGER + "qryGlaVchrByBathidTranstKj",
							hashMapQry);
				}

				// ����״̬
				String enstau = getEnstau(pastau, enfanm, ensunm, ennsnm, glibalg.getBathid());
				hashMapUpdGliBalg.put("enstau", enstau);
				// step1.2 end-----------

				// step1.3 ����gli_balg�����������
				commonDao.updateByNamedSql(MYBATIS_NS_DATAMANAGER + "updGliBalgEn", hashMapUpdGliBalg);

				// ����glo_imdt status
				String status = "";
				if (Enumeration.Status.O.value.equals(enstau)) {
					status = Enumeration.ImdtStatus.ENO.value;
				} else if (Enumeration.Status.S.value.equals(enstau)) {
					status = Enumeration.ImdtStatus.ENS.value;
				} else if (Enumeration.Status.F.value.equals(enstau)) {
					status = Enumeration.ImdtStatus.ENF.value;
				}
				if (StringUtils.isNotEmpty(status)) {
					hashMapUpdGliBalg.put("status", status);
					commonDao.updateByNamedSql(MYBATIS_NS_DATAMANAGER + "updGloImdtStatusABybathid", hashMapUpdGliBalg);
				}

			}
		}

	}

	private String getEnstau(String pastau, Integer enfanm, Integer ensunm, Integer ennsnm, String bathid) throws Exception {
		String enstau = "";
		// ����״̬Ϊδ��ʼ��ʧ�ܣ�������״̬�ͽ���״̬һ��
		if (Enumeration.Status.NS.value.equals(pastau) || Enumeration.Status.F.value.equals(pastau)) {
			enstau = pastau;
		}
		// ����״̬Ϊ������
		else if (Enumeration.Status.O.value.equals(pastau)) {
			// ��һ��ʧ�ܣ�������״̬Ϊʧ��
			if (enfanm > 0) {
				enstau = Enumeration.Status.F.value;
			} else if (ensunm > 0) {
				enstau = Enumeration.Status.O.value;
			}
		}
		// �����ɹ��������
		else if (Enumeration.Status.S.value.equals(pastau)) {
			if (enfanm == 0 && ennsnm == 0) {
				enstau = Enumeration.Status.S.value;
			} else if (enfanm == 0 && ennsnm > 0) {
				enstau = Enumeration.Status.O.value;
			} else {
				enstau = Enumeration.Status.F.value;
			}
		} else {
			throw new BimisException("99", "����״̬����ö��ֵ[0,1,2,3]��");
		}
		return enstau;
	}

	public String getPastau(Integer failNm, Integer succNm, Integer allNm) {
		// ������������
		if (failNm + succNm == allNm) {
			if (failNm == 0) {
				return Enumeration.Status.S.value;
			} else {
				return Enumeration.Status.F.value;
			}
		} else if (failNm == 0 && succNm == 0) {
			return Enumeration.Status.NS.value;
		} else {
			return Enumeration.Status.O.value;
		}
	}

	// selectTask���������������
	class ReturnData {

		// ���κ�
		private String batchId;
		private String stacid;
		private String plancd;
		private String systid;
		private String certno;

		public String getCertno() {
			return certno;
		}

		public void setCertno(String certno) {
			this.certno = certno;
		}

		private GliImpBean impInfo;
		private GloImdtBean gloImdtInfo;

		public String getSystid() {
			return systid;
		}

		public void setSystid(String systid) {
			this.systid = systid;
		}

		public GliImpBean getImpInfo() {
			return impInfo;
		}

		public void setImpInfo(GliImpBean impInfo) {
			this.impInfo = impInfo;
		}

		public GloImdtBean getGloImdtInfo() {
			return gloImdtInfo;
		}

		public void setGloImdtInfo(GloImdtBean gloImdtInfo) {
			this.gloImdtInfo = gloImdtInfo;
		}

		public String getPlancd() {
			return plancd;
		}

		public void setPlancd(String plancd) {
			this.plancd = plancd;
		}

		public String getStacid() {
			return stacid;
		}

		public void setStacid(String stacid) {
			this.stacid = stacid;
		}

		public String getBatchId() {
			return batchId;
		}

		public void setBatchId(String batchId) {
			this.batchId = batchId;
		}
	}

}
