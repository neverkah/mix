package com.sunline.sunfe.base;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.SessionParaUtils;

public class VchrIompActor extends Actor {
	// ����sql�������ռ�
	private static final String VHCRTMPL = "com.sunline.sunfe.mybatis.vchriomp.";

	Log log = new Log("IntfAction");

	/*
	 * ��ҳ��ѯ
	 */

	@SuppressWarnings("unchecked")
	public void VchrIompList() throws Exception {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		hashMap = req.getReqDataMap();
		hashMap.put("stacid", SessionParaUtils.getStacid());
		Element e = commonDao.queryByNamedSqlWithPage(VHCRTMPL
				+ "vchriomplistPage", req.getReqPageInfo(), hashMap);
		req.addRspData(e.removeContent());
	}

	/*
	 * ��ѯ����
	 */

	@SuppressWarnings("unchecked")
	public void getVchrIomp() throws Exception {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		hashMap = req.getReqDataMap();
		hashMap.put("stacid", SessionParaUtils.getStacid());
		Element e = commonDao
				.queryByNamedSql(VHCRTMPL + "getVchrIomp", hashMap);
		Element x = e.getChild("Record");
		String varitp = x.getChildText("varitp");
		if ("1".equals(varitp)) {
			req.addRspData("varitype", "�̶�����");
		} else if ("2".equals(varitp)) {
			req.addRspData("varitype", "��ά����");
		}
		req.addRspData(e.removeContent());
	}

	/*
	 * ��ѯ����
	 */

	@SuppressWarnings("unchecked")
	public void getVchrIompDetl() throws Exception {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		hashMap = req.getReqDataMap();
		Element e = commonDao.queryByNamedSql(VHCRTMPL + "getVchrIompDetl",
				hashMap);
		req.addRspData(e.removeContent());
	}

	/*
	 * ģ���µ�ӳ�䶨����Ϣ
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void queryVchrIomp() throws Exception {
		HashMap<String, String> hashMap = (HashMap<String, String>) req.getReqDataMap();
		String module = req.getReqDataStr("module");
		hashMap.put("stacid", SessionParaUtils.getStacid());
		// ��ѯ������Ϣ
		List e1 = commonDao.queryByNamedSqlForList(VHCRTMPL + "vchriomp",
				hashMap);

		if (e1.size() != 0) {
			Element el = commonDao.queryByNamedSql(VHCRTMPL + "vchriomp",
					hashMap);
			Element x = el.getChild("Record");
			module = x.getChildText("module");
			String desctx = x.getChildText("desctx");
			req.addRspData("module", module);
			req.addRspData("module_desctx", desctx);
		} else {
			req.addRspData("module", module);
			req.addRspData("module_desctx", "");
		}

		if (module != null && !"1".equals(module) && !"".equals(module)) {
			// ��ѯ�ӱ���Ϣ
			hashMap.put("stacid", SessionParaUtils.getStacid());
			hashMap.put("module", req.getReqDataStr("module"));
			hashMap.put("varitp", "1");
			Element e2 = commonDao.queryByNamedSql(VHCRTMPL + "getVchrIomp",hashMap);
			req.addRspData("Results2", e2.removeContent());
			// ��ѯ�ӱ���Ϣ
			hashMap.put("varitp", "2");
			Element e3 = commonDao.queryByNamedSql(VHCRTMPL + "getVchrIomp",hashMap);
			req.addRspData("Results3", e3.removeContent());
			// ��ѯ��ά��Ʒ�¼��Ϣ
			Element e4 = commonDao.queryByNamedSql(VHCRTMPL + "getVchrTmpl",hashMap);
			req.addRspData("Results4", e4.removeContent());
		}
	}

	/*
	 * ����ɾ��
	 */
	public void delVchrIomp() throws Exception, JDOMException {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		List<?> parampList = req.getReqDataTexts("paramp");
		if ((parampList != null) && (parampList.size() > 0)) {
			commonDao.beginTransaction();
			for (int i = 0; i < parampList.size(); i++) {
				String varitp = parampList.get(i).toString().split("-")[2]
						.trim();
				if ("1".equals(varitp)) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "�̶����ݣ�����ɾ��,�����¹�ѡ��");
					commonDao.rollBack();
					return;
				} else {
					hashMap.put("tovacd",
							parampList.get(i).toString().split("-")[0].trim());
					hashMap.put("module",
							parampList.get(i).toString().split("-")[1].trim());
					hashMap.put("stacid", SessionParaUtils.getStacid());
					int count = commonDao.deleteByNamedSql(VHCRTMPL
							+ "delVchrIompDetl", hashMap);
					if (count == 0) {
						req.addRspData("retCode", "300");
						req.addRspData("retMessage", "��" + (i + 1) + "����¼ɾ��ʧ��");
						commonDao.rollBack();
						return;
					}
				}
			}
			commonDao.commitTransaction();
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "ɾ���ɹ���");
		} else {
			String tovacd = req.getReqDataStr("tovacd");
			String module = req.getReqDataStr("module");

			hashMap.clear();
			hashMap.put("tovacd", tovacd);
			hashMap.put("module", module);
			hashMap.put("stacid", SessionParaUtils.getStacid());
			int count = commonDao.deleteByNamedSql(
					VHCRTMPL + "delVchrIompDetl", hashMap);
			if (count == 0) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "ɾ��ʧ��!");
				commonDao.rollBack();
				return;
			}

			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "ɾ���ɹ���");
		}
	}

	/*
	 * ����
	 */
	@SuppressWarnings({ "rawtypes", "unused" })
	public void insertVchrIomp() throws Exception, JDOMException {
		try {
			HashMap<String, String> hashMap = new HashMap<String, String>();
			String module = req.getReqDataStr("module");
			String stacid = req.getReqDataStr("stacid");
			List<String> desctx_List = req.getReqDataTexts("desctx");
			int index = Integer.parseInt(req.getReqDataStr("index"));

			commonDao.beginTransaction();

			// ɾ��������
			HashMap<String, String> delMap = new HashMap<String, String>();
			delMap.put("module", module);
			delMap.put("stacid", stacid);
			List del = commonDao.queryByNamedSqlForList(VHCRTMPL
					+ "getVchrIompDetl", delMap);

			if (del.size() != 0) {
				delMap.put("module", module);
				int count = commonDao.deleteByNamedSql(VHCRTMPL
						+ "delVchrIompDetl", delMap);
			}

			// �޸�������ע

			String module_desctx = req.getReqDataStr("module_desctx");
			hashMap.put("module_desctx", module_desctx);
			hashMap.put("module", module);
			hashMap.put("stacid", stacid);

			int upd = commonDao.updateByNamedSql(VHCRTMPL + "updateDesctx",
					hashMap);
			if (upd == 0
					&& commonDao
							.queryByNamedSql(VHCRTMPL + "vchriomp", hashMap)
							.getContentSize() == 0) {
				// û��������Ϣ����������
				commonDao.insertByNamedSql(VHCRTMPL + "insert", hashMap);

			}

			// �����µ�����

			if (index > 0) {

				for (int i = 1; i <= index; i++) {
					String fmvacd = req.getReqDataStr("fmvacd" + i);
					Boolean flag = true;
					if ("".equals(fmvacd) || fmvacd == null) {
						flag = false;
					}

					if (flag) {

						hashMap.clear();

						String tovacd = req.getReqDataStr("tovacd" + i);
						String tovana = req.getReqDataStr("tovana" + i);
						String varitp = req.getReqDataStr("varitp" + i);
						String dexctx;
						String fmvana = req.getReqDataStr("fmvana" + i);

						hashMap.put("module", module);
						hashMap.put("tovacd", tovacd);
						hashMap.put("tovana", tovana);
						hashMap.put("ordeid", String.valueOf(i));
						hashMap.put("varitp", varitp);
						hashMap.put("fmvacd", fmvacd);
						hashMap.put("fmvana", fmvana);

						if (desctx_List.get(i - 1) == null
								|| "".equals(desctx_List.get(i - 1))) {
							dexctx = fmvana;
						} else {
							dexctx = desctx_List.get(i - 1);
						}

						hashMap.put("desctx", dexctx);
						hashMap.put("stacid", stacid);

						// �ж��Ƿ��к͹̶������ظ�������
						List sumList = commonDao.queryByNamedSqlForList(
								VHCRTMPL + "checkVchrIompDetl", hashMap);
						if (sumList.size() > 0) {
							req.addRspData("retCode", "300");
							req.addRspData("retMessage", "Ŀ����������ظ������飡");
							return;
						}
						commonDao.insertByNamedSql(VHCRTMPL
								+ "insertVchrIompDetl", hashMap);
					}
				}
			}
			commonDao.commitTransaction();
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ���");
			req.addRspData("callbackType", "closeCurrent");// �ص���������,"closeCurrent"��ʾ�رյ�ǰҳ��
			req.addRspData("navTabId", "vchriomp_list");// ��תҳ�棬Ŀǰ��֧��navTabId����ҳ��
		} catch (Exception e) {
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ�ܣ�");
			log.logError(e);
		}
	}

	/*
	 * �޸�
	 */
	public void updateVchrIomp() throws Exception, JDOMException {
		HashMap<String, String> hashMap = (HashMap<String, String>) req
				.getReqDataMap();

		/*
		 * ������
		 * 
		 * String updaid = SessionParaUtils.getUsercd();// String updati =
		 * DatetimeUtil.getNow(DatetimeUtil.DATE_FORMAT_YMD);// ����ʱ��
		 * 
		 * hashMap.put("updaid", updaid); hashMap.put("updati", updati);
		 */

		int count = commonDao.updateByNamedSql(VHCRTMPL + "updateVchrIompDetl",
				hashMap);
		if (count == 0) {
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ�ܣ�");
		}
		req.addRspData("retCode", "200");
		req.addRspData("retMessage", "�����ɹ���");
		req.addRspData("callbackType", "closeCurrent");// �ص���������,"closeCurrent"��ʾ�رյ�ǰҳ��
		req.addRspData("navTabId", "vchriomp_list");// ��תҳ�棬Ŀǰ��֧��navTabId����ҳ��
	}

}
