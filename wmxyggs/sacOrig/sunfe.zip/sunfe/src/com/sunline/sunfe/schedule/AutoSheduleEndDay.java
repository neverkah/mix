package com.sunline.sunfe.schedule;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.security.UserAuthenticator;
import com.sunline.jraf.services.BimisUser;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.services.JrafSessionFactory;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.suncm.util.StringUtils;
import com.sunline.sunfe.dayend.StepProcesserThread;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.Sequence;
import com.taobao.pamirs.schedule.strategy.IStrategyTask;

public class AutoSheduleEndDay implements IStrategyTask, Runnable {

	private static Log log = LogFactory.getLog(AutoSheduleEndDay.class);

	private String parameter;
	private boolean stop = false;
	public String pckgdt = "";

	/*public String userCode = "admin";
	public String deptCode = "600000";
	public String glisdt = "20170728";*/
	public String userCode = null;
	public String deptCode = null;
	public String glisdt = null;
	public int intervaltime = 60;

	UserAuthenticator ua = null;

	public boolean isPrepared() {
		return true;
	}

	public void init() {
		//userCode = null;
	}

	@Override
	public void initialTaskParameter(String taskParameter) {

		parameter = taskParameter;
		HashMap<String, String> mp = StringUtils.String2Map(parameter);
		if (mp.containsKey("intervaltime") && StringUtils.isNumeric(mp.get("intervaltime"))) {
			intervaltime = Integer.parseInt(mp.get("intervaltime"));
		} else {
			log.info("AutoSheduleEndDay ����ʱ�������÷Ƿ���ʹ��Ĭ��������" + intervaltime);
		}
		new Thread(this).start();
	}

	@Override
	public void run() {
		while (!stop) {
			if (isPrepared()) {
				init();
				excute();
			}
			try {
				Thread.sleep(intervaltime * 1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				log.error(e);
			}
		}
	}

	private void excute() {
		BimisUser user1 = new BimisUser();
		// user1.setAttribute("userCode", userCode);
		// user1.setAttribute("deptcode", deptCode);
		HashMap<String, String> mp = StringUtils.String2Map(parameter);
		String refreshTime = mp.get("refreshTime");
		String stacid = mp.get("stacid");

		user1.setAttribute("stacid",stacid);
		user1.setDeptcode(this.deptCode);
		user1.setUserCode(this.userCode);
		
		/*user1.setAttribute("stacid", stacid);
		user1.setAttribute("deptCode", deptCode);
		user1.setAttribute("userCode", userCode);*/
		ua = new UserAuthenticator(user1);

		StepProcesserThread hostTask = null;

		JrafSession jrafSession = null;

		UserAuthenticator.setAuthenticator(ua);// �����߳��������û���֤��Ϣ
		String bsnssq = null;
		// ��ȡҵ����ˮ ������ˮ(ÿ�β����ļ����ˮ) �ڲ�������������
		try {
			//Sequence sequence = SequenceUtils.createSequenceInnerTran(Integer.parseInt(stacid.trim()), "glissq", SessionParaUtils.getDeptcd(), null, 1);
			//Sequence sequence = SequenceUtils.createSequence(stacid.trim(),PubUtil.getGlisdt(Integer.valueOf(stacid.trim())), "glissq", SessionParaUtils.getDeptcd(), SessionParaUtils.getUsercd(), 1);
			Sequence sequence = SequenceUtils.createSequence(stacid.trim(),PubUtil.getGlisdt(Integer.valueOf(stacid.trim())), "glissq", deptCode, userCode, 1);
			bsnssq = sequence.getSqueno();
		} catch (NumberFormatException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (BimisException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		try {

			if (!mp.containsKey("edcttp") || !mp.containsKey("stacid")) {
				log.error("AutoSheduleEndDay�Զ�����Ȳ��� ȱ�ٲ���edcttp��stacid��" + parameter);
				throw new Exception("AutoSheduleEndDay�Զ�����Ȳ��� ȱ�ٲ���edcttp��stacid��" + parameter);
			} else {
				pckgdt = "|edcttp=" + mp.get("edcttp").concat("|");
				pckgdt = pckgdt + "stacid=" + mp.get("stacid").concat("|");
				pckgdt = pckgdt.concat("user_bsnssq=").concat(bsnssq).concat("|");
			}

			jrafSession = getJrafSession(jrafSession);
			CommonDao commonDao = new CommonDao(jrafSession);
			Map<String, Object> stacInfo = commonDao.getSqlSession().selectOne("com.sunline.sunfe.mybatis.stacinfo.queryStacInfoDetail", mp);
			String stacGlisdt = stacInfo.get("glisdt").toString();
			if (null == glisdt || !glisdt.equals(stacGlisdt)) {
				log.error("ִ�����յ�����" + glisdt + "������" + stacid + "������" + stacGlisdt + "��һ�£����ε���ȡ��");
				throw new Exception("ִ�����յ�����" + glisdt + "������" + stacid + "������" + stacGlisdt + "��һ�£����ε���ȡ��");
			}

			int stacst = ((BigDecimal) stacInfo.get("stacst")).intValue();
			if (null != stacInfo && !stacInfo.isEmpty() && stacst != 20) {
				log.error("����" + stacid + "��״̬Ϊ" + stacst + "�����ڽ������ջ����ճ��������ε���ȡ��");
				throw new Exception("����" + stacid + "��״̬Ϊ" + stacst + "�����ڽ������ջ����ճ��������ε���ȡ��");
			} else if (stacInfo.isEmpty()) {
				log.error("����" + stacid + "������");
				throw new Exception("����" + stacid + "������");
			}

			if (ua != null) {
				hostTask = new StepProcesserThread(Integer.parseInt(stacid.trim()), pckgdt, ua);

				hostTask.start();
			}

		} catch (Exception e) {
			log.error(e);
			try {
				// this.stop();
				Thread.sleep(5000);
			} catch (Exception e1) {
				// TODO Auto-generated catch block

			}
		} finally {
			this.closeConnection(jrafSession);
		}

	}

	private synchronized static JrafSession getJrafSession(JrafSession jrafSession) {
		try {
			if (jrafSession == null || jrafSession.getConnection() == null || jrafSession.getConnection().isClosed()) {
				jrafSession = JrafSessionFactory.getInstance().openSession();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return jrafSession;
	}

	public void closeConnection(JrafSession jrafSession) {
		try {
			if (jrafSession != null && jrafSession.getConnection() != null && !jrafSession.getConnection().isClosed()) {
				jrafSession.close();
				jrafSession = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.debug("jrafSession�ر�ʧ��!");
		}
	}

	@Override
	public void stop() throws Exception {
		log.fatal("AutoSheduleEndDay ֹͣ");
		stop = true;
	}

}
