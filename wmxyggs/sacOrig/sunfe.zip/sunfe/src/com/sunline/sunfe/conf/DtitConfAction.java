package com.sunline.sunfe.conf;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.services.Actor;
import com.sunline.sunfe.util.StringUtils;

/**
 * ��Ʒ��Ӧ�������ñ������� && DtitConfAction
 * Author: luoyd
 * creation time: 2016-12-19
 * @author ASUS
 *
 */
public class DtitConfAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.dtitconf.";
	
	/**
	 * ��ѯ��Ʒ��Ӧ���������б� && queryDtitConfListPage
	 * 
	 */
	public void queryDtitConfListPage(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String prodcd = req.getReqDataStr("prodcd");
			String prodpa = req.getReqDataStr("prodpa");
			String pageNo = req.getReqDataStr("pageNum");
			if (StringUtils.isNotEmpty(pageNo)) {
				req.setReqPageNo(Integer.parseInt(pageNo));
			}
			hashmap.put("prodcd", prodcd);
			hashmap.put("prodpa", prodpa);
			
			Element element = commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryDtitConflistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(element.removeContent());
		} catch (JDOMException e) {
			e.printStackTrace();
		}
	}
	/**
	 * ��ѯ��Ʒ��Ӧ������������ && queryDtitConfInfo
	 * 
	 */
	public void queryDtitConfInfo(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String prodcd = req.getReqDataStr("prodcd");
			String stacid = req.getReqDataStr("stacid");
			
			hashmap.put("prodcd", prodcd);
			hashmap.put("stacid", stacid);
			
			Element element = commonDao.queryByNamedSql(MYBATIS_NS+"queryDtitConfInfo", hashmap);
			req.addRspData(element.removeContent());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 *  ��Ʒ��Ӧ����������Ϣ��Ϣ¼��
	 */
	public void addDtitConf(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			commonDao.beginTransaction();
			String prodcd = req.getReqDataStr("prodcd");//���Դ���
			String prodp1 = req.getReqDataStr("prodp1");//����1
			String prodp2 = req.getReqDataStr("prodp2");//����2
			String prodp3 = req.getReqDataStr("prodp3");//����3
			String prodp4 = req.getReqDataStr("prodp4");//����4
			String prodp5 = req.getReqDataStr("prodp5");//����5
			String prodp6 = req.getReqDataStr("prodp6");//����6
			String prodp7 = req.getReqDataStr("prodp7");//����7
			String prodp8 = req.getReqDataStr("prodp8");//����8
			String prodp9 = req.getReqDataStr("prodp9");//����9
			String prodpa = req.getReqDataStr("prodpa");//��������
			String stacid = req.getReqDataStr("stacid");//�������
			
			hashmap.put("prodcd", prodcd);
			hashmap.put("prodp1", prodp1);
			hashmap.put("prodp2", prodp2);
			hashmap.put("prodp3", prodp3);
			hashmap.put("prodp4", prodp4);
			hashmap.put("prodp5", prodp5);
			hashmap.put("prodp6", prodp6);
			hashmap.put("prodp7", prodp7);
			hashmap.put("prodp8", prodp8);
			hashmap.put("prodp9", prodp9);
			hashmap.put("prodpa", prodpa);
			hashmap.put("stacid", stacid);
			
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistDtitConf", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "�ò�Ʒ��Ӧ���������Ѵ��ڣ�");
					return;
				}
			}
			
			commonDao.insertByNamedSql(MYBATIS_NS+"addDtitConf", hashmap);
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("navTabId", "");
			req.addRspData("callbackType", "closeCurrent");
			req.addRspData("forwardUrl", "");
			commonDao.commitTransaction();
			
		} catch (Exception e) {
			commonDao.rollBack();
			e.printStackTrace();
		}	
		
	}
	/**
	 *  ���²�Ʒ��Ӧ����������Ϣ
	 */
	public void updateDtitConf(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			commonDao.beginTransaction();
			
			String stacid = req.getReqDataStr("stacid");//����
			String prodcd = req.getReqDataStr("prodcd");//��Ʒ����
			String prodpa = req.getReqDataStr("prodpa");//��������
			String prodp1 = req.getReqDataStr("prodp1");//����1
			String prodp2 = req.getReqDataStr("prodp2");//����2
			String prodp3 = req.getReqDataStr("prodp3");//����3
			String prodp4 = req.getReqDataStr("prodp4");//����4
			String prodp5 = req.getReqDataStr("prodp5");//����5
			String prodp6 = req.getReqDataStr("prodp6");//����6
			String prodp7 = req.getReqDataStr("prodp7");//����7
			String prodp8 = req.getReqDataStr("prodp8");//����8
			String prodp9 = req.getReqDataStr("prodp9");//����9
			
			hashmap.put("stacid", stacid);
			hashmap.put("prodcd", prodcd);
			hashmap.put("prodpa", prodpa);
			hashmap.put("prodp1", prodp1);
			hashmap.put("prodp2", prodp2);
			hashmap.put("prodp3", prodp3);
			hashmap.put("prodp4", prodp4);
			hashmap.put("prodp5", prodp5);
			hashmap.put("prodp6", prodp6);
			hashmap.put("prodp7", prodp7);
			hashmap.put("prodp8", prodp8);
			hashmap.put("prodp9", prodp9);
			
			commonDao.insertByNamedSql(MYBATIS_NS+"updateDtitConf", hashmap);
			commonDao.commitTransaction();
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("navTabId", "dtitconf_main");
			req.addRspData("callbackType", "closeCurrent");
			req.addRspData("forwardUrl", "");
		} catch (Exception e) {
			commonDao.rollBack();
			try {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage",e.toString().substring(e.toString().lastIndexOf("Cause")));
				req.addRspData("navTabId", "dtitconf_main");
				req.addRspData("callbackType", "closeCurrent");
				req.addRspData("forwardUrl", "");
			} catch (JDOMException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		  }
	 }	
	/**
	 * ɾ����Ʒ��Ӧ����ӳ�� && deleteDtitConf
	 * 
	 */
    public void deleteDtitConf() {
		 try {
	        	HashMap<String, String> param = new HashMap<String, String>();
	            List<String> dtcfcdList = req.getReqDataTexts("dtcfcd");
	            commonDao.beginTransaction();
	            for (int i=0;i<dtcfcdList.size();i++) {
	            	 param.clear();
	                 String [] array = dtcfcdList.get(i).split("-");
	                 param.put("stacid", array[0]);
	                 param.put("prodcd", array[1]);
	                 commonDao.deleteByNamedSql(MYBATIS_NS+"deleteDtitConf", param);
	            }
	            commonDao.commitTransaction();
	            req.addRspData("retCode", "200");
				req.addRspData("retMessage", "�����ɹ�");
				req.addRspData("navTabId", "dtitconf_main");
				req.addRspData("callbackType", "");
				req.addRspData("forwardUrl", "");
			} catch (Exception e) {
				commonDao.rollBack();
				try {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage",e.toString().substring(e.toString().lastIndexOf("Cause")));
					req.addRspData("navTabId", "dtitconf_main");
					req.addRspData("callbackType", "");
					req.addRspData("forwardUrl", "");
				} catch (JDOMException e1) {
					e1.printStackTrace();
				}
				e.printStackTrace();
			  }
		}	
}
