package com.sunline.sunfe.base;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.sunfe.util.StringUtils;
public class TmapAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.tmap.";
	Log log = new Log("TmapAction");
	/**
	 * ��ѯҵ��ģ������嵥 & queryTmapListPage
	 */
	@SuppressWarnings("unchecked")
	public void queryTmapListPage(){
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("vermod", "0");
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryTmaplistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			log.logError(e);
		}
	}
	/**
	 * ��ѯ�������벻Ϊ�յ�ҵ��ģ������嵥 & queryTmapMpcdinListPage
	 */
	public void queryTmapMpcdinListPage(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String tmplna = req.getReqDataStr("tmplna");//ģ������
			String profna = req.getReqDataStr("profna");//��������
			String module = req.getReqDataStr("module");//ģ��
			hashmap.put("vermod", "0");
			String pageNo = req.getReqDataStr("pageNum");
			if (StringUtils.isNotEmpty(pageNo)) {
				req.setReqPageNo(Integer.parseInt(pageNo));
			}
			hashmap.put("tmplna", tmplna);
			hashmap.put("module", module);
			hashmap.put("profna", profna);
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryTmapMpcdinlistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			log.logError(e);
		}
	}
	/**
	 * ��ѯҵ��ģ������嵥 & queryTmapListPage
	 */
	public void queryTmapInfo(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String tmpltp = req.getReqDataStr("tmpltp");//ģ������
			String sortno = req.getReqDataStr("sortno");//�������
			String tmplid = req.getReqDataStr("tmplid");//ģ��Id
			hashmap.put("tmpltp", tmpltp);
			hashmap.put("sortno", sortno);
			hashmap.put("tmplid", tmplid);
			hashmap.put("vremod", "0");
			
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryTmapInfo",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			e.printStackTrace();
		}
	}
	/**
	 *  ����ҵ��ģ�����
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addTmap() throws JDOMException{
			
			try {
				HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
				commonDao.beginTransaction();
				List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTmap", hashmap);
				if(countList!=null && countList.size()>0) {
					Map countMap = (HashMap)countList.get(0);
					int count = Integer.valueOf(countMap.get("CC").toString());
					if(count > 0) {
						req.addRspData("retCode", "300");
						req.addRspData("retMessage", "ҵ��ģ������Ѵ��ڣ�");
						return;
					}
				}
				
				commonDao.insertByNamedSql(MYBATIS_NS+"addTmap", hashmap);
				ResultUtils.setRspData(req, "200",  "�����ɹ�", "tmap_main", "closeCurrent", "");
				commonDao.commitTransaction();
			} catch (BimisException e) {
				commonDao.rollBack();
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
				log.logError(e);
			}	
		}
	/**
	 *  �޸�ҵ��ģ����� & updateTmap
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void updateTmap() throws JDOMException{
		try {
			HashMap<String, String> hashmap =(HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			commonDao.updateByNamedSql(MYBATIS_NS+"updateTmap", hashmap);
			hashmap.put("vermod", "0");
			commonDao.insertByNamedSql(MYBATIS_NS+"addTmap", hashmap);
			commonDao.commitTransaction();
			ResultUtils.setRspData(req, "200",  "�����ɹ�", "tmap_main", "closeCurrent", "");
		} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
		}
	 }	
		
	/**
	 * �������ɾ��ҵ��ģ�������Ϣ
	 * @throws JDOMException 
	 */
	 public void deleteManyTmap() throws JDOMException {
	        try {
	        	HashMap<String, String> param = new HashMap<String, String>();
	            List<String> tpidnoList = req.getReqDataTexts("tpidno");
	            commonDao.beginTransaction();
	            for (int i=0;i<tpidnoList.size();i++) {
	            	param.clear();
	                String [] array = tpidnoList.get(i).split("-");
                    param.put("tmpltp", array[0]);
                    param.put("tmplid", array[1]);
                    param.put("sortno", array[2]);
                    commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTmap", param);
	            }
	            commonDao.commitTransaction();
				ResultUtils.setRspData(req, "200",  "�����ɹ�", "tmap_main", "", "");
	        } catch (BimisException e) {
	        	commonDao.rollBack();
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
				log.logError(e);
			}
		}	

	/**
	 * ����ɾ��ҵ��ģ�������Ϣ & deleteTmap
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void deleteTmap() throws JDOMException{
		try {
				HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
				commonDao.beginTransaction();
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTmap", hashmap);
				commonDao.commitTransaction();
				ResultUtils.setRspData(req, "200",  "�����ɹ�", "tmap_main", "", "");
	        } catch (BimisException e) {
	        	commonDao.rollBack();
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
				log.logError(e);
			}
	  }	 
}
