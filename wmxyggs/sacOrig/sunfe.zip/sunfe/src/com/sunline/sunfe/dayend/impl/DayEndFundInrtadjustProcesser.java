package com.sunline.sunfe.dayend.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.dayend.IDayEndProcesser;
import com.sunline.sunfe.glisfund.PublicFmbCntrInfoUtil;

/**
 * @author ����
 * @Email xiongl@sunline.cn
 * @Time 2017��12��28��
 * @��������ã��ڲ��ʽ𶨼۵���
 */
public class DayEndFundInrtadjustProcesser extends IDayEndProcesser {
	private static final Logger logger = LoggerFactory.getLogger(DayEndFundInrtadjustProcesser.class);
	private String stacid;
	private boolean flag;
	private String sourdt;
	private CommonDao commonDao;
	private PublicFmbCntrInfoUtil publicFmbCntrInfo;

	/**
	 * @throws BimisException
	 * @�˷��������ã�
	 */
	@Override
	public void preProcess() throws BimisException {
		commonDao = this.getCommonDao();
		stacid = SessionParaUtils.getStacid();
		publicFmbCntrInfo = new PublicFmbCntrInfoUtil(commonDao);
		// �ж��Ƿ�������
		sourdt = PubUtil.getGlisdt(Integer.parseInt(stacid));
		flag = publicFmbCntrInfo.isNormalDay(stacid, sourdt);
	}

	/**
	 * @throws BimisException
	 * @�˷��������ã�
	 */
	@Override
	public void processing() throws BimisException {
		if (!flag)
			throw new BimisException("502", "��ǰϵͳʱ�䡾" + sourdt + "�����ǻ������ʱ��");
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("stacid", stacid);
		// ��ȡ��Ч�ĺ�ͬ��Ϣ
		map.put("status", "1");
		// ��ȡ��ͬ���������Ƿ�Ϊϵͳ����
		map.put("efctdt", sourdt);
		try {
			List<Map<String, Object>> list = publicFmbCntrInfo.selectFmpInrtAjstInfos(map);
			commonDao.beginTransaction();
			// �������ӻ�Ʒ�¼
			for (int i = 0, length = list.size(); i < length; i++) {
				map.put("efctdt", sourdt);
				map = publicFmbCntrInfo.selectFmpInrtnfos(list.get(i));
				if (map.get("oldEfctdt") != null) {
					if ((map.get("oldEfctdt") + "").compareTo(sourdt) < 0)
						publicFmbCntrInfo.updateFmpInrt(map);
					else if ((map.get("oldEfctdt") + "").compareTo(sourdt) == 0) {
						if ((map.get("inrtrt") + "").compareTo(map.get("oldInrtrt") + "") != 0)
							throw new BimisException("512", "��ǰ��Ч�����ʲ��Ǽƻ�����");
						else
							continue;
					} else
						throw new BimisException("512", "ԭ�ʽ𶨼���������");
				}
				map.put("status", "1");
				map.put("inefdtNew", "20500101");
				publicFmbCntrInfo.insertFmpInrt(map);
				map.clear();
			}
			map.put("status", "2");
			map.put("oldStatus", "1");
			map.put("efctdt", sourdt);
			publicFmbCntrInfo.updateFmpInrtAjstStatus(map);
			publicFmbCntrInfo.executeBatch(publicFmbCntrInfo.insertFmpInrt);
			commonDao.commitTransaction();
		} catch (Exception e) {
			commonDao.rollBack();
			logger.error(e.getMessage());
			throw new BimisException("500", e.getMessage());
		} finally {
			publicFmbCntrInfo.closePreparedStatement(publicFmbCntrInfo.insertFmpInrt);
		}
	}

	/**
	 * @throws BimisException
	 * @�˷��������ã�
	 */
	@Override
	public void processed() throws BimisException {
	}

}
