package com.sunline.sunfe.glisfund;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.hibernate.HibernateException;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ming.util.Log;
import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.services.JrafSessionFactory;
import com.sunline.suncm.util.Enumeration;
import com.sunline.suncm.util.Enumeration.FUNDTP;
import com.sunline.suncm.util.Enumeration.GLA_ACCT_ACCTLG;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.suncm.util.StringUtils;
import com.sunline.sunfe.core.bean.GlaAcctBean;
import com.sunline.sunfe.core.service.KernelBookingServiceImpl;
import com.sunline.sunfe.entity.GlaAeuv;
import com.sunline.sunfe.entity.GlaAeuvDetl;
import com.sunline.sunfe.util.MybatisPathUtil;
import com.sunline.sunfe.util.PkgUtil;

/**
 * @author ����
 * @Email xiongl@sunline.cn
 * @Time 2017��12��25��
 * @��������ã����з�����
 */
@SuppressWarnings({ "unchecked" })
public class PublicFmbCntrInfoUtil {
	private static final Logger logger = LoggerFactory.getLogger(PublicFmbCntrInfoUtil.class);
	private CommonDao commonDao = null;
	private Connection conn = null;
	public PreparedStatement insertGlaAuve = null, insertGlaAuveDeltl = null, insertFmbDrrt = null, updateAcmlbl = null, insertFmsinst = null, insertFmpInrt = null, updateFmpInrtAjst = null, insertFmpInrtAjst = null;

	// �跽
	public static final String ITEMCD_D = "D";
	// ����
	public static final String ITEMCD_C = "C";
	// ���ӻ�Ʒ�¼��Ϣ
	public static final String INSERT_GLA_AEUV = "INSERT INTO GLA_AEUV(STACID,SOURST,SOURDT,SOURSQ,TRANBR,ACETNA,TRANTP,USERCD,REMARK,PRCSCD,TRANST,STRKST) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
	// ���ӻ�Ʒ�¼����
	public static final String INSERT_GLA_AEUV_DETL = "INSERT INTO GLA_AEUV_DETL(STACID,SOURST,SOURDT,SOURSQ,DISPSQ,ACCTBR,ITEMCD,AMNTCD,CRCYCD,TRANAM,TRANNM,SMRYTX,CENTCD,PRSNCD,CUSTCD,PRDUCD,PRLNCD,ACCTNO,ASSIS0,ASSIS1,ASSIS2,ASSIS3,ASSIS4,ASSIS5,ASSIS6,ASSIS7,ASSIS8,ASSIS9,ACCTCD) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	// �����ʽ������ˮ��Ϣ
	public static final String INSERT_FMB_DRRT = "INSERT INTO FMB_DRRT(STACID,DRRTNO,CNTRNO,DATATP,BRCHNO,UPPRBR,USERID,APLYDT,APLYSQ,APLYAM,TRANST,ACPTDT,ACPTSQ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
	// ���ӽ�����ˮ
	public static final String INSERT_GLA_TRAN = "INSERT INTO GLA_TRAN(STACID, TRANDT, TRANSQ, TRANTI, TRANBR, USERCD, SOURDT, SOURSQ, TRANTP, CRCYCD, PRCSCD, TRANAM, PSAUUS, STRKST, ACSRNM, SYSTID, MENUID,MAINBD, PCKGSQ, BOOKNO, CLERTG, REMARK) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	// �޸��˻�������Ϣ
	public static final String UPDATE_GLA_ACCT_ACMLBL = "UPDATE GLA_ACCT SET ACMLDT=?,ACMLBL=(Nvl(Acmlbl,0.00) + LASTBL*?) WHERE STACID=? AND ACCTCD=?";
	// �ڲ��ʽ��Ϣ�ǼǱ�
	public static final String INSERT_FMS_INST = "INSERT INTO FMS_INST(STACID,TRANDT,TRANSQ,INSTTP,BRCHNO,CNTRNO,DRRTNO,CRCYCD,INRTTP,TERMCD,BGINDT,ACMLBL,INRTRT,INSTAM) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	// �ڲ��ʽ𶨼۱���Ϣ
	public static final String INSERT_FMP_INRT = "INSERT INTO FMP_INRT(STACID,INRTTP,CRCYCD,TERMCD,INRTRT,STATUS,EFCTDT,INEFDT,BRCHCD) VALUES(?,?,?,?,?,?,?,?,?)";
	// �ڲ��ʽ𶨼۵�����Ϣ
	public static final String INSERT_FMP_INRT_AJST = "INSERT INTO FMP_INRT_AJST(STACID, INTRDT, INTRSQ, INTRUS, INRTTP, CRCYCD, TERMCD, INRTRT, EFCTDT, STATUS, BRCHCD) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
	// �ڲ��ʽ𶨼۵�����Ϣ
	public static final String UPDATE_FMP_INRT_AJST = "UPDATE FMP_INRT_AJST SET STATUS=? WHERE STACID=? AND INRTTP=? AND TERMCD=? AND EFCTDT=? AND BRCHCD=?";
	// ���ݿ�����
	private static String DBName = null;
	// ��Ʒ�¼��Ϣ
	public List<GlaAeuv> glaAeuvs = new ArrayList<GlaAeuv>();
	// ��Ʒ�¼��Ϣ����
	public ArrayList<GlaAeuvDetl> glaAeuvDetls = new ArrayList<GlaAeuvDetl>();

	public static final String FILTER_FILED = "pageNum,jraf_initsubmit,sysName,oprID,actions,forward,csrftoken";

	public PublicFmbCntrInfoUtil(CommonDao commonDao) {
		super();
		if (commonDao == null) {
			JrafSession jrafSession = JrafSession.getCurrentRootSession();
			if (jrafSession == null)
				jrafSession = JrafSessionFactory.getInstance().openSession();
			commonDao = new CommonDao(jrafSession);
		}
		this.commonDao = commonDao;
		this.conn = commonDao.getSession().connection();
	}

	/**
	 * @param stacid
	 *            ����
	 * @param trandt
	 *            ʱ�䣨һ��ϵͳʱ�䣩
	 * @return
	 * @throws BimisException
	 * @�˷��������ã���ѯ��ǰʱ���Ƿ�������
	 */
	public Boolean isNormalDay(String stacid, String trandt) throws BimisException {
		boolean flag = false;
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("stacid", Integer.valueOf(stacid));
			map.put("trandt", trandt);
			Map mapComAcpd = commonDao.getSqlSession().selectOne(MybatisPathUtil.COM_ACPD + "queryComAcpdInfo", map);
			if (null != mapComAcpd) {
				if ("0".equals(mapComAcpd.get("acpdtp").toString())) {
					flag = true;
				}

			} else {
				logger.error(MessageFormat.format("[{0}]�ڻ���ڼ��в�����", trandt));
				throw new BimisException("-1", MessageFormat.format("[{0}]�ڻ���ڼ��в�����", trandt));
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BimisException("��ѯ���������Ϣʧ��", e.getMessage());
		}
		return flag;
	}

	/**
	 * @param stacid
	 * @return
	 * @throws BimisException
	 * @�˷��������ã���⵱ǰ�û��������Ƿ�Ƿ�
	 */
	public Boolean isComStacVlidtg(String stacid) throws BimisException {
		boolean flag = false;
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("stacid", Integer.valueOf(stacid));
			Element e = commonDao.queryByNamedSql(MybatisPathUtil.COM_STAC + "quereComStaclistPage", map);
			if (!e.removeContent().isEmpty() && !"1".equals(e.getChild("Record").getChildTextTrim("vlidtg")))
				flag = true;
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BimisException("��ѯ���������Ϣʧ��", e.getMessage());
		}
		return flag;
	}

	/**
	 * @param stacid
	 * @return
	 * @throws BimisException
	 * @�˷��������ã��ж�Դϵͳ��Ϣ�Ƿ���Ч
	 */
	public Boolean isComSystVlidtg(String stacid, String sourst) throws BimisException {
		boolean flag = false;
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("stacid", Integer.valueOf(stacid));
			map.put("sourst", sourst);
			Element e = commonDao.queryByNamedSql(MybatisPathUtil.COM_SYST + "queryComSystInfolistPage", map);
			if (!e.removeContent().isEmpty() && !"1".equals(e.getChild("Record").getChildTextTrim("vlidtg")))
				flag = true;
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BimisException("��ѯ���������Ϣʧ��", e.getMessage());
		}
		return flag;
	}

	/**
	 * @param stacid
	 * @param brchno
	 * @return
	 * @throws BimisException
	 * @�˷��������ã��жϻ����Ƿ�Ϊ�������
	 */
	public boolean isComBrch(String stacid, String brchcd) throws BimisException {
		boolean flag = false;
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("stacid", Integer.valueOf(stacid));
			map.put("brchcd", brchcd);
			map.put("rltstp", "1");
			Element e = commonDao.queryByNamedSql(MybatisPathUtil.COM_BRCH + "getComBrchByKey", map);
			if (e.getContentSize() == 0)
				throw new BimisException("513", "��ѯ��" + brchcd + "����ϢΪ��");
			if (e.getContentSize() != 1)
				throw new BimisException("514", "��ѯ��" + brchcd + "����ϢΪ" + e.getContentSize() + "��");
			flag = true;
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BimisException("��ѯ��" + brchcd + "����Ϣʧ��", e.getMessage());
		}
		return flag;
	}

	/**
	 * @param stacid
	 * @param prcscd
	 * @return
	 * @throws BimisException
	 * @�˷��������ã���ѯ��Ӧ��������Ϣ
	 */
	public Map<String, Object> prcsnaInfo(int stacid, String prcscd) throws BimisException {
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			map.put("stacid", stacid);
			map.put("funcno", prcscd);
			List<?> list = commonDao.queryByNamedSqlForList(MybatisPathUtil.COM_FUNC + "queryComFuncInfolistPage", map);
			if (list.isEmpty())
				throw new BimisException("515", "�ڴ��������COM_FUNC����ѯ����Ϊ��" + stacid + "��������Ϊ��" + prcscd + "������ϢΪ��");
			map = (Map<String, Object>) list.get(0);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BimisException("��ѯ��������Ϣʧ��", e.getMessage());
		}
		return map;
	}

	/**
	 * @param stacid
	 * @param brchcd
	 * @return
	 * @throws BimisException
	 * @�˷��������ã���ѯ����������Ŀ��Ϣ
	 */
	public Map<String, Object> comBrchInfo(Map<String, Object> map) throws BimisException {
		try {
			map.put("detltg", "1");
			map.put("brchcd", map.get("brchno"));
			List<?> list = commonDao.queryByNamedSqlForList(MybatisPathUtil.COM_BRCH + "selectVComBrchlistPage", map);
			if (list.isEmpty())
				throw new BimisException("515", "δ��ѯ������Ϊ��" + map.get("stacid") + "����ϵ����Ϊ��1��������Ϊ��" + map.get("brchcd") + "���Ļ�����Ϣ");
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BimisException("��ѯ������Ϣʧ��", e.getMessage());
		}
		return map;
	}

	/**
	 * @param map
	 * @return
	 * @throws BimisException
	 * @�˷��������ã���ȡ��ͬ��Ϣ
	 */
	public List<Map<String, Object>> selectFmbCntrInfos(Map<String, Object> map) throws BimisException {
		List<Map<String, Object>> list = null;
		try {
			list = (List<Map<String, Object>>) commonDao.queryByNamedSqlForList(MybatisPathUtil.FMB_CNTR + "queryFmbCntrInfolistPage", map);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BimisException("��ѯ��ͬ��Ϣʧ��", e.getMessage());
		}
		return list;
	}

	/**
	 * @param stacid
	 * @param brchcd
	 * @return
	 * @throws BimisException
	 * @�˷��������ã���ȡ��ǰ����������������Ϣ
	 */
	public Map<String, Object> selectClpConf(String stacid, String brchcd) throws BimisException {
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			map.put("stacid", stacid);
			map.put("brchcd", brchcd);
			map = ((List<Map<String, Object>>) commonDao.queryByNamedSqlForList(MybatisPathUtil.CLP_CONF + "quereClpConflistPage", map)).get(0);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BimisException("��ѯ����������Ϣʧ��", e.getMessage());
		}
		return map;
	}

	/**
	 * @param map
	 *            ��ѯ��������
	 * @param stacid
	 *            ����
	 * @param sourdt
	 *            ϵͳʱ��
	 * @param prscna
	 *            ����������
	 * @param usercd
	 *            �Ǽ��û�
	 * @param prcscd
	 *            ������
	 * @param sourst
	 *            ԴϵͳID
	 * @param noOpen
	 *            �Ƿ�����¿�����ʶ��0���¿�1�¿���Ĭ��0
	 * @param remark
	 *            ע��
	 * @param trantp
	 *            ��������(1:�ֹ��ʣ�2��ϵͳ��)
	 * @param transt
	 *            ����״̬��1������ 0 �Ǽ� 8����������9�����ϣ�
	 * @param strkst
	 *            ����״̬��0���������ף�1���ý����ѱ�������9���ý���Ϊ�������ף�
	 * @param transqName
	 *            ��ˮsql���ƣ��磺bsnssq
	 * @param brchno
	 *            ��ȡ�������ݵĻ���
	 * @return
	 * @throws Exception
	 * @�˷��������ã���ʼ��һ������
	 */
	public Map<String, Object> loadMapInfo(Map<String, Object> map, String stacid, String sourdt, String prscna, String usercd, String prcscd, String sourst, String noOpen, String remark, String trantp, String transt, String strkst, String transqName, String brchno) throws Exception {
		try {
			map.put("sourdt", sourdt);
			map.put("acetna", prscna);
			map.put("usercd", usercd);
			map.put("prcscd", prcscd);
			map.put("sourst", sourst);
			map.put("noOpen", noOpen);
			map.put("remark", remark);
			map.put("soursq", SequenceUtils.createSequence(stacid, sourdt, transqName, brchno, usercd, 1).getSqueno());
			map.put("trantp", trantp);
			map.put("transt", transt);
			map.put("strkst", strkst);
		} catch (BimisException e) {
			logger.error(e.getMessage());
			throw new BimisException("501", "��ʼ�������쳣" + e.getMessage());
		}
		return map;
	}

	/**
	 * @param map
	 * @param pst
	 * @param comBrch
	 * @param clpConf
	 * @return
	 * @throws Exception
	 * @�˷��������ã�������Ϣ�����Ʒ�¼��
	 */
	public Map<String, Object> insertGlaAeuvInfo(Map<String, Object> map) throws Exception {
		if (insertGlaAuve == null)
			insertGlaAuve = conn.prepareStatement(PublicFmbCntrInfoUtil.INSERT_GLA_AEUV);
		GlaAeuv glaAeuv = new GlaAeuv();
		insertGlaAuve.setInt(1, Integer.parseInt(map.get("stacid") + ""));
		glaAeuv.setStacid(Integer.parseInt(map.get("stacid") + ""));
		insertGlaAuve.setString(2, map.get("sourst") + "");
		glaAeuv.setSourst(map.get("sourst") + "");
		insertGlaAuve.setString(3, map.get("sourdt") + "");
		glaAeuv.setSourdt(map.get("sourdt") + "");
		insertGlaAuve.setString(4, map.get("soursq") + "");
		glaAeuv.setSoursq(map.get("soursq") + "");
		insertGlaAuve.setString(5, map.get("upprbr") + "");
		glaAeuv.setTranbr(map.get("upprbr") + "");
		insertGlaAuve.setString(6, map.get("acetna") + "");
		glaAeuv.setAcetna(map.get("acetna") + "");
		insertGlaAuve.setString(7, map.get("trantp") + "");
		glaAeuv.setTrantp(map.get("trantp") + "");
		insertGlaAuve.setString(8, map.get("usercd") + "");
		glaAeuv.setUsercd(map.get("usercd") + "");
		insertGlaAuve.setString(9, map.get("remark") + "");
		glaAeuv.setRemark(map.get("remark") + "");
		insertGlaAuve.setString(10, map.get("prcscd") + "");
		glaAeuv.setPrcscd(map.get("prcscd") + "");
		insertGlaAuve.setString(11, map.get("transt") + "");
		glaAeuv.setTranst(map.get("transt") + "");
		insertGlaAuve.setString(12, map.get("strkst") + "");
		glaAeuv.setStrkst(map.get("strkst") + "");
		glaAeuvs.add(glaAeuv);
		insertGlaAuve.addBatch();
		return map;
	}

	/**
	 * @param map
	 * @throws BimisException
	 * @�˷��������ã���ѯ�ϴ����¼���飬�ϴ��ĿΪ**_U���½��ĿΪ**_L
	 */
	private Map<String, Object> selectFmpCntraAebs(Map<String, Object> map) throws BimisException {
		List<Element> itemcds = commonDao.queryByNamedSql(MybatisPathUtil.FMP_CNTR_AEBS + "queryFmpCntrAebsInfolistPage", map).removeContent();
		if (itemcds.isEmpty())
			throw new BimisException("305", "���ϴ����¼��δ�����������Ϊ��" + map.get("aebscd") + "���ϴ��½�㼶Ϊ��" + map.get("aebslv") + "������Ϣ");
		if (itemcds.size() != 1)
			throw new BimisException("305", "���ϴ����¼��δ�����������Ϊ��" + map.get("aebscd") + "���ϴ��½�㼶Ϊ��" + map.get("aebslv") + "������Ϣ��Ψһ");
		if (itemcds.get(0).getChildTextTrim("upprdr").isEmpty())
			throw new BimisException("305", "���ϴ����¼��δ�����������Ϊ��" + map.get("aebscd") + "���ϴ��½�㼶Ϊ��" + map.get("aebslv") + "�����ϼ��跽��Ϣ��������Ϣ");
		map.put("itemcdD_U", itemcds.get(0).getChildTextTrim("upprdr"));
		if (itemcds.get(0).getChildTextTrim("upprdr").isEmpty())
			throw new BimisException("305", "���ϴ����¼��δ�����������Ϊ��" + map.get("aebscd") + "���ϴ��½�㼶Ϊ��" + map.get("aebslv") + "�����ϼ�������Ϣ��������Ϣ");
		map.put("itemcdC_U", itemcds.get(0).getChildTextTrim("upprcr"));
		if (itemcds.get(0).getChildTextTrim("upprdr").isEmpty())
			throw new BimisException("305", "���ϴ����¼��δ�����������Ϊ��" + map.get("aebscd") + "���ϴ��½�㼶Ϊ��" + map.get("aebslv") + "�����¼��跽��Ϣ��������Ϣ");
		map.put("itemcdD_L", itemcds.get(0).getChildTextTrim("lowrdr"));
		if (itemcds.get(0).getChildTextTrim("upprdr").isEmpty())
			throw new BimisException("305", "���ϴ����¼��δ�����������Ϊ��" + map.get("aebscd") + "���ϴ��½�㼶Ϊ��" + map.get("aebslv") + "�����¼�������Ϣ��������Ϣ");
		map.put("itemcdC_L", itemcds.get(0).getChildTextTrim("lowrcr"));
		return map;
	}

	/**
	 * @param stacid
	 *            ����
	 * @param sourst
	 *            Դϵͳ��Դ
	 * @param sourdt
	 *            ϵͳʱ��
	 * @param soursq
	 *            SequenceUtils.createSequence(stacid, sourdt, "bsnssq",
	 *            list.get(i).get("brchno") + "", usercd, 1).getSqueno()
	 * @param brchno
	 *            �������
	 * @param upprbr
	 *            ��˻���
	 * @param cntrtp
	 *            ��ͬ����
	 * @param crcycd
	 *            ����
	 * @param tranam
	 *            ��ͬ���
	 * @param cntrno
	 *            ��ͬ��
	 * @param aebscd
	 *            ��ͬ��
	 * @�˷��������ã��������˷���
	 * @throws Exception
	 */

	public String fundCmbk(int stacid, String sourst, String sourdt, String soursq, String brchno, String upprbr, String cntrtp, String aebscd, String crcycd, BigDecimal tranam, BigDecimal instam, BigDecimal uninam, String cntrno) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("stacid", stacid);
		map.put("sourst", sourst);
		map.put("sourdt", sourdt);
		map.put("soursq", soursq);
		map.put("brchno", brchno);
		map.put("upprbr", upprbr);
		map.put("cntrtp", cntrtp);
		map.put("crcycd", crcycd);
		map.put("cntrbl", tranam);
		map.put("aebscd", aebscd);
		map.put("instam", instam);
		map.put("uninam", uninam);
		map.put("addBatch", true);
		insertGlaAeuvDetl(map);
		commonDao.insertByNamedSql(MybatisPathUtil.GLA_AEUV_DETL + "saveGlaAeuvDetlBatch", glaAeuvDetls);
		comAccounting(map);
		return map.get("transq").toString();
	}

	public Map<String, Object> insertGlaAeuvDetl(Map<String, Object> map) throws BimisException {
		registerGlaAeuvDetl(map);
		map.put("instam", map.get("oldinstam"));
		map.put("uninam", map.get("olduninam"));
		return map;
	}

	/**
	 * @param pst
	 * @param map
	 * @throws BimisException
	 * @�˷��������ã����ӻ�Ʒ�¼��Ϣ
	 */
	public Map<String, Object> registerGlaAeuvDetl(Map<String, Object> map) throws BimisException {
		try {
			comBrchInfo(map);
			String aebslv = selectClpConf(map.get("stacid").toString(), map.get("brchno").toString()).get("clerty").toString();
			map.put("aebslv", aebslv);
			selectFmpCntraAebs(map);
			if (map.get("cntrno") != null && !"".equals(map.get("cntrno")))
				map.put("smrytx", bulidSmrytxInfo(map));
			boolean flag = false;
			if (map.get("smrytx") == null || (map.get("smrytx") + "").isEmpty())
				flag = true;
			map.put("itemcdD", map.get("itemcdD_L"));
			map.put("itemcdC", map.get("itemcdC_L"));
			buildAcctclSubscd(map);
			map.put("itemcd", map.get("itemcdD_L"));
			map.put("subscd", map.get("subscdD"));
			map.put("acctcl", map.get("acctclD"));
			buildAcctno(map, 0);
			map.put("amntcd", PublicFmbCntrInfoUtil.ITEMCD_D);
			if (flag)
				map.put("smrytx", "�¼��跽");
			insertGlaAeuvDetlInfo(map, 0);
			map.put("itemcd", map.get("itemcdC_L"));
			map.put("subscd", map.get("subscdC"));
			map.put("acctcl", map.get("acctclC"));
			buildAcctno(map, 0);
			map.put("amntcd", PublicFmbCntrInfoUtil.ITEMCD_C);
			if (flag)
				map.put("smrytx", "�¼�����");
			insertGlaAeuvDetlInfo(map, 0);
			map.put("itemcdD", map.get("itemcdD_U"));
			map.put("itemcdC", map.get("itemcdC_U"));
			buildAcctclSubscd(map);
			map.put("itemcd", map.get("itemcdD_U"));
			map.put("subscd", map.get("subscdD"));
			map.put("acctcl", map.get("acctclD"));
			buildAcctno(map, 1);
			map.put("amntcd", PublicFmbCntrInfoUtil.ITEMCD_D);
			if (flag)
				map.put("smrytx", "�ϼ��跽");
			insertGlaAeuvDetlInfo(map, 1);
			map.put("itemcd", map.get("itemcdC_U"));
			map.put("subscd", map.get("subscdC"));
			map.put("acctcl", map.get("acctclC"));
			buildAcctno(map, 1);
			map.put("amntcd", PublicFmbCntrInfoUtil.ITEMCD_C);
			if (flag)
				map.put("smrytx", "�ϼ�����");
			insertGlaAeuvDetlInfo(map, 1);
			// ��Ϣ���֡�����֧ȡ,�黹ʱ��ֵ
			if (map.get("instam") != null && new BigDecimal("0").compareTo(new BigDecimal(map.get("instam") + "")) != 0) {
				map.put("aebscd", map.get("cntrtp") + "D");
				map.put("oldinstam", map.get("instam"));
				map.remove("instam");
				insertGlaAeuvDetl(map);
			}
			// ������ս�Ϣ
			if (map.get("uninam") != null && new BigDecimal("0").compareTo(new BigDecimal(map.get("uninam") + "")) != 0) {
				map.put("aebscd", map.get("cntrtp") + "D");
				map.put("olduninam", map.get("uninam"));
				map.remove("uninam");
				insertGlaAeuvDetl(map);
			}
			return map;
		} catch (Exception e) {
			// logger.error(e.getMessage());
			e.printStackTrace();
			throw new BimisException("��ѯ����������Ϣʧ��", e.getMessage());
		}
	}

	/**
	 * @param cntrno
	 * @param stacid
	 * @return
	 * @throws BimisException
	 * @�˷��������ã�����ժҪ
	 */
	private String bulidSmrytxInfo(Map<String, Object> map) throws BimisException {
		String smrytx = "";
		if ((map.get("cntrno") + "").startsWith("A")) {
			map.put("cntrnoDouble", (map.get("cntrno") + "").substring(1, 30));
			smrytx += "��ǰ֧ȡ-";
		} else
			map.put("cntrnoDouble", map.get("cntrno"));
		List<Element> itemcds = commonDao.queryByNamedSql(MybatisPathUtil.TABLE_UNION + "queryFmbDoubleDictInfolistPage", map).removeContent();
		if (itemcds.isEmpty()) {
			itemcds = commonDao.queryByNamedSql(MybatisPathUtil.TABLE_UNION + "queryFmbDictInfolistPage", map).removeContent();
			if (!itemcds.isEmpty()) {
				smrytx = itemcds.get(0).getChildTextTrim("bparana");
				if (map.get("sourdt").equals(itemcds.get(0).getChildTextTrim("matudt")))
					smrytx += "-����";
			} else {
				smrytx = "";
			}
		} else {
			smrytx = smrytx + itemcds.get(0).getChildTextTrim("bparana") + itemcds.get(0).getChildTextTrim("cparana");
			if (map.get("sourdt").equals(itemcds.get(0).getChildTextTrim("matudt")))
				smrytx += "-����";
		}
		return smrytx;
	}

	/**
	 * @param map
	 * @throws BimisException
	 * @�˷��������ã�ȷ�������˻������Ŀ��
	 */
	@SuppressWarnings("rawtypes")
	private void buildAcctclSubscd(Map<String, Object> map) throws BimisException {
		Map mapParam = new HashMap();
		mapParam.put("stacid", SessionParaUtils.getStacid());
		String[] arrFundtp = { FUNDTP.SCBFJ.value, FUNDTP.SCZBJ.value, FUNDTP.SCDQ.value };
		mapParam.put("fundtp", arrFundtp);

		List<Map> lstFmpItemConfig = commonDao.getSqlSession().selectList("com.sunline.sunfe.mybatis.fmpitemconfig.queryFmpItemConfig", mapParam);
		List<String> lstItemcd = new ArrayList();
		for (Map mapFmpItemConfig : lstFmpItemConfig) {
			lstItemcd.add(mapFmpItemConfig.get("itemcd").toString());
		}

		if (lstItemcd.contains(StringUtils.toString(map.get("itemcdD")))) {
			map.put("acctclD", GLA_ACCT_ACCTLG.SPECIALUSE.value);
			map.put("subscdD", map.get("brchno"));
		} else
			map.put("acctclD", GLA_ACCT_ACCTLG.BASE.value);
		if (lstItemcd.contains(StringUtils.toString(map.get("itemcdC")))) {
			map.put("acctclC", GLA_ACCT_ACCTLG.SPECIALUSE.value);
			map.put("subscdC", map.get("brchno"));
		} else
			map.put("acctclC", GLA_ACCT_ACCTLG.BASE.value);
	}

	/**
	 * @param map
	 * @return
	 * @throws BimisException
	 * @�˷��������ã���ȡ�˺���Ϣ��û�о�����
	 */
	private void buildAcctno(Map<String, Object> map, int type) throws BimisException {
		if ("US,OU,CN,FC,CC,CU,CF".contains(map.get("crcycd") + ""))
			throw new BimisException("309", "�۱��ֲ��ܿ�������" + map.get("brchno") + "������������������");

		if (map.get("subscd") == null && StringUtils.isEmpty(map.get("acctcl"))) {
			map.put("acctcl", "1");// �ֹ��˻�
		} else if (StringUtils.isNotEmpty(map.get("acctcl")) && map.get("subscd") == null) {
		} else {
			map.put("acctcl", "3");
			// throw new BimisException("310", "ר���˻�����ָ����Ŀ��");
		}
		GlaAeuvDetl glaAeuvDetl = new GlaAeuvDetl();
		glaAeuvDetl.setStacid(Integer.parseInt(map.get("stacid") + ""));
		glaAeuvDetl.setSourst(map.get("sourst") + "");
		glaAeuvDetl.setSourdt(map.get("sourdt") + "");
		glaAeuvDetl.setSoursq(map.get("soursq") + "");
		if (type == 0) {
			glaAeuvDetl.setAcctbr(map.get("brchno") + "");
		} else {
			glaAeuvDetl.setAcctbr(map.get("upprbr") + "");
		}
		glaAeuvDetl.setCrcycd(map.get("crcycd") + "");
		glaAeuvDetl.setItemcd(map.get("itemcd") + "");
		String subscd = StringUtils.toString(map.get("subscd"));
		map.put("acctcd", GlaAcctBean.openAcctcd(commonDao, glaAeuvDetl, StringUtils.toString(map.get("acctcl")), subscd));
	}

	/**
	 * @param pst
	 * @param map
	 * @throws NumberFormatException
	 * @throws SQLException
	 * @�˷��������ã��������ӻ�Ʒ�¼����
	 */
	private void insertGlaAeuvDetlInfo(Map<String, Object> map, int type) throws NumberFormatException, SQLException {
		GlaAeuvDetl glaAeuvDetl = new GlaAeuvDetl();
		if (map.get("dispsq") == null || "".equals(map.get("dispsq")))
			map.put("dispsq", 0);
		glaAeuvDetl.setDispsq(Integer.parseInt(map.get("dispsq") + "") + 1);
		map.put("dispsq", glaAeuvDetl.getDispsq());
		glaAeuvDetl.setStacid(Integer.parseInt(map.get("stacid") + ""));
		glaAeuvDetl.setSourst(map.get("sourst") + "");
		glaAeuvDetl.setSourdt(map.get("sourdt") + "");
		glaAeuvDetl.setSoursq(map.get("soursq") + "");
		if (type == 0)
			glaAeuvDetl.setAcctbr(map.get("brchno") + "");
		else
			glaAeuvDetl.setAcctbr(map.get("upprbr") + "");
		glaAeuvDetl.setAcctcd(map.get("acctcd") + "");
		glaAeuvDetl.setItemcd(map.get("itemcd") + "");
		glaAeuvDetl.setAmntcd(map.get("amntcd") + "");
		glaAeuvDetl.setCrcycd(map.get("crcycd") + "");
		glaAeuvDetl.setTranam(new BigDecimal(map.get("cntrbl") + ""));
		glaAeuvDetl.setTrannm(1);
		glaAeuvDetl.setSmrytx(map.get("smrytx") + "");
		glaAeuvDetl.setAcctcd(map.get("acctcd") + "");
		glaAeuvDetls.add(glaAeuvDetl);
		if (!"true".equals(map.get("addBatch") + "")) {
			if (insertGlaAuveDeltl == null)
				insertGlaAuveDeltl = conn.prepareStatement(PublicFmbCntrInfoUtil.INSERT_GLA_AEUV_DETL);
			// ��Ʊ��ż�һ
			insertGlaAuveDeltl.setInt(1, glaAeuvDetl.getStacid());
			insertGlaAuveDeltl.setString(2, glaAeuvDetl.getSourst());
			insertGlaAuveDeltl.setString(3, glaAeuvDetl.getSourdt());
			insertGlaAuveDeltl.setString(4, glaAeuvDetl.getSoursq());
			insertGlaAuveDeltl.setInt(5, glaAeuvDetl.getDispsq());
			insertGlaAuveDeltl.setString(6, glaAeuvDetl.getAcctbr());
			insertGlaAuveDeltl.setString(7, glaAeuvDetl.getItemcd());
			insertGlaAuveDeltl.setString(8, glaAeuvDetl.getAmntcd());
			insertGlaAuveDeltl.setString(9, glaAeuvDetl.getCrcycd());
			insertGlaAuveDeltl.setBigDecimal(10, glaAeuvDetl.getTranam());
			insertGlaAuveDeltl.setInt(11, glaAeuvDetl.getTrannm());
			insertGlaAuveDeltl.setString(12, glaAeuvDetl.getSmrytx());
			insertGlaAuveDeltl.setString(13, "*");
			insertGlaAuveDeltl.setString(14, "*");
			insertGlaAuveDeltl.setString(15, "*");
			insertGlaAuveDeltl.setString(16, "*");
			insertGlaAuveDeltl.setString(17, "*");
			insertGlaAuveDeltl.setString(18, "*");
			insertGlaAuveDeltl.setString(19, "*");
			insertGlaAuveDeltl.setString(20, "*");
			insertGlaAuveDeltl.setString(21, "*");
			insertGlaAuveDeltl.setString(22, "*");
			insertGlaAuveDeltl.setString(23, "*");
			insertGlaAuveDeltl.setString(24, "*");
			insertGlaAuveDeltl.setString(25, "*");
			insertGlaAuveDeltl.setString(26, "*");
			insertGlaAuveDeltl.setString(27, "*");
			insertGlaAuveDeltl.setString(28, "*");
			insertGlaAuveDeltl.setString(29, glaAeuvDetl.getAcctcd());
			insertGlaAuveDeltl.addBatch();
		}
	}

	/**
	 * @param pst
	 * @param map
	 * @throws NumberFormatException
	 * @throws SQLException
	 * @throws BimisException
	 * @�˷��������ã������ʽ������ˮ��Ϣ
	 */
	public String insertDoubleFmBDrrt(Map<String, Object> map) throws NumberFormatException, SQLException, BimisException {
		if (insertFmbDrrt == null)
			insertFmbDrrt = conn.prepareStatement(PublicFmbCntrInfoUtil.INSERT_FMB_DRRT);
		insertFmbDrrt.setInt(1, Integer.parseInt(map.get("stacid") + ""));
		map.put("sequenceName", "Seq_Drrtsq");
		List<Element> e = null;
		selectDBName();
		if ("ORACLE".equals(DBName))
			e = commonDao.queryByNamedSql(MybatisPathUtil.FMB_DRRT + "selectOracleSequenceId", map).removeContent();
		if ("DB2".equals(DBName))
			e = commonDao.queryByNamedSql(MybatisPathUtil.FMB_DRRT + "selectDB2SequenceId", map).removeContent();
		String drrtno = map.get("sourdt") + lpad(e.get(0).getChildTextTrim("sequenceId"), 12, "0");
		insertFmbDrrt.setString(2, drrtno);
		insertFmbDrrt.setString(3, map.get("cntrno") + "");
		insertFmbDrrt.setString(4, map.get("datatp") + "");
		insertFmbDrrt.setString(5, map.get("brchno") + "");
		insertFmbDrrt.setString(6, map.get("upprbr") + "");
		insertFmbDrrt.setString(7, map.get("usercd") + "");
		insertFmbDrrt.setString(8, map.get("sourdt") + "");
		insertFmbDrrt.setString(9, map.get("aplysq") + "");
		insertFmbDrrt.setBigDecimal(10, new BigDecimal(map.get("cntrbl") + ""));
		insertFmbDrrt.setString(11, map.get("transt") + "");
		insertFmbDrrt.setString(12, map.get("sourdt") + "");
		insertFmbDrrt.setString(13, map.get("acptsq") + "");
		insertFmbDrrt.addBatch();
		return drrtno;
	}
	
	/**
	 * @return @�˷��������ã�
	 */
	private String selectDBName() {
		try {
			if (DBName == null || "".equals(DBName)) {
				DatabaseMetaData meta = commonDao.getSession().connection().getMetaData();
				String prodctName = meta.getDatabaseProductName();
				if (prodctName.toUpperCase().indexOf("ORACLE") > -1)
					DBName = "ORACLE";
				else if (prodctName.toUpperCase().indexOf("DB2") > -1)
					DBName = "DB2";
				else
					DBName = "";
			}
		} catch (HibernateException | SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		return DBName;
	}

	/**
	 * @param s
	 *            ���ֵ
	 * @param n
	 *            ����
	 * @param replace
	 * @return
	 * @�˷��������ã�ʵ��oracle��lpad���ܵ�s�ĳ���С��n�ǣ�ǰ�����replace
	 */
	private String lpad(String s, int n, String replace) {
		while (s.length() < n)
			s = replace + s;
		return s;
	}

	/**
	 * @param map
	 * @return
	 * @throws Exception
	 * @�˷��������ã����˷���
	 */
	public Map<String, Object> comAccounting(Map<String, Object> map) throws Exception {
		if (glaAeuvs.isEmpty()) {
			glaAeuvs = commonDao.getSqlSession().selectList("com.sunline.sunfe.mybatis.glaaeuv.quereGlaAeuv", map);
			if (glaAeuvs.isEmpty()) {
				throw new BimisException("513", "��Ʒ�¼������");
			}
		}
		if (glaAeuvDetls.isEmpty())
			throw new BimisException("513", "��Ʒ�¼���鲻����");
		String pckgdt =  PkgUtil.addParameter("", "callFlag", "1");
		map.put("transq", KernelBookingServiceImpl.kernelBooking(commonDao, pckgdt, glaAeuvs.get(0), glaAeuvDetls));
		glaAeuvs.clear();
		glaAeuvDetls.clear();
		return map;
	}

	/**
	 * @param map
	 * @throws BimisException
	 * @�˷��������ã��޸ĺ�ͬ��Ϣ
	 */
	public void updateFmbCntr(Map<String, Object> map) throws BimisException {
		try {
			commonDao.updateByNamedSql(MybatisPathUtil.FMB_CNTR + "updateFmbCntr", map);
		} catch (BimisException e) {
			throw new BimisException("504", "����" + map.get("") + "��ͬ��Ϣ�쳣");
		}
	}

	/**
	 * @param map
	 * @throws SQLException
	 * @�˷��������ã����»�����Ϣ
	 */
	public Map<String, Object> updateGlaAcctAcmlbl(Map<String, Object> map) throws SQLException {
		if (updateAcmlbl == null)
			updateAcmlbl = conn.prepareStatement(PublicFmbCntrInfoUtil.UPDATE_GLA_ACCT_ACMLBL);
		updateAcmlbl.setString(1, map.get("preday") + "");
		updateAcmlbl.setInt(2, Integer.parseInt(map.get("datediff") + ""));
		updateAcmlbl.setInt(3, Integer.parseInt(map.get("stacid") + ""));
		updateAcmlbl.setString(4, map.get("acctcd") + "");
		updateAcmlbl.addBatch();
		return map;
	}

	/**
	 * @param map
	 * @return
	 * @throws BimisException
	 * @�˷��������ã���ȡ��Ҫ������������
	 */
	public List<Map<String, Object>> selectGlaAcctAcmlbl(int stacid) throws BimisException {
		Map paramMap = new HashMap();
		List<Map<String, Object>> list = null;
		try {
			String[] arrFundtp = { Enumeration.FUNDTP.SCBFJ.value, Enumeration.FUNDTP.SCZBJ.value };
			paramMap.put("fundtp", arrFundtp);
			paramMap.put("stacid", stacid);
			list = (List<Map<String, Object>>) commonDao.queryByNamedSqlForList(MybatisPathUtil.GLA_ACCT + "selectGlaAcctAcmlbl", paramMap);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BimisException("��ѯ������������ʧ��", e.getMessage());
		}
		return list;
	}

	/**
	 * @param map
	 * @return
	 * @throws BimisException
	 * @�˷��������ã���ȡ��Ҫ�ڲ��ʽ��Ϣ������
	 */
	public List<Map<String, Object>> selectGlaAcctInterest(Map<String, Object> map) throws BimisException {
		List<Map<String, Object>> list = null;
		try {
			String[] arrFundtp = { Enumeration.FUNDTP.YSLX.value};
			map.put("fundtp", arrFundtp);
			map.put("rltstp", "1");
			map.put("blncdn", Enumeration.Amntcd.D.value);
			list = (List<Map<String, Object>>) commonDao.queryByNamedSqlForList(MybatisPathUtil.TABLE_UNION + "queryInterestInfolistPage", map);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BimisException("��ѯ�ڲ��ʽ��Ϣ������ʧ��", e.getMessage());
		}
		return list;
	}

	/**
	 * @param map
	 * @return
	 * @throws SQLException
	 * @�˷��������ã������ڲ��ʽ��Ϣ�ǼǱ�
	 */
	public Map<String, Object> insertFmsInst(Map<String, Object> map) throws SQLException {
		if (insertFmsinst == null)
			insertFmsinst = conn.prepareStatement(INSERT_FMS_INST);
		insertFmsinst.setInt(1, Integer.parseInt(map.get("stacid") + ""));
		insertFmsinst.setString(2, map.get("sourdt") + "");
		insertFmsinst.setString(3, map.get("transq") + "");
		if ("C01".equals((map.get("fundtp"))))
			insertFmsinst.setString(4, "3");
		else
			insertFmsinst.setString(4, "4");
		insertFmsinst.setString(5, map.get("brchno") + "");
		insertFmsinst.setString(6, map.get("cntrno") + "");
		insertFmsinst.setString(7, map.get("drrtno") + "");
		insertFmsinst.setString(8, map.get("crcycd") + "");
		insertFmsinst.setString(9, map.get("inrttp") + "");
		insertFmsinst.setString(10, map.get("termcd") + "");
		insertFmsinst.setString(11, map.get("preday") + "");
		insertFmsinst.setBigDecimal(12, new BigDecimal(map.get("acmlbl") + ""));
		insertFmsinst.setBigDecimal(13, new BigDecimal(map.get("instrt") + ""));
		insertFmsinst.setBigDecimal(14, new BigDecimal(map.get("instam") + ""));
		insertFmsinst.addBatch();
		return map;
	}

	/**
	 * 
	 * @param map
	 * @return
	 * @throws SQLException
	 * @throws BimisException
	 * @�˷��������ã����»�����Ϣ
	 */
	public Map<String, Object> updateGlaAcctInterset(Map<String, Object> map) throws SQLException, BimisException {
		try {
			commonDao.updateByNamedSql(MybatisPathUtil.GLA_ACCT + "updateGlaAcctAcmlbl", map);
		} catch (BimisException e) {
			logger.error(e.getMessage());
			throw new BimisException("500", "�����˻�����ʧ��");
		}
		return map;
	}

	/**
	 * @param map
	 * @return
	 * @throws BimisException
	 * @�˷��������ã��ڲ��ʽ𶨼۵�����Ϣ
	 */
	public List<Map<String, Object>> selectFmpInrtAjstInfos(Map<String, Object> map) throws BimisException {
		List<Map<String, Object>> list = null;
		try {
			list = (List<Map<String, Object>>) commonDao.queryByNamedSqlForList(MybatisPathUtil.FMP_INRT_AJST + "queryFmpInrtAjstlistPage", map);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BimisException("��ѯ�ڲ��ʽ𶨼۵�����Ϣʧ��", e.getMessage());
		}
		return list;
	}

	/**
	 * @param map
	 * @return
	 * @throws BimisException
	 * @�˷��������ã��ڲ��ʽ𶨼۱���Ϣ
	 */
	public Map<String, Object> selectFmpInrtnfos(Map<String, Object> map) throws BimisException {
		try {
			List<Map<String, Object>> list = (List<Map<String, Object>>) commonDao.queryByNamedSqlForList(MybatisPathUtil.FMP_INRT + "queryFmp_InrtInrtrt", map);
			if (!list.isEmpty()) {
				map.put("oldEfctdt", list.get(0).get("efctdt"));
				map.put("oldInrtrt", list.get(0).get("inrtrt"));
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BimisException("��ѯ�ڲ��ʽ𶨼۱���Ϣʧ��", e.getMessage());
		}
		return map;
	}

	/**
	 * @param map
	 * @return
	 * @throws SQLException
	 * @throws BimisException
	 * @�˷��������ã������ڲ��ʽ�
	 */
	public Map<String, Object> updateFmpInrt(Map<String, Object> map) throws SQLException, BimisException {
		map.put("sourdt", map.get("efctdt"));
		int count = commonDao.updateByNamedSql(MybatisPathUtil.FMP_INRT + "updateFmpInrt", map);
		if (count > 1)
			throw new BimisException("512", "����ԭ�ʽ𶨼۱�ʧ��,��Ҫ���µ����ݴ���1");
		if (count < 1)
			throw new BimisException("512", "����ԭ�ʽ𶨼۱�ʧ��,��Ҫ���µ����ݲ�����");
		return map;
	}

	/**
	 * @param map
	 * @return
	 * @throws SQLException
	 * @�˷��������ã������ڲ��ʽ𶨼���Ϣ
	 */
	public Map<String, Object> insertFmpInrtAjst(Map<String, Object> map) throws SQLException {
		if (insertFmpInrtAjst == null)
			insertFmpInrtAjst = conn.prepareStatement(INSERT_FMP_INRT_AJST);
		insertFmpInrt.setInt(1, Integer.parseInt(map.get("stacid") + ""));
		insertFmpInrt.setString(2, map.get("inrttp") + "");
		insertFmpInrt.setString(3, map.get("intrsq") + "");
		insertFmpInrt.setString(4, map.get("intrus") + "");
		insertFmpInrt.setString(5, map.get("inrttp") + "");
		insertFmpInrt.setString(6, map.get("crcycd") + "");
		insertFmpInrt.setString(7, map.get("termcd") + "");
		insertFmpInrt.setString(8, map.get("inrtrt") + "");
		insertFmpInrt.setString(9, map.get("efctdt") + "");
		insertFmpInrt.setString(10, map.get("status") + "");
		insertFmpInrt.setString(11, map.get("brchcd") + "");
		insertFmpInrt.addBatch();
		return map;
	}

	/**
	 * @param map
	 * @return
	 * @throws SQLException
	 * @�˷��������ã������ڲ��ʽ𶨼۱�
	 */
	public Map<String, Object> insertFmpInrt(Map<String, Object> map) throws SQLException {
		if (insertFmpInrt == null)
			insertFmpInrt = conn.prepareStatement(INSERT_FMP_INRT);
		insertFmpInrt.setInt(1, Integer.parseInt(map.get("stacid") + ""));
		insertFmpInrt.setString(2, map.get("inrttp") + "");
		insertFmpInrt.setString(3, map.get("crcycd") + "");
		insertFmpInrt.setString(4, map.get("termcd") + "");
		insertFmpInrt.setString(5, map.get("inrtrt") + "");
		insertFmpInrt.setString(6, map.get("status") + "");
		insertFmpInrt.setString(7, map.get("efctdt") + "");
		insertFmpInrt.setString(8, map.get("inefdtNew") + "");
		insertFmpInrt.setString(9, map.get("brchcd") + "");
		insertFmpInrt.addBatch();
		return map;
	}

	/**
	 * @param map
	 * @return
	 * @throws SQLException
	 * @�˷��������ã������޸����ʵ�����
	 */
	public Map<String, Object> updateFmpInrtAjst(Map<String, Object> map) throws SQLException {
		if (updateFmpInrtAjst == null)
			updateFmpInrtAjst = conn.prepareStatement(PublicFmbCntrInfoUtil.UPDATE_FMP_INRT_AJST);
		updateFmpInrtAjst.setString(1, map.get("status") + "");
		updateFmpInrtAjst.setInt(2, Integer.parseInt(map.get("stacid") + ""));
		updateFmpInrtAjst.setString(3, map.get("inrttp") + "");
		updateFmpInrtAjst.setString(4, map.get("termcd") + "");
		updateFmpInrtAjst.setString(5, map.get("efctdt") + "");
		updateFmpInrtAjst.setString(6, map.get("brchcd") + "");
		updateFmpInrtAjst.addBatch();
		return map;
	}

	/**
	 * @param map
	 * @throws BimisException
	 * @�˷��������ã��޸�״̬
	 */
	public void updateFmpInrtAjstStatus(Map<String, Object> map) throws BimisException {
		try {
			commonDao.updateByNamedSql(MybatisPathUtil.FMP_INRT_AJST + "updateFmpInrtAjstStatus", map);
		} catch (Exception e) {
			logger.error("500", e.getMessage());
			throw new BimisException("503", "�޸����ʵ������쳣" + e.getMessage());
		}
	}

	/**
	 * @param pst
	 * @throws BimisException
	 * @�˷��������ã�ִ��������
	 */
	public void executeBatch(PreparedStatement pst) throws BimisException {
		if (pst != null) {
			try {
				pst.executeBatch();
			} catch (SQLException e) {
				throw new BimisException("310", e.getMessage());
			}
		}
	}

	/**
	 * @param pst
	 * @throws BimisException
	 * @�˷��������ã��ر�����Դ
	 */
	public void closePreparedStatement(PreparedStatement pst) throws BimisException {
		if (pst != null) {
			try {
				pst.clearBatch();
				pst.close();
				pst = null;
			} catch (SQLException e) {
				throw new BimisException("310", e.getMessage());
			}
		}
	}

	/**
	 * @param req
	 * @return
	 * @�˷��������ã���ȡ����ID������
	 */
	public Map<String, Object> selectSessionComStac(com.sunline.jraf.util.PkgUtil req, String stacid) {
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			if (stacid == null || "".equals(stacid) || "null".equals(stacid))
				map.put("stacid", SessionParaUtils.getStacid());
			else
				map.put("stacid", stacid);
			List<Map<String, Object>> list = (List<Map<String, Object>>) commonDao.queryByNamedSqlForList(MybatisPathUtil.COM_STAC + "queryComStacAllInfo", map);
			if (list.isEmpty())
				throw new BimisException("502", stacid + "���ײ�����");
			map.put("stacna", list.get(0).get("recordName"));
			if (req != null) {
				req.addRspData("stacid", list.get(0).get("recordCode") + "");
				req.addRspData("stacna", list.get(0).get("recordName") + "");
			}
		} catch (BimisException | JDOMException e) {
			logger.error("501", "������Ϣ��ȡ�쳣");
		}
		return map;
	}

	/**
	 * @param map
	 * @param req
	 * @throws BimisException
	 * @�˷��������ã���Mapֵ����req��
	 */
	public void addReqInfoTo(Map<String, Object> map, com.sunline.jraf.util.PkgUtil req) throws BimisException {
		Set<Entry<String, Object>> set = map.entrySet();
		Iterator<Entry<String, Object>> it = set.iterator();
		Entry<String, Object> entry = null;
		StringBuffer sb = new StringBuffer();
		try {
			while (it.hasNext()) {
				entry = it.next();
				if (!FILTER_FILED.contains(entry.getKey()) && entry.getValue() != null && !"".equals(entry.getValue()) && !"null".equals(entry.getValue())) {
					req.addReqData(entry.getKey(), entry.getValue() + "");
					sb.append(entry.getKey() + ",");
				}
			}
			if (sb.length() > 0)
				req.addReqData("valueNotNull", sb.toString().substring(0, sb.toString().length() - 1));
		} catch (JDOMException e) {
			logger.error(e.getMessage());
			throw new BimisException("503", "req�洢��key��" + entry.getKey() + "��value��" + entry.getValue() + "��ʧ��");
		}
	}
}
