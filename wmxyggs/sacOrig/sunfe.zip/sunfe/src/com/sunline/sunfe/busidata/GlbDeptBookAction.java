package com.sunline.sunfe.busidata;

import java.util.HashMap;
import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.suncm.util.SessionParaUtils;

/**
 * �ֻ��Ǽǲ�
 * @author FZF
 */
public class GlbDeptBookAction extends Actor {
	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.glbDeptBook.";
	/**
	 * @Title: getLoanBusidata
	 * @Description: �ֻ��Ǽǲ��б���ѯ
	 * @return: void
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void queryglbDeptBookListPage() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("stacid", SessionParaUtils.getStacid());
			Element e = commonDao
					.queryByNamedSqlWithPage(MYBATIS_NS+ "queryglbDeptBooklistPage", req.getReqPageInfo(),hashmap);
			req.addRspData(e.removeContent());
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}


	
}
