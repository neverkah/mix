package com.sunline.sunfe.monitor;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.db.DBConnection;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.FileUtil;
import com.sunline.jraf.util.StringUtil;

/**
 * 
 * @ClassName: MonitorActor
 * @Description: ϵͳ��ص�sql��ѯ��ִ�е�action��
 * @author: zhangdq
 * @date: 2016-8-25 ����2:21:06
 */
public class MonitorActor extends Actor {
	/**
	 * mybatis �����ļ��������ռ�
	 */
	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.monitor.";

	/**
	 * 
	 * @Title: queryDataBySql
	 * @Description: ͨ��sql���ǰ̨��ѯ����
	 * @return: void
	 * @throws JDOMException
	 */
	public void queryDataBySql() throws JDOMException {
		try {
			// ҳ����������
			String querySql = req.getReqDataStr("querySql").trim();
			if (checkSql(querySql)) {
				String pageNo = req.getReqDataStr("pageNum");
				if (pageNo != null && !"".equals(pageNo)) {
					req.setReqPageNo(Integer.parseInt(pageNo));
				}
				Element sqlDataList = commonDao.queryByNamedSqlWithPage(
						MYBATIS_NS + "queryResultlistPage",
						req.getReqPageInfo(), querySql);
				// ���ؽ����װ
				req.addRspData(sqlDataList.removeContent());
			} else {
				return;
			}
		} catch (Exception e) {
			req.setResult("-1");
			req.setErrorMsg(e.getMessage());
			this.getLog().logError(e.getMessage(), e);
		}
	}

	/**
	 * 
	 * @Title: downloadCurrDataBySql
	 * @Description: ������ѯ�ĵ�ǰҳ����
	 * @return: void
	 * @throws JDOMException
	 */
	@SuppressWarnings("unchecked")
	public void downloadCurrDataBySql() throws JDOMException {
		try {
			// ҳ����������
			String querySql = req.getReqDataStr("querySql").trim();
			if (checkSql(querySql)) {
				String pageNo = req.getReqDataStr("pageNum");
				if (pageNo != null && !"".equals(pageNo)) {
					req.setReqPageNo(Integer.parseInt(pageNo));
				}
				Element sqlDataList = commonDao.queryByNamedSqlWithPage(
						MYBATIS_NS + "queryResultlistPage",
						req.getReqPageInfo(), querySql);

				List<Element> excelData = sqlDataList.getChildren("Record");
				// ����excel�����ļ�
				String outputFile = generateExcel(excelData,
						"downloadCurrDataBySql");
				if (outputFile != null) {
					req.addRspData("filepath", outputFile);
				} else {
					req.setResult("-1");
					req.setErrorMsg("����excel�ļ������쳣");
					return;
				}
			} else {
				return;
			}
		} catch (Exception e) {
			req.setResult("-1");
			req.setErrorMsg(e.getMessage());
			this.getLog().logError(e.getMessage(), e);
		}
	}

	/**
	 * 
	 * @Title: downloadCurrDataBySql
	 * @Description: ������ѯ�ĵ�ǰҳ����
	 * @return: void
	 * @throws JDOMException
	 */
	@SuppressWarnings("unchecked")
	public void downloadAllDataBySql() throws JDOMException {
		try {
			// ҳ����������
			String querySql = req.getReqDataStr("querySql").trim();
			if (checkSql(querySql)) {

				Element sqlDataList = commonDao.queryByNamedSql(MYBATIS_NS
						+ "queryResultlistPage", querySql);

				List<Element> excelData = sqlDataList.getChildren("Record");
				// ����excel�����ļ�
				String outputFile = generateExcel(excelData,
						"downloadAllDataBySql");
				if (outputFile != null) {
					req.addRspData("filepath", outputFile);
				} else {
					req.setResult("-1");
					req.setErrorMsg("����excel�ļ������쳣");
					return;
				}
			} else {
				return;
			}
		} catch (Exception e) {
			req.setResult("-1");
			req.setErrorMsg(e.getMessage());
			this.getLog().logError(e.getMessage(), e);
		}
	}

	/**
	 * 
	 * @Title: updateDataBySql
	 * @Description: ͨ��sql���ǰִ̨�и������
	 * @return: void
	 * @throws JDOMException
	 */
	public void updateDataBySql() throws JDOMException {
		String userID = String.valueOf(req.getUserID());//��sessionȥuserid�ֶ�ֵ
		String userCD = req.getUserCD();//��sessionȥusercode�ֶ�ֵ
		if (!("1".equals(userID) && "admin".equals(userCD))) {
			req.setResult("-1");
			req.setErrorMsg("ֻ�г�������Ա[admin]����ִ��Ȩ��");
			return;
		}

		// ҳ����������-ִ��sql
		String execSql = req.getReqDataStr("execSql").trim();
		if (StringUtil.isNullOrEmpty(execSql)) {
			req.setResult("-1");
			req.setErrorMsg("ִ��SQL����Ϊ��");
			return;
		}
		String sqlUp = execSql.trim().toUpperCase();
		if (sqlUp.replace("\r\n", " ").matches("(SELECT)\\s+.*")) {
			req.setResult("-1");
			req.setErrorMsg("SQL���Ϸ�,����ִ�в�ѯ��ز���");
			return;
		}
		String isProc = req.getReqDataStr("isProc");
		int succ = 0;
		int send = 0;
		int now = 1;
		SqlSession mybatisSession = commonDao.getSqlSession();
		try {

			mybatisSession.getConnection().setAutoCommit(false);
			if ("true".equals(isProc)) {
				mybatisSession.update(MYBATIS_NS + "executeSql", execSql);
			} else {
				String[] sqls = execSql.split(";");
				send = sqls.length;
				for (String sql : sqls) {
					if ("".equals(sql)) {
						send--;
						continue;
					}
					succ += mybatisSession.update(MYBATIS_NS + "executeSql",
							sql);
					now++;
				}
			}
			mybatisSession.getConnection().commit();
		} catch (Exception e) {
			try {
				mybatisSession.getConnection().rollback();
			} catch (SQLException e1) {
				req.setResult("-2");
				req.setErrorMsg("SQLִ��ʧ��,���˳����쳣,�쳣ԭ��:" + e1.getMessage());
				this.getLog().logError(e1.getMessage(), e1);
			}
			req.setResult("-2");
			req.setErrorMsg("SQLִ��ʧ��,�ѻ���,ʧ��ԭ��:" + e.getMessage());
			this.getLog().logError(e.getMessage(), e);
		}
		req.addRspData("send", String.valueOf(send));
		req.addRspData("succ", String.valueOf(succ));
		req.addRspData("now", String.valueOf(now));
	}

	/**
	 * 
	 * @Title: checkSql У��sql����Ƿ�Ϸ�
	 * @Description: ͨ��sql����ȡ���ݵ�Ԫ������Ϣ
	 * @return: void
	 * @throws JDOMException
	 */
	private Boolean checkSql(String querySql) throws JDOMException {
		if (StringUtil.isNullOrEmpty(querySql)) {
			req.setResult("-1");
			req.setErrorMsg("��ѯSQL����Ϊ��");
			return false;
		}
		String sqlUp = querySql.trim().toUpperCase();
		if (!sqlUp.replace("\r\n", " ").matches("(SELECT)\\s+.*")) {
			req.setResult("-1");
			req.setErrorMsg("SQL���Ϸ�,ֻ��ִ�в�ѯ��ز���");
			return false;
		}
		Connection conn = null;
		PreparedStatement prep = null;
		ResultSet rs = null;
		try {
			String tmp = "select tmp_tb.* from ( " + querySql
					+ " ) tmp_tb where ROWNUM<0";
			conn = DBConnection.getConnection("sunline.database");
			prep = conn.prepareStatement(tmp);
			rs = prep.executeQuery();
		} catch (SQLException e) {
			req.setResult("-1");
			req.setErrorMsg(e.getMessage());
			this.getLog().logError(e.getMessage(), e);
			return false;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				this.getLog().logError("�ͷ�resultset����", e);
			} finally {
				try {
					if (prep != null) {
						prep.close();
					}
				} catch (SQLException e) {
					this.getLog().logError("�ͷ�prepstatement����", e);
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException e) {
							this.getLog().logError("�ر��������ӳ���", e);

						}
					}
				}
			}
		}
		return true;
	}

	/**
	 * 
	 * @Title: checkSql У��sql����Ƿ�Ϸ�
	 * @Description: ͨ��sql����ȡ���ݵ�Ԫ������Ϣ
	 * @return: void
	 * @throws Exception
	 */
	private String generateExcel(List<Element> excelData, String filename)
			throws Exception {
		String outputFile = null;
		try {
			// ��ȡ��ͷ
			ArrayList<String> excelHeader = null;
			if (excelData != null && excelData.size() > 0) {
				Element first_record = (Element) excelData.get(0);
				excelHeader = new ArrayList<String>();
				for (int i = 0; i < first_record.getChildren().size(); i++) {
					Element colElement = (Element) first_record.getChildren()
							.get(i);
					String colName = colElement.getName();
					excelHeader.add(colName);
				}
			}
			// ��ʱ���·����Ҫ��ֹ�ļ�Խ��Խ��ֻ���������һ��
			String tempPath = FileUtil.getContextRealPath() + File.separator
					+ "WEB-INF" + File.separator + "config" + File.separator
					+ "excel" + File.separator + "monitor" + File.separator;
			File tempDir = new File(tempPath);
			if (!tempDir.exists()) {
				// ������ʱĿ¼
				tempDir.mkdir();
			}
			outputFile = tempDir + File.separator + filename + ".xls";// ��ʱ�ļ����·��

			ExcelModel excelModel = new ExcelModel();
			excelModel.setSheetName(filename);
			excelModel.setExcelHeader(excelHeader);
			excelModel.setExcelData(excelData);
			ExcelUtilOfMonitor.createExcelModel(excelModel, outputFile);

		} catch (Exception e) {
			this.getLog().logError(e.getMessage(), e);
			throw e;
		}
		return outputFile;
	}
}
