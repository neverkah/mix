package com.sunline.sunfe.busidata;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.StringUtil;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.SessionParaUtils;
/**
 * ϵͳ����������
 *
 */
public class GlkMiddActor extends Actor {

	private static final String GlkMiddConf = "com.sunline.sunfe.mybatis.glkmiddconf.";
	private static final String GlkMiddBook = "com.sunline.sunfe.mybatis.glkmiddbook.";
	private static final String AMNTCD_D = "D";
	private static final String AMNTCD_C = "C";


	/**
	 * ϵͳ��������������
	 * @throws JDOMException
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void getGlkMiddConfList() throws JDOMException {
		try {
			Map<String, String> paramMap = req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			paramMap.put("stacid", stacid);
			Element e = commonDao.queryByNamedSqlWithPage
					(GlkMiddConf + "getGlkMiddConfList", req.getReqPageInfo(), paramMap);
			req.addRspData(e.removeContent());
		} catch (Exception e) {
			getLog().logError(e);
		}
	}
	
	/**
	 * ������ѯϵͳ��������������
	 */
	@SuppressWarnings("unchecked")
	public void getGlkMiddConfById() throws JDOMException {
		try {
			Map<String, Object> paramMap = req.getReqDataMap();
			Element e = commonDao.queryByNamedSql(GlkMiddConf + "getGlkMiddConfById", paramMap);
			req.addRspData(e.removeContent());
		} catch (Exception e1) {
			getLog().logError(e1);
			ResultUtils.setRspData(req, "300", "��ѯʧ��", "", "");

		}
	}
	/**
	 * ɾ��ϵͳ��������������
	 */
	public void deleteGlkMiddConf() {
		try {
			List<?> parampList = this.req.getReqDataTexts("paramp");
			if ((parampList != null) && (parampList.size() > 0)) {
					commonDao.beginTransaction();
				for (int i = 0; i < parampList.size(); ++i) {
					String paramp = (String) parampList.get(i);
					String[] split = paramp.split("-");
					String  stacid=split[0];
					String  systid=split[1];
					String  itemcd=split[2];
					String  tosyst=split[3];
					String  toitem=split[4];
					String  status=split[5];
					if(status.equals("1")){
						req.addRspData("retCode", "300");
						req.addRspData("retMessage", "�����õ����ò�����ɾ����");
						return;
					}
					HashMap<String, Object> hashmap = new HashMap<String, Object>();
					hashmap.put("stacid", stacid);
					hashmap.put("systid", systid);
					hashmap.put("itemcd", itemcd);
					hashmap.put("tosyst", tosyst);
					hashmap.put("toitem", toitem);
					commonDao.deleteByNamedSql(GlkMiddConf + "deleteGlkMiddConf", hashmap);
				}

				    commonDao.commitTransaction();
				ResultUtils.setRspData(req, "200", "�����ɹ�", "glkMiddConf", "");
			}
		} catch (Exception e) {
			this.commonDao.rollBack();
			ResultUtils.setRspData(req, "300", "����ʧ��", "", "");
			getLog().logError(e);
		}
	}

	/**
	 * ����ϵͳ��������������
	 * @throws JDOMException
	 */
	@SuppressWarnings("unchecked")
	public void addGlkMiddConf() throws JDOMException {
		try {
			Map<String, String> paramMap = req.getReqDataMap();
			if(paramMap.get("systid").equals(paramMap.get("tosyst"))){
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "����ʧ�ܣ�ϵͳ����Դϵͳ������ͬ��");
				return;
			}
			if(commonDao.queryByNamedSqlForList(GlkMiddConf + "getGlkMiddConfById", paramMap).size()>0 ) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "����ʧ�ܣ��������Ѵ��ڣ�");
				return;
			}
			paramMap.put("status", "1");
			commonDao.insertByNamedSql(GlkMiddConf + "addGlkMiddConf", paramMap);
			ResultUtils.setRspData(req, "200", "�����ɹ�","glkMiddConf","closeCurrent");
		} catch (Exception e) {
			getLog().logError(e);
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ��");
		}
	}
	/**
	 * ����ϵͳ��������������
	 * @throws JDOMException
	 */
	@SuppressWarnings("unchecked")
	public void updateGlkMiddConf() throws JDOMException {
		try {
			Map<String, Object> paramMap =req.getReqDataMap();
			if(commonDao.queryByNamedSqlForList(GlkMiddConf + "getGlkMiddConfById", paramMap).size()>0 ) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "����ʧ�ܣ��������Ѵ��ڣ�");
				return;
			}
			commonDao.updateByNamedSql(GlkMiddConf + "updateGlkMiddConf", paramMap);
			ResultUtils.setRspData(req, "200", "�����ɹ�", "glkMiddConf", "closeCurrent");
		} catch (Exception e) {
			getLog().logError(e);
			ResultUtils.setRspData(req, "300", "����ʧ��", "", "closeCurrent");

		}
	}

	
	
	/**
	 * ϵͳ����������
	 * @throws JDOMException
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void getGlkMiddBookSummList() throws JDOMException {
		try {
			Map<String, Object> paramMap = req.getReqDataMap();
			String stacid =  SessionParaUtils.getStacid();
			String trandt=PubUtil.getGlisdt(Integer.parseInt(stacid));
			String flag = "false";
			paramMap.put("stacid", stacid);
			//Ĭ�ϲ�ѯ��������
			if(StringUtil.isNullOrEmpty(paramMap.get("trandt").toString())){
				paramMap.put("trandt",trandt);
			}
			if(trandt.equals(paramMap.get("trandt"))){
				 flag= "true";
			}
			Element e = commonDao.queryByNamedSqlWithPage
					(GlkMiddBook + "getGlkMiddBookSummList", req.getReqPageInfo(), paramMap);
			req.addRspData(e.removeContent());
			req.addRspData("flag",flag);
		} catch (Exception e) {
			getLog().logError(e);
		}
	}
	/**
	 * ϵͳ���������˻���
	 * @throws JDOMException
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void getGlkMiddBook() throws JDOMException {
		try {
			Map<String, Object> paramMap = req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			String trandt=PubUtil.getGlisdt(Integer.parseInt(stacid));
			paramMap.put("stacid", stacid);
			paramMap.put("trandt", trandt);
			paramMap.put("status", "1");
			Element e = commonDao.queryByNamedSql
					(GlkMiddBook + "getGlkMiddBookList", paramMap);
			
			HashSet <String> transq = new HashSet <String>();
			HashSet <String> totrsq = new HashSet <String>();
			HashSet <String> amntcd = new HashSet <String>();
			HashSet <String> toamntcd = new HashSet <String>();
			int size = e.getChildren().size();
			for(int i=0;i<size;i++){
				 transq.add(((Element)e.getChildren().get(i)).getChildText("transq"));
				 totrsq.add(((Element)e.getChildren().get(i)).getChildText("totrsq"));
				 
				 if(0 == BigDecimal.ZERO.compareTo(new BigDecimal(((Element)e.getChildren().get(i)).getChildText("drtram")))){
					 amntcd.add(AMNTCD_C);
				 }
				 if(0 == BigDecimal.ZERO.compareTo(new BigDecimal(((Element)e.getChildren().get(i)).getChildText("crtram")))){
					 amntcd.add(AMNTCD_D);
				 }
				 if(0 == BigDecimal.ZERO.compareTo(new BigDecimal(((Element)e.getChildren().get(i)).getChildText("todram")))){
					 toamntcd.add(AMNTCD_C);
				 }
				 if(0 == BigDecimal.ZERO.compareTo(new BigDecimal(((Element)e.getChildren().get(i)).getChildText("tocram")))){
					 toamntcd.add(AMNTCD_D); 
				 }
			}
			paramMap.put("transq", transq);
			paramMap.put("amntcd", amntcd);
			req.addRspData(e.removeContent());
			Element systid = commonDao.queryByNamedSql
					(GlkMiddBook + "getGlkMiddBookDetl", paramMap);
			req.addRspData("Results1",systid.removeContent());
			paramMap.put("transq", totrsq);
			paramMap.put("systid", paramMap.get("tosyst"));
			paramMap.put("itemcd", paramMap.get("itemcd"));
			paramMap.put("amntcd", toamntcd);
			Element tosyst = commonDao.queryByNamedSql
					(GlkMiddBook + "getGlkMiddBookDetl", paramMap);
			req.addRspData("Results2",tosyst.removeContent());
			
		} catch (Exception e) {
			getLog().logError(e);
		}
	}
	
	/**
	 * ϵͳ����������
	 * @throws JDOMException 
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "unchecked" })
	public void GlkMiddCheck() throws JDOMException, BimisException{
		try {
			//��ȡ��������
			String stacid = SessionParaUtils.getStacid();
			String trandt=PubUtil.getGlisdt(Integer.parseInt(stacid));
			HashMap<String, String> paramMap = new HashMap<String,String>();
			paramMap.put("stacid", stacid);
			paramMap.put("trandt", trandt);
			commonDao.beginTransaction();
			/**
			 * ɾ����ǰ����ϵͳ�������������ݣ�GLK_MIDD_BOOK_DETL��GLK_MIDD_BOOK��GLK_MIDD_BOOK_SUMM��
			 */
			commonDao.deleteByNamedSql(GlkMiddBook + "delCurrentGlkMiddBookDetl", paramMap);
			commonDao.deleteByNamedSql(GlkMiddBook + "delCurrentGlkMiddBook", paramMap);
			commonDao.deleteByNamedSql(GlkMiddBook + "delCurrentGlkMiddBookSumm", paramMap);
			/**
			 * �ٲ�ѯϵͳ�������������ñ�����ѯ������Ҫ��������ϵͳ�Ͷ�Ӧ��Ŀ
			 */
			List<HashMap<String, String>>  glkMiddConfList = (List<HashMap<String, String>>) commonDao.
							queryByNamedSqlForList(GlkMiddConf + "getGlkMiddConfList", paramMap);
			/**
			 *������ϵͳ��������ϸ����
			 */
			genGlkMiddBookDetl(glkMiddConfList,trandt);
			/**
			 *������ϵͳ��������������
			 */
			genGlkMiddBookSumm(glkMiddConfList,trandt,stacid);
			 /**
			  *������ϵͳ����������
			  */
			 glkMiddConfList = (List<HashMap<String, String>>) commonDao.
						queryByNamedSqlForList(GlkMiddConf + "getGlkMiddConfList", paramMap);
			genGlkMiddBook(glkMiddConfList,trandt,stacid);
			commonDao.commitTransaction();		
			ResultUtils.setRspData(req, "200", "�����ɹ�", "glkMiddBookSumm", "");
			} catch (BimisException e) {
				ResultUtils.setRspData(req, "300", "����ʧ��:"+e, "", "");
				commonDao.rollBack();
			    getLog().logError(e);
			    throw e;
		}
	}
	
	
	
	/**
	 *����ϵͳ��������������
	 * @param stacid 
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void genGlkMiddBookSumm(List<HashMap<String, String>> glkMiddConfList, String glisdt, String stacid) throws BimisException {
		for (Iterator iterator = glkMiddConfList.iterator(); iterator.hasNext();) {
			 //��������
			 HashMap<String, String> glkMiddConf = (HashMap<String, String>) iterator.next();
   			 // ���ܱ�����
			 HashMap<String, String> glkMiddSumm =  new HashMap<String, String>();
			 glkMiddSumm.putAll(glkMiddConf);
			 glkMiddSumm.put("trandt", glisdt);
			 //��������Ϊ��������
			 glkMiddConf.put("trandt", glisdt);
			 //����ϵͳ��ϸֵ
			 List<HashMap<String, String>>  glkMiddBookDetl = (List<HashMap<String, String>>)
					 commonDao.queryByNamedSqlForList(GlkMiddBook+"getGlkMiddBookDetlSumm", glkMiddConf);
			 glkMiddSumm.put("crtram", "0");
			 glkMiddSumm.put("drtram", "0");
			 for (Iterator iterator2 = glkMiddBookDetl.iterator(); iterator2.hasNext();) {
				HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator2.next();
				if(hashMap.get("amntcd").equals(AMNTCD_C)){
					glkMiddSumm.put("crtram", hashMap.get("tranam").toString());
				}
				if(hashMap.get("amntcd").equals(AMNTCD_D)){
					glkMiddSumm.put("drtram", hashMap.get("tranam").toString());
				}
			  }
			 //�Է�ϵͳ��ϸֵ
			 glkMiddConf.put("systid", glkMiddConf.get("tosyst").toString());
			 glkMiddConf.put("itemcd", glkMiddConf.get("toitem").toString());
			 List<HashMap<String, String>>  to_glkMiddBookDetl = (List<HashMap<String, String>>)
					 commonDao.queryByNamedSqlForList(GlkMiddBook+"getGlkMiddBookDetlSumm", glkMiddConf);
			 glkMiddSumm.put("todram", "0");
			 glkMiddSumm.put("tocram", "0");
			 for (Iterator iterator3 = to_glkMiddBookDetl.iterator(); iterator3.hasNext();) {
					HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator3.next();
					if(hashMap.get("amntcd").equals(AMNTCD_C)){
						glkMiddSumm.put("tocram", hashMap.get("tranam").toString());
					}
					if(hashMap.get("amntcd").equals(AMNTCD_D)){
						glkMiddSumm.put("todram", hashMap.get("tranam").toString());
					}
				}
			 String status="2";
			 if(glkMiddSumm.get("crtram").equals(glkMiddSumm.get("todram"))
					 &&  glkMiddSumm.get("drtram").equals(glkMiddSumm.get("tocram")) ){
				 status="1";
			 }
			 //���ܶ���״̬:1���˶���ȷ 2����һ��
			 glkMiddSumm.put("status", status);
			 commonDao.insertByNamedSql(GlkMiddBook+ "genGlkMiddBookSumm",glkMiddSumm);
		}
	}


	/**
	  *����ϵͳ��������������
	  * @param glkMiddConfList 
	  * @param glisdt 
	 * @throws BimisException 
	  */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void genGlkMiddBook( List<HashMap<String, String>> glkMiddConfList, String glisdt,String stacid) throws BimisException {
		 List<HashMap<String, String>>  glkMiddBookDetlBsnssqs =  (List<HashMap<String, String>>)
				 			commonDao.queryByNamedSqlForList(GlkMiddBook+ "getGlkMiddBookDetlBsnssq", null);
		 for (Iterator iterator = glkMiddBookDetlBsnssqs.iterator(); iterator.hasNext();) {
				HashMap<String, String> hashMap = (HashMap<String, String>) iterator.next();
				//ȫ����ˮ��
				String bsnssq = hashMap.get("bsnssq");
				HashMap<String, String>  glkMiddBook =  new HashMap<String, String>();
				glkMiddBook.put("bsnssq", bsnssq);
				glkMiddBook.put("trandt", glisdt);
				glkMiddBook.put("stacid", stacid);
				for (Iterator iterator1 = glkMiddConfList.iterator(); iterator1.hasNext();) {
					 HashMap<String, String> glkMiddConf = (HashMap<String, String>) iterator1.next();
					 HashMap<String, String> tempmap = new HashMap<String, String>();
					 glkMiddBook.putAll(glkMiddConf);
					 tempmap.putAll(glkMiddConf);
					 tempmap.put("trandt", glisdt);
					 tempmap.put("bsnssq", bsnssq);
					 List<HashMap<String, String>>  glkMiddBookDetl_01 = (List<HashMap<String, String>>)
							 	commonDao.queryByNamedSqlForList(GlkMiddBook+ "getGlkMiddBookDetlByBsnssq",tempmap);
					 tempmap.put("systid", glkMiddConf.get("tosyst"));
					 tempmap.put("itemcd", glkMiddConf.get("toitem"));
					 List<HashMap<String, String>>  glkMiddBookDetl_02 = (List<HashMap<String, String>>)
							 	commonDao.queryByNamedSqlForList(GlkMiddBook+ "getGlkMiddBookDetlByBsnssq",tempmap);
					 tempmap.clear();
					 //���𷽺ͶԷ�ϵͳ��ϸֵ����Ϊ�գ����ɹ�����¼
					 if(glkMiddBookDetl_01.size() > 0  && glkMiddBookDetl_02.size() > 0){
						 glkMiddBook.put("transq", glkMiddBookDetl_01.get(0).get("transq"));//�����׷�������ˮ
						 glkMiddBook.put("totrsq", glkMiddBookDetl_02.get(0).get("transq"));//�Է�������ˮ
						 for (Iterator iterator3 = glkMiddBookDetl_01.iterator(); iterator3.hasNext();) {
								HashMap<String, Object> temp = (HashMap<String, Object>) iterator3.next();
								if(temp.get("amntcd").equals(AMNTCD_C)){
									glkMiddBook.put("crtram", temp.get("tranam").toString());
								}
								if(temp.get("amntcd").equals(AMNTCD_D)){
									glkMiddBook.put("drtram", temp.get("tranam").toString());
								}
							  }
						 for (Iterator iterator4 = glkMiddBookDetl_02.iterator(); iterator4.hasNext();) {
								HashMap<String, Object> temp = (HashMap<String, Object>) iterator4.next();
								if(temp.get("amntcd").equals(AMNTCD_C)){
									glkMiddBook.put("tocram", temp.get("tranam").toString());
								}
								if(temp.get("amntcd").equals(AMNTCD_D)){
									glkMiddBook.put("todram", temp.get("tranam").toString());
								}
							  }
						 String status="2";
						 if((glkMiddBook.containsKey("crtram")&&glkMiddBook.containsKey("todram")&&
								 glkMiddBook.get("crtram").equals(glkMiddBook.get("todram")))
								 ||
								 (glkMiddBook.containsKey("drtram")&&glkMiddBook.containsKey("tocram")&&
								 glkMiddBook.get("drtram").equals(glkMiddBook.get("tocram"))) ){
							 status="1";
						 }
						 //���ܶ���״̬:1���˶���ȷ 2����һ��
						 glkMiddBook.put("status", status);
						 commonDao.insertByNamedSql(GlkMiddBook+ "genGlkMiddBook",glkMiddBook);
					 }else if(glkMiddBookDetl_01.size() >0 && glkMiddBookDetl_02.size()==0){
						 glkMiddBook.put("transq", glkMiddBookDetl_01.get(0).get("transq"));//�����׷�������ˮ
						 for (Iterator iterator3 = glkMiddBookDetl_01.iterator(); iterator3.hasNext();) {
								HashMap<String, Object> temp = (HashMap<String, Object>) iterator3.next();
								if(temp.get("amntcd").equals(AMNTCD_C)){
									glkMiddBook.put("crtram", temp.get("tranam").toString());
								}
								if(temp.get("amntcd").equals(AMNTCD_D)){
									glkMiddBook.put("drtram", temp.get("tranam").toString());
								}
							  }
						 //���ܶ���״̬:1���˶���ȷ 2����һ��
						 glkMiddBook.put("status", "0");
						 commonDao.insertByNamedSql(GlkMiddBook+ "genGlkMiddBook",glkMiddBook);
					 }else if(glkMiddBookDetl_02.size() >0 && glkMiddBookDetl_01.size()==0){
						 glkMiddBook.put("transq", glkMiddBookDetl_02.get(0).get("transq"));//�����׷�������ˮ
						 for (Iterator iterator3 = glkMiddBookDetl_02.iterator(); iterator3.hasNext();) {
								HashMap<String, Object> temp = (HashMap<String, Object>) iterator3.next();
								if(temp.get("amntcd").equals(AMNTCD_C)){
									glkMiddBook.put("crtram", temp.get("tranam").toString());
								}
								if(temp.get("amntcd").equals(AMNTCD_D)){
									glkMiddBook.put("drtram", temp.get("tranam").toString());
								}
							  }
						 //���ܶ���״̬:1���˶���ȷ 2����һ��
						 glkMiddBook.put("status", "0");
						 commonDao.insertByNamedSql(GlkMiddBook+ "genGlkMiddBook",glkMiddBook);
				}
		    }
		 }
	}
	
	
	/**
	 * ����ϵͳ��������ϸ����
	 * @param trandt 
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void genGlkMiddBookDetl(List<HashMap<String, String>> glkMiddConfList, String glisdt) throws BimisException {
		for (Iterator iterator = glkMiddConfList.iterator(); iterator.hasNext();) {
			 HashMap<String, String> glkMiddConf = (HashMap<String, String>) iterator.next();
			 glkMiddConf.put("trandt", glisdt);
			 commonDao.insertByNamedSql(GlkMiddBook+ "genGlkMiddBookDetl",glkMiddConf);
		}
	}
	
	
	/**
	 * �ֶ�������ϸ����
	 * @Title: GlkMiddblend 
	 * @return: void
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public  void  GlkMiddblend() throws JDOMException{
		 try {
			String systid_data = req.getReqDataStr("systid");
			if(StringUtil.isNullOrEmpty(systid_data)){
				ResultUtils.setRspData(req, "300", "�빴ѡ����ϵͳ���ݣ�", "");
				return;
			}
			String tosyst_data = req.getReqDataStr("tosyst");
			if(StringUtil.isNullOrEmpty(tosyst_data)){
				ResultUtils.setRspData(req, "300", "�빴ѡ�Է�ϵͳ���ݣ�", "");
				return;
			}
			//����ϵͳ����������
			String [] systid_array = systid_data.substring(0, systid_data.length()-1).split(",");
			 //�Է�ϵͳ����������
			String [] tosyst_array = tosyst_data.substring(0, tosyst_data.length()-1).split(",");
			//����ϵͳ���������� �ͶԷ�ϵͳ���������ݵ� ��ϵ����Ϊ��Զ�
			if(tosyst_array.length>1 && systid_array.length >1){
				ResultUtils.setRspData(req, "300", "����ϵͳ�Ĵ��������ݺͶԷ�ϵͳ���������ݵĹ�ϵֻ��Ϊһ�Զ���߶��һ��", "");
				return;
			}
			commonDao.beginTransaction();
			//�õ�����ϵͳ����
			 List<HashMap<String, String>>  glkMiddBookList = new ArrayList<HashMap<String,String>>();
			 List<String>  tosqList = new ArrayList<String>();

			 BigDecimal crtram  = BigDecimal.ZERO,drtram  = BigDecimal.ZERO,tocram  = BigDecimal.ZERO,todram = BigDecimal.ZERO;
				for (int i = 0; i < systid_array.length; i++) {
					HashMap<String, String> glkMiddBookMap = new HashMap<String, String>();
					String[] systid_detl_array = systid_array[i].split("-");
					glkMiddBookMap.put("stacid", systid_detl_array[0].trim());
					glkMiddBookMap.put("trandt", systid_detl_array[1].trim());
					glkMiddBookMap.put("systid", systid_detl_array[2].trim());
					glkMiddBookMap.put("itemcd", systid_detl_array[3].trim());
					glkMiddBookMap.put("transq", systid_detl_array[4].trim());//������ˮ��
					glkMiddBookMap.put("amntcd1",systid_detl_array[5].trim());//���𷽽������
					if(systid_detl_array[5].equals(AMNTCD_C)){
						glkMiddBookMap.put("crtram", systid_detl_array[6].trim());//���𷽴���������
						crtram=crtram.add(new BigDecimal(systid_detl_array[6].trim()));
					}
					if(systid_detl_array[5].equals(AMNTCD_D)){
						glkMiddBookMap.put("drtram", systid_detl_array[6].trim());//���𷽽跽������
						drtram=drtram.add(new BigDecimal(systid_detl_array[6].trim()));
					}
					if(systid_detl_array.length>7){
						glkMiddBookMap.put("bsnssq", systid_detl_array[7].trim());//
					}
					for (int j = 0; j < tosyst_array.length; j++) {
						String[] tosyst_detl_array = tosyst_array[j].split("-");
						glkMiddBookMap.put("stacid",  tosyst_detl_array[0].trim());
						glkMiddBookMap.put("tosyst",  tosyst_detl_array[2].trim());
						glkMiddBookMap.put("toitem",  tosyst_detl_array[3].trim());
						//glkMiddBookMap.put("totrsq",  tosyst_detl_array[4].trim());//�Է���ˮ��
						glkMiddBookMap.put("amntcd2", tosyst_detl_array[5].trim());
						tosqList.add(tosyst_detl_array[4].trim());
						//����ϵͳ�Ľ������ͶԷ�ϵͳ�����������ͬ
						if(glkMiddBookMap.get("amntcd1").equals(glkMiddBookMap.get("amntcd2"))){
							ResultUtils.setRspData(req, "300", "����ϵͳ�Ľ������ͶԷ�ϵͳ�����������ͬ��", "");
							commonDao.rollBack();
							return;
						}
						if(tosyst_detl_array[5].equals(AMNTCD_C)){
							glkMiddBookMap.put("tocram", systid_detl_array[6].trim());//�Է�����������
							tocram=tocram.add(new BigDecimal(tosyst_detl_array[6].trim()));
						}
						if(tosyst_detl_array[5].equals(AMNTCD_D)){
							glkMiddBookMap.put("todram", systid_detl_array[6].trim());//�Է��跽������
							todram=todram.add(new BigDecimal(tosyst_detl_array[6].trim()));
						}
						glkMiddBookList.add(glkMiddBookMap);
					}
				}
				String status ="2";
				if(crtram.compareTo(todram)==0
						&& drtram.compareTo(tocram)==0){
					status = "1";
				}else{
					ResultUtils.setRspData(req, "300", "����ϵͳ���ͶԷ�ϵͳ����ȣ�������ѡ��", "");
					commonDao.rollBack();
					return;
				}
				for (int i=0;i<glkMiddBookList.size();i++) {
					HashMap<String, String> hashMap = glkMiddBookList.get(i);
					//���ܶ���״̬:1���˶���ȷ 2����һ��
					hashMap.put("status", status);
					hashMap.put("totrsq", tosqList.get(i));
					commonDao.insertByNamedSql(GlkMiddBook+ "genGlkMiddBook",hashMap);
				}
				ResultUtils.setRspData(req, "200", "�����ɹ���", "");
				commonDao.commitTransaction();
		} catch (BimisException e) {
			ResultUtils.setRspData(req, "300", "����ʧ�ܣ�"+e, "");
			commonDao.rollBack();
			getLog().logError(e);
		}
	}
	
}
	
