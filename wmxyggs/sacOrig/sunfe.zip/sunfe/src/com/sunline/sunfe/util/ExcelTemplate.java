package com.sunline.sunfe.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.jdom.Element;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.util.DatetimeUtil;
import com.sunline.jraf.util.FileUtil;


public class ExcelTemplate {
	private static Log logger = LogFactory.getLog(ExcelTemplate.class);
	private static final String ROWDATA = "rowData";
	private static String TEMPLATEPATH = "excel"+File.separator;
	private HSSFWorkbook workbook;
	private HSSFSheet sheet;

	private Map<String, HSSFCellStyle> styles = new HashMap<String, HSSFCellStyle>(); // �����е�Ĭ����ʽ����
	private Map<String, Object> confStyles = new HashMap<String, Object>(); // ͨ������"#STYLE_XXX"����ʶ����ʽ����
	private List<String> fieldNames = new ArrayList<String>();
	private int initrow; // ���������ʼ��
	private int initcol; // ���������ʼ��
	private int currentcol; // ��ǰ��

	private int dataStyleType;
	private Map<String, Float> rowHeightMap = new HashMap<String, Float>();

	private ExcelTemplate() {
	}

	/**
	 * ʹ��Ĭ��ģ�崴��ExcelTemplate����
	 * 
	 * @return ����ģ���ѳ�ʼ����ɵ�ExcelTemplate����
	 */
	// private static ExcelTemplate newInstance() {
	// return newInstance("templates/default.xls");
	// }

	/**
	 * ָ��ģ�崴��ExcelTemplate����
	 * 
	 * @param templates
	 *            ģ������
	 * @return ����ģ���ѳ�ʼ����ɵ�ExcelTemplate����
	 */
	public static ExcelTemplate newInstance(String templates) {
		try {
			String filePath = null;
			if (StringUtils.isBlank(templates)) {
				throw new Exception("ģ���ļ�����Ϊ�գ�");
			}
			if (!templates.endsWith("xls")) {
				throw new Exception("��ѡ����ȷ��ģ���ļ���ģ���ļ�ֻ������.xls��β��excel�ļ���");
			}
			if (templates.indexOf(Chars.SLASH) == -1
					&& templates.indexOf(Chars.BACKSLASH) == -1) {
				String path=FileUtil.getWebPath();
				if(!path.endsWith("\\")){
					path=path+"/";
				}
				filePath =path + TEMPLATEPATH + templates;
			} else {
				filePath = templates;
			}
			logger.info("===����Excelģ��·��Ϊ:"+filePath);
			InputStream in = new FileInputStream(filePath);
			ExcelTemplate excel = new ExcelTemplate();
			POIFSFileSystem fs = new POIFSFileSystem(in);
			excel.workbook = new HSSFWorkbook(fs);
			excel.sheet = excel.workbook.getSheetAt(0);
			excel.initConfig();
			return excel;
		} catch (Exception e) {
			e.printStackTrace();
			logger.trace("����Excel��������쳣", e);
			throw new RuntimeException("����Excel��������쳣");
		}
	}

	/**
	 * ��ȡ��ǰHSSFWorkbook��ʵ��
	 * 
	 * @return
	 */
	public HSSFWorkbook getWorkbook() {
		return workbook;
	}

	/**
	 * ��ȡģ���ж���ĵ�Ԫ����ʽ�����û�ж��壬�򷵻ؿ�
	 * 
	 * @param style
	 *            ģ�嶨�����ʽ����
	 * @return ģ�嶨��ĵ�Ԫ�����ʽ�����û�ж����򷵻ؿ�
	 */
	public HSSFCellStyle getTemplateStyle(String style) {
		return (HSSFCellStyle) confStyles.get(style);
	}

	/**
	 * ��ʼ��Excel����
	 */
	@SuppressWarnings("deprecation")
	private void initConfig() {
		Iterator<?> rowit = sheet.rowIterator();
		boolean configFinish = false;
		int init = 0;
		int flag = 0;
		while (rowit.hasNext()) {
			if (configFinish) {
				break;
			}
			HSSFRow row = (HSSFRow) rowit.next();
			if (row == null)
				continue;
			int cellLength = row.getLastCellNum();
			for (int i = 0; i < cellLength; i++) {
				HSSFCell cell = (HSSFCell) row.getCell((short) i);
				if (cell == null)
					continue;
				String config = cell.getStringCellValue();
				if (config.startsWith("##")) {
					// ���������ݿ�ʼ�к���ʽ�����У���Ҫ��ȡ��Ӧ��������Ϣ
					readCellStyle(cell, "title");
					rowHeightMap.put("title_row_height",
							row.getHeightInPoints());
				} else if (config.startsWith("#")) {
					String fileName = config.substring(1);
					fieldNames.add(fileName);
					readCellStyle(cell, fileName);
					if (i == cellLength - 1) {
						rowHeightMap.put("field_row_height",
								row.getHeightInPoints());
					}
				} else if (config.equalsIgnoreCase(ROWDATA)) {
					if (init == 0) {
						initrow = row.getRowNum();
						initcol = cell.getCellNum();
						init++;
					}
					String key = ROWDATA + "_" + flag + "_" + cell.getCellNum();
					readCellStyle(cell, key);
					if (i == cellLength - 1) {
						rowHeightMap.put("date_row_height" + flag,
								row.getHeightInPoints());
						flag++;
					}
				}

			}

		}
		this.dataStyleType = flag;
	}

	/**
	 * ��ȡcell����ʽ
	 * 
	 * @param cell
	 */
	@SuppressWarnings("deprecation")
	private void readCellStyle(HSSFCell cell, String key) {
		HSSFCellStyle style = cell.getCellStyle();
		if (style == null)
			return;
		if (StringUtils.isNotBlank(key)) {
			styles.put(key, style);
		} else {
			styles.put("" + (cell.getCellNum()), style);
		}
	}

	
   
  
	/**
	 * ����ָ��sheetҳǩ����
	 * @param datas
	 * @param title
	 * @param fieldNameMap
	 * @param sheetIdx
	 * @return
	 * @throws BimisException
	 * @throws IOException
	 */
	public String exportExcel(List<Element> datas, String title,
			Map<String, String> fieldNameMap, int sheetIdx,int k) throws BimisException,
			IOException {
	
	    String path = FileUtil.getWebPath() + TEMPLATEPATH + "down"+File.separator;
	    logger.info("===����Excel�ļ����·��Ϊ:"+path);
	    File file = new File(path);
	    if(k==0)
	    {
	    	if (!file.exists()) {
				file.mkdir();
			}
//			else {
//				File[] files = file.listFiles();
//				if (files != null) {
//					for (File f : files) {
//						f.delete();
//					}
//				}
//			}
	    }
			HSSFWorkbook wb = getWorkbook();
			HSSFSheet sheet = wb.getSheetAt(sheetIdx);
			HSSFRow row = null;
			HSSFCell cell = null;
			int i = 0;
		if (fieldNameMap.size() != this.fieldNames.size()) {
			throw new BimisException("�����쳣", "������ֶγ��Ⱥ�ģ����ֶγ��Ȳ�һ�£�");
		}
		if (styles.get("title") != null) {
			row = sheet.createRow(i);
			row.setHeightInPoints(rowHeightMap.get("title_row_height"));
			cell = row.createCell(i);
			cell.setCellValue(title);
			cell.setCellStyle(styles.get("title"));
			i = i + 1;
		}
		row = sheet.createRow(i);
		if (rowHeightMap.get("field_row_height") != null) {
			row.setHeightInPoints(rowHeightMap.get("field_row_height"));
		}
		int cellIndex = this.currentcol;
		for (String fieldName : fieldNames) {
			cell = row.createCell(cellIndex++);
			cell.setCellValue(fieldNameMap.get(fieldName));
			if (styles.get(fieldName) != null) {
				cell.setCellStyle(styles.get(fieldName));
			}
		}
		i = this.initrow;
		for (Element e : datas) {
			row = sheet.createRow(i++);
			if (i % 2 == 0) {
				row.setHeightInPoints(rowHeightMap.get("date_row_height0"));
			} else {
				if (rowHeightMap.get("date_row_height1") == null) {
					row.setHeightInPoints(rowHeightMap.get("date_row_height0"));
				} else {
					row.setHeightInPoints(rowHeightMap.get("date_row_height1"));
				}
			}
			int j = this.currentcol;
			for (String fieldName : fieldNames) {
				cell = row.createCell(j);
				String value = e.getChildText(fieldName);
				cell.setCellValue(value);
				if (this.dataStyleType == 1) {
					cell.setCellStyle(styles.get(ROWDATA + "_" + 0 + "_" + j));
				}
				if (this.dataStyleType == 2) {
					if (i % 2 == 0) {
						cell.setCellStyle(styles.get(ROWDATA + "_" + 0 + "_"
								+ j));
					} else {
						cell.setCellStyle(styles.get(ROWDATA + "_" + 1 + "_"
								+ j));
					}
				}
				j++;
			}
		}
		//��������2��ʱ��ɾ��rowdate��
		if(datas.size()<2)
		{
			 for(int m=2+datas.size();m<4;m++)
			 {
			    HSSFRow row1 = sheet.getRow(m);  
			    if(row1!=null)
			    {
			    	sheet.removeRow(row1);
			    }  
			 }
		}
		String  fileName = path
						+  DatetimeUtil.formatDate(new Date(), "yyyyMMddHHmmss")+ ".xls";
		OutputStream out = new FileOutputStream(fileName);
		wb.write(out);
		out.close();
		return fileName;
	}
	
	public String exportExcel(List<Element> datas, String title,
			Map<String, String> fieldNameMap,int k) throws BimisException,
			IOException {
		return exportExcel(datas, title, fieldNameMap, 0,k);
	}

	public List<Map<String, Object>> importExcel(String importExcel)
			throws Exception {
		String filePath = null;
		if (importExcel.indexOf(Chars.SLASH) == -1
				&& importExcel.indexOf(Chars.BACKSLASH) == -1) {
			filePath = FileUtil.getWebPath() + TEMPLATEPATH + importExcel;
		} else {
			filePath = importExcel;
		}
		InputStream in = new FileInputStream(filePath);
		return importExcel(in);
	}

	public List<Map<String, Object>> importExcel(InputStream in)
			throws Exception {
		if (in == null) {
			throw new BimisException("���ݸ�ʽ�쳣", "���������ļ������ڻ��ļ�·������ȷ");
		}
		HSSFWorkbook wb = new HSSFWorkbook(in);
		HSSFSheet sheet = wb.getSheetAt(0);
		int rownum = sheet.getLastRowNum();
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Map<String, Object> data = null;
		for (int i = initrow; i <= rownum; i++) {
			int index = 0;
			HSSFRow row = sheet.getRow(i);
			data = new HashMap<String, Object>();
			int cellnum = row.getLastCellNum();
			if ((cellnum - initcol) != fieldNames.size()) {
				throw new BimisException("���ݸ�ʽ�쳣", "��������������ģ�岻��");
			}
			for (int j = this.initcol; j < cellnum; j++) {
				HSSFCell cell = row.getCell(j);
				Object value = null;
				if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
				    DecimalFormat df = new DecimalFormat("0");  
					value =df.format(cell.getNumericCellValue());
				} else if (cell.getCellType() == Cell.CELL_TYPE_BOOLEAN) {
					value =cell.getBooleanCellValue();
				} else if(cell.getCellType()==Cell.CELL_TYPE_BLANK){
					value = "";
				}else{
					value=cell.getStringCellValue();
				}
				data.put(this.fieldNames.get(index++), value);
			}
			list.add(data);
		}
		return list;
	}
}
