package com.sunline.sunfe.dayend.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.suncm.actor.common.DataDictParameter;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.dayend.IDayEndProcesser;

/**
 * ������Ŀ���
 * @ClassName: DayEndSysCheckProcesser 
 * @Description: TODO
 * @author: huangziq
 * @date: 2017-11-21 ����2:35:00
 */
public class DayEndSysCheckProcesser extends IDayEndProcesser {
	
	/**
	 * log ��־˽�б���
	 */
	private static Log log = LogFactory.getLog(DayEndSysCheckProcesser.class);
	/**
	 * mybatis �����ļ��������ռ�
	 */
	private static final String GlkMiddBook = "com.sunline.sunfe.mybatis.glkmiddbook.";
	private static final String GlkMiddConf = "com.sunline.sunfe.mybatis.glkmiddconf.";
	private static final String AMNTCD_D = "D";
	private static final String AMNTCD_C = "C";

	@Override
	public void preProcess() throws BimisException {
		// TODO Auto-generated method stub
		try {
			 commonDao = this.getCommonDao();
			//����ϵͳ�������˻�������
			GlkMiddCheck();
			int stacid = getStacid();//����
			String glisdt = PubUtil.getGlisdt(stacid);// ͨ�����׻�ȡ��������
			HashMap<String, Object> param = new HashMap<String, Object>();
			try {
				param.put("trandt", glisdt);
				param.put("stacid", stacid);
				param.put("status", "2");
				List<HashMap<String, String>>  glkMiddConfList = (List<HashMap<String, String>>) 
							commonDao.queryByNamedSqlForList(GlkMiddBook+"getGlkMiddBookSummList", param);
				//�ͻ�������������ϵͳ����ƽ���鲻ƽʱ���Ƿ����ִ�����գ�trueΪ����ִ�У�falseΪֹͣ����
				Map cusList = DataDictParameter.newInstance().getOptions("suncm_compara");
				Map cust = (Map) cusList.get(String.valueOf(stacid));
				String flag=(String) cust.get("glk_midd_check");
				if (glkMiddConfList.size() > 0) {
					if(flag.equals("true")){
						log.error("ϵͳ�������˲�ƽ������: "+glkMiddConfList.size()+"�����ݲ�ƽ");
					}else{
						log.error("ϵͳ�������˲�ƽ������: "+glkMiddConfList.size()+"�����ݲ�ƽ");
						throw new BimisException("-1", " ϵͳ�������˲�ƽ������ ");
					}
				}
			} catch (Exception ex) {
				log.error("���ռ���쳣: ϵͳ�������˲�ƽ", ex);
				throw new BimisException("-1","ִ�� DayEndSysCheckProcesser ��� processed �����쳣 :"+ ex.getMessage());
			} finally {
				this.closeSession();
			}
		} catch (Exception ex) {
			log.error("���ռ�飺ϵͳ�����˶�ʧ��", ex);
			throw new BimisException("-1","ִ�� DayEndSysCheckProcesser ��� processing ����ʧ�ܣ�"+ ex.getMessage());
		}	
	}

	@Override
	public void processing() throws BimisException {
		// TODO Auto-generated method stub

	}

	@Override
	public void processed() throws BimisException {
		// TODO Auto-generated method stub

	}
	
	@SuppressWarnings("unchecked")
	public void GlkMiddCheck() throws JDOMException, BimisException{
			//��ȡ��������
			String stacid = SessionParaUtils.getStacid();
			String trandt=PubUtil.getGlisdt(Integer.parseInt(stacid));
			HashMap<String, String> paramMap = new HashMap<String,String>();
			paramMap.put("stacid", stacid);
			paramMap.put("trandt", trandt);
			commonDao.beginTransaction();
			/**
			 * ɾ����ǰ����ϵͳ�������������ݣ�GLK_MIDD_BOOK_DETL��GLK_MIDD_BOOK��GLK_MIDD_BOOK_SUMM��
			 */
			commonDao.deleteByNamedSql(GlkMiddBook + "delCurrentGlkMiddBookDetl", paramMap);
			commonDao.deleteByNamedSql(GlkMiddBook + "delCurrentGlkMiddBook", paramMap);
			commonDao.deleteByNamedSql(GlkMiddBook + "delCurrentGlkMiddBookSumm", paramMap);
			/**
			 * �ٲ�ѯϵͳ�������������ñ�����ѯ������Ҫ��������ϵͳ�Ͷ�Ӧ��Ŀ
			 */
			List<HashMap<String, String>>  glkMiddConfList = (List<HashMap<String, String>>) commonDao.
							queryByNamedSqlForList(GlkMiddConf + "getGlkMiddConfList", paramMap);
			/**
			 *������ϵͳ��������ϸ����
			 */
			genGlkMiddBookDetl(glkMiddConfList,trandt);
			/**
			 *������ϵͳ��������������
			 */
			genGlkMiddBookSumm(glkMiddConfList,trandt,stacid);
			 /**
			  *������ϵͳ����������
			  */
			glkMiddConfList = (List<HashMap<String, String>>) commonDao.
						queryByNamedSqlForList(GlkMiddConf + "getGlkMiddConfList", paramMap);
			genGlkMiddBook(glkMiddConfList,trandt,stacid);
			commonDao.commitTransaction();		
	}
	/**
	 * ����ϵͳ��������ϸ����
	 * @param trandt 
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void genGlkMiddBookDetl(List<HashMap<String, String>> glkMiddConfList, String glisdt) throws BimisException {
		for (Iterator iterator = glkMiddConfList.iterator(); iterator.hasNext();) {
			 HashMap<String, String> glkMiddConf = (HashMap<String, String>) iterator.next();
			 glkMiddConf.put("trandt", glisdt);
			 commonDao.insertByNamedSql(GlkMiddBook+ "genGlkMiddBookDetl",glkMiddConf);
		}
	}
	/**
	 *����ϵͳ��������������
	 * @param stacid 
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void genGlkMiddBookSumm(List<HashMap<String, String>> glkMiddConfList, String glisdt, String stacid) throws BimisException {
		for (Iterator iterator = glkMiddConfList.iterator(); iterator.hasNext();) {
			 //��������
			 HashMap<String, String> glkMiddConf = (HashMap<String, String>) iterator.next();
   			 // ���ܱ�����
			 HashMap<String, String> glkMiddSumm =  new HashMap<String, String>();
			 glkMiddSumm.putAll(glkMiddConf);
			 glkMiddSumm.put("trandt", glisdt);
			 //��������Ϊ��������
			 glkMiddConf.put("trandt", glisdt);
			 //����ϵͳ��ϸֵ
			 List<HashMap<String, String>>  glkMiddBookDetl = (List<HashMap<String, String>>)
					 commonDao.queryByNamedSqlForList(GlkMiddBook+"getGlkMiddBookDetlSumm", glkMiddConf);
			 glkMiddSumm.put("crtram", "0");
			 glkMiddSumm.put("drtram", "0");
			 for (Iterator iterator2 = glkMiddBookDetl.iterator(); iterator2.hasNext();) {
				HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator2.next();
				if(hashMap.get("amntcd").equals(AMNTCD_C)){
					glkMiddSumm.put("crtram", hashMap.get("tranam").toString());
				}
				if(hashMap.get("amntcd").equals(AMNTCD_D)){
					glkMiddSumm.put("drtram", hashMap.get("tranam").toString());
				}
			  }
			 //�Է�ϵͳ��ϸֵ
			 glkMiddConf.put("systid", glkMiddConf.get("tosyst").toString());
			 glkMiddConf.put("itemcd", glkMiddConf.get("toitem").toString());
			 List<HashMap<String, String>>  to_glkMiddBookDetl = (List<HashMap<String, String>>)
					 commonDao.queryByNamedSqlForList(GlkMiddBook+"getGlkMiddBookDetlSumm", glkMiddConf);
			 glkMiddSumm.put("todram", "0");
			 glkMiddSumm.put("tocram", "0");
			 for (Iterator iterator3 = to_glkMiddBookDetl.iterator(); iterator3.hasNext();) {
					HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator3.next();
					if(hashMap.get("amntcd").equals(AMNTCD_C)){
						glkMiddSumm.put("tocram", hashMap.get("tranam").toString());
					}
					if(hashMap.get("amntcd").equals(AMNTCD_D)){
						glkMiddSumm.put("todram", hashMap.get("tranam").toString());
					}
				}
			 String status="2";
			 if(glkMiddSumm.get("crtram").equals(glkMiddSumm.get("todram"))
					 &&  glkMiddSumm.get("drtram").equals(glkMiddSumm.get("tocram")) ){
				 status="1";
			 }
			 //���ܶ���״̬:1���˶���ȷ 2����һ��
			 glkMiddSumm.put("status", status);
			 commonDao.insertByNamedSql(GlkMiddBook+ "genGlkMiddBookSumm",glkMiddSumm);
		}
	}
	/**
	  *����ϵͳ��������������
	  * @param glkMiddConfList 
	  * @param glisdt 
	 * @throws BimisException 
	  */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void genGlkMiddBook( List<HashMap<String, String>> glkMiddConfList, String glisdt,String stacid) throws BimisException {
		 List<HashMap<String, String>>  glkMiddBookDetlBsnssqs =  (List<HashMap<String, String>>)
				 			commonDao.queryByNamedSqlForList(GlkMiddBook+ "getGlkMiddBookDetlBsnssq", null);
		 for (Iterator iterator = glkMiddBookDetlBsnssqs.iterator(); iterator.hasNext();) {
				HashMap<String, String> hashMap = (HashMap<String, String>) iterator.next();
				//ȫ����ˮ��
				String bsnssq = hashMap.get("bsnssq");
				HashMap<String, String>  glkMiddBook =  new HashMap<String, String>();
				glkMiddBook.put("bsnssq", bsnssq);
				glkMiddBook.put("trandt", glisdt);
				glkMiddBook.put("stacid", stacid);
				for (Iterator iterator1 = glkMiddConfList.iterator(); iterator1.hasNext();) {
					 HashMap<String, String> glkMiddConf = (HashMap<String, String>) iterator1.next();
					 HashMap<String, String> tempmap = new HashMap<String, String>();
					 glkMiddBook.putAll(glkMiddConf);
					 tempmap.putAll(glkMiddConf);
					 tempmap.put("trandt", glisdt);
					 tempmap.put("bsnssq", bsnssq);
					 List<HashMap<String, String>>  glkMiddBookDetl_01 = (List<HashMap<String, String>>)
							 	commonDao.queryByNamedSqlForList(GlkMiddBook+ "getGlkMiddBookDetlByBsnssq",tempmap);
					 tempmap.put("systid", glkMiddConf.get("tosyst"));
					 tempmap.put("itemcd", glkMiddConf.get("toitem"));
					 List<HashMap<String, String>>  glkMiddBookDetl_02 = (List<HashMap<String, String>>)
							 	commonDao.queryByNamedSqlForList(GlkMiddBook+ "getGlkMiddBookDetlByBsnssq",tempmap);
					 tempmap.clear();
					 //���𷽺ͶԷ�ϵͳ��ϸֵ����Ϊ�գ����ɹ�����¼
					 if(glkMiddBookDetl_01.size() > 0  && glkMiddBookDetl_02.size() > 0){
						 glkMiddBook.put("transq", glkMiddBookDetl_01.get(0).get("transq"));//�����׷�������ˮ
						 glkMiddBook.put("totrsq", glkMiddBookDetl_02.get(0).get("transq"));//�Է�������ˮ
						 for (Iterator iterator3 = glkMiddBookDetl_01.iterator(); iterator3.hasNext();) {
								HashMap<String, Object> temp = (HashMap<String, Object>) iterator3.next();
								if(temp.get("amntcd").equals(AMNTCD_C)){
									glkMiddBook.put("crtram", temp.get("tranam").toString());
								}
								if(temp.get("amntcd").equals(AMNTCD_D)){
									glkMiddBook.put("drtram", temp.get("tranam").toString());
								}
							  }
						 for (Iterator iterator4 = glkMiddBookDetl_02.iterator(); iterator4.hasNext();) {
								HashMap<String, Object> temp = (HashMap<String, Object>) iterator4.next();
								if(temp.get("amntcd").equals(AMNTCD_C)){
									glkMiddBook.put("tocram", temp.get("tranam").toString());
								}
								if(temp.get("amntcd").equals(AMNTCD_D)){
									glkMiddBook.put("todram", temp.get("tranam").toString());
								}
							  }
						 String status="2";
						 if((glkMiddBook.containsKey("crtram")&&glkMiddBook.containsKey("todram")&&
								 glkMiddBook.get("crtram").equals(glkMiddBook.get("todram")))
								 ||
								 (glkMiddBook.containsKey("drtram")&&glkMiddBook.containsKey("tocram")&&
								 glkMiddBook.get("drtram").equals(glkMiddBook.get("tocram"))) ){
							 status="1";
						 }
						 //���ܶ���״̬:1���˶���ȷ 2����һ��
						 glkMiddBook.put("status", status);
						 commonDao.insertByNamedSql(GlkMiddBook+ "genGlkMiddBook",glkMiddBook);
					 }else if(glkMiddBookDetl_01.size() >0 && glkMiddBookDetl_02.size()==0){
						 glkMiddBook.put("transq", glkMiddBookDetl_01.get(0).get("transq"));//�����׷�������ˮ
						 for (Iterator iterator3 = glkMiddBookDetl_01.iterator(); iterator3.hasNext();) {
								HashMap<String, Object> temp = (HashMap<String, Object>) iterator3.next();
								if(temp.get("amntcd").equals(AMNTCD_C)){
									glkMiddBook.put("crtram", temp.get("tranam").toString());
								}
								if(temp.get("amntcd").equals(AMNTCD_D)){
									glkMiddBook.put("drtram", temp.get("tranam").toString());
								}
							  }
						 //���ܶ���״̬:1���˶���ȷ 2����һ��
						 glkMiddBook.put("status", "0");
						 commonDao.insertByNamedSql(GlkMiddBook+ "genGlkMiddBook",glkMiddBook);
					 }else if(glkMiddBookDetl_02.size() >0 && glkMiddBookDetl_01.size()==0){
						 glkMiddBook.put("transq", glkMiddBookDetl_02.get(0).get("transq"));//�����׷�������ˮ
						 for (Iterator iterator3 = glkMiddBookDetl_02.iterator(); iterator3.hasNext();) {
								HashMap<String, Object> temp = (HashMap<String, Object>) iterator3.next();
								if(temp.get("amntcd").equals(AMNTCD_C)){
									glkMiddBook.put("crtram", temp.get("tranam").toString());
								}
								if(temp.get("amntcd").equals(AMNTCD_D)){
									glkMiddBook.put("drtram", temp.get("tranam").toString());
								}
							  }
						 //���ܶ���״̬:1���˶���ȷ 2����һ��
						 glkMiddBook.put("status", "0");
						 commonDao.insertByNamedSql(GlkMiddBook+ "genGlkMiddBook",glkMiddBook);
				}
		    }
		 }
	}

}
