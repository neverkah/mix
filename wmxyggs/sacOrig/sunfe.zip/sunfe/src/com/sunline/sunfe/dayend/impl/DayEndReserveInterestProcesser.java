package com.sunline.sunfe.dayend.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sunline.jraf.BimisException;
import com.sunline.suncm.util.ComParaUtil;
import com.sunline.suncm.util.JrafSessionUtil;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.Sequence;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.core.bean.GlaAeuvBean;
import com.sunline.sunfe.dayend.IDayEndProcesser;
import com.sunline.sunfe.entity.GlaAeuv;
import com.sunline.sunfe.glisfund.PublicFmbCntrInfoUtil;
import com.sunline.sunfe.util.ClpConfUtil;
import com.sunline.sunfe.util.ComAcpdUtil;
import com.sunline.sunfe.util.DatetimeUtil;

/**
 * @ClassName: DayEndReserveInterestProcesser
 * @Description:�ڲ��ʽ��Ϣ
 * @author: huangzhongjie
 * @date: 2018��3��21�� ����3:36:38
 */

public class DayEndReserveInterestProcesser extends IDayEndProcesser {
	private static final Logger logger = LoggerFactory.getLogger(DayEndReserveInterestProcesser.class);

	private PublicFmbCntrInfoUtil publicFmbCntrInfo;

	/**
	 * @throws BimisException
	 * @�˷��������ã�
	 */
	@Override
	public void preProcess() throws BimisException {

	}

	@Override
	public void processing() throws BimisException {
		try {
			commonDao = this.getCommonDao();
			publicFmbCntrInfo = new PublicFmbCntrInfoUtil(commonDao);
			commonDao.beginTransaction();
			reserveInterest();

			commonDao.commitTransaction();
		} catch (Exception e) {
			commonDao.rollBack();
			logger.error(e.getMessage());
			e.printStackTrace();
			throw new BimisException("500", "�ڲ��ʽ��Ϣ����" + e.getMessage());
		} finally {
			JrafSessionUtil.closeConnection(jrafSession);
		}
	}

	public void reserveInterest() throws Exception {
		int stacid = Integer.valueOf(SessionParaUtils.getStacid());

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("stacid", stacid);

		// ����
		String sStacid = SessionParaUtils.getStacid();
		// ��¼�˺�
		String user_Usercd = SessionParaUtils.getUsercd();

		// ��Ϣ����
		String l_Fcvt_Freq = ComParaUtil.getParavl(sStacid, "resrit_freq");
		// ��������
		String trandt = PubUtil.getGlisdt(Integer.valueOf(sStacid));

		if ("M".equals(l_Fcvt_Freq)) {
			if (!ComAcpdUtil.isReptDay(sStacid, trandt)) {
				return;
			}

		} else if ("D".equals(l_Fcvt_Freq)) {

		} else if ("Q".equals(l_Fcvt_Freq)) {
			if (!trandt.equals(DatetimeUtil.getSpeldate(trandt, "QE", 0))) {
				return;
			}
		} else {
			throw new BimisException("99", "�ڲ��ʽ��ϢƵ��resrit_freq�����Ƿ�");
		}
		// ��ѯ��ĿΪӦ��ϵͳ��������Ϣ���˻�����������0���˻�
		List<Map<String, Object>> list = publicFmbCntrInfo.selectGlaAcctInterest(map);

		// ������
		String l_Prcscd = "gls_resrit";

		// ��������
		String l_Acetna = publicFmbCntrInfo.prcsnaInfo(stacid, l_Prcscd).get("functx").toString();

		// ��Ϣ���
		BigDecimal tranam = BigDecimal.ZERO;
		for (Map<String, Object> mapGlaAcct : list) {

			// �¼�����
			String brchno = mapGlaAcct.get("brchno").toString();

			// ����
			String crcycd = mapGlaAcct.get("crcycd").toString();
			
			// ��������
			String upprbr = ClpConfUtil.getClerBrch(stacid, brchno,crcycd);

			tranam = new BigDecimal(mapGlaAcct.get("onlnbl").toString());
			if (tranam.compareTo(BigDecimal.ZERO) <= 0) {
				continue;
			}

			// ������ˮ
			Sequence sequence = SequenceUtils.createSequence(sStacid, trandt, "bsnssq", brchno, user_Usercd, 1);

			String l_Soursq = sequence.getSqueno();

			// �Ǽ�gla_aeuv
			GlaAeuv glaAeuv = new GlaAeuv();

			glaAeuv.setStacid(stacid);
			glaAeuv.setSourst("90");
			glaAeuv.setSourdt(trandt);
			glaAeuv.setSoursq(l_Soursq);
			glaAeuv.setTranbr(upprbr); // �ϼ�����Ϊ���׻���
			glaAeuv.setAcetna(l_Acetna);
			glaAeuv.setUsercd(user_Usercd);
			glaAeuv.setPrcscd(l_Prcscd);
			glaAeuv.setTrantp("1"); // �ֹ���
			glaAeuv.setTranst("0");
			glaAeuv.setStrkst("0");

			GlaAeuvBean.saveGlaAeuv(commonDao, glaAeuv);

			// ����
			publicFmbCntrInfo.fundCmbk(stacid, glaAeuv.getSourst(), glaAeuv.getSourdt(), glaAeuv.getSoursq(), brchno, upprbr,
					null, "3D", crcycd, tranam, BigDecimal.ZERO, BigDecimal.ZERO, null);

		}
	}

	/**
	 * @throws BimisException
	 * @�˷��������ã�
	 */
	@Override
	public void processed() throws BimisException {
	}

}
