package com.sunline.sunfe.conf;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.services.Actor;
import com.sunline.sunfe.util.StringUtils;

/**
 * ��������ӳ��������� && IompAction
 * Author: luoyd
 * creation time: 2016-12-21
 * @author ASUS
 *
 */
public class IompAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.iomp.";
	
	/**
	 * ��ѯ��������ӳ�� && queryIompListPage
	 * 
	 */
	public void queryIompListPage(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String mapkey = req.getReqDataStr("mapkey");
			String ruleid = req.getReqDataStr("ruleid");
			String pageNo = req.getReqDataStr("pageNum");
			if (StringUtils.isNotEmpty(pageNo)) {
				req.setReqPageNo(Integer.parseInt(pageNo));
			}
			ruleid = StringUtils.repalceCharecter(ruleid);
			mapkey = StringUtils.repalceCharecter(mapkey);

			
			hashmap.put("mapkey", mapkey);
			hashmap.put("ruleid", ruleid);
			
			Element element = commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryIomplistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(element.removeContent());
		} catch (JDOMException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * ��ѯ��������ӳ����Ϣ����
	 */
	public void queryIompInfo(){
		try 
		{
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String mapkey = req.getReqDataStr("mapkey");//
			String ruleid = req.getReqDataStr("ruleid");//����1
			String ftokey = req.getReqDataStr("ftokey");//����2
			
			// String smrytx = req.getReqDataStr("smrytx");//����3
			hashmap.put("mapkey", mapkey);
			hashmap.put("ruleid", ruleid);
			hashmap.put("ftokey", ftokey);
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryIompInfo", hashmap);	
            req.addRspData(e.removeContent());        //���ؽ����װ	
		} catch (Exception e) {
			e.printStackTrace();
		}
	 }	
	
	/**
	 *  ��������ӳ����Ϣ��Ϣ¼��
	 */
	@SuppressWarnings("rawtypes")
	public void addIomp(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			commonDao.beginTransaction();
			String mapkey = req.getReqDataStr("mapkey");//���Դ���
			String ruleid = req.getReqDataStr("ruleid");//����1
			String ftokey = req.getReqDataStr("ftokey");//����2
			String smrytx = req.getReqDataStr("smrytx");//����3
			
			hashmap.put("mapkey", mapkey);
			hashmap.put("ruleid", ruleid);
			hashmap.put("ftokey", ftokey);
			hashmap.put("smrytx", smrytx);
			
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistIomp", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "�ù�������ӳ���Ѵ��ڣ�");
					return;
				}
			}
			
			commonDao.insertByNamedSql(MYBATIS_NS+"addIomp", hashmap);
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("navTabId", "");
			req.addRspData("callbackType", "closeCurrent");
			req.addRspData("forwardUrl", "");
			commonDao.commitTransaction();
			
		} catch (Exception e) {
			commonDao.rollBack();
			e.printStackTrace();
		}	
		
	}
	
	/**
	 * ɾ����������ӳ�� && deleteIomp
	 * 
	 */
    public void deleteIomp() {
		 try {
	        	HashMap<String, String> param = new HashMap<String, String>();
	            List<String> iompcdsList = req.getReqDataTexts("iompcds");
	            commonDao.beginTransaction();
	            for (int i=0;i<iompcdsList.size();i++) {
	            	 param.clear();
	                 String [] array = iompcdsList.get(i).split("-");
	                 param.put("mapkey", array[0]);
	                 param.put("ruleid", array[1]);
	                 param.put("ftokey", array[2]);
	                 commonDao.deleteByNamedSql(MYBATIS_NS+"deleteIomp", param);
	            }
	            commonDao.commitTransaction();
	            req.addRspData("retCode", "200");
				req.addRspData("retMessage", "�����ɹ�");
				req.addRspData("navTabId", "iomp_main");
				req.addRspData("callbackType", "");
				req.addRspData("forwardUrl", "");
			} catch (Exception e) {
				commonDao.rollBack();
				try {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage",e.toString().substring(e.toString().lastIndexOf("Cause")));
					req.addRspData("navTabId", "iomp_main");
					req.addRspData("callbackType", "");
					req.addRspData("forwardUrl", "");
				} catch (JDOMException e1) {
					e1.printStackTrace();
				}
				e.printStackTrace();
			  }
		}	
}
