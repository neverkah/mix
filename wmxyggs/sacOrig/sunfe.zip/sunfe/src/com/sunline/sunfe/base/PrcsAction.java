package com.sunline.sunfe.base;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.sunfe.util.StringUtils;

public class PrcsAction extends Actor {
	
    private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.prcs.";
    Log log = new Log("PrcsAction");
	/**
	 * ��ѯ�������嵥 & queryPrcsListPage
	 */
	@SuppressWarnings("unchecked")
	public void queryPrcsListPage(){
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("vermod", "0");
			hashmap.put("prcscd",  StringUtils.repalceCharecter(hashmap.get("prcscd")));
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryPrcslistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			log.logError(e);
		}
		
	}
	
	/**
	 * ���������� & addPrcs
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addPrcs() throws JDOMException{
		try {
			commonDao.beginTransaction();
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();			
			//���ݴ�������prcscd���ж�,�Ƿ����д��ڵĴ�����
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistPrcs", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "���������Ѵ��ڣ�");
					return;
				}
			}
			    commonDao.insertByNamedSql(MYBATIS_NS+"addPrcs",hashmap);
			    ResultUtils.setRspData(req, "200", "�����ɹ�", "prcs_main","closeCurrent");
				commonDao.commitTransaction();
			} catch (BimisException e) {
			    ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "","");
				commonDao.rollBack();
				log.logError(e);
		  }
	}
	/**
	 * �޸Ĵ�������Ϣ & updatePrcs
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void updatePrcs() throws JDOMException{
		try {
			commonDao.beginTransaction();
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			commonDao.updateByNamedSql(MYBATIS_NS+"updatePrcs", hashmap);	
			hashmap.put("vermod", "0");
		    commonDao.insertByNamedSql(MYBATIS_NS+"addPrcs",hashmap);
			commonDao.commitTransaction();
		    ResultUtils.setRspData(req, "200", "�����ɹ�", "prcs_main","closeCurrent");
		} catch (BimisException e) {
			commonDao.rollBack();
		    ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "prcs_main","");
		    log.logError(e);
		}
	}
	/**
	 * ɾ����������Ϣ & deletePrcs
	 * @throws JDOMException 
	 */
	@SuppressWarnings("rawtypes")
	public void deletePrcs() throws JDOMException{
		try {
			List<String> prcscdList = req.getReqDataTexts("prcscds");
			if (prcscdList != null && prcscdList.size() > 0) {
				commonDao.beginTransaction();
				HashMap<String, String> hashmap = new HashMap<String,String>();
				for (Iterator iterator = prcscdList.iterator(); iterator.hasNext();) {
					String string = (String) iterator.next();
					hashmap.put("prcscd", string.split("-")[0].trim());
					hashmap.put("projcd", string.split("-")[1].trim());
					commonDao.deleteByNamedSql(MYBATIS_NS+"deletePrcs", hashmap);
				}
				}
				commonDao.commitTransaction();
			    ResultUtils.setRspData(req, "200", "�����ɹ�", "prcs_main","");
		} catch (BimisException e) {
				commonDao.rollBack();
			    ResultUtils.setRspData(req, "200", "����ʧ��"+e.getErrmsg(), "prcs_main","");
			    log.logError(e);

		}
	}
}
