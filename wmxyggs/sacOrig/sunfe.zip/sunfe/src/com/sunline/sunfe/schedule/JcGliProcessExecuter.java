package com.sunline.sunfe.schedule;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.security.UserAuthenticator;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.services.JrafSessionFactory;
import com.sunline.sundp.util.Enumeration;
import com.sunline.sundp.util.StringUtils;
import com.taobao.pamirs.schedule.IScheduleTaskDealSingle;
import com.taobao.pamirs.schedule.TaskItemDefine;

/**
 * ���ݼӹ�
 * 
 * @author huangzhongjie
 * 
 */
public class JcGliProcessExecuter implements IScheduleTaskDealSingle<Object> {
	private static Log log = LogFactory.getLog(JcGliProcessExecuter.class);
	private String MYBATIS_NS_DATAMANAGER = "com.sunline.sundp.mybatis.dataFileManager.";
	private String MYBATIS_NS_GLIPROCESS = "com.sunline.sundp.mybatis.jcGliProcess.";
	public final static String ACTIVE_STATUS = "1";

	private JrafSession getJrafSession(JrafSession jrafSession) {
		try {
			if (jrafSession == null || jrafSession.getConnection() == null || jrafSession.getConnection().isClosed()) {
				jrafSession = JrafSessionFactory.getInstance().openSession();
			}
		} catch (Exception e) {
			log.error("���Ȼ�ȡJrafSessionʧ��", e);
		}
		return jrafSession;
	}

	/**
	 * �ر�����
	 * 
	 * @throws BimisException
	 */
	private void closeConnection(JrafSession jrafSession) throws BimisException {
		try {
			if (jrafSession != null && jrafSession.getConnection() != null && !jrafSession.getConnection().isClosed()) {
				jrafSession.close();
				jrafSession = null;
			}
		} catch (SQLException e) {
			log.error("�ر�JrafSessionʧ��", e);
			throw new BimisException("300", "�ر�JrafSessionʧ��");
		}
	}

	@Override
	public List<Object> selectTasks(String taskParameter, String ownSign, int taskItemNum, List<TaskItemDefine> taskItemList,
			int eachFetchDataNum) throws Exception {
		log.debug("......start GliProcessExecuter selectTasks......");

		List<Object> list = new ArrayList<Object>();
		JrafSession jrafSession = getJrafSession(null);

		try {
			log.debug("......end importDataExecuter selectTasks......");
			HashMap hashMap = new HashMap();
			
			HashMap<String, String> map = StringUtils.String2Map(taskParameter);
			String stacid = map.get("stacid");
			String systid = map.get("systid");
			hashMap.put("stacid", stacid);

			CommonDao commonDao = new CommonDao(jrafSession);
			String glisdt = commonDao.getSqlSession().selectOne(MYBATIS_NS_GLIPROCESS + "qryBsnsDt", hashMap);

			hashMap.clear();
			hashMap.put("sourdt", glisdt);

			List<String> lstBathid = commonDao.getSqlSession().selectList(MYBATIS_NS_GLIPROCESS + "qryBathidsBySourdt", hashMap);
			for (String bathid : lstBathid) {
				ReturnData returnData = new ReturnData();
				returnData.setBathid(bathid);
				returnData.setStacid(stacid);
				returnData.setSystid(systid);
				list.add(returnData);
			}

			// �������е�������Ϣ
			return list;
		} catch (Exception e) {
			throw e;
		} finally {
			closeConnection(jrafSession);
		}
	}

	/**
	 * 
	 */
	@Override
	public boolean execute(Object task, String ownSign) throws Exception {
		// ���ݼӹ�״̬
		String prstau = "";
		// GLO_IMDT ״̬
		String status = "";
		// ���ݼӹ�������־
		String prerlg = "";
		ReturnData rd = (ReturnData) task;
		JrafSession jrafSession = null;
		CommonDao commonDao = null;
		// ���ݼӹ���ʼʱ��
		Timestamp prbgdt = new Timestamp(System.currentTimeMillis());
		try {
			
			jrafSession = getJrafSession(null);
			commonDao = new CommonDao(jrafSession);
			commonDao.beginTransaction();
			// ����GLO_IMDT���ݼӹ�״̬Ϊ������
			HashMap hashMap = new HashMap();
			hashMap.put("bathid", rd.getBathid());
			hashMap.put("status", Enumeration.ImdtStatus.PRO.value);
			commonDao.updateByNamedSql(MYBATIS_NS_GLIPROCESS + "updGloImdtStatusABybathid", hashMap);

			// ����GLI_BALG���ݼӹ�״̬Ϊ������
			hashMap.put("prstau", Enumeration.Status.O.value);
			commonDao.updateByNamedSql(MYBATIS_NS_GLIPROCESS + "updGliBalgStatusBybathid", hashMap);

			doProcessMain(rd, ownSign, commonDao);

			commonDao.commitTransaction();

			status = Enumeration.ImdtStatus.PRS.value;
			// �����ɹ�
			prstau = Enumeration.Status.S.value;

		} catch (Exception e) {
			// ����ʧ��
			prstau = Enumeration.Status.F.value;
			status = Enumeration.ImdtStatus.PRF.value;
			prerlg = e.getMessage();
			commonDao.rollBack();
		} finally {
			closeConnection(jrafSession);
			JrafSession jrafSessionFinal = null;
			
			try {
				// ���ݼӹ�����ʱ��
				Timestamp provdt = new Timestamp(System.currentTimeMillis());
				jrafSessionFinal = getJrafSession(null);
				// ����glo_imdt
				HashMap hashMap = new HashMap();
				hashMap.put("bathid", rd.getBathid()); // ���κ�
				hashMap.put("status", status);// ״̬
				CommonDao commonDaofinal = new CommonDao(jrafSessionFinal);
				commonDaofinal.updateByNamedSql(MYBATIS_NS_GLIPROCESS + "updGloImdtStatusABybathid", hashMap);

				// ����gli_balg
				hashMap.put("prstau", prstau); // ���ݼӹ�״̬
				hashMap.put("prbgdt", prbgdt);//���ݼӹ���ʼʱ��
				hashMap.put("provdt", provdt);// ���ݼӹ�����ʱ��
				hashMap.put("prerlg", prerlg == null ? "java.lang.NullPointerException" : prerlg);// ���ݼӹ�������־
				commonDaofinal.updateByNamedSql(MYBATIS_NS_DATAMANAGER + "updGliBalgPrstauPrerlg", hashMap);

			} catch (Exception e1) {
				e1.printStackTrace();
				log.error(e1);
			} finally {
				closeConnection(jrafSessionFinal);
			}

		}

		return true;

	}

	private void doProcessMain(ReturnData task, String ownSign, CommonDao commonDao) throws Exception {
		HashMap hashMap = new HashMap();
		hashMap.put("bathid", task.getBathid());
		hashMap.put("stacid", task.getStacid());
		hashMap.put("systid", task.getSystid());
		// ��glo_loan_busi�ı���crcycd�ֶ� 01ת���� CNY
		commonDao.insertByNamedSql(MYBATIS_NS_GLIPROCESS + "insLoanBusiByBathid", hashMap);
	}

	// selectTask���������������
	class ReturnData {

		// ���κ�
		private String bathid;
		// ����
		private String stacid;
		//ϵͳ
		private String systid;

		public String getSystid() {
			return systid;
		}

		public void setSystid(String systid) {
			this.systid = systid;
		}

		public String getStacid() {
			return stacid;
		}

		public void setStacid(String stacid) {
			this.stacid = stacid;
		}

		public String getBathid() {
			return bathid;
		}

		public void setBathid(String bathid) {
			this.bathid = bathid;
		}

	}

	@Override
	public Comparator<Object> getComparator() {
		return null;
	}
	
}
