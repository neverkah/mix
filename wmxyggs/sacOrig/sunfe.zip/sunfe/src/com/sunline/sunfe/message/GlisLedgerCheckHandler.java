package com.sunline.sunfe.message;


import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.jcraft.jsch.Logger;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.services.JrafSessionFactory;
import com.sunline.sundp.gw.base.server.DealMessageImpl;
import com.sunline.sundp.gw.base.server.MsgFunction;
import com.sunline.sundp.gw.base.util.PropList;
public class GlisLedgerCheckHandler implements DealMessageImpl{
	private static Log log = LogFactory.getLog(GlisLedgerCheckHandler.class);


	@Override
	public Map dealMessage(Map map) {
		Map innerMap=new HashMap();
		PropList pl=new PropList();
		JrafSession jrafSession=null;
		try {
			if(map.isEmpty()){
				log.error("�ֺܷ˶Բ�ѯ����Ϊ�գ������ô������!");
				return null;
			}
			HashMap hash=new HashMap();
			if(map.containsKey("stacid")){
				hash.put("stacid", (String) map.get("stacid"));
			}
			if(map.containsKey("acctdt")){
				hash.put("acctdt", (String) map.get("acctdt"));
			}
			if(map.containsKey("systid")){
				hash.put("systid", (String) map.get("systid"));
			}
			if(map.containsKey("status")){
				hash.put("status",(String) map.get("status"));
			}
			if(map.containsKey("itemcd")){
				hash.put("itemcd", (String) map.get("itemcd"));
			}
			if(map.containsKey("brchcd")){
				hash.put("brchcd", (String) map.get("brchcd"));	
			}
			
			jrafSession=getJrafSession(jrafSession);
			CommonDao dao=new CommonDao(jrafSession);
			List<HashMap> list=dao.getSqlSession().selectList("com.sunline.sunfe.mybatis.glisledgercheck.checkGlisForClient", hash);
		if(list.size()>0){
			for(HashMap m:list){
				Map<String,String> h=new HashMap<String,String>();
				h.put("stacid", m.get("stacid").toString());
				h.put("acctdt", (String) m.get("acctdt"));
				h.put("systid", (String) m.get("systid"));
				h.put("status", (String) m.get("status"));
				h.put("itemcd", (String) m.get("itemcd"));
				h.put("brchcd", (String) m.get("brchcd"));
				h.put("balanc", m.get("balanc").toString());
				h.put("onlnbl", m.get("onlnbl").toString());
				h.put("crcycd", (String) m.get("crcycd"));
				pl.add(h);
			}
		}
		innerMap.put("queryForGlisLedger", pl);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			closeConnection(jrafSession);
		}

		return innerMap;
	}
	private synchronized static JrafSession getJrafSession(
			JrafSession jrafSession) {
		try {
			if (jrafSession == null || jrafSession.getConnection() == null
					|| jrafSession.getConnection().isClosed()) {
				jrafSession = JrafSessionFactory.getInstance().openSession();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return jrafSession;
	}

	public void closeConnection(JrafSession jrafSession) {
		try {
			if (jrafSession != null && jrafSession.getConnection() != null
					&& !jrafSession.getConnection().isClosed()) {
				jrafSession.close();
				jrafSession = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.debug("jrafSession�ر�ʧ��!");
		}
	}

}
