package com.sunline.sunfe.conf;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.util.StringUtils;

public class PmapAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.pmap.";
	Log log = new Log("PmapAction");
	/**
	 * ��ѯ��Ʒ�ӽ���ģ���б� & queryPmapListPage
	 */
	public void queryPmapListPage(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String prodna = req.getReqDataStr("prodna");
			String tranna = req.getReqDataStr("tranna");
			tranna = StringUtils.repalceCharecter(tranna);
			hashmap.put("prodna", prodna);
			hashmap.put("tranna", tranna);
			hashmap.put("stacid", SessionParaUtils.getStacid());
			hashmap.put("vermod", "0");
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryPmaplistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (Exception e) {
			log.logError(e);
		}
	}
	
	/**
	 * ��ѯ��Ʒ�ӽ���ģ����Ϣ����
	 */
	public void queryPmapInfo(){
		try 
		{
			HashMap<String, String> param = new HashMap<String, String>();
		    String pmtttp = req.getReqDataStr("pmtttp");
            	 String [] array = pmtttp.split("-");		            	           	 
                 param.put("prodcd", array[0]);  
                 param.put("trancd", array[1]);
                 param.put("tmplid", array[2]);
                 param.put("tmpltp", array[3]);
                 param.put("stacid", array[4]);
                 param.put("vermod","0");
			//����������ѯ��Ʒ�ӽ���ģ������
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryPmapInfo", param);	
            req.addRspData(e.removeContent());        //���ؽ����װ	
		} catch (Exception e) {
			log.logError(e);
		}
	 }	
	
	/**
	 *  ��Ʒ�ӽ���ģ����Ϣ¼��
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addPmap() throws JDOMException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			//У���Ƿ��Ѵ���
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistPmap", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "�ò�Ʒ�ӽ���ģ���Ѵ��ڣ�");
					return;
				}
			}
			//ִ����������
			commonDao.insertByNamedSql(MYBATIS_NS+"addPmap", hashmap);
		  	ResultUtils.setRspData(req, "200",  "�����ɹ�", "pmap_main", "closeCurrent", "");
			commonDao.commitTransaction();
		} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
	  }
		
	}
	/**
	 *  ά����Ʒ�ӽ���ģ����Ϣ
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void updatePmap() throws JDOMException{
		try {
			HashMap<String, String> hashmap =  (HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			commonDao.insertByNamedSql(MYBATIS_NS+"updatePmap", hashmap);
			hashmap.put("vermod", "0");
			commonDao.insertByNamedSql(MYBATIS_NS+"addPmap", hashmap);
			commonDao.commitTransaction();
		  	ResultUtils.setRspData(req, "200",  "�����ɹ�", "pmap_main", "closeCurrent", "");
		} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
	  }
	 }	
	
	/**
	 * �������ɾ����Ʒ�ӽ���ģ����Ϣ
	 * @throws JDOMException 
	 */
	 public void deleteManyPmap() throws JDOMException {
		  try {
	        	HashMap<String, String> param = new HashMap<String, String>();
	            List<String> pmtttpList = req.getReqDataTexts("pmtttp");
	            commonDao.beginTransaction();
	            for (int i=0;i<pmtttpList.size();i++) {
	            	 param.clear();	            	  	            	 
	            	 String [] array = pmtttpList.get(i).split("-");		            	           	 
	                 param.put("prodcd", array[0]);  
	                 param.put("trancd", array[1]);
	                 param.put("tmplid", array[2]);
	                 param.put("tmpltp", array[3]);
	                 param.put("stacid", array[4]);
	                 commonDao.deleteByNamedSql(MYBATIS_NS+"deletePmap", param);
	            }
	            commonDao.commitTransaction();
			  	ResultUtils.setRspData(req, "200",  "�����ɹ�", "pmap_main", "", "");
			} catch (BimisException e) {
				commonDao.rollBack();
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
				log.logError(e);
		  }
		}	

}
