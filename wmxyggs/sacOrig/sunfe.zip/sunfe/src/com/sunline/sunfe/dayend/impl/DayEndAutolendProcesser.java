package com.sunline.sunfe.dayend.impl;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sunline.jraf.BimisException;
import com.sunline.suncm.util.CollectionUtils;
import com.sunline.suncm.util.Constants;
import com.sunline.suncm.util.Enumeration;
import com.sunline.suncm.util.Enumeration.FUNDTP;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.Sequence;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.suncm.util.StringUtils;
import com.sunline.sunfe.core.bean.FmpItemConfigBean;
import com.sunline.sunfe.core.bean.GlaAeuvBean;
import com.sunline.sunfe.dayend.IDayEndProcesser;
import com.sunline.sunfe.entity.FmbCntr;
import com.sunline.sunfe.entity.FmsInst;
import com.sunline.sunfe.entity.GlaAeuv;
import com.sunline.sunfe.glisfund.GlisfundManage;
import com.sunline.sunfe.glisfund.PublicFmbCntrInfoUtil;
import com.sunline.sunfe.util.ClpConfUtil;
import com.sunline.suncm.util.ComParaUtil;
import com.sunline.sunfe.util.DatetimeUtil;
import com.sunline.sunfe.util.PkgUtil;

public class DayEndAutolendProcesser extends IDayEndProcesser {

	private String MYBATIS_NS_AUTOLEND = "com.sunline.sunfe.mybatis.autolend.";
	private static Log log = LogFactory.getLog(DayEndAutolendProcesser.class);

	private PublicFmbCntrInfoUtil fmbCntrInfoUtil;

	@Override
	public void preProcess() throws BimisException {
		try {
			getCommonDao();
			fmbCntrInfoUtil = new PublicFmbCntrInfoUtil(commonDao);

		} catch (Exception e) {
			throw new BimisException("-1", "�����Զ����Ԥ��������" + e.getMessage());
		}
	}

	@Override
	public void processing() throws BimisException {

		try {
			commonDao.beginTransaction();
			autolend();
			commonDao.commitTransaction();
		} catch (Exception e) {
			e.printStackTrace();
			commonDao.rollBack();
			throw new BimisException("-1", "�����Զ�������" + e.getMessage());
		} finally {
			closeSession();
		}

	}

	/**
	 * @Title: autolend
	 * @Description: �Զ����
	 * @throws Exception
	 * @return: void
	 */

	private void autolend() throws Exception {
		String pi_Pckgdt = getPram();
		String l_Stacid = null;
		String l_User_Brchcd = null;

		String l_Tranus = null;

		if (StringUtils.isNotEmpty(pi_Pckgdt)) {
			l_Stacid = PkgUtil.getPkgstr(pi_Pckgdt, "user_stacid");
			l_User_Brchcd = PkgUtil.getPkgstr(pi_Pckgdt, "user_brchcd");
			l_Tranus = PkgUtil.getPkgstr(pi_Pckgdt, "user_usercd");
		} else {
			l_Stacid = SessionParaUtils.getStacid();
			l_User_Brchcd = SessionParaUtils.getDeptcd();
			l_Tranus = SessionParaUtils.getUsercd();
		}

		int stacid = Integer.valueOf(l_Stacid);

		String l_Systdt = PubUtil.getGlisdt(Integer.valueOf(l_Stacid));

		String l_Prcscd = Constants.glisFundPrcscd;

		String l_Acetna = fmbCntrInfoUtil.prcsnaInfo(stacid, l_Prcscd).get("functx").toString();

		// ��ͬ����Ϊһ��
		String l_Matudt = DatetimeUtil.getSpeldate(l_Systdt, "D", 1);

		HashMap mapQuery = new HashMap();
		String[] arrFundtp = { Enumeration.FUNDTP.CFBFJ.value };
		mapQuery.put("fundtp", arrFundtp);
		mapQuery.put("stacid", stacid);

		// ��ѯ�������Ŀ
		List<Map<String, String>> lstFdcl = commonDao.getSqlSession().selectList("com.sunline.sunfe.mybatis.fmpitemconfig.queryFmpItemConfig",
				mapQuery);

		for (Map<String, String> mapFdcl : lstFdcl) {

			mapQuery.clear();
			mapQuery.put("blncdn", Constants.AMNTCD_DEBIT);

			mapQuery.put("itemcd", mapFdcl.get("itemcd"));

			List<Map<String, Object>> lstBrch = commonDao.getSqlSession().selectList(MYBATIS_NS_AUTOLEND + "queryAutolendBrch", mapQuery);

			// �����㼶
			String aebslv = mapFdcl.get("aebslv");

			if (CollectionUtils.isNotEmpty(lstBrch)) {

				for (Map<String, Object> mapBrch : lstBrch) {

					String brchno = mapBrch.get("brchno").toString();
					String crcycd = mapBrch.get("crcycd").toString();

					// ����������������ͼ�׻�ȡ
					String upprbr = ClpConfUtil.getClerBrch(stacid, brchno,crcycd);
				

					if (StringUtils.isEmpty(mapBrch.get("tranam").toString())) {
						throw new BimisException("99", MessageFormat.format("��ѯ����[{0}]�ı������Ŀͷ��Ϊ��", brchno));
					}

					BigDecimal tranam = new BigDecimal(mapBrch.get("tranam").toString());

					tranam = tranam.abs();

				

					if ("1231".equals(l_Systdt.substring(4))) {
						log.info("���ǿ��");
						// ��Ŷ��ڿ�Ŀ
						String itemcd_Sd = FmpItemConfigBean.getFmpItemConfigByPrimaryKey(stacid, aebslv, FUNDTP.CFDQ.value);
						mapQuery.clear();
						mapQuery.put("itemcd", itemcd_Sd);
						mapQuery.put("crcycd", crcycd);
						mapQuery.put("brchno", brchno);
						BigDecimal onlnbl_Sd = commonDao.getSqlSession().selectOne(MYBATIS_NS_AUTOLEND + "querySdOnlnbl", mapQuery);

						if (onlnbl_Sd.compareTo(tranam) >= 0) {
							/*
							 * ����Ƿ����δ�����ϴ��ͬ δ�����ϴ��ͬ����ܶ���ͷ����֧ȡ��ֱ��ǿ��
							 * ��ǰ֧ȡ����ҹ����A01��Ϣ���Ǽǽ�Ϣ�ǼǱ� ���º�ͬ�����Ϊ0�رպ�ͬ
							 */

							mapQuery.clear();

							mapQuery.put("cntrtp", "1");
							mapQuery.put("matudt", l_Systdt);
							mapQuery.put("transt", "2");
							mapQuery.put("crcycd", crcycd);
							mapQuery.put("brchno", brchno);
							mapQuery.put("stacid", stacid);

							Map<String, Object> mapFmbCntrbl = commonDao.getSqlSession().selectOne(
									"com.sunline.sunfe.mybatis.fmbcntr.queryFmb_CntrSumfamNotDue", mapQuery);

							String fmbcntrcount = mapFmbCntrbl.get("fmbcntrcount").toString();

							Object sumfam = mapFmbCntrbl.get("sumfam");
							if (Integer.valueOf(fmbcntrcount) > 0 && new BigDecimal(sumfam.toString()).compareTo(tranam) >= 0) {

								List<FmbCntr> lstFmbCntr = commonDao.getSqlSession().selectList(
										"com.sunline.sunfe.mybatis.fmbcntr.queryFmb_CntrNotDue", mapQuery);

								BigDecimal tempam = BigDecimal.ZERO;

								for (FmbCntr fmbCntr : lstFmbCntr) {

									if (tempam.compareTo(tranam) >= 0) {
										break;
									}

									// �黹���
									BigDecimal drrtam = BigDecimal.ZERO;
									if (fmbCntr.getCntrbl().compareTo(tranam.subtract(tempam)) > 0) {
										drrtam = tranam.subtract(tempam);
									} else {
										drrtam = fmbCntr.getCntrbl();

									}

									// ��ʼ֧ȡ����

									// ��ǰ֧ȡȫ������ҹ���ʼ�Ϣ
									BigDecimal l_Instrt_Dr = GlisfundManage.getCurrentInrt(stacid, "A01", "101", "*", fmbCntr.getCrcycd(), l_Systdt);

									// ��Ϣ
									BigDecimal l_Instam = GlisfundManage.calInterest(fmbCntr.getBgindt(), l_Systdt, l_Instrt_Dr, drrtam);

									int diffDays = DatetimeUtil.datediff("day", fmbCntr.getBgindt(), l_Systdt);

									// ����
									BigDecimal l_Acmlbl = drrtam.multiply(new BigDecimal(diffDays));

									// 1.�Ǽ����˽�����Ϣ

									// ȡҵ����ˮ
									Sequence sequence = SequenceUtils.createSequence(l_Stacid, l_Systdt, "bsnssq", fmbCntr.getUpprbr(), l_Tranus, 1);

									String bsnssq = sequence.getSqueno();

									GlaAeuv glaAeuv = new GlaAeuv();

									glaAeuv.setStacid(stacid);
									glaAeuv.setSourst("90");
									glaAeuv.setSourdt(l_Systdt);
									glaAeuv.setSoursq(bsnssq);
									glaAeuv.setTranbr(fmbCntr.getUpprbr()); // �ϼ�����Ϊ���׻���
									glaAeuv.setAcetna(l_Acetna);
									glaAeuv.setUsercd(l_Tranus);
									glaAeuv.setPrcscd(l_Prcscd);
									glaAeuv.setTrantp("2"); // ϵͳ��
									glaAeuv.setTranst("0");
									glaAeuv.setStrkst("0");

									GlaAeuvBean.saveGlaAeuv(commonDao, glaAeuv);

									String l_Transq_In = null;

									// ����
									fmbCntrInfoUtil.fundCmbk(stacid, glaAeuv.getSourst(), glaAeuv.getSourdt(), glaAeuv.getSoursq(), brchno,
											upprbr, "1", "1B", fmbCntr.getCrcycd(), drrtam, l_Instam, BigDecimal.ZERO, fmbCntr.getCntrno());

									// �Ǽ�֧ȡ�黹�ǼǱ�
									HashMap mapDrrt = new HashMap();
									mapDrrt.put("cntrno", fmbCntr.getCntrno());// ��ͬ��
									mapDrrt.put("datatp", "3");// �����Զ�����
									mapDrrt.put("brchno", fmbCntr.getBrchno());// �������
									mapDrrt.put("upprbr", fmbCntr.getUpprbr());// ��������(�ϼ�����)
									mapDrrt.put("userid", l_Tranus);// �����Ա
									mapDrrt.put("aplydt", l_Systdt);// �������
									mapDrrt.put("aplysq", "999999");// �Զ�֧ȡ������ˮΪ6��9
									mapDrrt.put("applam", drrtam);// ������
									mapDrrt.put("transt", "2");// ֱ�ӵǼ�Ϊ����״̬
									mapDrrt.put("acptdt", l_Systdt);// ��������
									mapDrrt.put("acptsq", l_Transq_In);// ������ˮ
									mapDrrt.put("remark", "��ͷǿ��");// ժҪ
									String l_Drrtno = fmbCntrInfoUtil.insertDoubleFmBDrrt(mapDrrt);

									// �Ǽ��ڲ��ʽ���Ϣ�ǼǱ�
									FmsInst fmsInst = new FmsInst();
									fmsInst.setTransq(l_Transq_In);
									fmsInst.setInsttp(fmbCntr.getCntrtp());
									fmsInst.setBrchno(fmbCntr.getBrchno());
									fmsInst.setCntrno(fmbCntr.getCntrno());
									fmsInst.setDrrtno(l_Drrtno);
									fmsInst.setCrcycd(fmbCntr.getCrcycd());
									fmsInst.setInrttp(fmbCntr.getCntrcl());
									fmsInst.setTermcd(fmbCntr.getTermcd());
									fmsInst.setBgindt(fmbCntr.getBgindt());
									fmsInst.setAcmlbl(l_Acmlbl);
									fmsInst.setInrtrt(l_Instrt_Dr);
									fmsInst.setInstam(l_Instam);
									GlisfundManage.registerAcpt(commonDao, l_Systdt, fmsInst);

									// ���º�ͬ��Ϣ
									mapQuery.clear();
									mapQuery.put("drrtam", drrtam);
									mapQuery.put("bgindt", l_Systdt);
									mapQuery.put("cntrno", fmbCntr.getCntrno());
									mapQuery.put("stacid", stacid);

									commonDao.updateByNamedSql("com.sunline.sunfe.mybatis.fmbcntr.updateFmbCntrAfterAppl", mapQuery);

									// �ۼƺ�ͬ���
									tempam = tempam.add(fmbCntr.getCntrbl());

								}

							}

						}

					}

					// ������գ�������ͷǿ��
					// �ȼ���(�½�)
					Sequence sequence = SequenceUtils.createSequence(l_Stacid, l_Systdt, "bsnssq", brchno, l_Tranus, 1);

					String l_Soursq = sequence.getSqueno();

					// -�Ǽ�gla_aeuv
					GlaAeuv glaAeuv = new GlaAeuv();

					glaAeuv.setStacid(stacid);
					glaAeuv.setSourst("90");
					glaAeuv.setSourdt(l_Systdt);
					glaAeuv.setSoursq(l_Soursq);
					glaAeuv.setTranbr(upprbr); // �ϼ�����Ϊ���׻���
					glaAeuv.setAcetna(l_Acetna);
					glaAeuv.setUsercd(l_Tranus);
					glaAeuv.setPrcscd(l_Prcscd);
					glaAeuv.setTrantp("1"); // �ֹ���
					glaAeuv.setTranst("0");
					glaAeuv.setStrkst("0");

					GlaAeuvBean.saveGlaAeuv(commonDao, glaAeuv);

					// ��ͷ���С�ڲ���ͬ��ͽ��ʱ������ͬ���Ϊ��ͽ��
					if (StringUtils.isEmpty(ComParaUtil.getParavl(l_Stacid, "fd_limitam"))) {
						throw new BimisException("99", "���ײ�����ͬ��ͽ��[fd_limitam]û������");
					}
					BigDecimal l_Limtam = new BigDecimal(ComParaUtil.getParavl(l_Stacid, "fd_limitam"));

					if (tranam.compareTo(l_Limtam) < 0) {
						tranam = l_Limtam;
					}

					// ����
					String transq = fmbCntrInfoUtil.fundCmbk(stacid, glaAeuv.getSourst(), glaAeuv.getSourdt(), glaAeuv.getSoursq(), brchno,
							upprbr, "2", "2A", crcycd, tranam, BigDecimal.ZERO, BigDecimal.ZERO, null);

					// Ȼ�����½��ͬ(����Ϊһ��)
					// �ǼǺ�ͬ��Ϣ(��ͬΪ����״̬)
					Sequence sequenceAplysq = SequenceUtils.createSequence(l_Stacid, l_Systdt, "aplysq", brchno, l_Tranus, 1);
					// ��ȡǿ������(��Ϣ�½�)
					BigDecimal instrt = GlisfundManage.getCurrentInrt(stacid, "B03", "101", brchno, crcycd, l_Systdt);
					String l_Aplysq = l_Systdt + sequenceAplysq.getSqueno();
					FmbCntr fmbCntr = new FmbCntr();
					fmbCntr.setAplydt(l_Systdt);
					fmbCntr.setAplysq(l_Aplysq);
					fmbCntr.setBrchno(brchno);
					fmbCntr.setUpprbr(upprbr);
					fmbCntr.setUserid(l_Tranus);
					fmbCntr.setCntrtp("2");// �½�
					fmbCntr.setCntrcl("23");// ��Ϣ�½�
					fmbCntr.setCrcycd(crcycd);
					fmbCntr.setTermcd("101");
					fmbCntr.setInstrt(instrt);
					fmbCntr.setCntram(tranam);
					fmbCntr.setCntrbl(tranam);
					fmbCntr.setBgindt(l_Systdt);
					fmbCntr.setMatudt(l_Matudt);
					fmbCntr.setRenwtg("0");
					fmbCntr.setTranst("2");// ����
					fmbCntr.setAcptdt(l_Systdt);
					fmbCntr.setAcptsq(transq);
					fmbCntr.setStacid(stacid);

					GlisfundManage.insertCntr(commonDao, fmbCntr);

				}
			}

		}
	}

	@Override
	public void processed() throws BimisException {
	}

}
