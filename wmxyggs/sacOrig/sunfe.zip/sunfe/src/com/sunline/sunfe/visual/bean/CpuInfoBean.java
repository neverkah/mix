package com.sunline.sunfe.visual.bean;

import java.io.Serializable;

import org.jdom.Element;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.XmlAble;
import com.sunline.jraf.util.XmlUtil;

public class CpuInfoBean implements Serializable,XmlAble{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String cpuNum;//cpu����
	private String mhz;//cpuƵ��(��λG)
	//private String catchSize ;//cpu����
	private String vendor;//cpu����
	private String model;//cpu�ͺ�
	
	

	private String cpuUser;//cpuƽ���û�ʹ���� 
	private String cpuSys;//ϵͳʹ����
	private String cpuWait;//�ȴ���
	private String cpuNice;
	private String cpuIdle;//������
	private String cpuCombined;//�ܵ�ʹ����
	
	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}
	public String getCpuNum() {
		return cpuNum;
	}

	public void setCpuNum(String cpuNum) {
		this.cpuNum = cpuNum;
	}

	public String getMhz() {
		return mhz;
	}

	public void setMhz(String mhz) {
		this.mhz = mhz;
	}


	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getCpuUser() {
		return cpuUser;
	}

	public void setCpuUser(String cpuUser) {
		this.cpuUser = cpuUser;
	}

	public String getCpuSys() {
		return cpuSys;
	}

	public void setCpuSys(String cpuSys) {
		this.cpuSys = cpuSys;
	}

	public String getCpuWait() {
		return cpuWait;
	}

	public void setCpuWait(String cpuWait) {
		this.cpuWait = cpuWait;
	}

	public String getCpuNice() {
		return cpuNice;
	}

	public void setCpuNice(String cpuNice) {
		this.cpuNice = cpuNice;
	}

	public String getCpuIdle() {
		return cpuIdle;
	}

	public void setCpuIdle(String cpuIdle) {
		this.cpuIdle = cpuIdle;
	}

	public String getCpuCombined() {
		return cpuCombined;
	}

	public void setCpuCombined(String cpuCombined) {
		this.cpuCombined = cpuCombined;
	}

	@Override
	public Element toXmlList() throws BimisException {
		
	 return XmlUtil.toXmlList(this);
	}

	@Override
	public Element toXml() throws BimisException {
		return toXmlList();
	}

}
