package com.sunline.sunfe.glisfund;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONArray;
import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.suncm.util.CollectionUtils;
import com.sunline.suncm.util.PcmcKnpParaUtils;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.util.MybatisPathUtil;
import com.sunline.sunfe.util.StringUtils;

/**
 * @author ����
 * @Email xiongl@sunline.cn
 * @Time 2018��1��3��
 * @��������ã��ڲ��ʽ����
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class FmpInrtAjstAction extends Actor {
	private static final Logger logger = LoggerFactory.getLogger(FmpInrtAjstAction.class);

	/**
	 * @throws JDOMException
	 * @�˷��������ã���ѯ�ڲ��ʽ𶨼۵�������Ϣ
	 */
	public void queryFmpInrtAjstInfo() throws JDOMException {
		try {
			Map<String, Object> map = req.getReqDataMap();
			String pageNo = req.getReqDataStr("pageNum");
			if (StringUtils.isNotEmpty(pageNo))
				req.setReqPageNo(Integer.parseInt(pageNo));
			Element e = commonDao.queryByNamedSqlWithPage(MybatisPathUtil.FMP_INRT_AJST + "queryFmpInrtAjstlistPage", req.getReqPageInfo(), map);
			req.addRspData(e.removeContent());
			new PublicFmbCntrInfoUtil(commonDao).addReqInfoTo(map, req);
		} catch (JDOMException | BimisException e) {
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "��ѯʧ��" + e.getMessage());
		}
	}

	/**
	 * @throws JDOMException
	 * @�˷��������ã������ڲ��ʽ𶨼۵�������Ϣ
	 */
	public void addFmpInrtAjst() throws JDOMException {
		try {

			Map mapParam = new HashMap();
			mapParam.put("intrdt", req.getReqDataStr("intrdt"));
			mapParam.put("inrttp", req.getReqDataStr("inrttp"));
			mapParam.put("crcycd", req.getReqDataStr("crcycd"));
			mapParam.put("status", "1");
			mapParam.put("termcd", req.getReqDataStr("termcd"));

			// ͬһ����������һ���ڲ���������
			List<Map> lstFmpInrtAjst = commonDao.getSqlSession().selectList(MybatisPathUtil.FMP_INRT_AJST + "queryFmpInrtAjstlistPage", mapParam);
			String inrttpna = PcmcKnpParaUtils.getPcmcKnpParaDataByParacd("fe", "inrt_inrttp", req.getReqDataStr("inrttp"));
			String termcdna = PcmcKnpParaUtils.getPcmcKnpParaDataByParacd("fe", "inrt_termcd", req.getReqDataStr("termcd"));
			if (CollectionUtils.isNotEmpty(lstFmpInrtAjst)) {

				String message = MessageFormat.format("�����Ѵ����������=[{0}],����=[{1}],����=[{2}]�ĵ�����¼", inrttpna, req.getReqDataStr("crcycd"), termcdna);
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", message);
				return;
			}

			mapParam.clear();
			mapParam.put("inrttp", req.getReqDataStr("inrttp"));
			mapParam.put("termcd", req.getReqDataStr("termcd"));
			mapParam.put("crcycd", req.getReqDataStr("crcycd"));
			// �ж��Ƿ�����ڲ��ʽ𶨼ۼ�¼
			/*
			 * List<Map> lstFmpInrt =
			 * commonDao.getSqlSession().selectList(MybatisPathUtil.FMP_INRT+
			 * "queryFmpInrtlistPage", mapParam);
			 * if(CollectionUtils.isEmpty(lstFmpInrt)){ String message =
			 * MessageFormat.format("�������������=[{0}],����=[{1}],����=[{2}]������",
			 * inrttpna, req.getReqDataStr("crcycd"), termcdna);
			 * req.addRspData("retCode", "300"); req.addRspData("retMessage",
			 * message); return; }
			 */

			Map<String, String> map = req.getReqDataMap();
			new PublicFmbCntrInfoUtil(commonDao).selectSessionComStac(req, map.get("stacid") + "");
			map.put("intrus", SessionParaUtils.getUsercd());
			map.put("intrsq", SequenceUtils.createSequence(map.get("stacid"), map.get("intrdt"), "bsnssq", SessionParaUtils.getDeptcd(), SessionParaUtils.getUsercd(), 1).getSqueno());
			commonDao.insertByNamedSql(MybatisPathUtil.FMP_INRT_AJST + "insertFmpInrtAjst", map);
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "���ӳɹ���");
			req.addRspData("callbackType", "closeCurrent");
		} catch (Exception e) {
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ��" + e.getMessage());
		}
	}

	/**
	 * @throws JDOMException
	 * @�˷��������ã�ɾ���ڲ��ʽ𶨼۱���Ϣ
	 */
	public void deleteFmpInrtAjst() throws JDOMException {
		try {
			Map<String, String> map = req.getReqDataMap();
			if ("2".equals(map.get("status"))) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "�Ѿ���Ч�����ʵ��������ݲ����޸�");
				return;
			}

			Map mapParam = new HashMap();
			mapParam.put("intrsq", req.getReqDataStr("intrsq"));
			mapParam.put("intrdt", req.getReqDataStr("intrdt"));
			mapParam.put("stacid", req.getReqDataStr("stacid"));
			commonDao.deleteByNamedSql(MybatisPathUtil.FMP_INRT_AJST + "deleteFmpInrtAjst", mapParam);
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
		} catch (JDOMException | BimisException e) {
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ��" + e.getMessage());
		}
	}

	/**
	 * @throws JDOMException
	 * @�˷��������ã��޸��ڲ��ʽ𶨼۱���Ϣ
	 */
	public void updateFmpInrtAjst() throws JDOMException {
		try {

			BigDecimal inrtrt = new BigDecimal(req.getReqDataStr("inrtrt"));
			if (inrtrt.compareTo(BigDecimal.ZERO) <= 0) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "���ʱ������0");
				return;
			}

			Map<String, String> map = req.getReqDataMap();
			if ("2".equals(map.get("status"))) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "�Ѿ���Ч�����ʵ��������ݲ����޸�");
				return;
			}
			new PublicFmbCntrInfoUtil(commonDao).selectSessionComStac(req, map.get("stacid") + "");
			map.put("intrus", SessionParaUtils.getUsercd());
			commonDao.updateByNamedSql(MybatisPathUtil.FMP_INRT_AJST + "updateFmpInrtAjst", map);
			new PublicFmbCntrInfoUtil(commonDao).selectSessionComStac(req, map.get("stacid"));
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�޸ĳɹ���");
		} catch (JDOMException | BimisException e) {
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "�޸�ʧ��" + e.getMessage());
		}
	}

	public void getTableFileldInfo() throws JDOMException {
		try {
			String tableValue = req.getReqDataStr("tableValue");
			String[] infos = tableValue.split("==");
			Map<String, String> map = new HashMap<String, String>();
			map.put("sqlInfo", "SELECT " + infos[3] + " AS nameFiled FROM " + infos[1] + " WHERE " + infos[2] + "='" + infos[0] + "'");
			Element e = commonDao.queryByNamedSql(MybatisPathUtil.FMP_INRT_AJST + "queryTableFieldInfo", map);
			req.addRspData(e.removeContent());
		} catch (JDOMException | BimisException e) {
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "�޸�ʧ��" + e.getMessage());
		}
	}

	/**
	 * @throws JDOMException
	 * @�˷��������ã�ɾ���ڲ��ʽ𶨼۱���Ϣ
	 */
	public void deleteFmpInrtAjstBatch() throws JDOMException {
		try {
			List<String> infos = req.getReqDataTexts("fmpBox");
			String[] params = null;
			commonDao.beginTransaction();
			for (int i = 0, len = infos.size(); i < len; i++) {
				params = infos.get(i).split("-");
				if ("2".equals(params[3]))
					throw new BimisException("301", "����Ϊ��" + params[0] + "��¼������Ϊ��" + params[1] + "��¼����ˮΪ��" + params[2] + "����������Ч������ɾ��");
				Map<String, String> map = new HashMap<String, String>();
				map.put("stacid", params[0]);
				map.put("intrdt", params[1]);
				map.put("intrsq", params[2]);
				commonDao.deleteByNamedSql(MybatisPathUtil.FMP_INRT_AJST + "deleteFmpInrtAjst", map);
				map.clear();
			}
			commonDao.commitTransaction();
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "ɾ���ɹ���");
		} catch (JDOMException | BimisException e) {
			commonDao.rollBack();
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "ɾ��ʧ��" + e.getMessage());
		}
	}

	/**
	 * @throws JDOMException
	 * @�˷��������ã���ѯ����
	 */
	public void selectComStac() throws JDOMException {
		try {
			List<Map<String, Object>> list = (List<Map<String, Object>>) commonDao.queryByNamedSqlForList(MybatisPathUtil.COM_STAC + "queryComStacAllInfo", null);
			req.addRspData("DataRecords", JSONArray.toJSONString(list).toString());
		} catch (BimisException e) {
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "��ѯʧ��" + e.getMessage());
		}
	}
}
