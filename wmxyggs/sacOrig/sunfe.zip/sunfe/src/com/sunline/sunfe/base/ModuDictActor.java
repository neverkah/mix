package com.sunline.sunfe.base;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.util.DatetimeUtil;

public class ModuDictActor extends Actor {
	// ����sql�������ռ�
	private static final String MODUDICT = "com.sunline.sunfe.mybatis.modudict.";

	Log log = new Log("ModuDictActor");

	/*
	 * ��ҳ��ѯ
	 */

	public void ModuDictList() throws Exception {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		hashMap = req.getReqDataMap();
		Element e = commonDao.queryByNamedSqlWithPage(MODUDICT
				+ "modudictlistPage", req.getReqPageInfo(), hashMap);
		req.addRspData(e.removeContent());
	}

	/*
	 * ��ѯ����
	 */

	public void getModuDictDetl() throws Exception {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		hashMap = req.getReqDataMap();
		String module= req.getReqDataStr("module");
		if(module==null||"".equals(module)){
			hashMap.put("module", "1");
		}
		Element e = commonDao.queryByNamedSqlWithPage(MODUDICT
				+ "getModuDictDetllistPage",req.getReqPageInfo(), hashMap);
		req.addRspData(e.removeContent());
	}
	
	public void getModuDetl() throws Exception {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		hashMap = req.getReqDataMap();
		String module= req.getReqDataStr("module");
		if(module==null||"".equals(module)){
			hashMap.put("module", "1");
		}
		Element e = commonDao.queryByNamedSql(MODUDICT
				+ "getModuDictDetl", hashMap);
		req.addRspData(e.removeContent());
	}
	
	
	public void getModuDict() throws Exception {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		hashMap = req.getReqDataMap();
		String module= req.getReqDataStr("module");
		if(module==null||"".equals(module)){
			hashMap.put("module", "1");
		}
		
		Element e = commonDao.queryByNamedSql(MODUDICT
				+ "modudict", hashMap);
		req.addRspData(e.removeContent());
	}
	
	
	/*
	 * ģ���µ�ӳ�䶨����Ϣ
	 */
	public void queryModuDict() throws Exception {
		HashMap<String, String> hashMap = (HashMap<String, String>) req.getReqDataMap();
		//��ѯ������Ϣ
		List e1 = commonDao.queryByNamedSqlForList(MODUDICT
				+ "modudict",hashMap);
		String module = req.getReqDataStr("module");
		if(e1.size()!=0){
			hashMap.put("varicd", null);
			Element el = commonDao.queryByNamedSql(MODUDICT
					+ "modudict",hashMap);
			Element x = el.getChild("Record");
			 module = x.getChildText("module");
			String tablcd = x.getChildText("tablcd");
			String desctx = x.getChildText("desctx");
			String status = x.getChildText("status");
			req.addRspData("module",module);
			req.addRspData("tablcd_top",tablcd);
			req.addRspData("desctx_top",desctx);
			req.addRspData("status_top",status);
		}else{
			req.addRspData("module",module);
			req.addRspData("tablcd_top","");
			req.addRspData("desctx_top","");
			req.addRspData("status_top","");
		}
		if(module!=null&&!"1".equals(module)&&!"".equals(module)){
		hashMap.put("varicd", null);
		//��ѯ�ӱ���Ϣ
		hashMap.put("varitp", "1");
		Element e2 = commonDao.queryByNamedSql(MODUDICT
				+ "getModuDictDetl", hashMap);
		req.addRspData("Results2", e2.removeContent());
		//��ѯ�ӱ���Ϣ
		hashMap.put("varitp", "2");
		Element e3 = commonDao.queryByNamedSql(MODUDICT
				+ "getModuDictDetl", hashMap);
		req.addRspData("Results3", e3.removeContent());
		}
	}

	/*
	 * ����ɾ��
	 */
	@SuppressWarnings("rawtypes")
	public void delModuDict() throws Exception, JDOMException {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		List<?> parampList = req.getReqDataTexts("paramp");
	    List<String> modulist = new ArrayList<String>();
	    commonDao.beginTransaction();
		if ((parampList != null) && (parampList.size() > 0)) {
			for (int i = 0; i < parampList.size(); i++) {
				String varitp = parampList.get(i).toString().split("-")[0].trim();
				hashMap.put("varicd",parampList.get(i).toString().split("-")[1].trim());
				hashMap.put("varitp",parampList.get(i).toString().split("-")[0].trim());
				hashMap.put("module",parampList.get(i).toString().split("-")[2].trim());
				
				modulist.add(hashMap.get("module").toString());
				/*
				 * �ж��Ƿ���ʹ��
				 */
				
				List checkmodu = commonDao.queryByNamedSqlForList(MODUDICT+"checkmodu", hashMap);
				
				if(checkmodu.size()!=0){
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "����ɾ��ʹ���е�ģ�����ݣ�");
					return;
				}
				
				/*
				 * �ж��Ƿ���ͣ��
				 
				hashMap.put("status", "1");
				List checkstatus = commonDao.queryByNamedSqlForList(MODUDICT+"checkstatus", hashMap);
				
				if(checkstatus.size()!=0){
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "����ɾ�������е�ģ�����ݣ�");
					return;
				}*/
				
				
				
				
				int count = commonDao.deleteByNamedSql(MODUDICT + "delModuDictDetl", hashMap);
				if (count == 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "��" + (i + 1) + "����¼ɾ��ʧ��");
					commonDao.rollBack();
					return;
				}
				//}
			}
		} else {
			String varicd = req.getReqDataStr("varicd");
			String module = req.getReqDataStr("module");
			String varitp = req.getReqDataStr("varitp");
			hashMap.put("varicd",varicd);
			hashMap.put("module",module);
			hashMap.put("varitp",varitp);
			
			modulist.add(module);
			
			if(hashMap.size()==0){
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "δѡ�м�¼��");
				return;
			}
			
			/*
			 * �ж��Ƿ���ʹ��
			 */
			
			List checkmodu = commonDao.queryByNamedSqlForList(MODUDICT+"checkmodu", hashMap);
			
			if(checkmodu.size()!=0){
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "����ģ�������Ѿ���ʹ�ã�");
				return;
			}
			
			/*
			 * �ж��Ƿ���ͣ��
			 */
			hashMap.put("status", "1");
			List checkstatus = commonDao.queryByNamedSqlForList(MODUDICT+"checkstatus", hashMap);
			
			if(checkstatus.size()!=0){
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "����ɾ�������е�ģ�����ݣ�");
				return;
			}
			
			
			
			int count = commonDao.deleteByNamedSql(
					MODUDICT + "delModuDictDetl", hashMap);
			if (count == 0) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "ɾ��ʧ��");
				commonDao.rollBack();
				return;
			}
			
		}
		for (Iterator iterator = modulist.iterator(); iterator.hasNext();) {
			String module = (String) iterator.next();
			List count = commonDao.queryByNamedSqlForList(MODUDICT+"getModuDicDetlCount", module);
			if(count.size() == 0){
				commonDao.deleteByNamedSql(MODUDICT+"delModuDictByModule", module);
			}
		}
		commonDao.commitTransaction();
		req.addRspData("retCode", "200");// ��Ӧ����
		req.addRspData("retMessage", "�����ɹ�");// ��Ӧ��Ϣ
		req.addRspData("navTabId", "modudict_list");// ��תҳ�棬Ŀǰ��֧��navTabId����ҳ��
		
		
	}

	/*
	 * ����
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void insertModuDict() throws Exception, JDOMException {
		try {
			String module = req.getReqDataStr("module");
			List<String> index_List = req.getReqDataTexts("tr_index");
			// �ж��Ƿ����ظ���varicd����
			List<String> varicd_List = new ArrayList<String>();
			List<HashMap<String, String>> modudictLsit = new ArrayList<HashMap<String, String>>();
			for (Iterator iterator = index_List.iterator(); iterator.hasNext();) {
				HashMap<String, String> hashMap = new HashMap<String, String>();
					String index = (String) iterator.next();
					hashMap.put("module", module);
					hashMap.put("varicd", req.getReqDataStr("varicd"+index));
					hashMap.put("busina", req.getReqDataStr("busina"+index));
					hashMap.put("ordeid", req.getReqDataStr("ordeid"+index));
					hashMap.put("varitp", req.getReqDataStr("varitp"+index));
					hashMap.put("status", req.getReqDataStr("status"+index));
					hashMap.put("desctx", req.getReqDataStr("desctx"+index));
					varicd_List.add(req.getReqDataStr("varicd"+index));
					modudictLsit.add(hashMap);
			}
			// �ж��Ƿ����ظ���varicd����
			Set set = new HashSet();
			set.addAll(varicd_List);
			if (set.size() != varicd_List.size()) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "����������Ψһ�ģ������������ݣ�");
				return;
			}
			commonDao.beginTransaction();
			//�޸�������ע
		    HashMap<String, String> hashMap = new HashMap<String, String>();
			String desctx_top = req.getReqDataStr("desctx_top");
			String tablcd_top = req.getReqDataStr("tablcd_top");
			hashMap.put("module_desctx", desctx_top);
			hashMap.put("module", module);
			hashMap.put("tablcd", tablcd_top);
			int upd = commonDao.updateByNamedSql(MODUDICT+"updateDesctx", hashMap);
			if(upd==0){
				//û��������Ϣ����������
				commonDao.insertByNamedSql(MODUDICT+"insert", hashMap);
			}
			// ɾ��������
			 commonDao.deleteByNamedSql(MODUDICT + "delModuDictDetl",hashMap);
			// �����µ�����
			 for (Iterator iterator2 = modudictLsit.iterator(); iterator2.hasNext();) {
			     HashMap<String, String>  param = ( HashMap<String, String>) iterator2.next();
			     commonDao.insertByNamedSql(MODUDICT + "insertModuDictDetl",param);
			}
			commonDao.commitTransaction();
			req.addRspData("retCode", "200");// ��Ӧ����
			req.addRspData("retMessage", "�����ɹ�");// ��Ӧ��Ϣ
			req.addRspData("callbackType", "closeCurrent");// �ص���������,"closeCurrent"��ʾ�رյ�ǰҳ��
			req.addRspData("navTabId", "modudict_list");// ��תҳ�棬Ŀǰ��֧��navTabId����ҳ��
		} catch (Exception e) {
			commonDao.rollBack();
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ�ܣ�");
			log.logError(e);
		}
	}
	
	/*
	 * �޸�
	 */
	public void UpdateModuDict() throws Exception, JDOMException {
		HashMap<String, String> hashMap = (HashMap<String, String>) req.getReqDataMap();
		String status = req.getReqDataStr("status");
		/*
		 * �ж��Ƿ���ʹ��
		 */
		if("0".equals(status)){
		List checkmodu = commonDao.queryByNamedSqlForList(MODUDICT+"checkmodu", hashMap);
		
		if(checkmodu.size()!=0){
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ģ�������Ѿ���ʹ��,����ͣ�ã�");
			return;
		}
		}
		
		int count = commonDao.updateByNamedSql(MODUDICT + "updateModuDictDetl",hashMap);
		if(count==0){
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ�ܣ�");
		}
		req.addRspData("retCode", "200");
		req.addRspData("retMessage", "�����ɹ���");
		req.addRspData("callbackType", "closeCurrent");// �ص���������,"closeCurrent"��ʾ�رյ�ǰҳ��
		req.addRspData("navTabId", "modudict_list");// ��תҳ�棬Ŀǰ��֧��navTabId����ҳ��
	}
	
	
	/*
	 * 
	 * ����ͣ��
	 */
	public void updateStatus() throws Exception, JDOMException {
		HashMap<String, String> hashMap = (HashMap<String, String>) req.getReqDataMap();
		String status = req.getReqDataStr("status");
		String checkid = req.getReqDataStr("checkid");
		
		if ("0".equals(checkid)) {
			/*
			 * �ж��Ƿ���ʹ��
			 */
			if ("0".equals(status)) {
				List checkmodu = commonDao.queryByNamedSqlForList(MODUDICT
						+ "checkmodu", hashMap);

				if (checkmodu.size() != 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "����ģ�������Ѿ���ʹ��,����ͣ�ã�");
					return;
				}

			}
			
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ���");			
			
		} else {

			/*
			 * �ж��Ƿ���ʹ��
			 */
			if ("0".equals(status)) {
				List checkmodu = commonDao.queryByNamedSqlForList(MODUDICT
						+ "checkmodu", hashMap);

				if (checkmodu.size() != 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "����ģ�������Ѿ���ʹ��,����ͣ�ã�");
					return;
				}

			}

			int count = commonDao.updateByNamedSql(MODUDICT + "updateStatus",
					hashMap);
			if (count == 0) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "����ʧ�ܣ�");
			}
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ���");
			// req.addRspData("callbackType", "closeCurrent");//
			// �ص���������,"closeCurrent"��ʾ�رյ�ǰҳ��
			req.addRspData("navTabId", "modudict_list");// ��תҳ�棬Ŀǰ��֧��navTabId����ҳ��
		}
	}
	
	
	/*
	 * �ж��Ƿ��Ѿ�ʹ��
	 */

	public void checkUse() throws Exception {
		Map<String, Object> hashMap = new HashMap<String, Object>();
		String module = req.getReqDataStr("module");
		String varicdDate = req.getReqDataStr("varicd");
		//List<?> varicdList = this.req.getReqDataTexts("varicd");
		String[] varicdList = varicdDate.split("-");
		
		for (int i = 0; i < varicdList.length; ++i) {
			hashMap.put("module", module);
			hashMap.put("varicd", varicdList[i].trim());
			List checkmodu = commonDao.queryByNamedSqlForList(MODUDICT+"checkmodu", hashMap);
			
			if(checkmodu.size()!=0){
				req.addRspData("retCode", "300");
				req.addRspData("retMessage","��������Ϊ��"+varicdList[i].trim()+"   �������� ʹ�ã�����ɾ����");
				return;
			}
		}
		
		req.addRspData("retCode", "200");
	}
	
	/**
	 * ��ѯloan_busi�������ֶ�
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void getLoanBusiCol() throws JDOMException{
		try {
			Map<String, Object> hashMap = req.getReqDataMap();
			hashMap.put("varicd", hashMap.get("varicd").toString().toUpperCase());
			Element e = commonDao.queryByNamedSqlWithPage(MODUDICT
									+ "getLoanBusiCollistPage", req.getReqPageInfo(), hashMap);
			req.addRspData(e.removeContent());
		} catch (Exception e) {
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ�ܣ�");
			log.logError(e);
		}
	}
}
