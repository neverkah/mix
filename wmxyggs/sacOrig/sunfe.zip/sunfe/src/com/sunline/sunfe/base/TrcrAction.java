package com.sunline.sunfe.base;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
public class TrcrAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.trcr.";
	Log  log = new Log(TrcrAction.class);
 /**
  * ��ѯ������Ͷ�Ӧ�������б�	
  */
 @SuppressWarnings("unchecked")
public void getTrcrListPage(){
	try {
		HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();;
		Element ement =commonDao.
				queryByNamedSqlWithPage(MYBATIS_NS+"getTrcrlistPage",req.getReqPageInfo(), hashmap);
		req.addRspData(ement.removeContent());
	} catch (JDOMException e) {
		log.logError(e);
	}
  }	
 
  /**
   * ��ѯ������Ͷ�Ӧ����
   */
  @SuppressWarnings("unchecked")
public void getTrcrInfo(){
	 try {
		 HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
		 Element ement =commonDao.
				 queryByNamedSql(MYBATIS_NS+"getTrcrInfo", hashmap);
		 req.addRspData(ement.removeContent());
	 } catch (Exception e) {
		 log.logError(e);
	 }
 }	
	
/**
 * ����������Ͷ�Ӧ
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public void addTrcr(){
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			List countList = commonDao.
					queryByNamedSqlForList(MYBATIS_NS+"checkExistTrcr", hashmap);
			if(countList.size()>0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "������Ͷ�Ӧ�Ѵ��ڣ�");
					return;
			}
			    commonDao.insertByNamedSql(MYBATIS_NS+"addTrcr",hashmap);
			    ResultUtils.setRspData(req, "200", "�����ɹ�", "trcr_main","closeCurrent");
				commonDao.commitTransaction();
			} catch (Exception e) {
			    ResultUtils.setRspData(req, "300", "����ʧ��", "","");
				commonDao.rollBack();
				log.logError(e);
		  }
      }	
  /**
   * ����������Ͷ�Ӧ
   * @throws JDOMException 
   */
  @SuppressWarnings("unchecked")
public void updateTrcr() throws JDOMException{
	  try {
		  HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
		    commonDao.updateByNamedSql(MYBATIS_NS+"updateTrcr", hashmap);
		    ResultUtils.setRspData(req, "200", "�����ɹ�", "trcr_main","closeCurrent","","");
		} catch (BimisException e) {
			commonDao.rollBack();
			log.logError(e);
			ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "trcr_main","","");
		}
    }	
    
    /**
     * ɾ��������Ͷ�Ӧ
     * @throws JDOMException 
     */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void deleteTrcr() throws JDOMException{
		try {
			List<String> parampList = req.getReqDataTexts("params");
			HashMap<String,String> hashmap = new HashMap<String, String>();
			commonDao.beginTransaction();
			//��ѡɾ��
			if (parampList != null && parampList.size() > 0) {
				for (Iterator iterator = parampList.iterator(); iterator.hasNext();) {
					String string = (String) iterator.next();
					hashmap.put("stacid", string.split("-")[0].trim());
					hashmap.put("sourst", string.split("-")[1].trim());
					hashmap.put("lstrpr", string.split("-")[2].trim());
					hashmap.put("module", string.split("-")[3].trim());
					commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTrcr", hashmap);
				}
			}else{
			//����ɾ��
				hashmap = (HashMap<String, String>) req.getReqDataMap();
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTrcr", hashmap);
			}
			commonDao.commitTransaction();
		    ResultUtils.setRspData(req, "200", "�����ɹ�", "trcr_main","","");
		} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "trcr_main","","");
			log.logError(e);
		}
	}
}
