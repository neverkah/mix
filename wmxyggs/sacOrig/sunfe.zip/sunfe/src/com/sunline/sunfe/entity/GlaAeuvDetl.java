package com.sunline.sunfe.entity;

import java.math.BigDecimal;
import com.sunline.suncm.util.Constants;

/**
 * 
 * @ClassName: GlaAeuvDetl
 * @Description: ��Ʒ�¼��ϸjavabean ��Ӧ���ݿ����gla_aeuv_detl
 * @author: zhangdq
 * @date: 2017-2-20 ����2:01:26
 */
public class GlaAeuvDetl implements Cloneable {
	private int stacid;// ���ױ��
	private String sourst;// Դϵͳ��ʶ
	private String sourdt;// Դϵͳ����
	private String soursq;// Դϵͳ��ˮ
	private int dispsq;// ���
	private String acctbr;// �������
	private String itemcd;// ��Ŀ����
	private String amntcd;// �������
	private BigDecimal tranam;// ���׽��
	private int trannm;// ���ױ���
	private String smrytx;// ժҪ
	private String centcd=Constants.DEFAULT_VALUE_START;// ��������
	private String prsncd=Constants.DEFAULT_VALUE_START;// ְԱ
	private String custcd=Constants.DEFAULT_VALUE_START;// �ͻ�
	private String prducd=Constants.DEFAULT_VALUE_START;// ��Ʒ
	private String prlncd=Constants.DEFAULT_VALUE_START;// ��Ʒ��
	private String acctno=Constants.DEFAULT_VALUE_START;// ��ά�˻�
	private String assis0=Constants.DEFAULT_VALUE_START;// ��������0���������㣩
	private String assis1=Constants.DEFAULT_VALUE_START;// ��������1����Ա���㣩
	private String assis2=Constants.DEFAULT_VALUE_START;// ��������2���������㣩
	private String assis3=Constants.DEFAULT_VALUE_START;// ��������3����Ʒ���㣩
	private String assis4=Constants.DEFAULT_VALUE_START;// ��������4���������ģ�
	private String assis5=Constants.DEFAULT_VALUE_START;// ��������5����Ŀ���㣩
	private String assis6=Constants.DEFAULT_VALUE_START;// ��������6���Զ��壩
	private String assis7=Constants.DEFAULT_VALUE_START;// ��������7���Զ��壩
	private String assis8=Constants.DEFAULT_VALUE_START;// ��������8���Զ��壩
	private String assis9=Constants.DEFAULT_VALUE_START;// ��������9���Զ��壩
	private int cnvtmd;// "���㷽ʽ(1  ���ڻ��� 2  ʵ�ʼ۸�)"
	private BigDecimal cvtrmb;// ������ҽ��
	private BigDecimal cvtusd;// ����Ԫ���
	private String crcycd;// ����
	private String acctcd;// �˻���Ψһ��ʶ
	

	public String getAcctcd() {
		return acctcd;
	}

	public void setAcctcd(String acctcd) {
		this.acctcd = acctcd;
	}

	public int getStacid() {
		return stacid;
	}

	public void setStacid(int stacid) {
		this.stacid = stacid;
	}

	public String getSourst() {
		return sourst;
	}

	public void setSourst(String sourst) {
		this.sourst = sourst;
	}

	public String getSourdt() {
		return sourdt;
	}

	public void setSourdt(String sourdt) {
		this.sourdt = sourdt;
	}

	public String getSoursq() {
		return soursq;
	}

	public void setSoursq(String soursq) {
		this.soursq = soursq;
	}

	public int getDispsq() {
		return dispsq;
	}

	public void setDispsq(int dispsq) {
		this.dispsq = dispsq;
	}

	public String getAcctbr() {
		return acctbr;
	}

	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}

	public String getItemcd() {
		return itemcd;
	}

	public void setItemcd(String itemcd) {
		this.itemcd = itemcd;
	}

	public String getAmntcd() {
		return amntcd;
	}

	public void setAmntcd(String amntcd) {
		this.amntcd = amntcd;
	}

	public BigDecimal getTranam() {
		return tranam;
	}

	public void setTranam(BigDecimal tranam) {
		this.tranam = tranam;
	}

	public int getTrannm() {
		return trannm;
	}

	public void setTrannm(int trannm) {
		this.trannm = trannm;
	}

	public String getSmrytx() {
		return smrytx;
	}

	public void setSmrytx(String smrytx) {
		this.smrytx = smrytx;
	}

	public String getCentcd() {
		return centcd;
	}

	public void setCentcd(String centcd) {
		this.centcd = centcd;
	}

	public String getPrsncd() {
		return prsncd;
	}

	public void setPrsncd(String prsncd) {
		this.prsncd = prsncd;
	}

	public String getCustcd() {
		return custcd;
	}

	public void setCustcd(String custcd) {
		this.custcd = custcd;
	}

	public String getPrducd() {
		return prducd;
	}

	public void setPrducd(String prducd) {
		this.prducd = prducd;
	}

	public String getPrlncd() {
		return prlncd;
	}

	public void setPrlncd(String prlncd) {
		this.prlncd = prlncd;
	}

	public String getAcctno() {
		return acctno;
	}

	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}

	public String getAssis0() {
		return assis0;
	}

	public void setAssis0(String assis0) {
		this.assis0 = assis0;
	}

	public String getAssis1() {
		return assis1;
	}

	public void setAssis1(String assis1) {
		this.assis1 = assis1;
	}

	public String getAssis2() {
		return assis2;
	}

	public void setAssis2(String assis2) {
		this.assis2 = assis2;
	}

	public String getAssis3() {
		return assis3;
	}

	public void setAssis3(String assis3) {
		this.assis3 = assis3;
	}

	public String getAssis4() {
		return assis4;
	}

	public void setAssis4(String assis4) {
		this.assis4 = assis4;
	}

	public String getAssis5() {
		return assis5;
	}

	public void setAssis5(String assis5) {
		this.assis5 = assis5;
	}

	public String getAssis6() {
		return assis6;
	}

	public void setAssis6(String assis6) {
		this.assis6 = assis6;
	}

	public String getAssis7() {
		return assis7;
	}

	public void setAssis7(String assis7) {
		this.assis7 = assis7;
	}

	public String getAssis8() {
		return assis8;
	}

	public void setAssis8(String assis8) {
		this.assis8 = assis8;
	}

	public String getAssis9() {
		return assis9;
	}

	public void setAssis9(String assis9) {
		this.assis9 = assis9;
	}

	public int getCnvtmd() {
		return cnvtmd;
	}

	public void setCnvtmd(int cnvtmd) {
		this.cnvtmd = cnvtmd;
	}

	public BigDecimal getCvtrmb() {
		return cvtrmb;
	}

	public void setCvtrmb(BigDecimal cvtrmb) {
		this.cvtrmb = cvtrmb;
	}

	public BigDecimal getCvtusd() {
		return cvtusd;
	}

	public void setCvtusd(BigDecimal cvtusd) {
		this.cvtusd = cvtusd;
	}

	public String getCrcycd() {
		return crcycd;
	}

	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	@Override
	public String toString() {
		return "GlaAeuvDetl [stacid=" + stacid + ", sourst=" + sourst
				+ ", sourdt=" + sourdt + ", soursq=" + soursq + ", dispsq="
				+ dispsq + ", acctbr=" + acctbr + ", itemcd=" + itemcd
				+ ", amntcd=" + amntcd + ", tranam=" + tranam + ", trannm="
				+ trannm + ", smrytx=" + smrytx + ", centcd=" + centcd
				+ ", prsncd=" + prsncd + ", custcd=" + custcd + ", prducd="
				+ prducd + ", prlncd=" + prlncd + ", acctno=" + acctno
				+ ", assis0=" + assis0 + ", assis1=" + assis1 + ", assis2="
				+ assis2 + ", assis3=" + assis3 + ", assis4=" + assis4
				+ ", assis5=" + assis5 + ", assis6=" + assis6 + ", assis7="
				+ assis7 + ", assis8=" + assis8 + ", assis9=" + assis9
				+ ", cnvtmd=" + cnvtmd + ", cvtrmb=" + cvtrmb + ", cvtusd="
				+ cvtusd + ", crcycd=" + crcycd + ", acctcd=" + acctcd+"]";
	}
	
	
}


