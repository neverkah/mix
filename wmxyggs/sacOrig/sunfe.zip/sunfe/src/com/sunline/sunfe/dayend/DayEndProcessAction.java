package com.sunline.sunfe.dayend;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.security.UserAuthenticator;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.JsonUtil;
import com.sunline.sunfe.engine.FundClearDeal;
import com.sunline.suncm.util.CollectionUtils;
import com.sunline.suncm.util.PcmcKnpParaUtils;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.sunfe.util.Sequence;
import com.sunline.sunfe.util.SequenceUtils;
import com.sunline.suncm.util.SessionParaUtils;

/**
 * ���մ���action
 * 
 * @author zhangdq
 * 
 */
public class DayEndProcessAction extends Actor {
	public static final String NON_USE = "0"; // δʹ��
	public static final String USING = "1"; // ʹ��
	// public static final String EDCTTP = "g1";
	public static final String PROCESS_NO = "0"; // δ����
	public static final String PROCESS_SUCCESS = "1"; // ������
	public static final String PROCESS_FAIL = "2"; // ����ʧ��
	public static boolean isStart = false; // �Ƿ�ʼ����
	private static final String DEFAULT_EDSTEP = "9999"; // ����λ�������ƶ���ʱ��ʶ

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.comedct.";
	private final static String MYBATIS_NS_DAYENDLG = "com.sunline.sunfe.mybatis.comdayendlg.";
	private final static String MYBATIS_NS_DAYENDCHECK = "com.sunline.sunfe.mybatis.beforedayendcheck.";

	/**
	 * ��ѯ��ǰ���׵�����״̬
	 * 
	 * @throws JDOMException
	 */
	public void querystacst() throws JDOMException {
		try {
			String stacid = SessionParaUtils.getStacid();
			HashMap<String, String> hashp = new HashMap<String, String>();
			hashp.put("stacid", stacid);
			Element element = commonDao.queryByNamedSql(MYBATIS_NS + "querystacst", hashp);
			req.addRspData(element.removeContent());
		} catch (BimisException e) {
			e.printStackTrace();
		}
	}

	/**
	 * ҳ���ѯ�����Ĳ���
	 */
	public void queryProcessStep() {
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String stacid = SessionParaUtils.getStacid();
			String edcttp = req.getReqDataStr("edcttp");
			String proctg = req.getReqDataStr("proctg");
			String myRefreshs = req.getReqDataStr("myRefreshTime");
			if (myRefreshs == null || "".equals(myRefreshs)) {
				myRefreshs = "-1";
			}

			hashmap.put("stacid", stacid);
			hashmap.put("edcttp", edcttp);
			hashmap.put("proctg", proctg);
			hashmap.put("status", USING);
			hashmap.put("bsnsdt", PubUtil.getGlisdt(Integer.valueOf(stacid)));

			List<?> dataList = commonDao.queryByNamedSqlForList(MYBATIS_NS + "qryComEdctByStacid", hashmap);
			Element e = commonDao.createDataObjectElement(dataList);

			req.addRspData(e.removeContent()); // ���ؽ����װ
			req.addRspData("myRefreshs", myRefreshs);
			req.addRspData("proctg", proctg);
			req.addRspData("isStart", String.valueOf(isStart));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * ��ѯ״̬
	 */
	@SuppressWarnings("unchecked")
	public void queryProcessStepStatus() {
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String stacid = SessionParaUtils.getStacid();
			String edcttp = req.getReqDataStr("edcttp");
			String proctg = req.getReqDataStr("proctg");

			hashmap.put("stacid", stacid);
			hashmap.put("edcttp", edcttp);
			hashmap.put("proctg", proctg);
			hashmap.put("status", USING);

			Element element = commonDao.queryByNamedSql(MYBATIS_NS + "queryComEdctPage", hashmap);
			List<Element> dataList = element.removeContent();

			StringBuffer strb = new StringBuffer();

			for (Element e : dataList) {
				String status = e.getChildTextTrim("proctg");// ִ��״̬
				String val = getStatusStr(status);

				strb.append("{ ");
				strb.append("\"proctg\": \"" + val + "\"");
				strb.append("},");
			}
			req.addRspData("allStepInfo", strb.toString().substring(0, strb.toString().lastIndexOf(",")));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void queryProcessStepStatusDialog() throws Exception {
		List lstResult = new ArrayList();
		HashMap hashMap = (HashMap) req.getReqDataMap();
		hashMap.put("bsnsdt", PubUtil.getGlisdt(Integer.valueOf(SessionParaUtils.getStacid())));
		hashMap.put("stacid", SessionParaUtils.getStacid());
		HashMap hashMapResult = new HashMap();
		hashMapResult = commonDao.getSqlSession().selectOne(MYBATIS_NS_DAYENDLG + "qryComStacByStacid", hashMap);
		String stacstKey = hashMapResult.get("stacst").toString();

		// ����״̬(20������״̬��99���������գ�28�����մ���)
		String stacstValue = "";
		if ("20".equals(stacstKey)) {
			stacstValue = "����״̬";
		} else if ("99".equals(stacstKey)) {
			stacstValue = "��������";
		} else if ("28".equals(stacstKey)) {
			stacstValue = "���մ���";
		}
		hashMapResult.put("stacst", stacstValue);
		List<HashMap> lstComDayendlg = (List<HashMap>) commonDao.queryByNamedSqlForList(MYBATIS_NS_DAYENDLG + "qryComErms", hashMap);

		hashMapResult.put("step", lstComDayendlg);
		hashMapResult.put("stacid", SessionParaUtils.getStacid());

		lstResult.add(hashMapResult);
		req.addRspData("allStepInfo", JsonUtil.convertObject2Json(lstResult));

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void queryProcessStepStatusDialog1() {
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String stacid = SessionParaUtils.getStacid();
			String edcttp = req.getReqDataStr("edcttp");
			String proctg = req.getReqDataStr("proctg");

			hashmap.put("stacid", stacid);
			hashmap.put("edcttp", edcttp);
			hashmap.put("proctg", proctg);
			hashmap.put("status", USING);

			Element element = commonDao.queryByNamedSql(MYBATIS_NS + "queryDialogPage1", hashmap);

			List<Element> dataList = element.removeContent();
			List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

			if (!dataList.isEmpty()) {
				Map map1 = new HashMap<String, Object>();

				Element first = dataList.get(0);
				String bsnsdt = first.getChildTextTrim("bsnsdt");
				String stacst = first.getChildTextTrim("stacst");

				if ("20".equals(stacst)) {
					stacst = "δִ��";
				} else if ("99".equals(stacst)) {
					stacst = "��������";
				} else if ("28".equals(stacst)) {
					stacst = "���ճ���";
				}
				map1.put("bsnsdt", bsnsdt);
				map1.put("stacst", stacst);

				List<Map<String, Object>> l = new ArrayList<Map<String, Object>>();
				for (Element e : dataList) {
					String status = e.getChildTextTrim("proctg");// ִ��״̬
					String val = getStatusStr(status);

					String remark = e.getChildTextTrim("remark");
					String edstep = e.getChildTextTrim("edstep");

					Map map2 = new HashMap<String, Object>();
					map2.put("proctg", val);
					map2.put("remark", remark);
					map2.put("edstep", edstep);
					l.add(map2);
				}
				map1.put("step", l);
				list.add(map1);

				req.addRspData("allStepInfo", JsonUtil.convertObject2Json(list));
			} else {
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private String getStatusStr(String statusCode) {
		List<Map<String, Object>> lists = PcmcKnpParaUtils.getPcmcKnpParaData("sunvat", "dectstatus");
		String result = "";
		if (CollectionUtils.isNotEmpty(lists)) {
			for (Iterator iterator = lists.iterator(); iterator.hasNext();) {
				Map<String, Object> map = (Map<String, Object>) iterator.next();
				if (map.get("paracd").equals(statusCode)) {
					result = (String) map.get("parana");
					return result;
				}
			}
		}

		return result;
	}

	/**
	 * ��ѯ��������Ŀ
	 */
	public void queryProcessManage() {
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String stacid = SessionParaUtils.getStacid();
			String edcttp = req.getReqDataStr("edcttp");
			String proctg = req.getReqDataStr("proctg");
			String edstep = req.getReqDataStr("edstep");
			String status = req.getReqDataStr("status");

			hashmap.put("stacid", stacid);
			hashmap.put("edcttp", edcttp);
			hashmap.put("edstep", edstep);
			hashmap.put("proctg", proctg);
			hashmap.put("status", status);

			List<?> dataList = commonDao.queryByNamedSqlForList(MYBATIS_NS + "queryComEdct", hashmap);
			Element e = commonDao.createDataObjectElement(dataList);

			req.addRspData(e.removeContent()); // ���ؽ����װ
			req.addRspData("proctg", proctg);
			int num = 1;
			if (dataList != null) {
				num = dataList.size() + 1; // ��������+1
			}
			req.addRspData("num_edstep", num + "");
			req.addRspData("isStart", String.valueOf(isStart));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * �޸�ҳ���ȡ��ǰ�޸�����Ϣ
	 */
	public void queryComEdctStep() {
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String stacid = SessionParaUtils.getStacid();
			String edcttp = req.getReqDataStr("edcttp");
			String proctg = req.getReqDataStr("proctg");
			String edstep = req.getReqDataStr("edstep");

			hashmap.put("stacid", stacid);
			hashmap.put("edcttp", edcttp);
			hashmap.put("edstep", edstep);
			hashmap.put("proctg", proctg);

			List<?> dataList = commonDao.queryByNamedSqlForList(MYBATIS_NS + "queryComEdctStep", hashmap);
			Element e = commonDao.createDataObjectElement(dataList);

			req.addRspData(e.removeContent()); // ���ؽ����װ
			req.addRspData("proctg", proctg);
			req.addRspData("isStart", String.valueOf(isStart));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * ��õ�ǰ�����ղ���
	 * 
	 * @Title: getEdstep
	 * @Description: TODO
	 * @param stacid
	 *            ����
	 * @param edtp
	 *            �������
	 * @return
	 * @return: String
	 * @throws BimisException
	 */
	@SuppressWarnings("unchecked")
	public String getEdstep(String stacid, String edtp) throws BimisException {
		HashMap<String, Object> hs = new HashMap<String, Object>();
		hs.put("stacid", stacid);
		hs.put("edcttp", edtp);
		List<HashMap<String, Object>> list = (List<HashMap<String, Object>>) commonDao.queryByNamedSqlForList(MYBATIS_NS + "getEdstep", hs);
		return list.get(0).get("edstep").toString();
	}

	// ����������Ŀ
	@SuppressWarnings("unchecked")
	public void addComEdct() {
		try {
			commonDao.beginTransaction();

			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();

			HashMap<String, Object> hashmap2 = new HashMap<String, Object>();

			String stacid = SessionParaUtils.getStacid();// ����
			String edcttp = hashmap.get("edcttp");
			String edstep = getEdstep(stacid, edcttp);
			String procna = req.getReqDataStr("procna");// ������
			String remark = req.getReqDataStr("remark");// ��ע

			String edstep2 = req.getReqDataStr("edstep2");
			if (edstep2 != "" && !"".equals(edstep2)) {
				edstep = edstep2;
				int begin = Integer.parseInt(edstep2);

				// ��ѯ�����м�¼������edstep2��ļ�¼ȫ����һ
				List<HashMap<String, Object>> list = (List<HashMap<String, Object>>) commonDao.queryByNamedSqlForList(MYBATIS_NS + "comedctCount", hashmap);
				int total = Integer.parseInt(list.get(0).get("total").toString());

				for (int i = total; i >= begin; i--) {
					hashmap2.put("edstep", i);
					hashmap2.put("edcttp", edcttp);
					hashmap2.put("stacid", stacid);
					commonDao.updateByNamedSql(MYBATIS_NS + "updatechecked", hashmap2);
				}

			}

			hashmap.put("edstep", edstep);
			hashmap.put("procna", procna);
			hashmap.put("status", NON_USE);
			hashmap.put("proctg", PROCESS_NO);
			hashmap.put("remark", remark);

			commonDao.insertByNamedSql(MYBATIS_NS + "addComEdct", hashmap);
			commonDao.commitTransaction();

			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("navTabId", "comEdct");
			req.addRspData("callbackType", "closeCurrent");
			req.addRspData("forwardUrl", "");

		} catch (Exception e) {
			try {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", e.getMessage());
				req.addRspData("navTabId", "sysparam");
				req.addRspData("callbackType", "closeCurrent");
				req.addRspData("forwardUrl", "");
			} catch (JDOMException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}

	// ɾ��������Ŀ
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void delComEdct() {
		try {
			List parampList = req.getReqDataTexts("dayEndProcessIds");
			HashMap<String, String> hashmap = new HashMap<String, String>();
			if (parampList != null && parampList.size() > 0) {
				commonDao.beginTransaction();
				for (int i = 0; i < parampList.size(); i++) {
					String paramp = (String) parampList.get(i);
					String[] primary = paramp.split("-");

					if (null != primary && 4 == primary.length) {
						String stacid = primary[0];// ����
						String edcttp = primary[1];// �������
						String edstep = primary[2];// ��������
						String status = primary[3];// ״̬

						hashmap.put("stacid", stacid);
						hashmap.put("edcttp", edcttp);
						hashmap.put("edstep", edstep);

						if (status.equals("1")) {
							ResultUtils.setRspData(req, "300", "��ʹ�õ�����������ɾ��", "comEdct", "closeCurren");
							return;
						}

						commonDao.deleteByNamedSql(MYBATIS_NS + "delComEdct", hashmap);

					} else {
						commonDao.rollBack();
						return;
					}
				}
				List<Map<String, Object>> dataList = (List<Map<String, Object>>) commonDao.queryByNamedSqlForList(MYBATIS_NS + "queryComEdct", hashmap);
				for (int i = 0; i < dataList.size(); i++) {
					dataList.get(i).put("newEdstep", Integer.toString(i + 1));
					commonDao.updateByNamedSql(MYBATIS_NS + "updateComEdctOrder", dataList.get(i));
				}
				
				commonDao.commitTransaction();
				req.addRspData("retCode", "200");
				req.addRspData("retMessage", "�����ɹ�");
				req.addRspData("navTabId", "");
				req.addRspData("callbackType", "closeCurren");
				req.addRspData("forwardUrl", "");
			}

		} catch (Exception e) {
			try {
				commonDao.rollBack();
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", e.getMessage());
				req.addRspData("navTabId", "showUsers");
				req.addRspData("callbackType", "");
				req.addRspData("forwardUrl", "");
			} catch (JDOMException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}

	// �޸�������Ŀ
	public void updateComEdct() {
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String stacid = req.getReqDataStr("stacid");// ����
			String edstep = req.getReqDataStr("edstep");// ��������
			String edcttp = req.getReqDataStr("edcttp");//
			String procna = req.getReqDataStr("procna");//
			String remark = req.getReqDataStr("remark");//
			String status = req.getReqDataStr("status");//
			String proctg = req.getReqDataStr("proctg");//

			hashmap.put("status", status);
			hashmap.put("proctg", proctg);
			hashmap.put("stacid", stacid);
			hashmap.put("edstep", edstep);
			hashmap.put("edcttp", edcttp);
			hashmap.put("procna", procna);
			hashmap.put("remark", remark);

			int result = commonDao.updateByNamedSql(MYBATIS_NS + "updateComEdct", hashmap);

			if (result > 0) {
				req.addRspData("retCode", "200");
				req.addRspData("retMessage", "�����ɹ�");
				req.addRspData("navTabId", "comEdct");
				req.addRspData("callbackType", "closeCurrent");
				req.addRspData("forwardUrl", "");
			} else {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "����ʧ��");
				req.addRspData("navTabId", "comEdct");
				req.addRspData("callbackType", "closeCurrent");
				req.addRspData("forwardUrl", "");
			}
		} catch (Exception e) {
			try {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", e.getMessage());
				req.addRspData("navTabId", "comEdct");
				req.addRspData("callbackType", "closeCurrent");
				req.addRspData("forwardUrl", "");
			} catch (JDOMException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}

	// ������Ŀ���ƺ�����λ�ò���
	public void changeProcessComEdct() {
		try {

			HashMap<String, String> hashmapUp = new HashMap<String, String>();
			HashMap<String, String> hashmapDown = new HashMap<String, String>();
			// ���������һ������
			String stacidUp = req.getReqDataStr("stacidUp");
			String edstepUp = req.getReqDataStr("edstepUp");
			String edcttpUp = req.getReqDataStr("edcttpUp");
			// ���������һ������
			String stacidDown = req.getReqDataStr("stacidDown");
			String edstepDown = req.getReqDataStr("edstepDown");
			String edcttpDown = req.getReqDataStr("edcttpDown");
			// ���յ�ǰ��������������
			String changeId = req.getReqDataStr("changeId");

			hashmapUp.put("stacid", stacidUp);
			hashmapUp.put("edcttp", edcttpUp);
			hashmapUp.put("edstep", edstepUp);
			hashmapUp.put("newEdstep", DEFAULT_EDSTEP);
			commonDao.updateByNamedSql(MYBATIS_NS + "updateComEdctOrder", hashmapUp); // ��ʱλ��

			hashmapDown.put("stacid", stacidDown);
			hashmapDown.put("edcttp", edcttpDown);
			hashmapDown.put("edstep", edstepDown);
			hashmapDown.put("newEdstep", Integer.toString(Integer.parseInt(changeId) - 1));
			int resultDown = commonDao.updateByNamedSql(MYBATIS_NS + "updateComEdctOrder", hashmapDown);
			hashmapUp.put("edstep", DEFAULT_EDSTEP);
			hashmapUp.put("newEdstep", changeId);
			int resultUp = commonDao.updateByNamedSql(MYBATIS_NS + "updateComEdctOrder", hashmapUp);

			if (resultUp > 0 && resultDown > 0) {
				req.addRspData("retCode", "200");
				req.addRspData("retMessage", "�����ɹ�");
				req.addRspData("navTabId", "");
				req.addRspData("forwardUrl", "");
			} else {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "����ʧ��");
				req.addRspData("navTabId", "");
				req.addRspData("forwardUrl", "");
			}
		} catch (Exception e) {
			try {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", e.getMessage());
				req.addRspData("navTabId", "");
				req.addRspData("callbackType", "closeCurrent");
				req.addRspData("forwardUrl", "");
			} catch (JDOMException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}

	/**
	 * ���մ���
	 * 
	 */
	public void execute() {

		// ������ҵ���ȵ����߳�
		StepProcesserThread task = null;
		try {
			isStart = true;
			// jsp���洫�����|�ָ��ı���
			String pckgdt = "|".concat("edcttp=").concat(req.getReqDataStr("edcttp")).concat("|");
			String myRefreshs = req.getReqDataStr("myRefreshTime1");

			String stacid = SessionParaUtils.getStacid();
			// ��ȡҵ����ˮ ������ˮ(ÿ�β����ļ����ˮ) �ڲ�������������
			Sequence sequence = SequenceUtils.createSequenceInnerTran(Integer.valueOf(stacid), "glissq", SessionParaUtils.getDeptcd(), null, 1);

			/*
			 * PubUtil.getGlisdt(Integer.parseInt(stacid.trim())) Sequence
			 * sequence = SequenceUtils.createSequence(
			 * stacid,PubUtil.getGlisdt(Integer.parseInt(stacid.trim())),
			 * "glissq", SessionParaUtils.getDeptcd(),
			 * SessionParaUtils.getUsercd(), 1);
			 */
			String bsnssq = sequence.getSqueno();
			if (pckgdt == null || "".equals(pckgdt)) {
				pckgdt = "|".concat("user_bsnssq=").concat(bsnssq).concat("|");
			} else {
				pckgdt = pckgdt.concat("user_bsnssq=").concat(bsnssq).concat("|");
			}
			UserAuthenticator ua = UserAuthenticator.currentAuthenticator();
			task = new StepProcesserThread(Integer.parseInt(stacid.trim()), pckgdt, ua);
			task.start();
			req.addRspData("myRefreshs", myRefreshs);
		} catch (Exception e1) {
			getLog().logError("�������յ�����ʧ��", e1);
			isStart = false;
			e1.printStackTrace();
		}
	}

	/**
	 * 
	 * @Title: beforeDayEndOperator
	 * @Description: ����ǰ�������Ƿ������
	 * @return: void
	 */
	public void beforeDayEndOperator() {
		try {
			String stacid = SessionParaUtils.getStacid();
			HashMap<String, String> returnMap = new HashMap<String, String>();
			HashMap<String, String> para = new HashMap<String, String>();
			Integer count = 0;
			para.put("stacid", stacid);
			para.put("trandt", PubUtil.getGlisdt(Integer.valueOf(stacid)));

			// 1 ��ѯ��ˮ�ӿڱ�δ�����ļ�¼��
			count = (Integer) commonDao.getSqlSession().selectOne(MYBATIS_NS_DAYENDCHECK + "getCountOfLoanBusiNotExecute", para);
			if (count > 0) {
				returnMap.put("retcode", "FAIL");
				returnMap.put("retmsg", "ҵ����ˮ����δ������ɣ���ȴ���");
				req.addRspData("jsonDataStr", JsonUtil.convertObject2Json(returnMap));
				return;
			}
			// 2 ��ѯ��ˮ�ӿڱ�����ʧ�ܵļ�¼��
			count = (Integer) commonDao.getSqlSession().selectOne(MYBATIS_NS_DAYENDCHECK + "getCountOfLoanBusiExecuteFail", para);
			if (count > 0) {
				returnMap.put("retcode", "FAIL");
				returnMap.put("retmsg", "ҵ����ˮ���ݽ���ʧ�ܵļ�¼��Ϊ��" + count + "����鿴������������־��");
				req.addRspData("jsonDataStr", JsonUtil.convertObject2Json(returnMap));
				return;
			}
			// 3 ��ѯ��Ʊ�ӿڱ�δ�����ļ�¼��
			count = (Integer) commonDao.getSqlSession().selectOne(MYBATIS_NS_DAYENDCHECK + "getCountOfGliVchrNotExecute", para);
			if (count > 0) {
				returnMap.put("retcode", "FAIL");
				returnMap.put("retmsg", "�����ˮ����δ������ɣ���ȴ���");
				req.addRspData("jsonDataStr", JsonUtil.convertObject2Json(returnMap));
				return;
			}
			// 4 ��ѯ��Ʊ�ӿڱ�����ʧ�ܵļ�¼��
			count = (Integer) commonDao.getSqlSession().selectOne(MYBATIS_NS_DAYENDCHECK + "getCountOfGliVchrExecuteFail", para);
			if (count > 0) {
				returnMap.put("retcode", "FAIL");
				returnMap.put("retmsg", "�����ˮ���ݽ���ʧ�ܵļ�¼��Ϊ��" + count + "����鿴������������־��");
				req.addRspData("jsonDataStr", JsonUtil.convertObject2Json(returnMap));
				return;
			}
			// 5 ��ѯ��Ʊ��δ���˵ļ�¼��
			count = (Integer) commonDao.getSqlSession().selectOne(MYBATIS_NS_DAYENDCHECK + "getCountOfGlaVchrNotExecute", para);
			if (count > 0) {
				returnMap.put("retcode", "FAIL");
				returnMap.put("retmsg", "���˴�Ʊδ������ɣ���ȴ���");
				req.addRspData("jsonDataStr", JsonUtil.convertObject2Json(returnMap));
				return;
			}
			// 6 ��ѯ��Ʊ������ʧ�ܵļ�¼��
			count = (Integer) commonDao.getSqlSession().selectOne(MYBATIS_NS_DAYENDCHECK + "getCountOfGlaVchrExecuteFail", para);
			if (count > 0) {
				returnMap.put("retcode", "FAIL");
				returnMap.put("retmsg", "���˴�Ʊ����ʧ�ܵļ�¼��Ϊ��" + count + "����鿴������������־��");
				req.addRspData("jsonDataStr", JsonUtil.convertObject2Json(returnMap));
				return;
			}
			// 7 ��ѯ��Ʊ��δ����ļ�¼��
			count = (Integer) commonDao.getSqlSession().selectOne(MYBATIS_NS_DAYENDCHECK + "getCountOfGlaVchrNotClear", para);
			if (count > 0) {
				returnMap.put("retcode", "FAIL");
				returnMap.put("retmsg", "���˴�Ʊδ������ɣ���ȴ���");
				req.addRspData("jsonDataStr", JsonUtil.convertObject2Json(returnMap));
				return;
			}

			returnMap.put("retcode", "SUCC");
			req.addRspData("jsonDataStr", JsonUtil.convertObject2Json(returnMap));// �̶���ʽ�����뵽json������,������jsonDataStr�����ɸı�
		} catch (Exception e) {
			getLog().logError("����ǰ����ʧ��", e);
			try {
				String retmsg = e.getMessage();
				req.addRspData("jsonDataStr", "{\"retcode\":\"FAIL\",\"retmsg\":\"ʧ��:" + retmsg + "\"}");
			} catch (JDOMException e1) {
				// e1.printStackTrace();
				getLog().logError("����ǰ����ʧ��", e);
			}
		}
	}

	/**
	 * 
	 * @Title: executeCler
	 * @Description: ҵ�����ִ������
	 * @return: void
	 */
	public void executeCler() {
		try {
			String stacid = SessionParaUtils.getStacid();
			HashMap<String, String> returnMap = new HashMap<String, String>();
			// ����
			FundClearDeal fundClear = new FundClearDeal();
			String result = fundClear.fundClear(stacid);
			if (!"EXE0000".equals(result)) {
				returnMap.put("retcode", "FAIL");
				returnMap.put("retmsg", "�������ʧ�ܣ����飡");
				req.addRspData("jsonDataStr", JsonUtil.convertObject2Json(returnMap));
				return;
			}

			returnMap.put("retcode", "SUCC");
			req.addRspData("jsonDataStr", JsonUtil.convertObject2Json(returnMap));// �̶���ʽ�����뵽json������,������jsonDataStr�����ɸı�
		} catch (Exception e) {
			getLog().logError("�������ʧ��", e);
			try {
				String retmsg = e.getMessage();
				req.addRspData("jsonDataStr", "{\"retcode\":\"FAIL\",\"retmsg\":\"ʧ��:" + retmsg + "\"}");
			} catch (JDOMException e1) {
				// e1.printStackTrace();
				getLog().logError("�������ʧ��", e);
			}
		}
	}
}
