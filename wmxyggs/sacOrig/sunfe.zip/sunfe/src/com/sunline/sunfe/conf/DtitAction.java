package com.sunline.sunfe.conf;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.util.StringUtils;
public class DtitAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.dtit.";
	Log log = new Log(DtitAction.class);
	/**
	 * ��ѯ���������б� & queryDtitListPage
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void queryDtitListPage() throws JDOMException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			hashmap.put("typecd",  StringUtils.repalceCharecter(hashmap.get("typecd")));
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryDtitlistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (BimisException e) {
			log.logError(e);
		}
	}
	/**
	 * ��ѯ���������б� & dtitLookupSingListPage
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void dtitLookupSingListPage() throws JDOMException{
		try {
			HashMap<String, String> hashmap =(HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"dtitLookupSinglistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (BimisException e) {
			log.logError(e);
		}
	}
	
	
	/**
	 * ��ѯ����������Ϣ����
	 */
	@SuppressWarnings("unchecked")
	public void queryDtitInfo(){
		try 
		{	
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryDtitInfo", hashmap);	
            req.addRspData(e.removeContent());        //���ؽ����װ	
		} catch (Exception e) {
			log.logError(e);
		}
	 }	
	
	/**
	 *  ����������Ϣ¼��
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addDtit(){
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistDtit", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "�ú������õ��Ѵ��ڣ�");
					return;
				}
			}
			commonDao.insertByNamedSql(MYBATIS_NS+"addDtit", hashmap);
		    ResultUtils.setRspData(req, "200", "�����ɹ�", "dtit_main","closeCurrent","");
			commonDao.commitTransaction();
		} catch (Exception e) {
			commonDao.rollBack();
			log.logError(e);
		}	
		
	}
	/**
	 *  ά������������Ϣ
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void updateDtit() throws JDOMException{
		try {
			HashMap<String, String> hashmap =  (HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			commonDao.insertByNamedSql(MYBATIS_NS+"updateDtit", hashmap);
			commonDao.commitTransaction();
		    ResultUtils.setRspData(req, "200", "�����ɹ�", "dtit_main","closeCurrent","");
		} catch (BimisException e) {
			commonDao.rollBack();
			log.logError(e);
			ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "dtit_main","closeCurrent","");
		  }
	 }	
	
	/**
	 * �������ɾ������������Ϣ
	 * @throws JDOMException 
	 */
	 public void deleteManyDtit() throws JDOMException {
		 try {
	        	HashMap<String, String> param = new HashMap<String, String>();
	            List<String> tytrcdList = req.getReqDataTexts("tytrcd");
	            commonDao.beginTransaction();
	            for (int i=0;i<tytrcdList.size();i++) {
	            	 param.clear();
	                 String [] array = tytrcdList.get(i).split("-");
	                 param.put("typecd", array[0]);
	                 param.put("trprcd", array[1]);
	                 param.put("stacid", array[2]);
	                 commonDao.deleteByNamedSql(MYBATIS_NS+"deleteDtit", param);
	            }
	            commonDao.commitTransaction();
			    ResultUtils.setRspData(req, "200", "�����ɹ�", "dtit_main","","");
			} catch (BimisException e) {
				commonDao.rollBack();
				ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "dtit_main","","");
				log.logError(e);
			  }
		}	

	/**
	 * ����ɾ������������Ϣ & deleteDtit
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void deleteDtit() throws JDOMException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			commonDao.deleteByNamedSql(MYBATIS_NS+"deleteDtit", hashmap);//ִ��ɾ��SQL���
			commonDao.commitTransaction();
		    ResultUtils.setRspData(req, "200", "�����ɹ�", "dtit_main","","");
		} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "dtit_main","","");
			log.logError(e);
		  }
	  }	 
	
	/**
	 * ��ѯ��Ŀ�����б� & queryItemListPage
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void queryItemListPage() throws BimisException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("stacid", SessionParaUtils.getStacid());
			//��������ѡ��Ŀ�Ŀ��Ϊĩ����Ŀ   
			hashmap.put("detltg", "1");
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryItemlistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}
}
