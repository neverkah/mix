package com.sunline.sunfe.core.bean;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.sunline.jraf.BimisException;
import com.sunline.suncm.util.Constants;
import com.sunline.suncm.util.Enumeration;
import com.sunline.sunfe.entity.AccountingItem;
import com.sunline.sunfe.entity.GlaAeuvDetl;
import com.sunline.sunfe.entity.GlaGlis;
import com.sunline.sunfe.entity.GlaVoucher;

/**
 * 
 * @ClassName: GlaGlisBean
 * @Description: ���˺��Ĳ���bean
 * @author: zhangdq
 * @date: 2017-2-27 ����10:01:24
 */
public class GlaGlisBean {

	private static final Logger logger = Logger.getLogger(GlaGlisBean.class);

	private static final String DTAG = ".";

	/**
	 * 
	 * @Title: updateBalanceByVchr
	 * @Description: ͨ��gla_vchr��������
	 * @param vchr
	 * @param glisEntity
	 * @param itemEntity
	 * @return: void
	 */
	public static void updateBalanceByVchr(GlaVoucher vchr, GlaGlis glisEntity, AccountingItem itemEntity) {
		// TODO Auto-generated method stub

		BigDecimal drctbl = new BigDecimal(0);//�跽�������
		BigDecimal crctbl = new BigDecimal(0);//�����������
		BigDecimal onlnbl = new BigDecimal(0);//��ǰ���
		String blncdn = null;//��ǰ����
		BigDecimal dtranam = new BigDecimal(0);//�跽���ڷ�����
		BigDecimal ctranam = new BigDecimal(0);//�������ڷ�����
		int dtranm = 0;//�跽���ڷ�������
		int ctranm = 0;//�������ڷ�������
		BigDecimal devTranam = new BigDecimal(0);

		if (vchr.getAmntcd().equalsIgnoreCase(Constants.AMNTCD_DEBIT)) {
			dtranam = vchr.getTranam();
			dtranm = vchr.getTrannm();
		} else if (vchr.getAmntcd().equalsIgnoreCase(Constants.AMNTCD_CREDIT)) {
			ctranam = vchr.getTranam();
			ctranm = vchr.getTrannm();
		} else if (vchr.getAmntcd().equalsIgnoreCase(Enumeration.Amntcd.R.value)) {
			dtranam = vchr.getTranam();
			dtranm = vchr.getTrannm();
		} else if (vchr.getAmntcd().equalsIgnoreCase(Enumeration.Amntcd.P.value)) {
			ctranam = vchr.getTranam();
			ctranm = vchr.getTrannm();
		}
		/*
		 * ����Ŀ����ֱ���
		 */
		if (itemEntity.getItemdn().equalsIgnoreCase(Constants.AMNTCD_DEBIT) || itemEntity.getItemdn().equalsIgnoreCase(Enumeration.Amntcd.R.value)) {
			drctbl = glisEntity.getDrctbl().add(dtranam).subtract(ctranam);
			onlnbl = drctbl;
			blncdn = itemEntity.getItemdn();
		} else if (itemEntity.getItemdn().equalsIgnoreCase(Constants.AMNTCD_CREDIT) || itemEntity.getItemdn().equalsIgnoreCase(Enumeration.Amntcd.P.value)) {
			crctbl = glisEntity.getCrctbl().add(ctranam).subtract(dtranam);
			onlnbl = crctbl;
			blncdn = itemEntity.getItemdn();
		} else if (itemEntity.getItemdn().equalsIgnoreCase(Constants.AMNTCD_B)) {
			crctbl = glisEntity.getCrctbl().add(ctranam);
			drctbl = glisEntity.getDrctbl().add(dtranam);
			devTranam = dtranam.subtract(ctranam);

			if (glisEntity.getBlncdn().equals(Constants.AMNTCD_DEBIT)) {
				if ((glisEntity.getOnlnbl().add(devTranam).compareTo(BigDecimal.valueOf(0))) < 0) {
					blncdn = Constants.AMNTCD_CREDIT;
				} else {
					blncdn = Constants.AMNTCD_DEBIT;
				}
				onlnbl = glisEntity.getOnlnbl().add(devTranam).abs();
			} else {
				if (glisEntity.getOnlnbl().subtract(devTranam).compareTo(BigDecimal.ZERO) < 0) {
					blncdn = Constants.AMNTCD_DEBIT;
				} else {
					blncdn = Constants.AMNTCD_CREDIT;
				}
				onlnbl = glisEntity.getOnlnbl().subtract(devTranam).abs();
			}
		} else if (itemEntity.getItemdn().equalsIgnoreCase(Constants.AMNTCD_Z)) {
			devTranam = dtranam.subtract(ctranam);
			if (glisEntity.getBlncdn().equals(Constants.AMNTCD_DEBIT)) {
				if (glisEntity.getOnlnbl().add(devTranam).compareTo(BigDecimal.ZERO) < 0) {
					blncdn = Constants.AMNTCD_CREDIT;
				} else {
					blncdn = Constants.AMNTCD_DEBIT;
				}
				onlnbl = glisEntity.getOnlnbl().add(devTranam).abs();
			} else {
				if (glisEntity.getOnlnbl().subtract(devTranam).compareTo(BigDecimal.ZERO) < 0) {
					blncdn = Constants.AMNTCD_DEBIT;
				} else {
					blncdn = Constants.AMNTCD_CREDIT;
				}
				onlnbl = glisEntity.getOnlnbl().subtract(devTranam).abs();
			}
			if (blncdn.equals(Constants.AMNTCD_DEBIT)) {
				drctbl = onlnbl;
				crctbl = BigDecimal.valueOf(0);
			} else {
				crctbl = onlnbl;
				drctbl = BigDecimal.valueOf(0);
			}
		} else {

		}

		// ����跽�������Ľ��׽��ϼơ����ױ����ϼ�
		dtranam = dtranam.add(glisEntity.getDrtsam());
		ctranam = ctranam.add(glisEntity.getCrtsam());

		dtranm = dtranm + glisEntity.getDrtsnm();
		ctranm = ctranm + glisEntity.getCrtsnm();

		// ����ֵ
		glisEntity.setDrtsam(dtranam);
		glisEntity.setCrtsam(ctranam);
		glisEntity.setDrtsnm(dtranm);
		glisEntity.setCrtsnm(ctranm);
		glisEntity.setDrctbl(drctbl);
		glisEntity.setCrctbl(crctbl);
		glisEntity.setBlncdn(blncdn);
		glisEntity.setOnlnbl(onlnbl);

		logger.debug("���˸��²����嵥:");
		logger.debug("Drtsam=" + glisEntity.getDrtsam());
		logger.debug("Crtsam=" + glisEntity.getCrtsam());
		logger.debug("Drtsnm=" + glisEntity.getDrtsnm());
		logger.debug("Crtsnm=" + glisEntity.getCrtsnm());
		logger.debug("Drctbl=" + glisEntity.getDrctbl());
		logger.debug("Crctbl=" + glisEntity.getCrctbl());
		logger.debug("Blncdn=" + glisEntity.getBlncdn());
		logger.debug("Onlnbl=" + glisEntity.getOnlnbl());
	}

	
	/**
	 * 
	 * @Title: updateAuditGlaGlisByVchr
	 * @Description: ͨ��gla_vchr����������׷���
	 * @param vchr
	 * @param glisEntity
	 * @param itemEntity
	 * @return: void
	 */
	public static void updateTranamByVchr(GlaVoucher vchr, GlaGlis glisEntity, AccountingItem itemEntity) {

		BigDecimal dtranam = new BigDecimal(0);//�跽���ڷ�����
		BigDecimal ctranam = new BigDecimal(0);//�������ڷ�����
		int dtranm = 0;//�跽���ڷ�������
		int ctranm = 0;//�������ڷ�������

		if (vchr.getAmntcd().equalsIgnoreCase(Constants.AMNTCD_DEBIT)) {
			dtranam = vchr.getTranam();
			dtranm = vchr.getTrannm();
		} else if (vchr.getAmntcd().equalsIgnoreCase(Constants.AMNTCD_CREDIT)) {
			ctranam = vchr.getTranam();
			ctranm = vchr.getTrannm();
		} else if (vchr.getAmntcd().equalsIgnoreCase(Enumeration.Amntcd.R.value)) {
			dtranam = vchr.getTranam();
			dtranm = vchr.getTrannm();
		} else if (vchr.getAmntcd().equalsIgnoreCase(Enumeration.Amntcd.P.value)) {
			ctranam = vchr.getTranam();
			ctranm = vchr.getTrannm();
		}
		
		// ����跽�������Ľ��׽��ϼơ����ױ����ϼ�
		dtranam = glisEntity.getDrtsam().add(dtranam);
		ctranam = glisEntity.getCrtsam().add(ctranam);

		dtranm = glisEntity.getDrtsnm() - dtranm;
		ctranm = glisEntity.getCrtsnm() - ctranm;

		// ����ֵ
		glisEntity.setDrtsam(dtranam);
		glisEntity.setCrtsam(ctranam);
		glisEntity.setDrtsnm(dtranm);
		glisEntity.setCrtsnm(ctranm);

		logger.debug("���˸��²����嵥:");
		logger.debug("Drtsam=" + glisEntity.getDrtsam());
		logger.debug("Crtsam=" + glisEntity.getCrtsam());
		logger.debug("Drtsnm=" + glisEntity.getDrtsam());
		logger.debug("Crtsnm=" + glisEntity.getCrtsnm());
	}
	
	

	/**
	 * 
	 * @Title: updateBalanceByVchr
	 * @Description: ͨ��gla_aeuv_detl��������, ͨ�ü��˵�ģʽ����Ʊ�лᱣ����ǰ�������������˸���ǰ����Ϣ
	 * @param glaAeuvDetl
	 *            ��Ʒ�¼��ϸ
	 * @param glisEntity
	 *            ����
	 * @param itemEntity
	 *            ��Ŀ��Ϣ
	 * @return: void
	 */
	public static void updateBalanceByAeuv(GlaAeuvDetl glaAeuvDetl, GlaGlis glisEntity, AccountingItem itemEntity) {
		// TODO Auto-generated method stub

		BigDecimal drctbl = new BigDecimal(0);// �跽�������
		BigDecimal crctbl = new BigDecimal(0);// �����������
		BigDecimal onlnbl = new BigDecimal(0);// ��ǰ���
		BigDecimal dtranam = new BigDecimal(0);// �跽���׽��
		BigDecimal ctranam = new BigDecimal(0);// �������׽��
		int dtranm = 0;
		int ctranm = 0;
		String blncdn = null;
		BigDecimal devTranam = new BigDecimal(0);

		if (glaAeuvDetl.getAmntcd().equalsIgnoreCase(Enumeration.Amntcd.D.value)) {
			dtranam = glaAeuvDetl.getTranam();
			dtranm = glaAeuvDetl.getTrannm();
		} else if (glaAeuvDetl.getAmntcd().equalsIgnoreCase(Enumeration.Amntcd.C.value)) {
			ctranam = glaAeuvDetl.getTranam();
			ctranm = glaAeuvDetl.getTrannm();
		} else if (glaAeuvDetl.getAmntcd().equalsIgnoreCase(Enumeration.Amntcd.R.value)) {
			dtranam = glaAeuvDetl.getTranam();
			dtranm = glaAeuvDetl.getTrannm();
		} else if (glaAeuvDetl.getAmntcd().equalsIgnoreCase(Enumeration.Amntcd.P.value)) {
			ctranam = glaAeuvDetl.getTranam();
			ctranm = glaAeuvDetl.getTrannm();
		}
		/*
		 * ����Ŀ����ֱ���
		 */
		if (itemEntity.getItemdn().equalsIgnoreCase(Constants.AMNTCD_DEBIT) || itemEntity.getItemdn().equalsIgnoreCase(Enumeration.Amntcd.R.value)) {
			drctbl = glisEntity.getDrctbl().add(dtranam).subtract(ctranam);
			onlnbl = drctbl;
			blncdn = itemEntity.getItemdn();
		} else if (itemEntity.getItemdn().equalsIgnoreCase(Constants.AMNTCD_CREDIT) || itemEntity.getItemdn().equalsIgnoreCase(Enumeration.Amntcd.P.value)) {
			crctbl = glisEntity.getCrctbl().add(ctranam).subtract(dtranam);
			onlnbl = crctbl;
			blncdn = itemEntity.getItemdn();
		} else if (itemEntity.getItemdn().equalsIgnoreCase(Constants.AMNTCD_B)) {
			crctbl = glisEntity.getCrctbl().add(ctranam);
			drctbl = glisEntity.getDrctbl().add(dtranam);
			devTranam = dtranam.subtract(ctranam);

			if (glisEntity.getBlncdn().equals(Constants.AMNTCD_DEBIT)) {
				if ((glisEntity.getOnlnbl().add(devTranam).compareTo(BigDecimal.valueOf(0))) < 0) {
					blncdn = Constants.AMNTCD_CREDIT;
				} else {
					blncdn = Constants.AMNTCD_DEBIT;
				}
				onlnbl = glisEntity.getOnlnbl().add(devTranam).abs();
			} else {
				if (glisEntity.getOnlnbl().subtract(devTranam).compareTo(BigDecimal.ZERO) < 0) {
					blncdn = Constants.AMNTCD_DEBIT;
				} else {
					blncdn = Constants.AMNTCD_CREDIT;
				}
				onlnbl = glisEntity.getOnlnbl().subtract(devTranam).abs();
			}
		} else if (itemEntity.getItemdn().equalsIgnoreCase(Constants.AMNTCD_Z)) {
			devTranam = dtranam.subtract(ctranam);
			if (glisEntity.getBlncdn().equals(Constants.AMNTCD_DEBIT)) {
				if (glisEntity.getOnlnbl().add(devTranam).compareTo(BigDecimal.ZERO) < 0) {
					blncdn = Constants.AMNTCD_CREDIT;
				} else {
					blncdn = Constants.AMNTCD_DEBIT;
				}
				onlnbl = glisEntity.getOnlnbl().add(devTranam).abs();
			} else {
				if (glisEntity.getOnlnbl().subtract(devTranam).compareTo(BigDecimal.ZERO) < 0) {
					blncdn = Constants.AMNTCD_DEBIT;
				} else {
					blncdn = Constants.AMNTCD_CREDIT;
				}
				onlnbl = glisEntity.getOnlnbl().subtract(devTranam).abs();
			}
			if (blncdn.equals(Constants.AMNTCD_DEBIT)) {
				drctbl = onlnbl;
				crctbl = BigDecimal.valueOf(0);
			} else {
				crctbl = onlnbl;
				drctbl = BigDecimal.valueOf(0);
			}
		} else {

		}

		// ����跽�������Ľ��׽��ϼơ����ױ����ϼ�
		dtranam = dtranam.add(glisEntity.getDrtsam());
		ctranam = ctranam.add(glisEntity.getCrtsam());

		dtranm = dtranm + glisEntity.getDrtsnm();
		ctranm = ctranm + glisEntity.getCrtsnm();

		// ����ֵ
		glisEntity.setDrtsam(dtranam);
		glisEntity.setCrtsam(ctranam);
		glisEntity.setDrtsnm(dtranm);
		glisEntity.setCrtsnm(ctranm);
		glisEntity.setDrctbl(drctbl);
		glisEntity.setCrctbl(crctbl);
		glisEntity.setBlncdn(blncdn);
		glisEntity.setOnlnbl(onlnbl);

		logger.debug("���˸��²����嵥:");
		logger.debug("Drtsam=" + glisEntity.getDrtsam());
		logger.debug("Crtsam=" + glisEntity.getCrtsam());
		logger.debug("Drtsnm=" + glisEntity.getDrtsam());
		logger.debug("Crtsnm=" + glisEntity.getCrtsnm());
		logger.debug("Drctbl=" + glisEntity.getDrctbl());
		logger.debug("Crctbl=" + glisEntity.getCrctbl());
		logger.debug("Blncdn=" + glisEntity.getBlncdn());
		logger.debug("Onlnbl=" + glisEntity.getOnlnbl());
	}

	/**
	 * 
	 * @Title: openGlisByVchr
	 * @Description: ��ȡһ�����˵�ʵ��
	 * @param itemEntity
	 *            ��Ŀ��Ϣ
	 * @param vchr
	 *            ��Ʊ��Ϣ
	 * @return: GlaGlis ������Ϣ
	 */
	public static GlaGlis openGlisByVchr(AccountingItem itemEntity, GlaVoucher vchr) {

		// ��ȡ��Ŀ����
		// String itemdn = itemEntity.getItemdn();
		String itemdn = itemEntity.getItemdn();

		// ��Ŀ����Ϊ�跽
		if (itemdn.equalsIgnoreCase(Constants.AMNTCD_CREDIT)) {
			itemdn = Constants.AMNTCD_CREDIT;
		} else if (itemdn.equalsIgnoreCase(Enumeration.Amntcd.R.value)) {
			itemdn = Enumeration.Amntcd.R.value;
		} else {
			itemdn = Constants.AMNTCD_DEBIT;
		}

		GlaGlis entity = new GlaGlis();
		entity.setStacid(vchr.getStacid());
		entity.setSystid(vchr.getSystid());
		entity.setAcctdt(vchr.getTrandt());
		entity.setBrchcd(vchr.getAcctbr());
		entity.setItemcd(vchr.getItemcd());
		entity.setCrcycd(vchr.getCrcycd());
		entity.setDrtsam(BigDecimal.ZERO);
		entity.setDrtsnm(0);
		entity.setCrtsam(BigDecimal.ZERO);
		entity.setCrtsnm(0);
		entity.setDrctbl(BigDecimal.ZERO);
		entity.setCrctbl(BigDecimal.ZERO);
		entity.setBlncdn(itemdn);
		entity.setOnlnbl(BigDecimal.ZERO);
		entity.setLastdn(itemdn);
		entity.setLastbl(BigDecimal.ZERO);
		entity.setGeldtp(vchr.getGeldtp());
		entity.setCentcd(vchr.getCentcd());
		entity.setPrsncd(vchr.getPrsncd());
		entity.setCustcd(vchr.getCustcd());
		entity.setPrducd(vchr.getPrducd());
		entity.setPrlncd(vchr.getPrlncd());
		entity.setAcctno(vchr.getAcctno());
		entity.setAssis0(vchr.getAssis0());
		entity.setAssis1(vchr.getAssis1());
		entity.setAssis2(vchr.getAssis2());
		entity.setAssis3(vchr.getAssis3());
		entity.setAssis4(vchr.getAssis4());
		entity.setAssis5(vchr.getAssis5());
		entity.setAssis6(vchr.getAssis6());
		entity.setAssis7(vchr.getAssis7());
		entity.setAssis8(vchr.getAssis8());
		entity.setAssis9(vchr.getAssis9());

		return entity;
	}

	/**
	 * 
	 * @Title: openGlisByAeuv
	 * @Description: ͨ����Ʊ��Ϣ��ȡһ�����˵�ʵ��
	 * @param itemEntity
	 *            ��Ŀ��Ϣ
	 * @param glaAeuvDetl
	 *            ��Ʒ�¼��ϸ��Ϣ
	 * @return: GlaGlis ������Ϣ
	 */
	public static GlaGlis openGlisByAeuv(AccountingItem itemEntity, GlaAeuvDetl glaAeuvDetl) {

		// ��ȡ��Ŀ����
		String itemdn = itemEntity.getItemdn();

		// ��Ŀ����Ϊ�跽
		if (itemdn.equalsIgnoreCase(Constants.AMNTCD_CREDIT)) {
			itemdn = Constants.AMNTCD_CREDIT;
		} else if (itemdn.equalsIgnoreCase(Enumeration.Amntcd.R.value)) {
			itemdn = Enumeration.Amntcd.R.value;
		} else {
			itemdn = Constants.AMNTCD_DEBIT;
		}

		GlaGlis entity = new GlaGlis();
		entity.setStacid(glaAeuvDetl.getStacid());
		entity.setSystid(glaAeuvDetl.getSourst());
		entity.setAcctdt(glaAeuvDetl.getSourdt());
		entity.setBrchcd(glaAeuvDetl.getAcctbr());
		entity.setItemcd(glaAeuvDetl.getItemcd());
		entity.setCrcycd(glaAeuvDetl.getCrcycd());
		entity.setDrtsam(BigDecimal.ZERO);
		entity.setDrtsnm(0);
		entity.setCrtsam(BigDecimal.ZERO);
		entity.setCrtsnm(0);
		entity.setDrctbl(BigDecimal.ZERO);
		entity.setCrctbl(BigDecimal.ZERO);
		entity.setBlncdn(itemdn);
		entity.setOnlnbl(BigDecimal.ZERO);
		entity.setLastdn(itemdn);
		entity.setLastbl(BigDecimal.ZERO);
		entity.setGeldtp("D");
		entity.setCentcd(glaAeuvDetl.getCentcd());
		entity.setPrsncd(glaAeuvDetl.getPrsncd());
		entity.setCustcd(glaAeuvDetl.getCustcd());
		entity.setPrducd(glaAeuvDetl.getPrducd());
		entity.setPrlncd(glaAeuvDetl.getPrlncd());
		entity.setAcctno(glaAeuvDetl.getAcctno());
		entity.setAssis0(glaAeuvDetl.getAssis0());
		entity.setAssis1(glaAeuvDetl.getAssis1());
		entity.setAssis2(glaAeuvDetl.getAssis2());
		entity.setAssis3(glaAeuvDetl.getAssis3());
		entity.setAssis4(glaAeuvDetl.getAssis4());
		entity.setAssis5(glaAeuvDetl.getAssis5());
		entity.setAssis6(glaAeuvDetl.getAssis6());
		entity.setAssis7(glaAeuvDetl.getAssis7());
		entity.setAssis8(glaAeuvDetl.getAssis8());
		entity.setAssis9(glaAeuvDetl.getAssis9());

		return entity;
	}

	/**
	 * �������ԺϷ���У��
	 * 
	 * @param glisEntity
	 * @throws BimisException
	 */
	public static void checkProperty(GlaGlis glisEntity) throws BimisException {
		// �쳣��Ϣ
		String message = "";
		// ���򣨽衢�����ա������Ϸ���У��
		if (!(glisEntity.getBlncdn().equals(Enumeration.Amntcd.D.value) || glisEntity.getBlncdn().equals(Enumeration.Amntcd.C.value) || glisEntity.getBlncdn().equals(Enumeration.Amntcd.P.value) || glisEntity
				.getBlncdn().equals(Enumeration.Amntcd.R.value))) {
			message = "��ǰ���ˣ����ף�" + glisEntity.getStacid() + "�ݻ�����" + glisEntity.getBrchcd() + "�ݿ�Ŀ��" + glisEntity.getItemcd() + "�ݱ��֣�" + glisEntity.getCrcycd() + "�ݵ������" + glisEntity.getBlncdn()
					+ "�ݷǷ�����ҵ���ֵ䲻����";
			logger.error(message);
			throw new BimisException("3000", message);
		}
	}

	// ƴװ���˵�����
	public static String getGlisKey(GlaGlis glaGlis) {
		return String.valueOf(glaGlis.getStacid()).concat(DTAG).concat(glaGlis.getAcctdt()).concat(DTAG).concat(glaGlis.getSystid()).concat(DTAG).concat(glaGlis.getBrchcd()).concat(DTAG)
				.concat(glaGlis.getItemcd()).concat(DTAG).concat(glaGlis.getCrcycd()).concat(DTAG).concat(glaGlis.getGeldtp()).concat(DTAG).concat(glaGlis.getCentcd()).concat(DTAG)
				.concat(glaGlis.getPrsncd()).concat(DTAG).concat(glaGlis.getCustcd()).concat(DTAG).concat(glaGlis.getPrducd()).concat(DTAG).concat(glaGlis.getPrlncd()).concat(DTAG)
				.concat(glaGlis.getAcctno()).concat(DTAG).concat(glaGlis.getAssis0()).concat(DTAG).concat(glaGlis.getAssis1()).concat(DTAG).concat(glaGlis.getAssis2()).concat(DTAG)
				.concat(glaGlis.getAssis3()).concat(DTAG).concat(glaGlis.getAssis4()).concat(DTAG).concat(glaGlis.getAssis5()).concat(DTAG).concat(glaGlis.getAssis6()).concat(DTAG)
				.concat(glaGlis.getAssis7()).concat(DTAG).concat(glaGlis.getAssis8()).concat(DTAG).concat(glaGlis.getAssis9());
	}
}
