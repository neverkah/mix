package com.sunline.sunfe.dayend.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.JrafSession;
import com.sunline.suncm.util.Constants;
import com.sunline.suncm.util.Enumeration;
import com.sunline.suncm.util.JrafSessionUtil;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.suncm.util.StringUtils;
import com.sunline.sunfe.core.bean.ComItemBean;
import com.sunline.sunfe.core.bean.GlaAcctBean;
import com.sunline.sunfe.dayend.IDayEndProcesser;
import com.sunline.sunfe.entity.AccountingItem;
import com.sunline.sunfe.entity.GlaAcct;
import com.sunline.sunfe.entity.GlaAeuvDetl;
import com.sunline.sunfe.util.ClpConfUtil;
import com.sunline.suncm.util.ComParaUtil;

/**
 * @ClassName: SynEbsGlaAcct
 * @Description: ͬ�����ݵ��˻���GLA_ACCT
 * @author: huangzhongjie
 * @date: 2018��1��6�� ����2:12:33
 */
public class DayEndSynGlaAcctProcesser extends IDayEndProcesser {

	@Override
	public void preProcess() throws BimisException {
		getCommonDao();
	}

	@Override
	public void processing() throws BimisException {

		try {
			synGlaAcct();
		} catch (Exception e) {
			e.printStackTrace();
			throw new BimisException("-1", "ͬ���˻�������" + e.getMessage());
		} finally {
			closeSession();
		}

	}

	@Override
	public void processed() throws BimisException {

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void synGlaAcct() throws BimisException {
		String s_stacid = SessionParaUtils.getStacid();
		int stacid = Integer.valueOf(s_stacid);
		// �����Ŀ sysEbsGlisFundItem����ֵΪ�����ͬҵ��Ŀ,ͬҵ��ſ�Ŀ ����10110101,20220101
		String sysItemcd = ComParaUtil.getParavl(s_stacid, "sysEbsGlisFundItem");
		if (null == sysItemcd) {
			throw new BimisException("-1", "���ײ���[sysEbsGlisFundItem]û������");
		}

		String[] arrItemcds = sysItemcd.split(",");
		List itemcdLst = new ArrayList();
		Map<String, String> mapItemcd = new HashMap<String, String>();
		for (int i = 0; i < arrItemcds.length; i++) {
			itemcdLst.add(arrItemcds[i]);
			mapItemcd.put(arrItemcds[i], arrItemcds[++i]);
		}

		Map mapParam = new HashMap();

		mapParam.put("itemcds", itemcdLst);
		mapParam.put("acctdt", PubUtil.getGlisdt(stacid));
		mapParam.put("stacid", stacid);

		List<Map> glaAcctLst = commonDao.getSqlSession().selectList("com.sunline.sunfe.mybatis.synebsglaacct.getGlaAcctByAcctdtItemcd", mapParam);

		for (Map mapGlaAcct : glaAcctLst) {
			JrafSession jrafSessionGlaAcct = null;
			CommonDao commonDaoGlaAcct = null;
			try {
				jrafSessionGlaAcct = JrafSessionUtil.getJrafSession(null);
				commonDaoGlaAcct = new CommonDao(jrafSessionGlaAcct);
				commonDaoGlaAcct.beginTransaction();
				prcOneGlaAcct(commonDaoGlaAcct, stacid, mapItemcd, mapGlaAcct);
				commonDaoGlaAcct.commitTransaction();
			} catch (Exception e) {
				if (null != commonDaoGlaAcct) {
					commonDaoGlaAcct.rollBack();
				}
				throw e;
			} finally {
				JrafSessionUtil.closeConnection(jrafSessionGlaAcct);
			}
		}

	}

	/**
	 * @Title: prcOneGlaAcct
	 * @Description: ����һ���˻�����
	 * @param s_stacid
	 * @param stacid
	 * @param mapItemcd
	 * @param mapParam
	 * @param mapGlaAcct
	 * @throws BimisException
	 */
	private void prcOneGlaAcct(CommonDao commonDaoGlaAcct, int stacid, Map<String, String> mapItemcd, Map mapGlaAcct) throws BimisException {
		// �¼�����
		String brchno = mapGlaAcct.get("brchno").toString();
		String crcycd = mapGlaAcct.get("crcycd").toString();
		String itemcd = mapGlaAcct.get("itemcd").toString();

		BigDecimal drctbl = new BigDecimal(mapGlaAcct.get("drbl").toString());
		BigDecimal crctbl = new BigDecimal(mapGlaAcct.get("crbl").toString());

		// ͬ���¼�������׼�˻�
		generateGlaAcct(commonDaoGlaAcct, stacid, brchno, null, crcycd, itemcd, drctbl, crctbl);

		// ��������
		String upperBrchno = ClpConfUtil.getClerBrch(stacid, brchno,crcycd);
		// ͬ����������ר���˻�����Ŀ��Ϊ�¼�������
		generateGlaAcct(commonDaoGlaAcct, stacid, upperBrchno, brchno, crcycd, mapItemcd.get(itemcd), drctbl.negate(), crctbl.negate());

	}

	/**
	 * @Title: generateGlaAcct
	 * @Description: ͬ�������˻���GLA_ACCT����
	 * @param commonDaoGlaAcct
	 * @param stacid
	 * @param brchno
	 * @param subscd
	 * @param crcycd
	 * @param itemcd
	 * @param drctbl
	 * @param crctbl
	 * @throws BimisException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void generateGlaAcct(CommonDao commonDaoGlaAcct, int stacid, String brchno, String subscd, String crcycd, String itemcd,
			BigDecimal drctbl, BigDecimal crctbl) throws BimisException {

		// ��ѯ�˻��Ƿ����
		GlaAcct glaAcct = queryGlaAcct(stacid, brchno, itemcd, crcycd, subscd);
		AccountingItem comItem = ComItemBean.getAccountingItemByPrimaryKey(stacid, itemcd);

		if (null == glaAcct) {
			String systid = Constants.c_Systgl;
			GlaAeuvDetl glaAeuvDetl = new GlaAeuvDetl();
			glaAeuvDetl.setItemcd(itemcd);
			glaAeuvDetl.setAcctbr(brchno);
			glaAeuvDetl.setSourst(systid);
			glaAeuvDetl.setStacid(stacid);
			glaAeuvDetl.setCrcycd(crcycd);

			// �˻�����
			String acctcl = StringUtils.isEmpty(subscd) ? Enumeration.GLA_ACCT_ACCTLG.BASE.value : Enumeration.GLA_ACCT_ACCTLG.SPECIALUSE.value;
			// ����
			GlaAcctBean.openAcctcd(commonDaoGlaAcct, glaAeuvDetl, acctcl, subscd);

			// ר���˻���ʼ����������������
			if (StringUtils.isNotEmpty(subscd)) {
				// ��������������
				Map map = new HashMap();
				map.put("acmlbl", BigDecimal.ZERO);
				map.put("acmldt", PubUtil.getGlisdt(stacid));
				map.put("brchno", brchno);
				map.put("itemcd", itemcd);
				map.put("crcycd", crcycd);
				map.put("stacid", stacid);
				map.put("subscd", subscd);
				commonDaoGlaAcct.updateByNamedSql("com.sunline.sunfe.mybatis.synebsglaacct.updateGlaAcctAcmlblAcmldt", map);
			}

		}

		Map mapBlDn = setBlDn(comItem, drctbl, crctbl);
		// ��������
		String blncdn = mapBlDn.get("dn").toString();
		// �������
		BigDecimal onlnbl = new BigDecimal(mapBlDn.get("bl").toString());

		Map mapParam = new HashMap();
		mapParam.put("brchno", brchno);
		mapParam.put("itemcd", itemcd);
		mapParam.put("crcycd", crcycd);
		mapParam.put("stacid", stacid);
		mapParam.put("subscd", subscd);
		mapParam.put("blncdn", blncdn);
		mapParam.put("onlnbl", onlnbl);

		commonDaoGlaAcct.updateByNamedSql("com.sunline.sunfe.mybatis.synebsglaacct.updateGlaAcctOnlnbl", mapParam);
	}

	/**
	 * @Title: setBlDn
	 * @Description:�����˻���������
	 * @param drctbl
	 * @param crctbl
	 * @param glaAcct
	 * @param comItem
	 */
	private Map setBlDn(AccountingItem comItem, BigDecimal drctbl, BigDecimal crctbl) {

		Map mapResult = new HashMap();

		if (Enumeration.Amntcd.D.value.equals(comItem.getItemdn())) {
			mapResult.put("dn", comItem.getItemdn());
			mapResult.put("bl", drctbl.subtract(crctbl));
		} else if (Enumeration.Amntcd.C.value.equals(comItem.getItemdn())) {
			mapResult.put("dn", comItem.getItemdn());
			mapResult.put("bl", crctbl.subtract(drctbl));
		} else if (Enumeration.Amntcd.B.value.equals(comItem.getItemdn()) || Enumeration.Amntcd.Z.value.equals(comItem.getItemdn())) {
			if (drctbl.subtract(crctbl).compareTo(BigDecimal.ZERO) >= 0) {
				mapResult.put("dn", Enumeration.Amntcd.D.value);
				mapResult.put("bl", drctbl.subtract(crctbl));
			} else {
				mapResult.put("dn", Enumeration.Amntcd.C.value);
				mapResult.put("bl", drctbl.subtract(crctbl).abs());
			}
		}

		return mapResult;
	}

	private GlaAcct queryGlaAcct(int stacid, String brchno, String itemcd, String crcycd, String subscd) {
		Map mapQuery = new HashMap();
		// ��ѯ�˻��Ƿ����
		mapQuery.clear();
		mapQuery.put("brchno", brchno);
		mapQuery.put("itemcd", itemcd);
		mapQuery.put("crcycd", crcycd);
		mapQuery.put("subscd", subscd);
		mapQuery.put("stacid", stacid);

		GlaAcct glaAcct = commonDao.getSqlSession().selectOne("com.sunline.sunfe.mybatis.glaacct.queryGlaAcctByBrchItemCrcySubs", mapQuery);

		return glaAcct;

	}

}
