package com.sunline.sunfe.test;

/**
 * 
 * @ClassName: ZhangdqTest 
 * @Description: TODO
 * @author: zhangdq
 * @date: 2016-8-25 ����2:44:58
 */
public class ZhangdqTest {

	/** 
	 * @Title: main 
	 * @Description: TODO
	 * @param args
	 * @return: void
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*		String execSql = "1;2;3;";
		String[] sqls = execSql.split(";");
		System.out.println(sqls.length);
		*/
		try {
			Object obj = Class.forName("com.sunline.sunfe.datamanager.InvoiceGliFechPlanAction").newInstance();
			
			System.out.println(obj);
		
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
