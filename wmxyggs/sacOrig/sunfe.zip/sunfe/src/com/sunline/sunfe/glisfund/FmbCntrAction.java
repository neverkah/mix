package com.sunline.sunfe.glisfund;

import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.sunfe.util.MybatisPathUtil;

/**
 * @author ����
 * @Email xiongl@sunline.cn
 * @Time 2018��1��3��
 * @��������ã���ͬ��Ϣ
 */
@SuppressWarnings("unchecked")
public class FmbCntrAction extends Actor {
	private static final Logger logger = LoggerFactory.getLogger(FmbCntrAction.class);
	/**
	 * @throws JDOMException
	 * @�˷��������ã���ѯ��ͬ��Ϣ
	 */
	public void queryFmbCntrInfo() throws JDOMException {
		try {
			Map<String, Object> map = req.getReqDataMap();
			Element e = commonDao.queryByNamedSql(MybatisPathUtil.FMB_CNTR + "queryFmbCntrInfo", map);
			req.addRspData(e.removeContent());
			new PublicFmbCntrInfoUtil(commonDao).addReqInfoTo(map, req);
		} catch (JDOMException | BimisException e) {
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "��ѯʧ��" + e.getMessage());
		}
	}

}
