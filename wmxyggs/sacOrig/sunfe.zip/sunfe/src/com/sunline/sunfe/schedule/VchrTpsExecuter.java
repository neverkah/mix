package com.sunline.sunfe.schedule;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.services.JrafSessionFactory;
import com.sunline.jraf.util.Log;
import com.sunline.sunfe.util.StringUtils;
import com.taobao.pamirs.schedule.strategy.IStrategyTask;

public class VchrTpsExecuter implements IStrategyTask,Runnable{
	private static Log log = new Log(VchrTpsExecuter.class.getName());
	private static final String Tps_Minute="5";
	public String MY_BATIS_SYSMONIT="com.sunline.sunfe.mybatis.sysMonit.";
	private String parameter;
    private boolean stop = false;
	@Override
	public void initialTaskParameter(String taskParameter) {
		parameter = taskParameter;
		new Thread(this).start();
	}

	@Override
	public void stop() throws Exception {
		this.stop = true;
		
	}

	@Override
	public void run(){
		while(stop == false){
			log.logDebug("��ǰ�������:"+parameter);
			HashMap<String, String> map = StringUtils.String2Map(parameter);
			String stacid = map.get("stacid");
			//String minute=map.get("minute");//ǰ̨��ȡ��ʱ�䣬�������ٷ���ִ��һ��
			int curMin=new Date().getMinutes();
			int sec=new Date().getSeconds();
			if(curMin%Integer.parseInt(Tps_Minute)==0&&sec/2==0){
				
			
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			JrafSession jrafSession=null;
			try {
				 Date curt=format.parse(format.format(new Date()));
				//��ȡ��ǰʱ���ʱ�������ȷ���룩
				Timestamp current=new Timestamp(curt.getTime());
				//����dao��ѯ���ݿ�������
				jrafSession=this.getJrafSession(null);
				CommonDao commonDao = new CommonDao(jrafSession);
				this.getVchrTpsData(commonDao,stacid,current);
				Integer min=Integer.parseInt(Tps_Minute);
				Thread.sleep(min*60*1000-2000);
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				this.closeConnection(jrafSession);
			}
			}else{
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	 private void getVchrTpsData(CommonDao commonDao,String stacid,Timestamp current) throws Exception{
		 commonDao.beginTransaction();  
		 HashMap map=new HashMap();
		    map.put("stacid", stacid);
		    //����ָ�����׻�ȡ�������ڹ���ѯ
		    DateFormat fm = new SimpleDateFormat("yyyyMMdd");
		    
			String trandt =fm.format(new Date());
			map.put("trandt", trandt);
			map.put("trandtStart", trandt+" 00:00:00");
			map.put("trandtEnd", trandt+" 23:59:59");
			map.put("trannow", current);
			for(int tranType=0;tranType<5;tranType++){
				if(tranType==0){
					map.put("tranType", tranType);//���ݼӹ����ͣ�0
					//��ѯ���ݼӹ�������
					Integer prs=commonDao.getSqlSession().selectOne(MY_BATIS_SYSMONIT+"queryForPrs", map);
					//��ѯ�ϴ����ݼӹ������������ݵ�ǰ���ݿ���ʱ���Ž���
					 map.put("trannm", prs);//��������
					    List<HashMap> lst=this.getLastTranTime(commonDao, map,tranType);
					if(lst.size()==0||"".equals(lst)||null==lst){
						map.put("tranlast",current);
					}else{
						Timestamp tranlast=this.getTranLastTime(lst);
						map.put("tranlast",tranlast);
					}
					commonDao.insertByNamedSql(MY_BATIS_SYSMONIT+"InsertData", map);
					}else if(tranType==1){
						map.put("tranType", tranType);//���ݽ������ͣ�1
					//��ѯ������������������
				    Integer pas=commonDao.getSqlSession().selectOne(MY_BATIS_SYSMONIT+"queryForPas", map);
				    map.put("trannm", pas);//��������
				    List<HashMap> lst=this.getLastTranTime(commonDao, map,tranType);
				    if(lst.size()==0||"".equals(lst)||null==lst){
						map.put("tranlast",current);
					}else{
						Timestamp tranlast=this.getTranLastTime(lst);
						map.put("tranlast",tranlast);
					}
				    commonDao.insertByNamedSql(MY_BATIS_SYSMONIT+"InsertData", map);
					}else if(tranType==2){
						map.put("tranType", tranType);//�����������ͣ�2
						 //��ѯ�����������˵�����
					    Integer ens=commonDao.getSqlSession().selectOne(MY_BATIS_SYSMONIT+"queryForEns", map);
					    map.put("trannm", ens);//��������
					    List<HashMap> lst=this.getLastTranTime(commonDao, map,tranType);
					    if(lst.size()==0||"".equals(lst)||null==lst){
							map.put("tranlast",current);
						}else{
							Timestamp tranlast=this.getTranLastTime(lst);
							map.put("tranlast",tranlast);
						}
					    commonDao.insertByNamedSql(MY_BATIS_SYSMONIT+"InsertData", map);
					}else if(tranType==3){
						map.put("tranType", tranType);//ʵʱ������ˮ�������ͣ�3
						 //��ѯʵʱ������ˮ����������
					    Integer intPasSuc=commonDao.getSqlSession().selectOne(MY_BATIS_SYSMONIT+"queryForIntPas", map);
					    map.put("trannm", intPasSuc);//��������
					    List<HashMap> lst=this.getLastTranTime(commonDao, map,tranType);
					    if(lst.size()==0||"".equals(lst)||null==lst){
							map.put("tranlast",current);
						}else{
							Timestamp tranlast=this.getTranLastTime(lst);
							map.put("tranlast",tranlast);
						}
					    commonDao.insertByNamedSql(MY_BATIS_SYSMONIT+"InsertData", map);
					}else if(tranType==4){
						map.put("tranType", tranType);//ʵʱ������ˮ�������ͣ�4
						//��ѯʵʱ��Ʊ��ˮ���˵�����
					    Integer intVchrSuc=commonDao.getSqlSession().selectOne(MY_BATIS_SYSMONIT+"queryForIntVchr", map);
					    map.put("trannm", intVchrSuc);//��������
					    List<HashMap> lst=this.getLastTranTime(commonDao, map,tranType);
					    if(lst.size()==0||"".equals(lst)||null==lst){
							map.put("tranlast",current);
						}else{
							Timestamp tranlast=this.getTranLastTime(lst);
							map.put("tranlast",tranlast);
						}
					    commonDao.insertByNamedSql(MY_BATIS_SYSMONIT+"InsertData", map);
					    break;
			}
			}
			commonDao.commitTransaction(); 
	}

	/**
     * ����session
     * @param jrafSession
     * @return
     */
	private JrafSession getJrafSession(JrafSession jrafSession) {
		try {
			if (jrafSession == null || jrafSession.getConnection() == null || jrafSession.getConnection().isClosed()) {
				jrafSession = JrafSessionFactory.getInstance().openSession();
			}
		} catch (Exception e) {
			log.logError("���Ȼ�ȡJrafSessionʧ��", e);
		}
		return jrafSession;
	}
	public static void closeConnection(JrafSession jrafSession) {
		try {
			if (jrafSession != null && jrafSession.getConnection() != null && !jrafSession.getConnection().isClosed()) {
				jrafSession.close();
				jrafSession = null;
			}
		} catch (SQLException e) {
			log.logError("�ر�JrafSessionʧ��", e);

		}
	}
	
	public static String getGlisdt(int stacid, CommonDao commonDao) {
		String glisdt = null;
		try {
			Map<String, Integer> paMap = new HashMap<String, Integer>();
			paMap.put("stacid", stacid);
			HashMap hashMapStac = commonDao.getSqlSession().selectOne("com.sunline.sunfe.mybatis.stacinfo.queryStacInfoDetail",
					paMap);

			glisdt = hashMapStac.get("glisdt").toString();
		} catch (Exception e) {
			log.logError("ͨ������id ��ȡ��������ʧ��", e);
		}
		return glisdt;
	}
	
	public Timestamp getTranLastTime(List<HashMap> lst)throws Exception{
		String tranl = null;
		Iterator iter=lst.get(0).entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry entry = (Map.Entry) iter.next();
			tranl=entry.getValue().toString();
		}
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		format.setLenient(false);
		
			Timestamp tranlast = new Timestamp(format.parse(tranl).getTime());
		
		return tranlast;
		
	}
	/*
	 * ��ȡ��һ�εĽ���ʱ��
	 */
	public List<HashMap> getLastTranTime(CommonDao commonDao,HashMap map,Integer tranType){
		/*
		 * ��ѯ��һ�β����ļ�¼ʱ�䣬��COM_DAYBUSI_TPS���е�tranNow�ֶ��в�ѯ��
		 * ���ݽ������в�ȡ����һ�β�����ʱ��
		 */
		List<HashMap> lst=commonDao.getSqlSession().selectList(MY_BATIS_SYSMONIT+"queryForDate", map);
		return lst;
		
	}
}