package com.sunline.sunfe.conf;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.sunfe.util.StringUtils;

public class TmprAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.tmpr.";
	Log log =new Log("TmprAction");
	/**
	 * ��ѯ������ҵ��ģ������б� & queryTmprListPage
	 */
	public void queryTmprListPage(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String prcsna = req.getReqDataStr("prcsna");
			String tmplna = req.getReqDataStr("tmplna");
			
			String pageNo = req.getReqDataStr("pageNum");
			if (StringUtils.isNotEmpty(pageNo)) {
				req.setReqPageNo(Integer.parseInt(pageNo));
			}
			hashmap.put("prcsna", prcsna);
			hashmap.put("tmplna", tmplna);
			hashmap.put("vermod", "0");
			
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryTmprlistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			log.logError(e);
		}
	}
	/**
	 * ��ѯ�������ӽ���ģ�������Ϣ
	 */
	public void queryTmprInfo(){
		try 
		{
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String prcscd = req.getReqDataStr("prcscd");
			String sortno = req.getReqDataStr("sortno");
			String dttrcd = req.getReqDataStr("dttrcd");
			String tmpltp = req.getReqDataStr("tmpltp");
			String tmplid = req.getReqDataStr("tmplid");
			String trtlno = req.getReqDataStr("trtlno");
			
			hashmap.put("prcscd", prcscd);
			hashmap.put("sortno", sortno);
			hashmap.put("dttrcd", dttrcd);
			hashmap.put("tmpltp", tmpltp);
			hashmap.put("tmplid", tmplid);
			hashmap.put("trtlno", trtlno);
			
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryTmprInfo", hashmap);	
            req.addRspData(e.removeContent());        //���ؽ����װ	
		} catch (Exception e) {
			log.logError(e);
		}
	 }	
	
	
	/**
	 *  ������ҵ��ģ�������Ϣ¼��
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addTmpr() throws JDOMException{
		try {
			commonDao.beginTransaction();
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTmpr", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "�ô�����ҵ��ģ�������Ѵ��ڣ�");
					return;
				}
			}
			commonDao.insertByNamedSql(MYBATIS_NS+"addTmpr", hashmap);
		  	ResultUtils.setRspData(req, "200",  "�����ɹ�", "tmpr_main", "closeCurrent", "");
			commonDao.commitTransaction();
		} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
	  }
		
	}
	/**
	 * ɾ��������ҵ��ģ�������Ϣ
	 * @throws JDOMException 
	 */
	 public void deleteTmpr() throws JDOMException {
		try{ 
		 HashMap<String, String> param = new HashMap<String, String>();
         List<String> tisncdList = req.getReqDataTexts("tisncd");
         commonDao.beginTransaction();
         for (int i=0;i<tisncdList.size();i++) {
         	param.clear();
             String [] array = tisncdList.get(i).split("-");//��ȡҳ���װ�õ������ַ���������ȡ�������鵱��
             param.put("tmpltp", array[0]);
             param.put("tmplid", array[1]);
             param.put("sortno", array[2]);
             param.put("trtlno", array[3]);
             param.put("prcscd", array[4]);
             param.put("dttrcd", array[5]);
             
             commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTmpr", param);
         }
         	commonDao.commitTransaction();
		  	ResultUtils.setRspData(req, "200",  "�����ɹ�", "tmpr_main", "", "");
       } catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
	  }
	}	
}
