package com.sunline.sunfe.entity;

import java.util.Date;

/**
 * @ClassName: ComDayendPf
 * @Description: ���ղ��� ��־��¼bean ���ݿ��com_dayendlogm
 * @author: huangzhongjie
 * @date: 2017��9��15�� ����3:08:27
 */

public class ComDayendlg {

	private String bsnsdt; // ҵ������
	private Integer stacid; // ����
	private String edcttp; // �������
	private Integer edstep; // ���ղ���
	private String procna; //��������
	private Date begidt; // ��ʼʱ��
	private Date overdt; // ����ʱ��
	private Integer durati;// ����ʱ��

	private String status; // ״̬
	private String erortx; // ������־

	public String getErortx() {
		return erortx;
	}

	public void setErortx(String erortx) {
		this.erortx = erortx;
	}

	public String getBsnsdt() {
		return bsnsdt;
	}

	public void setBsnsdt(String bsnsdt) {
		this.bsnsdt = bsnsdt;
	}

	public Integer getStacid() {
		return stacid;
	}

	public void setStacid(Integer stacid) {
		this.stacid = stacid;
	}

	public String getEdcttp() {
		return edcttp;
	}

	public void setEdcttp(String edcttp) {
		this.edcttp = edcttp;
	}

	public Integer getEdstep() {
		return edstep;
	}

	public void setEdstep(Integer edstep) {
		this.edstep = edstep;
	}

	public String getProcna() {
		return procna;
	}

	public void setProcna(String procna) {
		this.procna = procna;
	}

	public Date getBegidt() {
		return begidt;
	}

	public void setBegidt(Date begidt) {
		this.begidt = begidt;
	}

	public Date getOverdt() {
		return overdt;
	}

	public void setOverdt(Date overdt) {
		this.overdt = overdt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getDurati() {
		return durati;
	}

	public void setDurati(Integer durati) {
		this.durati = durati;
	}

}
