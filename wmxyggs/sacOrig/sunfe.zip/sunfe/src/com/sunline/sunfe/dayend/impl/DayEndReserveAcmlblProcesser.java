package com.sunline.sunfe.dayend.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.dayend.IDayEndProcesser;
import com.sunline.sunfe.glisfund.PublicFmbCntrInfoUtil;
import com.sunline.sunfe.util.DatetimeUtil;

/**
 * @author ����
 * @Email xiongl@sunline.cn
 * @Time 2017��12��27��
 * @��������ã��ڲ��ʽ��������
 */
public class DayEndReserveAcmlblProcesser extends IDayEndProcesser {
	private String stacid;
	private String trandt;
	private String preday;
	private CommonDao commonDao;
	private PublicFmbCntrInfoUtil publicFmbCntrInfo;

	/**
	 * @throws BimisException
	 * @�˷��������ã�
	 */
	@Override
	public void preProcess() throws BimisException {
		stacid = SessionParaUtils.getStacid();
		trandt = PubUtil.getGlisdt(Integer.valueOf(stacid));
		preday = DatetimeUtil.getNewPreDay(trandt);
		commonDao = this.getCommonDao();
		publicFmbCntrInfo = new PublicFmbCntrInfoUtil(commonDao);
	}

	/**
	 * @throws BimisException
	 * @�˷��������ã�������
	 */
	@Override
	public void processing() throws BimisException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("preday", preday);
		map.put("stacid", stacid);
		List<Map<String, Object>> list = publicFmbCntrInfo.selectGlaAcctAcmlbl(Integer.valueOf( stacid));
		try {
			commonDao.beginTransaction();
			for (int i = 0, len = list.size(); i < len; i++) {
				if (list.get(i).get("acmldt") == null || "".equals(list.get(i).get("acmldt")))
					throw new BimisException("601", "����Ϊ����" + stacid + "��,�˺�Ϊ����" + list.get(i).get("acctcd") + "�����˻����ݻ�������Ϊ�գ����ܽ��л�������");
				map.put("datediff", DatetimeUtil.datediff("day", list.get(i).get("acmldt") + "", trandt));
				map.put("acctcd", list.get(i).get("acctcd"));
				publicFmbCntrInfo.updateGlaAcctAcmlbl(map);
			}
			publicFmbCntrInfo.executeBatch(publicFmbCntrInfo.updateAcmlbl);
			commonDao.commitTransaction();
		} catch (SQLException e) {
			commonDao.rollBack();
			throw new BimisException("601", e.getMessage());
		} finally {
			publicFmbCntrInfo.closePreparedStatement(publicFmbCntrInfo.updateAcmlbl);
		}
	}

	/**
	 * @throws BimisException
	 * @�˷��������ã�
	 */
	@Override
	public void processed() throws BimisException {
	}

}
