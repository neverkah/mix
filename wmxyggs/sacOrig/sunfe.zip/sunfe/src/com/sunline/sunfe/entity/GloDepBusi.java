package com.sunline.sunfe.entity;

import java.math.BigDecimal;

public class GloDepBusi
{
  private int stacid;
  private String systid;
  private String cainsq;
  private String transq;
  private String trandt;
  private String acctbr;
  private String crcycd;
  private String itemcd;
  private BigDecimal tranam = BigDecimal.ZERO;
  private BigDecimal lastbl = BigDecimal.ZERO;
  private BigDecimal onlnbl = BigDecimal.ZERO;
  private String bkfnst;
  private String dtitcd;
  private String dptp01;
  private String dptp08;
  private String bathid;
  private String dptp10;

  public String getDptp10()
  {
    return this.dptp10;
  }
  public void setDptp10(String dptp10) {
    this.dptp10 = dptp10;
  }

  public BigDecimal getTranam()
  {
    return this.tranam;
  }

  public void setTranam(BigDecimal tranam)
  {
    this.tranam = tranam;
  }

  public BigDecimal getLastbl()
  {
    return this.lastbl;
  }

  public void setLastbl(BigDecimal lastbl)
  {
    this.lastbl = lastbl;
  }

  public BigDecimal getOnlnbl()
  {
    return this.onlnbl;
  }

  public void setOnlnbl(BigDecimal onlnbl)
  {
    this.onlnbl = onlnbl;
  }

  public String getAcctbr()
  {
    return this.acctbr;
  }

  public void setAcctbr(String acctbr)
  {
    this.acctbr = acctbr;
  }

  public String getDtitcd()
  {
    return this.dtitcd;
  }

  public void setDtitcd(String dtitcd)
  {
    this.dtitcd = dtitcd;
  }

  public String getDptp01()
  {
    return this.dptp01;
  }

  public void setDptp01(String dptp01)
  {
    this.dptp01 = dptp01;
  }

  public String getDptp08()
  {
    return this.dptp08;
  }

  public void setDptp08(String dptp08)
  {
    this.dptp08 = dptp08;
  }

  public int getStacid()
  {
    return this.stacid;
  }

  public void setStacid(int stacid)
  {
    this.stacid = stacid;
  }

  public String getSystid()
  {
    return this.systid;
  }

  public void setSystid(String systid)
  {
    this.systid = systid;
  }

  public String getTrandt()
  {
    return this.trandt;
  }

  public void setTrandt(String trandt)
  {
    this.trandt = trandt;
  }

  public String getCrcycd()
  {
    return this.crcycd;
  }

  public void setCrcycd(String crcycd)
  {
    this.crcycd = crcycd;
  }

  public String getItemcd()
  {
    return this.itemcd;
  }

  public void setItemcd(String itemcd)
  {
    this.itemcd = itemcd;
  }

  public String getCainsq()
  {
    return this.cainsq;
  }

  public void setCainsq(String cainsq)
  {
    this.cainsq = cainsq;
  }

  public String getTransq()
  {
    return this.transq;
  }

  public void setTransq(String transq)
  {
    this.transq = transq;
  }

  public String getBkfnst()
  {
    return this.bkfnst;
  }

  public void setBkfnst(String bkfnst)
  {
    this.bkfnst = bkfnst;
  }

  public String getBathid()
  {
    return this.bathid;
  }

  public void setBathid(String bathid)
  {
    this.bathid = bathid;
  }
}