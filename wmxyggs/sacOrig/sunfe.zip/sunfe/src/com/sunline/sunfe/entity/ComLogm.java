package com.sunline.sunfe.entity;

/**
 * 
 * @ClassName: ComLogm
 * @Description: ҵ����־��Ϣ�� com_logm
 * @author: zhangdq
 * @date: 2017-4-15 ����4:06:03
 */
public class ComLogm {
	private String bsnsdt;// ҵ������
	private String bsnssq;// ҵ����ˮ
	private String usercd;// �û�����
	private String brchcd;// ��������
	private String callpk;// ���ù���
	private String logmsg;// ��־��Ϣ

	public String getBsnsdt() {
		return bsnsdt;
	}

	public void setBsnsdt(String bsnsdt) {
		this.bsnsdt = bsnsdt;
	}

	public String getBsnssq() {
		return bsnssq;
	}

	public void setBsnssq(String bsnssq) {
		this.bsnssq = bsnssq;
	}

	public String getUsercd() {
		return usercd;
	}

	public void setUsercd(String usercd) {
		this.usercd = usercd;
	}

	public String getBrchcd() {
		return brchcd;
	}

	public void setBrchcd(String brchcd) {
		this.brchcd = brchcd;
	}

	public String getCallpk() {
		return callpk;
	}

	public void setCallpk(String callpk) {
		this.callpk = callpk;
	}

	public String getLogmsg() {
		return logmsg;
	}

	public void setLogmsg(String logmsg) {
		this.logmsg = logmsg;
	}
}
