package com.sunline.sunfe.entity;

import java.math.BigDecimal;

public class LoanBusi {
	
		private int stacid;
		private String systid;
		private String trandt;
		private String transq;
		private int serino;
		private String bsnssq;
		private String tranbr;
		private String acctbr;
		private String prcscd;
		private String prodcd;
		private String trantp;
		private String crcycd;
		private String bathid;
		public String getBathid() {
			return bathid;
		}
		public void setBathid(String bathid) {
			this.bathid = bathid;
		}
		
		/**
		 * �黹������Ϣ���
		 */
		private BigDecimal tranam = BigDecimal.ZERO;
		private String custcd;
		private String status;
		private String loanp1;
		private String loanp2;
		private String loanp3;
		private String loanp4;
		private String loanp5;
		private String loanp6;
		private String loanp7;
		private String loanp8;
		private String loanp9;
		private String loanpa;
		
		public String getSystid() {
			return systid;
		}
		public void setSystid(String systid) {
			this.systid = systid;
		}
		public String getTrandt() {
			return trandt;
		}
		public void setTrandt(String trandt) {
			this.trandt = trandt;
		}
		public String getTransq() {
			return transq;
		}
		public void setTransq(String transq) {
			this.transq = transq;
		}
		public String getTranbr() {
			return tranbr;
		}
		public void setTranbr(String tranbr) {
			this.tranbr = tranbr;
		}
		public String getAcctbr() {
			return acctbr;
		}
		public void setAcctbr(String acctbr) {
			this.acctbr = acctbr;
		}
		public String getPrcscd() {
			return prcscd;
		}
		public void setPrcscd(String prcscd) {
			this.prcscd = prcscd;
		}
		public String getTrantp() {
			return trantp;
		}
		public void setTrantp(String trantp) {
			this.trantp = trantp;
		}
		public String getCrcycd() {
			return crcycd;
		}
		public void setCrcycd(String crcycd) {
			this.crcycd = crcycd;
		}
		
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getProdcd() {
			return prodcd;
		}
		public void setProdcd(String prodcd) {
			this.prodcd = prodcd;
		}
		public String getLoanp1() {
			return loanp1;
		}
		public void setLoanp1(String loanp1) {
			this.loanp1 = loanp1;
		}
		public String getLoanp2() {
			return loanp2;
		}
		public void setLoanp2(String loanp2) {
			this.loanp2 = loanp2;
		}
		public String getLoanp3() {
			return loanp3;
		}
		public void setLoanp3(String loanp3) {
			this.loanp3 = loanp3;
		}
		public String getLoanp4() {
			return loanp4;
		}
		public void setLoanp4(String loanp4) {
			this.loanp4 = loanp4;
		}
		public String getLoanp5() {
			return loanp5;
		}
		public void setLoanp5(String loanp5) {
			this.loanp5 = loanp5;
		}
		public String getLoanp6() {
			return loanp6;
		}
		public void setLoanp6(String loanp6) {
			this.loanp6 = loanp6;
		}
		public String getBsnssq() {
			return bsnssq;
		}
		public void setBsnssq(String bsnssq) {
			this.bsnssq = bsnssq;
		}
		
		public String getCustcd() {
			return custcd;
		}
		public void setCustcd(String custcd) {
			this.custcd = custcd;
		}
	
		public int getStacid() {
			return stacid;
		}
		public void setStacid(int stacid) {
			this.stacid = stacid;
		}
		
		public String getLoanp7() {
			return loanp7;
		}
		public void setLoanp7(String loanp7) {
			this.loanp7 = loanp7;
		}
		public String getLoanp8() {
			return loanp8;
		}
		public void setLoanp8(String loanp8) {
			this.loanp8 = loanp8;
		}
		public String getLoanp9() {
			return loanp9;
		}
		public void setLoanp9(String loanp9) {
			this.loanp9 = loanp9;
		}
		public String getLoanpa() {
			return loanpa;
		}
		public void setLoanpa(String loanpa) {
			this.loanpa = loanpa;
		}
		public int getSerino() {
			return serino;
		}
		public void setSerino(int serino) {
			this.serino = serino;
		}
		
		
		 /**
		 * @return the tranam
		 */
		 
		public BigDecimal getTranam() {
			return tranam;
		}
		
		 /**
		 * @param tranam the tranam to set
		 */
		 
		public void setTranam(BigDecimal tranam) {
			this.tranam = tranam;
		}
	}
