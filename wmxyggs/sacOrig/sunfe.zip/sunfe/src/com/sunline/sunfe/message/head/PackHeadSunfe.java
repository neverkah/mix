
package com.sunline.sunfe.message.head;

import java.io.UnsupportedEncodingException;

/**
 * 
 * ���ɱ���ͷ
 *
 * @author yourname (mailto:yourname@primeton.com)
 */

public class PackHeadSunfe {
	
	private static final int SUNLINE_PACK_HEAD_LENGTH = 124;
	private static final int SUNLINE_PACK_LENGTH_LENGTH = 8;
	private static final int SUNLINE_PACK_CHECK_LENGTH = 16; //����У����
	private static final int SUNLINE_PACK_ID_LENGTH = 20;
	private static final int SUNLINE_PACK_TRAN_CODE_LENGTH = 8;
	private static final int SUNLINE_PACK_TIMEOUT_LENGTH = 6;
	private static final int SUNLINE_PACK_IP_LENGTH = 12;
	private static final int SUNLINE_PACK_SENDTP_LENGTH = 3;
	private static final int SUNLINE_PACK_TRANTP_LENGTH = 3;
	private static final int SUNLINE_PACK_DIRECTION_LENGTH = 3;
	private static final int SUNLINE_PACK_PASSWORD_LENGTH = 1;
	private static final int SUNLINE_PACK_SAVING_LENGTH = 44;
	private static final int SUNLINE_PACK_SESSION_ID_LENGTH = 5;
	private static final int SUNLINE_PACK_USER_ID_LENGTH = 8;
	private static final int SUNLINE_PACK_RESERVED_LENGTH = 12;
	private static final int SUNLINE_PACK_TYPE_LENGTH = 0;

	private static final int SUNLINE_PACK_LENGTH_OFFSET = 0;
	private static final int SUNLINE_PACK_CHECK_OFFSET = 8;
	private static final int SUNLINE_PACK_ID_OFFSET = 24;
	private static final int SUNLINE_PACK_TRAN_CODE_OFFSET = 44;
	private static final int SUNLINE_PACK_TIMEOUT_OFFSET = 52;
	private static final int SUNLINE_PACK_IP_OFFSET = 58;
	private static final int SUNLINE_PACK_SENDTP_OFFSET = 70;
	private static final int SUNLINE_PACK_TRANTP_OFFSET = 73;
	private static final int SUNLINE_PACK_DIRECTION_OFFSET = 76;
	private static final int SUNLINE_PACK_PASSWORD_OFFSET = 79;
	private static final int SUNLINE_PACK_SAVING_OFFSET = 80;
	private static final int SUNLINE_PACK_USER_ID_OFFSET = 44;
	private static final int SUNLINE_PACK_SESSION_ID_OFFSET = 39;
	private static final int SUNLINE_PACK_RESERVED_OFFSET = 52;
	private static final int SUNLINE_PACK_TYPE_OFFSET = 0;
	
	private static String charset;
	
	private static Integer packetId = new Integer(0);
	public  static  int getPacketId() {
		synchronized (packetId) {			
			return (packetId++).intValue();
		}
	}
	
	public static void setCharSet(String charSet){
		charset = charSet;
	}
	
	
	public static int getPackHeadLength(){
		return SUNLINE_PACK_LENGTH_LENGTH;
	}
	
	/**
	 * ȡsunfri���ĳ���
	 * @param len  ���ĳ���
	 * @return
	 */
	private static String getSunfiPackLen(int len){
		  
		 // int prefix = SUNLINE_PACK_HEAD_LENGTH - SUNLINE_PACK_LENGTH_LENGTH - 4;//����ͷ�������ĳ���
		 
		  //return (prefix+len) + "";
		  return String.format("%08d",len) + "";
	  }
	
	public static byte[] getLttsPackBySunfrs(String packStr,String prcscd,String userid,String sessionid,String bsnsdt)throws UnsupportedEncodingException{
		int len = packStr.getBytes(charset).length;
		byte[] bs = new byte[SUNLINE_PACK_LENGTH_LENGTH];
		
		byte[] bb = fixLength(getSunfiPackLen(len), SUNLINE_PACK_LENGTH_LENGTH);//�����ܳ��ȡ�10�����ַ���
		System.arraycopy(bb, 0, bs, SUNLINE_PACK_LENGTH_OFFSET, SUNLINE_PACK_LENGTH_LENGTH);
	
		return bs;
	
}
	
	
	public static byte[] getLttsPack(String packStr,String prcscd,String userid,String sessionid)throws UnsupportedEncodingException{
	
			int len = packStr.getBytes(charset).length;
			
			byte[] bs = new byte[len + SUNLINE_PACK_HEAD_LENGTH];
			byte[] bb = fixLength(len + SUNLINE_PACK_HEAD_LENGTH + "", SUNLINE_PACK_LENGTH_LENGTH);//�����ܳ��ȡ�10�����ַ���
			System.arraycopy(bb, 0, bs, SUNLINE_PACK_LENGTH_OFFSET, SUNLINE_PACK_LENGTH_LENGTH);
		
			bb = fixLengths(getPacketId()+"", SUNLINE_PACK_ID_LENGTH);//������ˮ�š��ͻ��˲���������Ψһ��
			System.arraycopy(bb, 0, bs, SUNLINE_PACK_ID_OFFSET, SUNLINE_PACK_ID_LENGTH);

			System.arraycopy(new byte[]{'0','0'}, 0, bs, SUNLINE_PACK_TYPE_OFFSET, SUNLINE_PACK_TYPE_LENGTH);//�������͡��ַ���00
			System.arraycopy(new byte[]{'0','0'}, 0, bs, SUNLINE_PACK_DIRECTION_OFFSET, SUNLINE_PACK_DIRECTION_LENGTH);//���ķ���00������99���ɹ����أ�������ʧ�ܷ��ء�
			
			bb = fixLength(prcscd, SUNLINE_PACK_TRAN_CODE_LENGTH);//������
			System.arraycopy(bb, 0, bs, SUNLINE_PACK_TRAN_CODE_OFFSET, SUNLINE_PACK_TRAN_CODE_LENGTH);
		
			bb = fixLength(userid, SUNLINE_PACK_USER_ID_LENGTH);//�û�����
			System.arraycopy(bb, 0, bs, SUNLINE_PACK_USER_ID_OFFSET, SUNLINE_PACK_USER_ID_LENGTH);
		
			bb = fixLength(sessionid, SUNLINE_PACK_SESSION_ID_LENGTH);//�Ự���ƴ��롣��¼���ģ�������userin������ո񣬵�¼�ɹ��󷵻ػỰ���ƴ��롣
			System.arraycopy(bb, 0, bs, SUNLINE_PACK_SESSION_ID_OFFSET, SUNLINE_PACK_SESSION_ID_LENGTH);
		
			bb = fixLength("", SUNLINE_PACK_RESERVED_LENGTH);//����������ո�
			System.arraycopy(bb, 0, bs, SUNLINE_PACK_RESERVED_OFFSET, SUNLINE_PACK_RESERVED_LENGTH);
			
			System.arraycopy(packStr.getBytes(charset), 0, bs, SUNLINE_PACK_HEAD_LENGTH, len);//����
			
			return bs;
		
	}
	
	private static byte[] fixLength(String src, int len) throws UnsupportedEncodingException {
		byte[] bs = src.getBytes(charset);
		int srcLen = bs.length;
		if (srcLen == len) {
			return src.getBytes(charset);
		} else if (srcLen < len) {
			StringBuffer bf = new StringBuffer();
			for (int i = 0; i < len - srcLen; i++) {
				bf.append(" ");
			}
			return (src + bf.toString()).getBytes(charset);
		} else {
			byte[] dest = new byte[len];
			System.arraycopy(bs, 0, dest, 0, len);
			return dest;
		}
	}
	
	private static byte[] fixLengths(String src, int len) throws UnsupportedEncodingException {
		byte[] bs = src.getBytes(charset);
		int srcLen = bs.length;
		if (srcLen == len) {
			return src.getBytes(charset);
		} else if (srcLen < len) {
			StringBuffer bf = new StringBuffer();
			for (int i = 0; i < len - srcLen; i++) {
				bf.append("0");
			}
			return (bf.toString() + src).getBytes(charset);
		} else {
			byte[] dest = new byte[len];
			System.arraycopy(bs, 0, dest, 0, len);
			return dest;
		}
	}

}
