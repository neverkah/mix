package com.sunline.sunfe.schedule;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.services.JrafSessionFactory;
import com.sunline.suncm.actor.common.DataDictParameter;
import com.sunline.sundp.entity.DistRelaBean;
import com.sunline.sundp.entity.GlaVchrBean;
import com.sunline.sundp.entity.GliVchrBean;
import com.sunline.sundp.entity.GloImdtBean;
import com.sunline.sundp.entity.ReturnData;
import com.sunline.sundp.entity.TrbTxlsBean;
import com.sunline.sundp.entity.TxaGlisBean;
import com.sunline.sundp.entity.TxaVchrBean;
import com.sunline.sundp.entity.TxbExrtBean;
import com.sunline.sundp.foundation.EnumerationBean;
import com.sunline.sundp.util.ComParaUtils;
import com.sunline.sundp.util.DatetimeUtil;
import com.sunline.sundp.util.NumberUtils;
import com.sunline.sundp.util.StringUtils;
import com.taobao.pamirs.schedule.IScheduleTaskDealSingle;
import com.taobao.pamirs.schedule.TaskItemDefine;

/**
 * ���ɼ�˰������ܵǼǲ�
 * 
 * @author zhanghong
 *
 */
public class PriceTaxSumRegExecute implements IScheduleTaskDealSingle<Object> {

	private static Log log = LogFactory.getLog(PriceTaxSumRegExecute.class);
	private JrafSession jrafSession = null;
	private static Map<String, HashMap<?, ?>> txptypeMapBykey = new HashMap<String, HashMap<?, ?>>();
	private static String ConfKey = "";
	private static String[] confKeys;

	public static final String OPENFQ_M = "M"; // ÿ��
	public static final String OPENFQ_Q = "Q"; // ÿ����
	public static final String OPENFQ_H = "H"; // ÿ����
	public static final String Crcycd_CNY = "CNY"; // �����
	public static final String Crcycd_CC = "CCC"; // �ۺ������
	private static String item10 = "M11";// ��Ŀ����Ϊ������Ʒת�á����׼�˰
	private static final String DATACH = "hzj_cert";
	public final static String IMPORT_COMPLETED = "1";// �ɹ�
	public final static String IMPORT_FAILED = "2";// ʧ��
	public final static String IMPORT_ING = "0";// ���ݴ�����

	private String stacid = "";
	@SuppressWarnings("unused")
	private String systid = "";
	private String bsnsdt = "";
	private final String FIND_GLO_IMDT_BY_KEY_TYPE = "select stacid,sourst,sourdt,acctbr,bathid,"
			+ "usercd,brchcd,status,nextdt,currdt,switdt,plancd,datach, typecd "
			+ "from glo_imdt where STACID = ? and BATHID = ? and PLANCD = ? "
			+ "and TYPECD ='1'";
	private static final String INSERT_GLO_IMDT = "INSERT INTO GLO_IMDT (STACID, SOURST, SOURDT, "
			+ "ACCTBR, BATHID, USERCD, BRCHCD, STATUS, NEXTDT, CURRDT, SWITDT, PLANCD, DATACH, TYPECD) "
			+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	private static final String UPDATE_GLO_IMDT_STATUS = "UPDATE GLO_IMDT SET STATUS = ? WHERE"
			+ " STACID = ? AND BATHID = ? AND PLANCD = ? AND DATACH = ?AND TYPECD ='1'";

	/**
	 * ��ȡ����
	 * 
	 * @param trandt
	 * @param crcycd
	 * @return
	 * @throws BimisException
	 */
	private TxbExrtBean getTxbExrt(String trandt, String crcycd)
			throws BimisException {
		CommonDao commonDao = new CommonDao(this.getJrafSession());
		TxbExrtBean txbExrtInfo = new TxbExrtBean();
		try {

			HashMap<String, String> queryMap = new HashMap<String, String>();
			queryMap.put("trandt", trandt);
			queryMap.put("crcycd", crcycd);
			queryMap.put("tocrcy", Crcycd_CNY);

			@SuppressWarnings("unchecked")
			List<TxbExrtBean> TxbExrtLists = (List<TxbExrtBean>) commonDao
					.queryByNamedSqlForList(
							"com.sunline.sundp.mybatis.gl.queryTxbExrtbyCrcycd",
							queryMap);
			if (TxbExrtLists.size() < 1) {
				throw new BimisException("-1", "δ�ҵ�����" + crcycd + "����Ļ���");
			}
			txbExrtInfo = TxbExrtLists.get(0);
		} catch (BimisException e) {
			throw new BimisException("-1", "��ȡ������Ϣʧ�ܣ�" + e.getErrmsg());
		}
		return txbExrtInfo;
	}

	private TxbExrtBean getTxbExrtByCrcysd(String trandt, String crcycd,
			String crcysd) throws BimisException {
		CommonDao commonDao = new CommonDao(this.getJrafSession());
		TxbExrtBean txbExrtInfo = new TxbExrtBean();
		try {

			HashMap<String, String> queryMap = new HashMap<String, String>();
			queryMap.put("trandt", trandt);
			queryMap.put("crcycd", crcycd);
			queryMap.put("tocrcy", crcysd);// ��λ��

			@SuppressWarnings("unchecked")
			List<TxbExrtBean> TxbExrtLists = (List<TxbExrtBean>) commonDao
					.queryByNamedSqlForList(
							"com.sunline.sundp.mybatis.gl.queryTxbExrtbyCrcycd",
							queryMap);
			if (TxbExrtLists.size() < 1) {
				throw new BimisException("-1", "δ�ҵ�����" + crcycd + "����Ļ���");
			}
			txbExrtInfo = TxbExrtLists.get(0);
		} catch (BimisException e) {
			throw new BimisException("-1", "��ȡ������Ϣʧ�ܣ�" + e.getErrmsg());
		}
		return txbExrtInfo;
	}

	/**
	 * ���ܵ������
	 * 
	 * @param stacid
	 * @param bsnsdt
	 * @param txprmh
	 *            �걨Ƶ��
	 * @param DeptSQL
	 * @throws BimisException
	 */
	private void GliVchrSumm(String stacid, String bsnsdt, String txprmh,
			String DeptSQL) throws BimisException {
		String lastmh = "", begndt = "", conmth = "";
		// ��ǰ��
		conmth = bsnsdt.substring(0, 6);
		CommonDao commonDao = new CommonDao(this.getJrafSession());
		if (OPENFQ_M.equals(txprmh)) {
			if (!"01".equals(bsnsdt.substring(4, 6))) {
				// ����
				lastmh = String.valueOf((Integer.parseInt(bsnsdt
						.substring(0, 6)) - 1));
			}
			begndt = bsnsdt.substring(0, 6) + "01";
		} else if (OPENFQ_Q.equals(txprmh)) {
			if (!"03".contains(bsnsdt.substring(4, 6))) {
				lastmh = String.valueOf((Integer.parseInt(bsnsdt
						.substring(0, 6)) - 3));
			}
			begndt = String
					.valueOf((Integer.parseInt(bsnsdt.substring(0, 6)) - 2))
					+ "01";
		}
		HashMap<String, String> queryTxaGlisMap = new HashMap<String, String>();
		HashMap<String, String> hashmap = new HashMap<String, String>();
		TxbExrtBean txbExrtInfo = new TxbExrtBean();
		TxaGlisBean txaGlisInfo = new TxaGlisBean();
		queryTxaGlisMap.put("lastdt", lastmh);
		queryTxaGlisMap.put("bsnsdt", conmth);
		queryTxaGlisMap.put("DeptSQL", DeptSQL);
		if (!"".equals(lastmh)) {
			// ������ĩ�����Ϊ�����ڳ����
			commonDao.insertByNamedSql(
					"com.sunline.sundp.mybatis.gl.insertHTxaGlis",
					queryTxaGlisMap);
		}
		try {
			BigDecimal drtsam = BigDecimal.ZERO, crtsam = BigDecimal.ZERO;

			hashmap.put("stacid", stacid);
			hashmap.put("begndt", begndt);
			hashmap.put("bsnsdt", bsnsdt);
			hashmap.put("DeptSQL", DeptSQL);
			@SuppressWarnings("unchecked")
			List<GliVchrBean> glivchrlists = (List<GliVchrBean>) commonDao
					.queryByNamedSqlForList(
							"com.sunline.sundp.mybatis.gl.queryGliVchrs",
							hashmap);
			for (GliVchrBean glivchrinfo : glivchrlists) {
				// �跽���ڷ�����
				drtsam = BigDecimal.ZERO;
				// �������ڷ�����
				crtsam = BigDecimal.ZERO;
				// ��ȡ����
				txbExrtInfo = getTxbExrt(glivchrinfo.getTrandt(),
						glivchrinfo.getCrcycd());
				if ("C".equals(glivchrinfo.getAmntcd())) {
					crtsam = new BigDecimal(glivchrinfo.getTranam());
					drtsam = BigDecimal.ZERO;
				} else {
					crtsam = BigDecimal.ZERO;
					drtsam = new BigDecimal(glivchrinfo.getTranam());
				}
				txaGlisInfo.setStacid(stacid);
				txaGlisInfo.setAcctdt(bsnsdt.substring(0, 6));// ��˰�ڼ�
				txaGlisInfo.setBrchcd(glivchrinfo.getAcctbr());
				txaGlisInfo.setCrcycd(glivchrinfo.getCrcycd());
				txaGlisInfo.setItemcd(glivchrinfo.getItemcd());
				txaGlisInfo.setPrducd(glivchrinfo.getPrducd());
				txaGlisInfo.setCentcd(glivchrinfo.getCentcd());
				txaGlisInfo.setPrsncd(glivchrinfo.getPrsncd());
				txaGlisInfo.setPrlncd(glivchrinfo.getPrlncd());
				txaGlisInfo.setCustcd(glivchrinfo.getCustcd());
				txaGlisInfo.setAcctno(glivchrinfo.getAcctno());
				txaGlisInfo.setDrtsam(drtsam);
				txaGlisInfo.setCrtsam(crtsam);
				// ���ܴ�Ʊ���ܵǼǲ�
				int updatecount = commonDao.updateByNamedSql(
						"com.sunline.sundp.mybatis.gl.updateTxaGlis",
						txaGlisInfo);
				if (updatecount == 0) {
					commonDao.updateByNamedSql(
							"com.sunline.sundp.mybatis.gl.insertTxaGlis",
							txaGlisInfo);
				}
				// MathContext(12):ʹ��ָ���ľ��Ⱥ� HALF_UP ����ģʽ����һ���µ� MathContext
				// ������ҵı��ڷ�����
				txaGlisInfo.setDrtsam(drtsam.multiply(txbExrtInfo.getExchrt()
						.divide(txbExrtInfo.getExunit()), new MathContext(12)));
				txaGlisInfo.setCrtsam(crtsam.multiply(txbExrtInfo.getExchrt()
						.divide(txbExrtInfo.getExunit()), new MathContext(12)));
				txaGlisInfo.setCrcycd(Crcycd_CC);
				updatecount = commonDao.updateByNamedSql(
						"com.sunline.sundp.mybatis.gl.updateTxaGlis",
						txaGlisInfo);
				if (updatecount == 0) {
					commonDao.updateByNamedSql(
							"com.sunline.sundp.mybatis.gl.insertTxaGlis",
							txaGlisInfo);
				}

			}
			// ��ȡ��ǰ���ڵ���һ��
			// begndt = DatetimeUtil.getnextDay(begndt);
			// }

		} catch (BimisException e) {
			throw new BimisException("-1", "������˰�ڴ�Ʊ��Ŀ�������ʧ��" + e.getErrmsg());
		} catch (Exception e) {
			e.getStackTrace();
		}
	}
	
	/**
	 * ���ɻ��ܼ�˰����Ǽǲ�
	 * 
	 * @param rule
	 * @throws BimisException
	 */
	private void genSumTxaPfitBooks(String stacid, String bsnsdt,
			String txprmh, String DeptSQL, String deptcd) throws BimisException {
		// ������õ�ҵ���ֵ�
		@SuppressWarnings("rawtypes")
		Map m = (Map) DataDictParameter.newInstance()
				.getOptions("suncm_compara").get(stacid);
		CommonDao commonDao = new CommonDao(this.getJrafSession());
		String vrflag = "1", conmth = "";
		HashMap<String, String> hashmap = new HashMap<String, String>();
		HashMap<String, String> insertTxaPfitBook = new HashMap<String, String>();
		Map<String, String> lmap = new HashMap<String, String>();
		Double onlnbl = 0.0, lastbl = 0.0, tranam = 0.0, txpram = 0.0;
		String lastmh = "", typecd = "", brchcd = "", crcycd = "", itemcd = "";
		Double vatxrt = 0.0, yrtxbl = 0.0, lstxam = 0.0, lqtxam = 0.0;
		String lastyr = String
				.valueOf(Integer.parseInt(bsnsdt.substring(0, 4)) - 1);
		if (OPENFQ_M.equals(txprmh)) {
			conmth = bsnsdt.substring(0, 6);
			if (!"01".equals(bsnsdt.substring(4, 6))) {
				lastmh = String.valueOf((Integer.parseInt(bsnsdt
						.substring(0, 6)) - 1));
			}
		} else if (OPENFQ_Q.equals(txprmh)) {
			conmth = bsnsdt.substring(0, 6);
			if (!"03".contains(bsnsdt.substring(4, 6))) {
				lastmh = String.valueOf((Integer.parseInt(bsnsdt
						.substring(0, 6)) - 3));
			}
		}
		hashmap.put("bsnsdt", conmth);// ��˰�ڼ�
		hashmap.put("stacid", stacid);
		hashmap.put("crcycd", Crcycd_CC);
		hashmap.put("brchcd", deptcd);// ����

		try {
			vrflag = "1";
			hashmap.put("DeptSQL", DeptSQL);
			// �������ݵ���˰���崫Ʊ���ܵǼǲ����ۺ�����ң�
			commonDao.insertByNamedSql(
					"com.sunline.sundp.mybatis.gl.InsertTxaGlisSum", hashmap);

			// ��ĩ������
			@SuppressWarnings("unchecked")
			List<HashMap<String, Object>> TxaGlisSum = (List<HashMap<String, Object>>) commonDao
					.queryByNamedSqlForList(
							"com.sunline.sundp.mybatis.gl.queryTxaGlisSum",
							hashmap);
			String Sonlnbl = TxaGlisSum.get(0).get("Sonlnbl").toString();// �����������-�跽�������
			String Stranam = TxaGlisSum.get(0).get("Stranam").toString();// �������ڷ�����-�跽���ڷ�����

			// ��ȡ�������������
			hashmap.put("bsnsdt", conmth.substring(0, 4));
			Element TxaGlisSumMax = commonDao
					.queryByNamedSql(
							"com.sunline.sundp.mybatis.gl.queryTxaGlisSumMax",
							hashmap);
			String SumMax = TxaGlisSumMax.getChild("Record")
					.getChildTextNormalize("SumMax");

			// ������:�ٴ����������-�跽�������<0
			// �ڴ������ڷ�����-�跽���ڷ�����<0
			// �۴����������-�跽�������<�������������
			// ������òƻ᡾22���ļ�������������Ҫ���û��������еĿͻ���������new_calculated_schem��
			if ((Double.parseDouble(Stranam) < Double.parseDouble("0.00001")
					|| Double.parseDouble(Sonlnbl) < Double
							.parseDouble("0.00001") || Double
					.parseDouble(Sonlnbl) < Double.parseDouble(SumMax))
					&& (m == null || m.get("new_calculated_schem") == null || !"true"
							.equals(m.get("new_calculated_schem")))) {
				vrflag = "0";
			}
			// }
			hashmap.put("bsnsdt", conmth);// ��˰�ڼ�
			// ��ѯ��Ʊ���ܵǼǲ�
			List<?> TxaGliss = commonDao.queryByNamedSqlForList(
					"com.sunline.sundp.mybatis.gl.queryTxaGliss", hashmap);
			for (int i = 0; i < TxaGliss.size(); i++) {
				vatxrt = 0.0;
				yrtxbl = 0.0;
				lstxam = 0.0;
				lqtxam = 0.0;
				onlnbl = 0.0;
				lastbl = 0.0;
				tranam = 0.0;
				txpram = 0.0;
				HashMap<?, ?> map = (HashMap<?, ?>) TxaGliss.get(i);
				onlnbl = Double.parseDouble(map.get("onlnbl").toString());// �����������-�跽�������
				brchcd = (String) map.get("brchcd");
				itemcd = (String) map.get("itemcd");
				crcycd = (String) map.get("crcycd");
				String valueKey = itemcd + "-pricetaxspsm";
				for (int j = 2; j < confKeys.length; j++) {
					valueKey = valueKey + "-" + map.get(confKeys[j]);
				}
				HashMap<?, ?> txptypemap = (HashMap<?, ?>) txptypeMapBykey
						.get(valueKey);
				if (null == txptypemap) {
					throw new BimisException("-1",
							"����Ͷ�������˰����Ǽǲ�ʧ��,ȡ��Ӧ�ļ�˰����������");
				}
				vatxrt = Double
						.parseDouble(txptypemap.get("vatxrt").toString());
				typecd = (String) txptypemap.get("typecd");
				yrtxbl = NumberUtils.mul(
						NumberUtils.div(onlnbl, 1 + vatxrt / 100, 12),
						vatxrt / 100);
				if ("".equals(lastmh)) {
					// ����������Ϊ0��������������
					tranam = onlnbl;
					lmap.put("stacid", stacid);
					lmap.put("txisyr", lastyr);
					lmap.put("txismh", lastyr + "12");
					lmap.put("brchcd", brchcd);
					lmap.put("crcycd", crcycd);
					lmap.put("prodcd", itemcd);
					lmap.put("prducd", map.get("prducd").toString());
					lmap.put("prsncd", map.get("prsncd").toString());
					lmap.put("centcd", map.get("centcd").toString());
					lmap.put("prlncd", map.get("prlncd").toString());
					lmap.put("custcd", map.get("custcd").toString());
					lmap.put("acctno", map.get("acctno").toString());
					// ��ѯ���ܼ�˰����Ǽǲ���Txa_Pfit_Book��
					// List<?> TxaPfitBooks = commonDao.queryByNamedSqlForList(
					// "com.sunline.sundp.mybatis.suntx-gl.queryTxaPfitBook",
					// lmap);
					lmap.clear();
					// if(TxaPfitBooks.size() > 0){
					// HashMap<?, ?> TxaPfitBooksMap = (HashMap<?, ?>)
					// TxaPfitBooks.get(0);
					// //��������˰��lstxam
					// lstxam =
					// Double.parseDouble(TxaPfitBooksMap.get("yrtxbl").toString());//�����ۼ�˰��(yrtxbl)
					// //������ĩ���۶�(lastbl)
					// lastbl =
					// Double.parseDouble(TxaPfitBooksMap.get("onlnbl").toString());//��ĩ��(onlnbl)
					// }
					if ("1".equals(vrflag)) {
						double txpramTemp = txpram = yrtxbl;
						if (m != null && m.get("new_calculated_schem") != null
								&& "true".equals(m.get("new_calculated_schem"))) {
							double temp = NumberUtils
									.mul(NumberUtils.div(lastbl,
											1 + vatxrt / 100, 12), vatxrt / 100);
							txpram = NumberUtils.sub(yrtxbl, temp);
							if (txpramTemp < 0.0) {
								yrtxbl = 0.0;
							}
						}
					} else {
						yrtxbl = 0.0;
					}
				} else {
					lmap.put("stacid", stacid);
					lmap.put("txisyr", bsnsdt.substring(0, 4));
					lmap.put("txismh", lastmh);
					lmap.put("brchcd", brchcd);
					lmap.put("crcycd", crcycd);
					lmap.put("prodcd", itemcd);
					lmap.put("prducd", map.get("prducd").toString());
					lmap.put("prsncd", map.get("prsncd").toString());
					lmap.put("centcd", map.get("centcd").toString());
					lmap.put("prlncd", map.get("prlncd").toString());
					lmap.put("custcd", map.get("custcd").toString());
					lmap.put("acctno", map.get("acctno").toString());
					List<?> TxaPfitBook = commonDao.queryByNamedSqlForList(
							"com.sunline.sundp.mybatis.gl.queryTxaPfitBook",
							lmap);
					lmap.clear();
					if (TxaPfitBook.size() > 0) {
						HashMap<?, ?> TxaPfitBooksMap = (HashMap<?, ?>) TxaPfitBook
								.get(0);
						lqtxam = Double.parseDouble(TxaPfitBooksMap.get(
								"yrtxbl").toString());// �����ۼ�˰��(yrtxbl)
						lstxam = Double.parseDouble(TxaPfitBooksMap.get(
								"lstxam").toString());// ��������˰��(lstxam)
						// �ڳ���(lastbl)
						lastbl = Double.parseDouble(TxaPfitBooksMap.get(
								"onlnbl").toString());// ��ĩ��(onlnbl)
					}
					if ("1".equals(vrflag)) {
						double txpramTemp = txpram = NumberUtils.sub(yrtxbl,
								lqtxam);
						if (m != null && m.get("new_calculated_schem") != null
								&& "true".equals(m.get("new_calculated_schem"))) {
							double temp = NumberUtils
									.mul(NumberUtils.div(lastbl,
											1 + vatxrt / 100, 12), vatxrt / 100);
							txpram = NumberUtils.sub(yrtxbl, temp);
							if (txpramTemp < 0.0) {
								yrtxbl = lqtxam;
							}

						}
					} else if ("2".equals(vrflag)) {
						yrtxbl = 0.0;
						txpram = NumberUtils.sub(0.0, lqtxam);
					} else {
						yrtxbl = lqtxam;
					}
				}
				// ����Ͷ�������Ŀ=�������-�������
				tranam = NumberUtils.sub(onlnbl, lastbl);
				insertTxaPfitBook.put("stacid", stacid);
				insertTxaPfitBook.put("txisyr", bsnsdt.substring(0, 4));
				insertTxaPfitBook.put("txismh", conmth);
				insertTxaPfitBook.put("brchcd", brchcd);
				insertTxaPfitBook.put("crcycd", crcycd);
				insertTxaPfitBook.put("prodcd", itemcd);
				insertTxaPfitBook.put("lastbl", String.valueOf(lastbl));
				insertTxaPfitBook.put("tranam", String.valueOf(tranam));
				insertTxaPfitBook.put("onlnbl", String.valueOf(onlnbl));
				insertTxaPfitBook.put("yronbl", String.valueOf(onlnbl));
				insertTxaPfitBook.put("lstxam", String.valueOf(lstxam));
				insertTxaPfitBook.put("vatxam", String.valueOf(txpram));
				insertTxaPfitBook.put("typecd", typecd);
				insertTxaPfitBook.put("vatxrt", String.valueOf(vatxrt));
				insertTxaPfitBook.put("yrtxbl", String.valueOf(yrtxbl));
				insertTxaPfitBook.put("prducd", map.get("prducd").toString());
				insertTxaPfitBook.put("prsncd", map.get("prsncd").toString());
				insertTxaPfitBook.put("centcd", map.get("centcd").toString());
				insertTxaPfitBook.put("prlncd", map.get("prlncd").toString());
				insertTxaPfitBook.put("custcd", map.get("custcd").toString());
				insertTxaPfitBook.put("acctno", map.get("acctno").toString());

				commonDao.insertByNamedSql(
						"com.sunline.sundp.mybatis.gl.insertTxaPfitBook",
						insertTxaPfitBook);

				// �����δʹ��״̬�����¹���ʹ��״̬
				String usedtg = (String) txptypemap.get("usedtg");
				if (EnumerationBean.USEDFLAG.NOTUSED.value.equals(usedtg)) {
					BigDecimal spuuid = (BigDecimal) txptypemap.get("spuuid");
					hashmap.clear();
					hashmap.put("spuuid", spuuid.toString());
					commonDao
							.updateByNamedSql(
									"com.sunline.sundp.mybatis.gl.updateTxpTypeMapUsedtg",
									hashmap);
				}
			}
		} catch (BimisException e) {
			throw new BimisException("-1", e.getMessage());
		}
	}

	/**
	 * �޸Ĺ���ִ��״̬
	 * 
	 * @param rule
	 * @throws BimisException
	 */
	@SuppressWarnings("unchecked")
	private void insertTxaVchr(String stacid, String bsnsdt)
			throws BimisException {

		CommonDao commonDao = new CommonDao(this.getJrafSession());
		try {
			HashMap<String, String> queryMap = new HashMap<String, String>();
			TxaVchrBean txaVchrInfo = new TxaVchrBean();
			String itemcd = "";
			queryMap.put("stacid", stacid);
			queryMap.put("vatxam", "0");
			queryMap.put("txismh", bsnsdt.substring(0, 6));
			queryMap.put("txisyr", bsnsdt.substring(0, 4));
			List<?> txaPfitBooks = commonDao
					.queryByNamedSqlForList(
							"com.sunline.sundp.mybatis.gl.queryTxaPfitBooks",
							queryMap);
			// ��ȡ��ǰ������Ϣ
			Element stacInfo = commonDao.queryByNamedSql(
					"com.sunline.sundp.mybatis.stacinfo.queryStacInfoDetail",
					queryMap);
			String crcysd = "";
			if (StringUtils.isEmpty(stacInfo.getChild("Record")
					.getChildTextNormalize("crcycd"))) {
				crcysd = Crcycd_CNY;
			} else {
				crcysd = stacInfo.getChild("Record").getChildTextNormalize(
						"crcycd");
			}
			// ������õ�ҵ���ֵ�
			@SuppressWarnings("rawtypes")
			Map m = (Map) DataDictParameter.newInstance()
					.getOptions("suncm_compara").get(stacid);
			for (int i = 0; i < txaPfitBooks.size(); i++) {
				HashMap<String, Object> txaPfitBookMap = (HashMap<String, Object>) txaPfitBooks
						.get(i);
				String itemcl = (String) txaPfitBookMap.get("itemcl");
				String transq = StringUtils.getSequenceNumber("HZ_",
						"gli_vchr", 20);

				itemcd = ComParaUtils.getOutItemByDept(stacid, txaPfitBookMap
						.get("brchcd").toString());
				if (!item10.equals(itemcl)
						&& ("".equals(itemcd) || StringUtils.isEmpty(itemcd))) {
					throw new BimisException("-1", "δ�ҵ�����"
							+ txaPfitBookMap.get("brchcd").toString()
							+ "��Ӧ������˰��Ŀ��");
				}
				// ������Ʒת�ÿ�Ŀ
				if (item10.equals(itemcl)
						&& (m == null || m.get("item10") == null)) {
					throw new BimisException("-1",
							"���������ϡ�-���ͻ�����������δ���ò�����Ϊ��item10���Ľ�����Ʒת�ÿ�Ŀ�������ò�ˢ��ҵ���ֵ䣡");
				}
				txaVchrInfo.setStacid(stacid);
				txaVchrInfo.setSystid("00");
				txaVchrInfo.setTrandt(bsnsdt);
				txaVchrInfo.setTransq(transq);
				txaVchrInfo.setVchrsq("1");
				txaVchrInfo.setTranbr(txaPfitBookMap.get("brchcd").toString());
				txaVchrInfo.setAcctbr(txaPfitBookMap.get("brchcd").toString());
				txaVchrInfo.setItemcd(txaPfitBookMap.get("prodcd").toString());
				txaVchrInfo.setCrcycd(txaPfitBookMap.get("crcycd").toString());
				txaVchrInfo.setTrantp("TR");
				txaVchrInfo.setAmntcd("C");
				txaVchrInfo.setTranam(BigDecimal.ZERO.subtract(new BigDecimal(
						txaPfitBookMap.get("vatxam").toString())));
				txaVchrInfo.setUsercd("*****");
				txaVchrInfo.setSmrytx("���ܼ�˰����");
				txaVchrInfo.setPrducd(txaPfitBookMap.get("prducd").toString());
				txaVchrInfo.setPrsncd(txaPfitBookMap.get("prsncd").toString());
				txaVchrInfo.setCentcd(txaPfitBookMap.get("centcd").toString());
				txaVchrInfo.setPrlncd(txaPfitBookMap.get("prlncd").toString());
				txaVchrInfo.setCustcd(txaPfitBookMap.get("custcd").toString());
				txaVchrInfo.setAcctno(txaPfitBookMap.get("acctno").toString());
				txaVchrInfo.setCrcysd(crcysd);// ���ִ��루��λ�ң�
				// ���׽���λ�ң�
				TxbExrtBean exrt = getTxbExrtByCrcysd(bsnsdt,
						txaVchrInfo.getCrcycd(), crcysd);
				txaVchrInfo.setTrsdam(exrt.getExchrt()
						.multiply(txaVchrInfo.getTranam())
						.divide(exrt.getExunit(), 2, BigDecimal.ROUND_HALF_UP));
				commonDao.insertByNamedSql(
						"com.sunline.sundp.mybatis.gl.insertTxaVchr",
						txaVchrInfo);

				txaVchrInfo.setVchrsq("2");
				// ��Ŀ����Ϊ������Ʒת��
				if (item10.equals(itemcl)) {
					txaVchrInfo.setItemcd((String) m.get("item10"));
				}
				// ��Ŀ����Ϊ����˰
				else {
					txaVchrInfo.setItemcd(itemcd);
				}
				txaVchrInfo.setTranam(new BigDecimal(txaPfitBookMap.get(
						"vatxam").toString()));
				txaVchrInfo.setTrsdam(exrt.getExchrt()
						.multiply(txaVchrInfo.getTranam())
						.divide(exrt.getExunit(), 2, BigDecimal.ROUND_HALF_UP));
				commonDao.insertByNamedSql(
						"com.sunline.sundp.mybatis.gl.insertTxaVchr",
						txaVchrInfo);

				txaPfitBookMap.put("transq", txaVchrInfo.getTransq());
				txaPfitBookMap.put("trandt", bsnsdt);
				insertTrbTxls(txaPfitBookMap);
			}
			// �·�����������걨��
			if ("12".equals(bsnsdt.substring(4, 6)) && m != null
					&& m.get("new_calculated_schem") != null
					&& "true".equals(m.get("new_calculated_schem"))) {
				queryMap.put("txismh", "");
				queryMap.put("txisyr", bsnsdt.substring(0, 4));
				queryMap.put("vatxam", "");
				List<?> txaPfitBookList = commonDao.queryByNamedSqlForList(
						"com.sunline.sundp.mybatis.gl.queryTxaPfitBooks",
						queryMap);
				BigDecimal vatxamSum = new BigDecimal("0");
				HashMap<String, Object> map = null;
				for (int q = 0; q < txaPfitBookList.size(); q++) {
					map = (HashMap<String, Object>) txaPfitBookList.get(q);
					vatxamSum = vatxamSum.add(new BigDecimal(map.get("vatxam")
							.toString()));
				}
				if (vatxamSum.compareTo(new BigDecimal(0)) >= 0)
					return;
				itemcd = ComParaUtils.getOutItemByDept(stacid, map
						.get("brchcd").toString());
				if ("".equals(itemcd) || StringUtils.isEmpty(itemcd)) {
					throw new BimisException("-1", "δ�ҵ�����"
							+ map.get("brchcd").toString() + "��Ӧ������˰��Ŀ��");
				}
				/*
				 * Sequence sequence =
				 * com.sunline.sundp.util.SequenceUtils.createSequence
				 * (commonDao, Integer.parseInt(stacid), "transq", (String)
				 * map.get("brchcd"), null, "*", 1);
				 */
				String transq = StringUtils.getSequenceNumber("HZ_",
						"gli_vchr", 20);
				// ���׽���λ�ң�
				txaVchrInfo.setCrcysd(crcysd);// ���ִ��루��λ�ң�
				txaVchrInfo.setCrcycd(map.get("crcycd").toString());
				TxbExrtBean exrt = getTxbExrtByCrcysd(bsnsdt,
						txaVchrInfo.getCrcycd(), crcysd);
				txaVchrInfo.setStacid(stacid);
				txaVchrInfo.setSystid("00");
				txaVchrInfo.setTrandt(bsnsdt);
				txaVchrInfo.setTransq(transq);
				txaVchrInfo.setVchrsq("1");
				txaVchrInfo.setTranbr(map.get("brchcd").toString());
				txaVchrInfo.setAcctbr(map.get("brchcd").toString());
				txaVchrInfo.setItemcd(map.get("prodcd").toString());
				txaVchrInfo.setTrantp("TR");
				txaVchrInfo.setAmntcd("C");
				txaVchrInfo.setUsercd("*****");
				txaVchrInfo.setSmrytx("���ܼ�˰����");
				txaVchrInfo.setPrducd(map.get("prducd").toString());
				txaVchrInfo.setPrsncd(map.get("prsncd").toString());
				txaVchrInfo.setCentcd(map.get("centcd").toString());
				txaVchrInfo.setPrlncd(map.get("prlncd").toString());
				txaVchrInfo.setCustcd(map.get("custcd").toString());
				txaVchrInfo.setAcctno(map.get("acctno").toString());
				// txaVchrInfo.setTrandt(bsnsdt);

				// txaVchrInfo.setVchrsq("1");
				// txaVchrInfo.setTransq(sequence.getSqueno());
				txaVchrInfo.setTranam(vatxamSum);
				txaVchrInfo.setTrsdam(exrt.getExchrt()
						.multiply(txaVchrInfo.getTranam())
						.divide(exrt.getExunit(), 2, BigDecimal.ROUND_HALF_UP));
				commonDao.insertByNamedSql(
						"com.sunline.sundp.mybatis.gl.insertTxaVchr",
						txaVchrInfo);
				txaVchrInfo.setVchrsq("2");
				// ��Ŀ����Ϊ������Ʒת��
				if (item10.equals(map.get("itemcl"))) {
					txaVchrInfo.setItemcd((String) m.get("item10"));
				}
				// ��Ŀ����Ϊ����˰
				else {
					txaVchrInfo.setItemcd(itemcd);
				}
				txaVchrInfo.setTranam(BigDecimal.ZERO.subtract(vatxamSum));
				txaVchrInfo.setTrsdam(exrt.getExchrt()
						.multiply(txaVchrInfo.getTranam())
						.divide(exrt.getExunit(), 2, BigDecimal.ROUND_HALF_UP));
				commonDao.insertByNamedSql(
						"com.sunline.sundp.mybatis.gl.insertTxaVchr",
						txaVchrInfo);
				map.put("transq", txaVchrInfo.getTransq());
				map.put("trandt", bsnsdt);
				insertTrbTxls(map);
			}
		} catch (BimisException e) {
			throw new BimisException("-1", "���ɴ�Ʊ��ʧ�ܣ�" + e.getErrmsg());
		} catch (Exception e) {
			throw new BimisException("-1", e.getMessage());
		}
	}

	/**
	 * ����Ӧ˰��ˮ��
	 * 
	 * @param rule
	 * @throws BimisException
	 */
	private void insertTrbTxls(HashMap<String, Object> map)
			throws BimisException {

		CommonDao commonDao = new CommonDao(this.getJrafSession());
		BigDecimal expram = BigDecimal.ZERO, extxam = BigDecimal.ZERO, pricam = BigDecimal.ZERO;
		try {

			TrbTxlsBean trbTxlsInfo = new TrbTxlsBean();
			String bsnsdt = map.get("trandt").toString();

			TxbExrtBean txbExrtInfo = getTxbExrt(bsnsdt, map.get("crcycd")
					.toString());
			BigDecimal exchrt = txbExrtInfo.getExchrt().divide(
					txbExrtInfo.getExunit());
			extxam = exchrt.multiply(new BigDecimal(map.get("vatxam")
					.toString()), new MathContext(12));
			pricam = new BigDecimal(map.get("tranam").toString())
					.subtract(new BigDecimal(map.get("vatxam").toString()));
			expram = exchrt.multiply(pricam, new MathContext(12));

			trbTxlsInfo.setStacid(map.get("stacid").toString());
			trbTxlsInfo.setSystid("00");
			trbTxlsInfo.setTrandt(map.get("trandt").toString());
			trbTxlsInfo.setTransq(map.get("transq").toString());
			trbTxlsInfo.setVchrsq("1");
			trbTxlsInfo.setTranbr(map.get("brchcd").toString());
			trbTxlsInfo.setAcctbr(map.get("brchcd").toString());
			trbTxlsInfo.setBusitp("0");
			trbTxlsInfo.setCrcycd(map.get("crcycd").toString());
			trbTxlsInfo.setTranam(map.get("tranam").toString());
			trbTxlsInfo.setVatxrt(map.get("vatxrt").toString());
			trbTxlsInfo.setTaxbam(map.get("vatxam").toString());
			trbTxlsInfo.setPricam(String.valueOf(NumberUtils.sub(
					Double.parseDouble(map.get("tranam").toString()),
					Double.parseDouble(map.get("vatxam").toString()))));
			trbTxlsInfo.setSmrytx("���ܼ�˰����");
			trbTxlsInfo.setStatus("0");
			trbTxlsInfo.setCatxtp(map.get("catxtp").toString());
			trbTxlsInfo.setExeptg(map.get("exeptg").toString());
			trbTxlsInfo.setTypecd(map.get("typecd").toString());
			trbTxlsInfo.setCrcyiv(Crcycd_CNY);
			trbTxlsInfo.setExtxam(extxam.toString());
			trbTxlsInfo.setExpram(expram.toString());
			trbTxlsInfo.setExchrt(exchrt.toString());
			trbTxlsInfo.setItemcd(map.get("prodcd").toString());
			commonDao.insertByNamedSql(
					"com.sunline.sundp.mybatis.gl.insertTrbTxls", trbTxlsInfo);

		} catch (BimisException e) {
			throw new BimisException("-1", "����Ӧ˰��ˮ��ʧ�ܣ�" + e.getErrmsg());
		} catch (Exception e) {
			throw new BimisException("-1", "����Ӧ˰��ˮ��ʧ�ܣ�");
		}
	}

	/**
	 * ȡ�ü�˰�����ڼ�
	 * 
	 * @param rule
	 * @return
	 */
	@SuppressWarnings("unused")
	private String getParavl(String stacid, String paracd)
			throws BimisException {

		CommonDao commonDao = new CommonDao(this.getJrafSession());
		String paravl = "";
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("stacid", stacid);
		map.put("paracd", paracd);
		try {
			List<?> compara = commonDao.queryByNamedSqlForList(
					"com.sunline.sundp.mybatis.gl.queryComPara", map);
			HashMap<?, ?> comparamap = (HashMap<?, ?>) compara.get(0);
			paravl = (String) comparamap.get("paravl");
		} catch (BimisException e) {
			throw new BimisException("-1", "��ѯ���ײ�����" + paracd + "��ʧ�ܣ�");
		}
		return paravl;
	}

	public boolean priceTaxSeparated(String stacid, String bsnsdt)
			throws BimisException {
		boolean execflag = true;
		CommonDao commonDao = new CommonDao(this.getJrafSession());
		commonDao.beginTransaction();

		try {
			// ���ҿ�Ʊ����
			String flag = "0";
			HashMap<String, String> hashmap = new HashMap<String, String>();
			// �����õ���������
			HashMap<String, String> conf = new HashMap<String, String>();
			HashMap<String, String> lmap = new HashMap<String, String>();
			hashmap.put("stacid", stacid);
			// ��ѯ����������ñ�,�����������ʵ�ֱ� (prodp1 = 'pricetaxspsm')�����룺���ܼ�˰����
			List<?> txpTypeConf = commonDao.queryByNamedSqlForList(
					"com.sunline.sundp.mybatis.gl.queryTxpTypeConf", hashmap);
			if (txpTypeConf.size() == 0) {
				throw new BimisException("-1", "û���ҵ����ܼ�˰�����Ŀ��ص������������ã�");
			}
			HashMap<?, ?> txpTypeConfMap = (HashMap<?, ?>) txpTypeConf.get(0);
			ConfKey = "itemcd-" + txpTypeConfMap.get("prodp1").toString();
			if (!txpTypeConfMap.get("prodp2").equals("*")) {
				ConfKey = ConfKey + "-"
						+ txpTypeConfMap.get("prodp2").toString();
				conf.put("prodp2", txpTypeConfMap.get("prodp2").toString());
			} else if (!txpTypeConfMap.get("prodp3").equals("*")) {
				ConfKey = ConfKey + "-"
						+ txpTypeConfMap.get("prodp3").toString();
				conf.put("prodp3", txpTypeConfMap.get("prodp3").toString());
			} else if (!txpTypeConfMap.get("prodp4").equals("*")) {
				ConfKey = ConfKey + "-"
						+ txpTypeConfMap.get("prodp4").toString();
				conf.put("prodp4", txpTypeConfMap.get("prodp4").toString());
			} else if (!txpTypeConfMap.get("prodp5").equals("*")) {
				ConfKey = ConfKey + "-"
						+ txpTypeConfMap.get("prodp5").toString();
				conf.put("prodp5", txpTypeConfMap.get("prodp5").toString());
			} else if (!txpTypeConfMap.get("prodp6").equals("*")) {
				ConfKey = ConfKey + "-"
						+ txpTypeConfMap.get("prodp6").toString();
				conf.put("prodp6", txpTypeConfMap.get("prodp6").toString());
			} else if (!txpTypeConfMap.get("prodp7").equals("*")) {
				ConfKey = ConfKey + "-"
						+ txpTypeConfMap.get("prodp7").toString();
				conf.put("prodp7", txpTypeConfMap.get("prodp7").toString());
			} else if (!txpTypeConfMap.get("prodp8").equals("*")) {
				ConfKey = ConfKey + "-"
						+ txpTypeConfMap.get("prodp8").toString();
				conf.put("prodp8", txpTypeConfMap.get("prodp8").toString());
			} else if (!txpTypeConfMap.get("prodp9").equals("*")) {
				ConfKey = ConfKey + "-"
						+ txpTypeConfMap.get("prodp9").toString();
				conf.put("prodp9", txpTypeConfMap.get("prodp9").toString());
			} else if (!txpTypeConfMap.get("prodpa").equals("*")) {
				ConfKey = ConfKey + "-"
						+ txpTypeConfMap.get("prodpa").toString();
				conf.put("prodpa", txpTypeConfMap.get("prodpa").toString());
			}

			// ������Ϊ���ܼ�˰����ļ�˰�������������õ�����
			confKeys = ConfKey.split("-");

			lmap.put("stacid", stacid);
			// ������˰Ŀ��Ӧ��˰��
			List<?> txpmap = commonDao.queryByNamedSqlForList(
					"com.sunline.sundp.mybatis.gl.queryTxpTypeMap", lmap);
			// ����ÿһ�����õĹ���
			for (int n = 0; n < txpmap.size(); n++) {
				HashMap<?, ?> txptypemap = (HashMap<?, ?>) txpmap.get(n);
				String MapKey = txptypemap.get("prodcd").toString() + "-"
						+ txptypemap.get("prodp1").toString();
				if (conf.containsKey("prodp2")) {
					MapKey = MapKey + "-" + txptypemap.get("prodp2").toString();
				} else if (conf.containsKey("prodp3")) {
					MapKey = MapKey + "-" + txptypemap.get("prodp3").toString();
				} else if (conf.containsKey("prodp4")) {
					MapKey = MapKey + "-" + txptypemap.get("prodp4").toString();
				} else if (conf.containsKey("prodp5")) {
					MapKey = MapKey + "-" + txptypemap.get("prodp5").toString();
				} else if (conf.containsKey("prodp6")) {
					MapKey = MapKey + "-" + txptypemap.get("prodp6").toString();
				} else if (conf.containsKey("prodp7")) {
					MapKey = MapKey + "-" + txptypemap.get("prodp7").toString();
				} else if (conf.containsKey("prodp8")) {
					MapKey = MapKey + "-" + txptypemap.get("prodp8").toString();
				} else if (conf.containsKey("prodp9")) {
					MapKey = MapKey + "-" + txptypemap.get("prodp9").toString();
				} else if (conf.containsKey("prodpa")) {
					MapKey = MapKey + "-" + txptypemap.get("prodpa").toString();
				}
				txptypeMapBykey.put(MapKey, txptypemap);
			}

			// ��ѯ������Ϣ
			Map<String, String> stacmap = new HashMap<String, String>();
			stacmap.put("stacid", stacid);
			/*
			 * List<?> staclist = commonDao.queryByNamedSqlForList(
			 * "com.sunline.sundp.mybatis.stacinfo.queryStacInfoDetail",
			 * stacmap);
			 */
			// ��ѯ��˰�걨������Ϣ ,com_dist_rela.relatp='02'
			@SuppressWarnings("unchecked")
			List<DistRelaBean> distRelaList = (List<DistRelaBean>) commonDao
					.queryByNamedSqlForList(
							"com.sunline.sundp.mybatis.gl.getDeptListByType",
							stacmap);

			for (DistRelaBean distrela : distRelaList) {
				// sprrdp='-1',Ϊһ������
				if ("-1".equals(distrela.getSprrdp())) {
					flag = "0";
					// �걨Ƶ��(Reptdp)Ϊ�»��߼���
					if (OPENFQ_M.equals(distrela.getReptdp())) {
						SimpleDateFormat format = new SimpleDateFormat(
								"yyyyMMdd");
						Date date = null;
						try {
							date = format.parse(bsnsdt);
						} catch (ParseException e) {
							e.printStackTrace();
						}
						if (bsnsdt
								.equals(DatetimeUtil.getCurMonthLastDay(date))) {
							flag = "1";
						}
					} else if (OPENFQ_Q.equals(distrela.getReptdp())) {
						if (("0331,0630,0930,1231".contains(bsnsdt.substring(4,
								8)))) {
							flag = "1";
						}
					}
					// flag=1��ʾ���л���
					if ("1".equals(flag)) {
						// ��������(deptcd)
						String deptcd = distrela.getDeptcd();
						StringBuffer deptbf = new StringBuffer();
						String DeptSQL = getChildDept(distRelaList, deptcd,
								true, deptbf, 0);

						// ���ܵ������
						GliVchrSumm(stacid, bsnsdt, distrela.getReptdp(),
								DeptSQL);

						// ���ɻ��ܼ�˰����Ǽǲ�
						genSumTxaPfitBooks(stacid, bsnsdt,
								distrela.getReptdp(), DeptSQL, deptcd);

					}

				}
			}

			insertTxaVchr(stacid, bsnsdt);
			insertGlaVchr(stacid, bsnsdt);
			commonDao.commitTransaction();
		} catch (Exception e) {
			commonDao.rollBack();
			execflag = false;
			log.debug("ִ�� PriceTaxSumRegExecute ��� execute ����ʧ�ܣ�"
					+ e.getMessage());
			e.printStackTrace();
		}
		return execflag;
	}

	private void insertGlaVchr(String stacid, String bsnsdt)
			throws BimisException {
		CommonDao commonDao = new CommonDao(this.getJrafSession());
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("stacid", stacid);
		params.put("bsnsdt", bsnsdt);
		@SuppressWarnings("unchecked")
		List<TxaVchrBean> txavchrs = (List<TxaVchrBean>) commonDao
				.queryByNamedSqlForList(
						"com.sunline.sundp.mybatis.gl.queryTxaVchrs", params);
		GlaVchrBean glavchr = null;
		if (null != txavchrs && txavchrs.size() != 0) {
			for (TxaVchrBean txavchr : txavchrs) {
				glavchr = genGlaVchr(txavchr);
				commonDao.insertByNamedSql(
						"com.sunline.sundp.mybatis.gl.insertGlaVchr", glavchr);
			}
		}
	}

	private GlaVchrBean genGlaVchr(TxaVchrBean txavchr) {
		// TODO Auto-generated method stub
		GlaVchrBean glavchr = new GlaVchrBean(txavchr);
		return glavchr;
	}

	@Override
	public List<Object> selectTasks(String taskParameter, String ownSign,
			int taskItemNum, List<TaskItemDefine> taskItemList,
			int eachFetchDataNum) throws Exception {
		log.debug("start PriceTaxSumRegExecute.selectTasks......");
		String plancd = "";
		String systid = "";
		HashMap<String, String> map = StringUtils.String2Map(taskParameter);
		stacid = map.get("stacid");
		plancd = map.get("plancd") == null ? "hzjsfl" : map.get("plancd");
		systid = map.get("systid");
		log.debug("����������л�ȡ����Ϊ��" + stacid + " �������� = " + plancd + " ϵͳID = "
				+ systid);
		String trandt = getBsnsdt(stacid);
		log.debug("����ҵ�����ڣ�" + trandt);
		List<Object> list = new ArrayList<Object>();
		if (!DatetimeUtil.isEndOfDay(trandt, DatetimeUtil.DATE_FORMAT_YMD,
				OPENFQ_M)) {
			log.debug("����ҵ�����ڣ�" + trandt + "������ĩ������ִ�л��ܼ�˰����");
			log.debug("end PriceTaxSumRegExecute.selectTasks......");
			Thread.sleep(60000);
			return list;
		}
		GloImdtBean gloImdtInfo = getGloImdtInfo(stacid, plancd, trandt);
		if (null != gloImdtInfo
				&& IMPORT_COMPLETED.equals(gloImdtInfo.getStatus())) {
			log.debug("����ҵ�����ڡ�" + trandt + "������ɻ��ܼ�˰���룡");
			Thread.sleep(60000);
			return list;
		}
		boolean pricetaxsepcompleteflag = checkPriceTax(trandt);
		if (!pricetaxsepcompleteflag) {
			log.debug("����ҵ�����ڣ�" + trandt + "������Χϵͳ������δ��ɻ��˰������δ��ɣ�����ִ�л��ܼ�˰���룡");
			Thread.sleep(60000);
			return list;
		}
		ReturnData rd = new ReturnData();
		rd.setStacid(stacid);
		rd.setPlancd(plancd);// ��Ҫ���ҵı�����
		rd.setBatchId(trandt);// ���κ�
		rd.setGloImdtInfo(gloImdtInfo);
		rd.setSystid(systid);
		rd.setCertno(DATACH);
		list.add(rd);
		log.debug("end PriceTaxSumRegExecute.selectTasks......");
		return list;
	}

	private boolean checkPriceTax(String bsnsdt) throws BimisException {
		CommonDao commonDao = new CommonDao(this.getJrafSession());
		boolean flag = true;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("bsnsdt", bsnsdt);

		Element element = commonDao.queryByNamedSql(
				"com.sunline.sundp.mybatis.gl.countSysIsPrepst", params);
		String cnt = ((Element) element.getChildren("Record").get(0))
				.getChildText("cnt");
		if (!"0".equals(cnt)) {
			log.debug("����ҵ�����ڣ�" + bsnsdt + "��Χϵͳ���ݻ�û��׼���ã����ܽ��л��ܼ�˰���룡");
			flag = false;
		}
		if (flag) {
			element = commonDao.queryByNamedSql(
					"com.sunline.sundp.mybatis.gl.countSysIsPrepstBySystdt",
					params);
			cnt = ((Element) element.getChildren("Record").get(0))
					.getChildText("cnt");

			if ("0".equals(cnt)) {
				log.debug("����ҵ�����ڣ�" + bsnsdt
						+ "��Χϵͳ���ݴ��������뵱ǰϵͳ���ݴ���ҵ�����ڲ�һ�£����ܽ��л��ܼ�˰���룡");
				flag = false;
			}
		}
		if (flag) {
			element = commonDao.queryByNamedSql(
					"com.sunline.sundp.mybatis.gl.countPriceTaxCompleteInfo",
					params);
			cnt = ((Element) element.getChildren("Record").get(0))
					.getChildText("cnt");
			if (!"0".equals(cnt)) {
				log.debug("����ҵ�����ڣ�" + bsnsdt + "��" + bsnsdt
						+ "��ǰ��˰����û����ɣ���δ�������ݻ����������ݣ������ܽ��л��ܼ�˰���룡");
				flag = false;
			}
		}
		if (flag) {
			element = commonDao
					.queryByNamedSql(
							"com.sunline.sundp.mybatis.gl.countPriceTaxCompleteByTrandt",
							params);
			cnt = ((Element) element.getChildren("Record").get(0))
					.getChildText("cnt");
			if ("0".equals(cnt)) {
				log.debug("����ҵ�����ڣ�" + bsnsdt
						+ "����û�н��м�˰�����������δ���е��룬���ܽ��л��ܼ�˰����!");
				flag = false;
			}
		}
		return flag;
	}

	@Override
	public Comparator<Object> getComparator() {
		return null;
	}

	@Override
	public boolean execute(Object task, String ownSign) throws Exception {
		log.debug("start PriceTaxSumRegExecute.execute......");
		ReturnData rd = (ReturnData) task;
		String stacid = rd.getStacid();
		String plancd = rd.getPlancd();
		String batchId = rd.getBatchId();
		GloImdtBean gloImdtInfo = rd.getGloImdtInfo();
		String systid = rd.getSystid();
		String certno = rd.getCertno();
		bsnsdt = rd.getBatchId();
		if (gloImdtInfo == null) {
			String usercd = "****";
			String brchcd = "****";
			String nextdt = "";
			String currdt = "";
			String switdt = "";
			String acctbr = "";
			String sourdt = DatetimeUtil.getNow(DatetimeUtil.DATE_FORMAT_YMD);
			boolean isGliImpSuccess = this.priceTaxSeparated(stacid, bsnsdt);
			if ("null".equals(isGliImpSuccess)) {
				log.debug("����ҵ�����ڡ�" + batchId + "��û�л������ݣ���ȷ�ϣ�");
				return true;
			}
			String imdtStatus = isGliImpSuccess ? IMPORT_COMPLETED
					: IMPORT_FAILED;
			// ����gloImdt��¼
			insertDataToGloImdt(stacid, systid, sourdt, acctbr, batchId,
					usercd, brchcd, imdtStatus, nextdt, currdt, switdt, plancd,
					certno);
		} else {
			if (IMPORT_FAILED.equals(gloImdtInfo.getStatus())) {// ����ʧ�ܵļ�¼
				boolean isGliImpSuccess = priceTaxSeparated(stacid, bsnsdt);
				String imdtStatus = isGliImpSuccess ? IMPORT_COMPLETED
						: IMPORT_FAILED;
				this.updateGloImdtStatus(stacid, batchId, imdtStatus, plancd,
						certno);
			}
			/*
			 * else if (IMPORT_COMPLETED.equals(gloImdtInfo.getStatus())) {
			 * log.debug("����ҵ�����ڡ�" + batchId + "������ɻ��ܼ�˰���룡"); }
			 */
		}
		closeConnection(); //�ر�����
		log.debug("end PriceTaxSumRegExecute.execute......");
		return true;

	}

	/**
	 * ȡ�����׺ŵ�ҵ������
	 * 
	 * @param stacid
	 * @return
	 */
	private String getBsnsdt(String stacid) {
		Map<String, String> paMap = new HashMap<String, String>();
		CommonDao commonDao = new CommonDao(this.getJrafSession());
		String bsnsdt = null;
		try {
			paMap.put("stacid", stacid);
			Element element = commonDao.queryByNamedSql(
					"com.sunline.sundp.mybatis.stacinfo.queryStacInfoDetail",
					paMap);
			bsnsdt = ((Element) element.getChildren("Record").get(0))
					.getChildText("glisdt");
		} catch (BimisException e) {
			e.printStackTrace();
		}
		return bsnsdt;
	}

	/**
	 * ��ȡjrafSession
	 * 
	 * @return jrafSession
	 */
	private JrafSession getJrafSession() {
		try {
			if (jrafSession == null || jrafSession.getConnection() == null
					|| jrafSession.getConnection().isClosed()) {
				jrafSession = JrafSessionFactory.getInstance().openSession();
			}
		} catch (Exception e) {
			log.error("���Ȼ�ȡJrafSessionʧ��", e);
		}
		return jrafSession;
	}

	/**
	 * ����״̬����ѯ
	 * 
	 * @param stacid
	 * @param plancd
	 * @param bathid
	 * @return
	 */
	private GloImdtBean getGloImdtInfo(String stacid, String plancd,
			String bathId) {
		Connection conn = getConnection();
		if (conn == null) {
			return null;
		}

		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			pst = conn.prepareStatement(FIND_GLO_IMDT_BY_KEY_TYPE);
			pst.setString(1, stacid);
			pst.setString(2, bathId);
			pst.setString(3, plancd);

			rs = pst.executeQuery();
			while (rs.next()) {
				GloImdtBean info = new GloImdtBean();
				info.setStacid(stacid);
				info.setAcctbr(rs.getString("acctbr"));
				info.setBathid(bathId);
				info.setBrchcd(rs.getString("brchcd"));
				info.setCurrdt(rs.getString("currdt"));
				info.setDatach(rs.getString("datach"));
				info.setNextdt(rs.getString("nextdt"));
				info.setPlancd(plancd);
				info.setSourdt(rs.getString("sourdt"));
				info.setSourst(rs.getString("sourst"));
				info.setStatus(rs.getString("status"));
				info.setSwitdt(rs.getString("switdt"));
				info.setUsercd(rs.getString("usercd"));
				info.setTypecd(rs.getString("typecd"));

				return info;
			}
		} catch (Exception ex) {
			log.error("��ѯ����״̬��������" + ex.getMessage());
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pst != null) {
					pst.close();
				}
				// closeConnection();
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		return null;
	}

	private Connection getConnection() {
		Connection conn = null;
		try {
			conn = getJrafSession().getConnection();
			if (null == conn || conn.isClosed()) {
				log.debug("�޷���ȡ�����ݿ����ӣ�");
				throw new Exception("�޷���ȡ�����ݿ����ӣ�");
			}
		} catch (Exception e) {
			log.error("���Ȼ�ȡConnectionʧ��", e);
		}
		return conn;
	}

	/**
	 * ��һ����������м�һ����¼,���ظ��ľͲ�������
	 * 
	 * @param stacid
	 * @param sourst
	 * @param sourdt
	 * @param acctbr
	 * @param bathid
	 * @param usercd
	 * @param brchcd
	 * @param status
	 * @param nextdt
	 * @param currdt
	 * @param switdt
	 * @param plancd
	 * @param datach
	 * @throws BimisException
	 */
	private void insertDataToGloImdt(String stacid, String sourst,
			String sourdt, String acctbr, String bathid, String usercd,
			String brchcd, String status, String nextdt, String currdt,
			String switdt, String plancd, String datach) throws BimisException {
		Connection conn = getConnection();
		if (conn == null) {
			return;
		}

		PreparedStatement pst = null;

		try {
			pst = conn.prepareStatement(INSERT_GLO_IMDT);

			pst.setBigDecimal(1, BigDecimal.valueOf(Integer.valueOf(stacid)));
			pst.setString(2, sourst);
			pst.setString(3, sourdt);
			pst.setString(4, acctbr);
			pst.setString(5, bathid);
			pst.setString(6, usercd);
			pst.setString(7, brchcd);
			pst.setString(8, status);
			pst.setString(9, nextdt);
			pst.setString(10, currdt);
			pst.setString(11, switdt);
			pst.setString(12, plancd);
			pst.setString(13, datach);
			pst.setString(14, "1");

			pst.execute();
		} catch (Exception ex) {
			log.error("��glo_imdt���в��������쳣:" + ex.getMessage());
		} finally {
			try {
				if (pst != null) {
					pst.close();
				}
			  closeConnection();
			} catch (Exception ex) {
				log.error(ex.getMessage());
			}
		}
	}

	/**
	 * ����glo_imdt״̬
	 * 
	 * @param stacid
	 *            ���ױ��
	 * @param bathid
	 *            ���κ�
	 * @param status
	 *            ״̬
	 * @param plancd
	 *            ��������
	 * @param datach
	 *            ���ݴ���
	 * @throws BimisException
	 */
	private void updateGloImdtStatus(String stacid, String bathid,
			String status, String plancd, String datach) throws BimisException {
		Connection conn = getConnection();
		if (conn == null) {
			return;
		}

		PreparedStatement pst = null;
		try {
			pst = conn.prepareStatement(UPDATE_GLO_IMDT_STATUS);
			pst.setString(1, status);
			pst.setBigDecimal(2, BigDecimal.valueOf(Integer.valueOf(stacid)));
			pst.setString(3, bathid);
			pst.setString(4, plancd);
			pst.setString(5, datach);

			pst.execute();
		} catch (Exception ex) {
			log.error("����glo_imdt״̬������" + ex.getMessage());
		} finally {
			try {
				if (pst != null) {
					pst.close();
				}
				closeConnection();
			} catch (Exception ex) {
				log.error(ex.getMessage());
			}
		}
	}

	/**
	 * ��ѯ�����¼�����
	 * 
	 * @param distList
	 * @param deptcd
	 * @param isFirst
	 * @param result
	 * @param count
	 * @return
	 */
	private String getChildDept(List<DistRelaBean> distList, String deptcd,
			boolean isFirst, StringBuffer result, int count) {
		result.append("'" + deptcd + "'");
		if (!isFirst)
			return result.toString();
		// �ڶ���
		for (int m = 0; m < distList.size(); m++) {
			DistRelaBean dept = distList.get(m);
			String sprrdp = dept.getSprrdp();
			if (deptcd.equals(sprrdp)) {
				result.append(",'" + dept.getDeptcd() + "'");
				// ������
				for (int n = 0; n < distList.size(); n++) {
					DistRelaBean dept1 = distList.get(n);
					if (dept.getDeptcd().equals(dept1.getSprrdp())) {
						result.append(",'" + dept1.getDeptcd() + "'");
						// ���ļ�
						for (int i = 0; i < distList.size(); i++) {
							DistRelaBean dept2 = distList.get(i);
							if (dept1.getDeptcd().equals(dept2.getSprrdp())) {
								result.append(",'" + dept2.getDeptcd() + "'");
								// ���弶
								for (int j = 0; j < distList.size(); j++) {
									DistRelaBean dept3 = distList.get(j);
									if (dept2.getDeptcd().equals(
											dept3.getSprrdp())) {
										result.append(",'" + dept3.getDeptcd()
												+ "'");
									}
								}
							}
						}
					}
				}
			}
		}
		return result.toString();
	}
	
	private void closeConnection() {
		if (jrafSession != null) {
			jrafSession.close();
			jrafSession = null;
		}
	}
}