package com.sunline.sunfe.datamanager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Document;
import org.jdom.Element;

import com.sunline.jraf.conf.BimisConf;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.DatetimeUtil;
import com.sunline.jraf.util.FileUtil;
import com.sunline.jraf.util.JDomUtil;
import com.sunline.jraf.util.XmlUtil;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sundp.adapter.DataFileAdapter;
import com.sunline.suncm.util.ComParaUtil;
import com.sunline.sunfe.util.DateUtil;
@SuppressWarnings({"unchecked","rawtypes"})
public class FileManagerActor extends Actor {

	public String MY_BATIS_SFDATAMANAGER = "com.sunline.sunfe.mybatis.sfdatamanager.";
	private static String sunline_Path = FileUtil.getHomePath();
	
	public void queryBatcdts() throws Exception {

		List<HashMap> lst = new ArrayList<HashMap>();
		String glisdt = PubUtil.getGlisdt(Integer.parseInt(SessionParaUtils.getStacid()));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Date dateGlisdt = sdf.parse(glisdt);

		for (int i = 0; i <= 30; i++) {
			HashMap hashMap = new HashMap();

			Date date = DateUtil.getDateByDays(dateGlisdt, 0 - i);
			// ����
			String batcdt = DatetimeUtil.formatDate(date, DatetimeUtil.DATE_FORMAT_YMD);
			hashMap.put("batcdt", batcdt);
			if (i == 0) {
				hashMap.put("isCurDate", true);
			}
			lst.add(hashMap);

		}

		req.addRspData(XmlUtil.createDataObjectElement(lst).removeContent());

	}

	/**
	 * @author ��ҵǿ
	 * @time 2017.8.3 15:22:32
	 * @module �����ļ�����ҳ���ѯ
	 * @desc �������κ�(batcid)������״̬(imstau)�����ݼӹ�״̬��prstau����
	 *       ����״̬(PASTAU)������״̬(ENSTAU)��������ʼʱ������(imbgdtbeg,imbgdtend)
	 */
	public void queryBatchsByBatcdt() throws Exception {
		Map hashMap = req.getReqDataMap();
		String isCurrentDate = req.getReqDataStr("isCurrentDate");
		// ��ѯ��ǰ�����������ڵ�����
		if("1".equals(isCurrentDate)){
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(SessionParaUtils.getStacid()));
			hashMap.put("batcdt", glisdt);
		}
		String imbgdtbeg = req.getReqDataStr("imbgdtbeg");
		if (imbgdtbeg != null && !"".equals(imbgdtbeg)) {
			imbgdtbeg = imbgdtbeg + ".000";
		}
		String imbgdtend = req.getReqDataStr("imbgdtend");
		if (imbgdtend != null && !"".equals(imbgdtend)) {
			imbgdtend = imbgdtend + ".000";
		}
		hashMap.put("imbgdtbeg", imbgdtbeg);
		hashMap.put("imbgdtend", imbgdtend);
		Element ele = commonDao.queryByNamedSql(MY_BATIS_SFDATAMANAGER + "queryFilesByBatcdt", hashMap);
		req.addRspData(ele.removeContent());
		req.addRspData("isCurrentDate", isCurrentDate);

	}

	public void queryBatchInfoByBatcid() throws Exception {
	
		Map map = req.getReqDataMap();

		Element ele = commonDao.queryByNamedSql(MY_BATIS_SFDATAMANAGER + "queryBatchInfoByBatcid", map);

		req.addRspData(ele.removeContent());

	}

	/**
	 * @module �����ļ�����ģ��
	 * @author ��ҵǿ
	 * @time 2017-08-04 11:20:20
	 * @desc �����ļ�����ģ�� �������κ�ID��bathid����ȡ��������־�ļ��Ĵ�����Ϣ������������Ϣ��ѯ
	 */
	public void queryFilesByBatcid() throws Exception {
		Map map = req.getReqDataMap();
		String imbgdtb = req.getReqDataStr("imbgdtb");
		if (imbgdtb != null && !"".equals(imbgdtb)) {
			imbgdtb = imbgdtb + ".000";
		}
		String imbgdte = req.getReqDataStr("imbgdte");
		if (imbgdte != null && !"".equals(imbgdte)) {
			imbgdte = imbgdte + ".000";
		}
		map.put("imbgdtb", imbgdtb);
		map.put("imbgdte", imbgdte);
		Element ele = commonDao.queryByNamedSql(MY_BATIS_SFDATAMANAGER + "queryFilesByBatcid", map);

		req.addRspData(ele.removeContent());

	}

	public void queryFileByBatcidFiNa() throws Exception {
		Map map = req.getReqDataMap();
		Element ele = commonDao.queryByNamedSql(MY_BATIS_SFDATAMANAGER + "queryFileByBatcidFiNa", map);

		req.addRspData(ele.removeContent());
	}

	/**
	 * @desc �������ס�Դϵͳ������ʱ��ȶ�������ѯ���Ĵ������
	 * @author ��ҵǿ
	 * @time 2017-7-28 15:34:23
	 * @throws Exception
	 */
	public void queryFilesBatchInfoByStacidSystidAndImdtListPage() throws Exception {
		Map map = req.getReqDataMap();
		String recedtBegin = req.getReqDataStr("recedtBegin");// ���տ�ʼʱ��

		String recedtEnd = req.getReqDataStr("recedtEnd");// ���ս���ʱ��

		if (recedtBegin != null && !"".equals(recedtBegin)) {
			recedtBegin = recedtBegin + ".000";

		}
		if (recedtEnd != null && !"".equals(recedtEnd)) {
			recedtEnd = recedtEnd + ".000";
		}
		map.put("recedtBegin", recedtBegin);
		map.put("recedtEnd", recedtEnd);
		Element element = commonDao.queryByNamedSqlWithPage(MY_BATIS_SFDATAMANAGER
				+ "queryFilesBatchInfoByStacidSystidAndImdtlistPage", req.getReqPageInfo(), map);
		req.addRspData(element.removeContent());
	}

	/**
	 * @desc ���ݱ�����־ID��ѯ���ļ�¼
	 * @author ��ҵǿ
	 */
	public void getStacXmlByMessid() throws Exception {
		String messid = req.getReqDataStr("messid");
		HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
		hashmap.put("messid", messid);
		Element e = commonDao.queryByNamedSql(MY_BATIS_SFDATAMANAGER + "getStacXmlByMessId", hashmap);
		req.addRspData(e.removeContent());
	}
	
	public void getPaerlgByBathid() throws Exception{
		String bathid = req.getReqDataStr("bathid");
		HashMap hashMap = new HashMap();
		hashMap.put("bathid", bathid);
		Element e = commonDao.queryByNamedSqlWithPage(MY_BATIS_SFDATAMANAGER + "qrySysBusiErroErromgsByBathidlistPage", req.getReqPageInfo(),hashMap);
		req.addRspData(e.removeContent());
		req.addRspData("bathid", bathid);
		
	}
	
	public void getEnerlgByBathid() throws Exception{
		String bathid = req.getReqDataStr("bathid");
		HashMap hashMap = new HashMap();
		hashMap.put("bathid", bathid);
		Element e = commonDao.queryByNamedSqlWithPage(MY_BATIS_SFDATAMANAGER + "qrySysVchrErroLogmsgsByBathidlistPage", req.getReqPageInfo(),hashMap);
		req.addRspData(e.removeContent());
		req.addRspData("bathid", bathid);
		
	}
	/**
	 * @desc �����ļ�����
	 * @author �ų�
	 * @time 2018-01-06 15:34:23
	 * @throws Exception
	 */
	public void canclFailBathid(){
		try {
			commonDao.beginTransaction();
			Map<String,Object> map = req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			map.put("stacid", stacid);
			List<Map<String,String>> list = (List<Map<String, String>>) commonDao.queryByNamedSqlForList(MY_BATIS_SFDATAMANAGER + "queryGloimdtByBatcid", map);
			
			for(Map<String,String> tempMap:list){
				String status = tempMap.get("status");    
				map.put("status", "M");
				
				if("B".equalsIgnoreCase(status)){
					 //ɾ���������������õ������õı�
					List<Map<String,String>> list2 = (List<Map<String, String>>) commonDao.queryByNamedSqlForList(MY_BATIS_SFDATAMANAGER + "queryGliMapByStatus", tempMap);
					for(Map<String,String> entina:list2){
						map.put("entina", entina.get("entina"));
						commonDao.deleteByNamedSql(MY_BATIS_SFDATAMANAGER+"deleteTablesByGliMap", map);
					}
					commonDao.updateByNamedSql(MY_BATIS_SFDATAMANAGER + "updateGloImdtByBathid", map);
				}else if("2".equals(status)){
					commonDao.updateByNamedSql(MY_BATIS_SFDATAMANAGER + "updateGloImdtByBathid", map);
				}else{
					ResultUtils.setRspData(req, "300", "ֻ�����ϵ���ʧ�ܻ����ݼӹ�ʧ�ܵ�����", "", "");
					return;
				}
			}
			 
			commonDao.commitTransaction();
			ResultUtils.setRspData(req, "200", "�����ɹ�", "", "closeCurrent","");
		} catch (Exception e) {
			getLog().logError(e);
			ResultUtils.setRspData(req, "300", "����ʧ��", "", "");
		}
	}

	/**
	 * @desc �����ļ��鵵
	 * @author �ų�
	 * @time 2018-01-08 15:34:23
	 * @throws Exception
	 *   
	 */
	public void fileUnloadingByBathid(){
		try {
			Map<String,Object> map = req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			String unLoadDay =ComParaUtil.getParavl(SessionParaUtils.getStacid(), "unloadday");
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid));
			String batcdt = (String)map.get("batcdt");
			if(Long.parseLong(unLoadDay)>getDiffDay(glisdt,batcdt)){
				ResultUtils.setRspData(req, "300", "����ʧ��,ֻ�ܹ鵵"+unLoadDay+"�����ϵ�����", "", "");
				return;
			}
			commonDao.beginTransaction();
			map.put("stacid", stacid);
			//�������β�ѯ����
			List<Map<String,String>> list = (List<Map<String, String>>) commonDao.queryByNamedSqlForList(MY_BATIS_SFDATAMANAGER + "queryGloimdtByBatcid", map);
			List<String> dataList =new ArrayList<String>();
			if(list.size()>0){
				for(Map<String,String> dataMap:list){
					dataList.add(dataMap.get("datach"));    
				}
			}else{
				ResultUtils.setRspData(req, "300", "����ʧ��,���ݲ�����", "", "");
				return;
			}
			map.put("dataList", dataList);
			//���ݵ��ݲ�ѯĿ¼
			List<Map<String,String>> list2= (List<Map<String, String>>) commonDao.queryByNamedSqlForList(MY_BATIS_SFDATAMANAGER + "queryGliimpByDatach", map);
			//ȡ���ļ�����Ŀ¼��ַ����ȡ�ļ�
			if(list2.size()==0){
				ResultUtils.setRspData(req, "300", "����ʧ��", "", "");
				return;
			}
			
			//�������β�ѯ�鵵Դ�ļ�
			List<Map<String,String>> list3= (List<Map<String, String>>) commonDao.queryByNamedSqlForList(MY_BATIS_SFDATAMANAGER + "queryGliDtlgByBatcid", map);
		
			if(list3.size()==0){
				ResultUtils.setRspData(req, "300", "�鵵�ļ�������", "", "");
				return;
			}
			
			for(Map<String,String> dataMap:list2){
				ReadFileByBuff(dataMap,list3,map);
			}
			commonDao.commitTransaction();
			ResultUtils.setRspData(req, "200", "�����ɹ�", "", "closeCurrent","");
		} catch (Exception e) {
			getLog().logError(e);
			ResultUtils.setRspData(req, "300", "����ʧ��", "", "");
		}
	}
	
	public void ReadFileByBuff(Map<String,String> dataMap,List<Map<String,String>>  fileNames,Map<String,Object> batchMap) {
	    Document config = JDomUtil.getDocument(new File(sunline_Path + "config.xml"));
	    JDomUtil jdomUtil = new JDomUtil(config);     //��ȡ�����ļ�
	
		String dir = dataMap.get("urlxph");
		try{
			String temppath = jdomUtil.getSingleNodeString("/config/sungl/fileNameManager/expConfig/filePath");//��config.xml�л�ȡ�鵵·��
			String operClassPath = BimisConf.getString("/config/sungl/datamanager/adapter");
			DataFileAdapter fnimpl = (DataFileAdapter)Class.forName(operClassPath).newInstance();
			String okFileName = fnimpl.getOkFileName((String)batchMap.get("bathid"));
			SourceUnloading(dir, temppath,okFileName);
		    for(Map<String,String> map:fileNames){
		    	SourceUnloading(dir, temppath, map.get("filena"));
		    }
			
		}catch(Exception e){
			getLog().logError(e);
			ResultUtils.setRspData(req, "300", "����ʧ��", "", "");
		}
	}

	private void SourceUnloading(String dir, String temppath, String filena) {
		FileInputStream in = null;  
		FileOutputStream out = null;
		
		// Դ�ļ�  
		File sourceFile = new File(dir + filena);  
		// Ŀ���ļ�  
		File toFile = new File(temppath + File.separator + filena);  
      try{
		  if(!sourceFile.exists()){
			  return;
		  }
		if (toFile.exists()) {//�ж��ļ�Ŀ¼�Ĵ���
		    if(!toFile.isDirectory()){//�ж��ļ��Ĵ�����       
		    	toFile.createNewFile();//�����ļ�
		     }
		}else{
		    File file2=new File(toFile.getParent());
		    file2.mkdirs();
		    if(!toFile.isDirectory()){       
			    toFile.createNewFile();//�����ļ�  
		    }
		}
		// Դ�ļ�����������  
		in = new FileInputStream(sourceFile);  
		// Ŀ���ļ����������  
		out = new FileOutputStream(toFile);  
		// �����ֽ�����  
		byte[] bs = new byte[1024*1024];  
		int length = 0;  
		// Դ�ļ���ȡһ��������  
		while ((length = in.read(bs)) != -1) {  
		    // Ŀ���ļ�д�� 
		    out.write(bs, 0, length);  
		}
		sourceFile.delete();
      }catch(Exception e){
    	  e.printStackTrace();
      }finally{
		try {
			if(in!=null){
				in.close();	
			}
			if(out!=null){
				out.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
      }
	}
	public long getDiffDay(String gilsdt,String batcdt) throws Exception{
		SimpleDateFormat sf = new SimpleDateFormat("yyyyMMdd");
    	Long diffDay = sf.parse(gilsdt).getTime()-sf.parse(batcdt).getTime();
    	long result= diffDay/1000/60/60/24;   //��
		return result;
		
	}
}
