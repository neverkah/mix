package com.sunline.sunfe.visual;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.hyperic.sigar.CpuInfo;
import org.hyperic.sigar.CpuPerc;
import org.hyperic.sigar.Sigar;

import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.JsonUtil;
import com.sunline.sunfe.visual.bean.CpuInfoBean;

/**
 * @desc ��������ʱ��ȡCPUʹ���ʵ���Ϣ����ǰ̨�����ѯ
 * @author Lanyq
 * 
 */
public class CpuInfoListener extends Actor implements ServletContextListener, Runnable {
	protected CpuInfoBean cupInfo;
	protected static ArrayBlockingQueue<HashMap> queue=new ArrayBlockingQueue<HashMap>(5000);;

	public CpuInfoBean getScheduleCpuInfo(CpuInfoBean cupInfo) {
		this.cupInfo = cupInfo;
		return cupInfo;
	}

	@Override
	public void contextInitialized(ServletContextEvent event) {
		event.getServletContext().log("��ѯCPU��Ϣ�ļ�������...");
		try {
				new Thread(this).start();
		} catch (Exception e) {

		}
	}

	@Override
	public void contextDestroyed(ServletContextEvent event) {
        event.getServletContext().log("��ǰ����رգ�ֹͣ��ѯCPU��Ϣ");
	}

	// ��ȡcpu��Ϣ
	public CpuInfoBean getCpuInfo() {
		Sigar siger = new Sigar();
		CpuInfoBean cpuInfoBean = new CpuInfoBean();

		CpuInfo[] cpuInfo;
		CpuPerc[] cpuPerc;

		java.text.DecimalFormat df = new java.text.DecimalFormat("#0.00");
		try {
			cpuInfo = siger.getCpuInfoList();
			String cpuNum = cpuInfo.length + "";// cpu����
			String mhz = df.format(cpuInfo[0].getMhz() / 1024);// cpuƵ��(��λG)
			String vendor = cpuInfo[0].getVendor();
			String model = cpuInfo[0].getModel();

			cpuInfoBean.setCpuNum(cpuNum);
			cpuInfoBean.setMhz(mhz);
			cpuInfoBean.setVendor(vendor);
			cpuInfoBean.setModel(model);
			cpuPerc = siger.getCpuPercList();
			double user = 0.0;// �û�ʹ����
			double sys = 0.0;// ϵͳʹ����
			double wait = 0.0;// ��ǰ�ȴ���
			double nice = 0.0;// Nice
			double idle = 0.0;// ������
			double combined = 0.0;// ��ʹ����

			for (int i = 0; i < cpuPerc.length; i++) {
				user += cpuPerc[i].getUser();
				sys += cpuPerc[i].getSys();
				wait += cpuPerc[i].getWait();
				nice += cpuPerc[i].getNice();
				idle += cpuPerc[i].getIdle();
				combined += cpuPerc[i].getCombined();
			}
			String cpuUser = CpuPerc.format(user / cpuPerc.length);// cpuƽ���û�ʹ����
			String cpuSys = CpuPerc.format(sys / cpuPerc.length);
			String cpuWait = CpuPerc.format(wait / cpuPerc.length);
			String cpuNice = CpuPerc.format(nice / cpuPerc.length);
			String cpuIdle = CpuPerc.format(idle / cpuPerc.length);
			String cpuCombined = CpuPerc.format(combined / cpuPerc.length);

			cpuInfoBean.setCpuUser(cpuUser);
			cpuInfoBean.setCpuSys(cpuSys);
			cpuInfoBean.setCpuWait(cpuWait);
			cpuInfoBean.setCpuIdle(cpuIdle);
			cpuInfoBean.setCpuCombined(cpuCombined);
			cpuInfoBean.setCpuNice(cpuNice);
		} catch (Exception e) {
		}
		return cpuInfoBean;
	}

	public CpuInfoBean getCupInfo() {
		return cupInfo;
	}

	public void setCupInfo(CpuInfoBean cupInfo) {
		this.cupInfo = cupInfo;
	}

	@Override
	public void run() {
		while(true){
			int h = new Date().getHours();
			int m = new Date().getMinutes();
			int s = new Date().getSeconds();
			if(s%10==0){
			cupInfo = getCpuInfo();
			HashMap hashMap=new HashMap();
			hashMap.put(h+":"+m+":"+s, cupInfo.getCpuCombined());
			try {
				if(queue.size()<5000){
					queue.put(hashMap);
				}else{
					queue.remove();//����������ʱ���Ƴ����е�ͷ��
					queue.put(hashMap);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			//System.out.println("��ǰʱ��Ϊ:"+h+":"+m+":"+s+"CPUʹ����Ϊ��"+cupInfo.getCpuCombined()+"���д�СΪ��"+queue.size());
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
