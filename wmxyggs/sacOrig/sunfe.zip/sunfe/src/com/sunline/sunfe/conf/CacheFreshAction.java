package com.sunline.sunfe.conf;


import java.util.HashMap;

import org.jdom.JDOMException;

import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.JsonUtil;
import com.sunline.sunfe.engine.CacheFreshDeal;

public class CacheFreshAction extends Actor{
	/**
	 * ˢ�»������������û���
	 */
	public void  cacheFresh(){
		try {
			HashMap<String, String> returnMap = new HashMap<String, String>();
			// ����
			CacheFreshDeal cacheFresh = new CacheFreshDeal();
			String result = cacheFresh.fresh(req.getReqDataStr("cacheName").trim());
			if (!"EXE0000".equals(result)) {
				returnMap.put("retcode", "FAIL");
				returnMap.put("retmsg", "ˢ�»���ʧ�ܣ����飡");
				req.addRspData("jsonDataStr",
						JsonUtil.convertObject2Json(returnMap));
				return;
			}
			returnMap.put("retcode", "SUCC");
			req.addRspData("jsonDataStr",JsonUtil.convertObject2Json(returnMap));
		} catch (Exception e) {
			getLog().logError("ˢ�»���ʧ��", e);
			try {
				String retmsg = e.getMessage();
				req.addRspData("jsonDataStr",
						"{\"retcode\":\"FAIL\",\"retmsg\":\"ʧ��:" + retmsg
								+ "\"}");
			} catch (JDOMException e1) {
				getLog().logError("ˢ�»���ʧ��", e);
			}
		}
	}

}
