package com.sunline.sunfe.conf;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.services.BimisFile;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.util.DatetimeUtil;
import com.sunline.jraf.util.Log;
import com.sunline.jraf.util.StringUtil;
import com.sunline.jraf.util.XmlUtil;
import com.sunline.suncm.util.ExcelUtil;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.util.ExportExcel;
import com.sunline.sunfe.util.StringUtils;

/**
 * ��Ʒ�������ñ������� && DtitAction
 * creation time: 2017-4-6 
 *
 */
public class ProdDtitAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.proddtit.";
	Log log = new Log("ProdDtitAction");
	
	/**
	 * ��ѯ��Ʒ���������б� & queryProdDtitListPage
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void queryProdDtitListPage() throws BimisException{
		try {
			SessionParaUtils.getStacid();
			HashMap<String, String> hashmap = new HashMap<String, String>();
			HashMap<String, String> resultMap = new HashMap<String, String>();
			String stacid = req.getReqDataStr("stacid"); //����ID
			String prodna = req	.getReqDataStr("prodna"); //��Ʒ����
			hashmap.put("stacid", stacid);
			hashmap.put("prodna", prodna);
			//��Ʒ��������
			Element element = commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryProdDtitlistPage",req.getReqPageInfo(), hashmap);
			List<HashMap<String,String>> sysCondList = (List<HashMap<String, String>>)
					commonDao.queryByNamedSqlForListWithPage(MYBATIS_NS+"queryProdDtitlistPage",req.getReqPageInfo(), hashmap);
			
			//��ѯ�������Ե����ֵ
			String [] prodps ={"1","2","3","4","5","6","7","8","9","a"};
			for (Iterator iterator = sysCondList.iterator(); iterator.hasNext();) {
				HashMap<String,String> confMap = (HashMap<String, String>) iterator.next();
				for (int i = 0; i < prodps.length; i++) {
					 String prodp = confMap.get("prodp"+prodps[i]);
					 if(prodp.equals("1")){
						 resultMap.put("prodp"+(i+1), "1");
					 }
				}
			}
			
			//����������
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryPrtpInfo", hashmap);
			req.addRspData(element.removeContent());
			req.addRspData("Results1",e.removeContent());
			req.addRspData("Results2",XmlUtil.createDataObjectElement(resultMap).removeContent());
		} catch (JDOMException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * �������׺Ͳ�Ʒ�����ѯ��Ʒ����������ϸ
	 * @Title: queryProdDtitInfo 
	 * @Description: luoyd
	 * @return: void
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void queryProdDtitInfo() throws BimisException{
		try {
			HashMap<String, String> hashmap =(HashMap<String, String>) req.getReqDataMap();
			Element element = commonDao.queryByNamedSql(MYBATIS_NS+"queryProdDtitInfo",hashmap);
			String module = element.getChild("Record").getChildTextNormalize("module");
			req.addRspData(element.removeContent());
			hashmap.put("module", module);
			Element trprele = commonDao.queryByNamedSql(MYBATIS_NS+"querySysTrpr", hashmap);//�������
			req.addRspData("Results3",trprele.removeContent());
			Element prtpele = commonDao.queryByNamedSql(MYBATIS_NS+"querySysPrtp", hashmap);//��������
			req.addRspData("Results4",prtpele.removeContent());
		} catch (JDOMException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * ���ղ�Ʒ��������
	 * @Title: consultProdDtit 
	 * @Description: luoyd
	 * @return: void
	 */
	public void consultProdDtit(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String stacid = req.getReqDataStr("stacid"); //����ID
			String module = req.getReqDataStr("module"); //ģ��
			
			hashmap.put("stacid", stacid);
			hashmap.put("module", module);
			
			Element element = commonDao.queryByNamedSql(MYBATIS_NS+"consultProdDtit",hashmap);
			req.addReqData(element.removeContent());
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	/**
	 * ��������
	 * @Title: adjustProdDtit 
	 * @Description: luoyd
	 * @return: void
	 */
	@SuppressWarnings("unchecked")
	public void adjustProdDtit(){
		
		HashMap<String, Object> hashmap = new HashMap<String, Object>();
		HashMap<String, String> resultMap = new HashMap<String, String>();
		 List<String> prgptpList = new LinkedList<String>();
		try {
			String stacid = req.getReqDataStr("stacid"); //����ID
			String prodcd = req.getReqDataStr("prodcd"); //��Ʒ����
			
			hashmap.put("stacid", stacid);
			hashmap.put("prodcd", prodcd);
			Element element = commonDao.queryByNamedSql(MYBATIS_NS+"queryProdDtitInfo",hashmap);
			hashmap.put("prodna", element.getChild("Record").getChildTextNormalize("prodna"));
			String p1tpkd = element.getChild("Record").getChildTextNormalize("p1tpkd");
			String p2tpkd = element.getChild("Record").getChildTextNormalize("p2tpkd");
			String p3tpkd = element.getChild("Record").getChildTextNormalize("p3tpkd");
			String p4tpkd = element.getChild("Record").getChildTextNormalize("p4tpkd");
			String p5tpkd = element.getChild("Record").getChildTextNormalize("p5tpkd");
			String p6tpkd = element.getChild("Record").getChildTextNormalize("p6tpkd");
			String p7tpkd = element.getChild("Record").getChildTextNormalize("p7tpkd");
			String p8tpkd = element.getChild("Record").getChildTextNormalize("p8tpkd");
			String p9tpkd = element.getChild("Record").getChildTextNormalize("p9tpkd");
			String patpkd = element.getChild("Record").getChildTextNormalize("patpkd");
			String trprgp = element.getChild("Record").getChildTextNormalize("trprgp");
			String module = element.getChild("Record").getChildTextNormalize("module");
			
			if(StringUtils.isNotEmpty(p1tpkd)){
				prgptpList.add(p1tpkd);
			}
			if(StringUtils.isNotEmpty(p2tpkd)){
				prgptpList.add(p2tpkd);
			}
			if(StringUtils.isNotEmpty(p3tpkd)){
				prgptpList.add(p3tpkd);
			}
			if(StringUtils.isNotEmpty(p4tpkd)){
				prgptpList.add(p4tpkd);
			}
			if(StringUtils.isNotEmpty(p5tpkd)){
				prgptpList.add(p5tpkd);
			}
			if(StringUtils.isNotEmpty(p6tpkd)){
				prgptpList.add(p6tpkd);
			}
			if(StringUtils.isNotEmpty(p7tpkd)){
				prgptpList.add(p7tpkd);
			}
			if(StringUtils.isNotEmpty(p8tpkd)){
				prgptpList.add(p8tpkd);
			}
			if(StringUtils.isNotEmpty(p9tpkd)){
				prgptpList.add(p9tpkd);
			}
			if(StringUtils.isNotEmpty(patpkd)){
				prgptpList.add(patpkd);
			}
			hashmap.put("prgptpList", prgptpList);
			//��������ϸʱ
			if(prgptpList.size()>0){
				Element prtpelement = commonDao.queryByNamedSql(MYBATIS_NS+"queryPrtpInfo",hashmap);
				req.addRspData("Results2",prtpelement.removeContent());
				Element prtpDetlelement = commonDao.queryByNamedSql(MYBATIS_NS+"queryPrtpDetlInfo",hashmap);
				req.addRspData("Results3",prtpDetlelement.removeContent());
				//�õ��ѿ�����
				List<HashMap<String,String>> descarteslist= getDescartes(hashmap,trprgp);
	            req.addRspData("Results5",XmlUtil.createDataObjectElement(descarteslist).removeContent());
			}else{
				 resultMap.put("stacid", stacid);
				 resultMap.put("productinfo", prodcd);
				 resultMap.put("productinfona", element.getChild("Record").getChildTextNormalize("prodna"));
				 String[] trprgpArray = trprgp.split(","); 
				 String [] prodps ={"1","2","3","4","5","6","7","8","9","a"};
				 for (int i = 0; i < prodps.length; i++) {
					 String prodp = element.getChild("Record").getChildTextNormalize("prodp"+prodps[i]);
					 if(prodp.equals("0")){
						 hashmap.put("prodp"+(i+1), "*");
					 }else{
						 hashmap.put("prodp"+(i+1), prodp);
					 }
				 }
				 for (int j = 0; j < trprgpArray.length; j++) {
					 hashmap.put("trprcd", trprgpArray[j]);
					 List<HashMap<String,String>>  temp = (List<HashMap<String, String>>) commonDao.
								queryByNamedSqlForList(MYBATIS_NS+"querySysDtitMap", hashmap);
					 if(temp.size()>0){
						 resultMap.put("itemcd"+trprgpArray[j], temp.get(0).get("itemcd")); //��Ŀ����
						 resultMap.put("itemna"+trprgpArray[j], temp.get(0).get("desctx")); //��Ŀ����
						 resultMap.put("typecd", temp.get(0).get("typecd")); ///�������
					 }
				}
				 List<HashMap<String,String>> descarteslist = new ArrayList<HashMap<String,String>>();
				 descarteslist.add(resultMap);
				 req.addRspData("Results5",XmlUtil.createDataObjectElement(descarteslist).removeContent());
			}
			hashmap.put("module", module);
            if (StringUtils.isNotEmpty(trprgp)) {
            	String[] trprgpArray = trprgp.split(","); 
            	hashmap.put("trprgpArray", trprgpArray);
            	Element trprelement = commonDao.queryByNamedSql(MYBATIS_NS+"queryTrprList",hashmap);
            	req.addRspData("Results4",trprelement.removeContent());
			}
        	req.addRspData(element.removeContent());
		} catch (Exception e) {
			log.logError(e);
		} 
	}
	
	/**
	 * ��ȡ�ѿ�����
	 * ProdDtitAction.java
	 * TODO
	 * FZF
	 * ����11:19:08
	 * List
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private List getDescartes(HashMap<String, Object> hashmap, String trprgp) throws BimisException {
		List<String>  prtps = (List<String>) hashmap.get("prgptpList"); // ������
		List<List<String>> prtpdetl = new  ArrayList<List<String>>();//��������ϸ�ĵѿ�����
		List<List<String>> prtpdetlna = new  ArrayList<List<String>>();//��������ϸ�ĵѿ�����
        List<List<String>> dimvalue = new ArrayList<List<String>>();//��������ϸ�ļ���
        List<List<String>> dimvaluena = new ArrayList<List<String>>();//��������ϸ�ļ���
        List<HashMap<String,String>> resultList = new ArrayList<HashMap<String,String>>();
       //ѭ����������ϸ�ļ���
		for (Iterator iterator = prtps.iterator(); iterator.hasNext();) {
			String   prtp = (String)iterator.next();
			List<String> listcd = new ArrayList<String>();
			listcd = (List<String>) commonDao.queryByNamedSqlForList(MYBATIS_NS+"queryPrtpDetlInfoGroup",prtp);
			dimvalue.add(listcd);
			
			List<String> listna = new ArrayList<String>();
			listna = (List<String>) commonDao.queryByNamedSqlForList(MYBATIS_NS+"queryPrtpDetlInfoGroupna",prtp);
			dimvaluena.add(listna);
		}
		//�õ��ѿ�����
		circulate(dimvalue, prtpdetl);
		circulate(dimvaluena, prtpdetlna);
		//�����ѿ�����
		int index=0;
		for(Iterator iterator = prtpdetl.iterator(); iterator.hasNext();) {
			 HashMap<String,String> resultMap = new HashMap<String, String>();//һ�н������
			 List<String> prodArray = ((List<String>) iterator.next());//����
			 List<String> prodnaArray = prtpdetlna.get(index);//������ϸ����
			 //��Ʒ��Ϣ
			 resultMap.put("productinfo",  hashmap.get("prodcd").toString()+","+ prodArray.toString().substring(1, prodArray.toString().length()-1).trim());
			 resultMap.put("productinfona",hashmap.get("prodna").toString()+","+ prodnaArray.toString().substring(1, prodnaArray.toString().length()-1));
			 index = index+1;
			 String [] prodps ={"1","2","3","4","5","6","7","8","9","10"};
			 HashMap<String,String > queryMap = new HashMap<String, String>();//��ѯMAP
			 for(int i = 0; i<10;i++){
				 queryMap.put("prodp"+prodps[i], "*"); //����
			 }
			 for(int i = 0; i<prodArray.size();i++){
				 queryMap.put("prodp"+prodps[i], prodArray.get(i)); //����
			 }
			 queryMap.put("prodcd", hashmap.get("prodcd").toString()); // ��Ʒ
			 queryMap.put("stacid", hashmap.get("stacid").toString()); // ����
			 String[] trprgpArray = trprgp.split(","); //�������
			 for (int i = 0; i < trprgpArray.length; i++) {
				 queryMap.put("trprcd", trprgpArray[i]);
				 List<HashMap<String,String>>  temp = (List<HashMap<String, String>>) commonDao.
	 						queryByNamedSqlForList(MYBATIS_NS+"querySysDtitMap", queryMap);
				 if(temp.size()>0){
					 resultMap.put("itemcd"+trprgpArray[i], temp.get(0).get("itemcd")); //��Ŀ����
					 resultMap.put("itemna"+trprgpArray[i], temp.get(0).get("desctx")); //��Ŀ����
					 resultMap.put("typecd", temp.get(0).get("typecd")); ///�������
				 }
			 }
			 resultList.add(resultMap);
		}
		return resultList;
	}
	 /** 
     * ѭ��ʵ��dimValue�еĵѿ��������������result�� 
     * @param dimValue ԭʼ���� 
     * @param result ������� 
     */  
	@SuppressWarnings("unused")
	public void circulate(List<List<String>> dimValue, List<List<String>> result) {
		int total = 1;
		for (List<String> list : dimValue) {
			total *= list.size();
		}
		String[] myResult = new String[total];
		int itemLoopNum = 1;
		int loopPerItem = 1;
		int now = 1;
		for (List<String> list : dimValue) {
			now *= list.size();

			int index = 0;
			int currentSize = list.size();

			itemLoopNum = total / now;
			loopPerItem = total / (itemLoopNum * currentSize);
			int myIndex = 0;

			for (String string : list) {
				for (int i = 0; i < loopPerItem; i++) {
					if (myIndex == list.size()) {
						myIndex = 0;
					}

					for (int j = 0; j < itemLoopNum; j++) {
						myResult[index] = (myResult[index] == null ? ""
								: myResult[index] + ",") + list.get(myIndex);
						index++;
					}
					myIndex++;
				}

			}
		}

		List<String> stringResult = Arrays.asList(myResult);
		for (String string : stringResult) {
			String[] stringArray = string.split(",");
			result.add(Arrays.asList(stringArray));
		}
	}
	
	/**
	 * ���ݲ�Ʒ����ģ���ѯϵͳ���������Ͷ���
	 * @throws BimisException 
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void querysysprtpBymodule() throws BimisException, JDOMException{
		HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
		Element prtpele = commonDao.queryByNamedSql(MYBATIS_NS+"querySysPrtp", hashmap);
		req.addRspData("Results1",prtpele.removeContent());
		Element trprele = commonDao.queryByNamedSql(MYBATIS_NS+"querySysTrpr", hashmap);
		req.addRspData("Results2",trprele.removeContent());
	}
	
	/**
	 * ������Ʒ����
	 * @Title: addDtit 
	 * @Description: TODO
	 * @return: void
	 * @throws JDOMException 
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void addDtit() throws JDOMException{
		try{
			HashMap<String, Object> hashmap = (HashMap<String, Object>) req.getReqDataMap();
			Element ProdDtitdetail = commonDao.queryByNamedSql(MYBATIS_NS+"queryProdDtitdetail", hashmap);
			if(ProdDtitdetail.getChild("Record") != null){
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "�ò�Ʒ�Ѵ��ڣ�������ѡ��");
				return;
			}
			if(!(hashmap.get("trprcd") instanceof String)){
				List<String> trprcdlist = (List) hashmap.get("trprcd");
				String trprcdString="";
				if(trprcdlist != null){
					for (Iterator iterator = trprcdlist.iterator(); iterator.hasNext();) {
						String trprcd = (String) iterator.next();
						trprcdString = trprcdString+trprcd+",";
					}
					hashmap.put("trprcd", trprcdString.substring(0, trprcdString.length()-1));
				}
			}
			commonDao.insertByNamedSql(MYBATIS_NS+"addDtitConf", hashmap);
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("stacid", hashmap.get("stacid").toString());
			req.addRspData("prodcd", hashmap.get("prodcd").toString());
		}catch(BimisException e){
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ��");
			log.logError("������Ʒ������Ϣ������"+e.getMessage());
		}
		
	}
	
	/**
	 * ��ѯ��Ʒ��������
	 * @Title: queryProdDtitdetail 
	 * @return: void
	 */
	@SuppressWarnings("unchecked")
	public void queryProdDtitdetail() throws BimisException, JDOMException{
		HashMap<String, Object> hashmap = (HashMap<String, Object>) req.getReqDataMap();
		Element ProdDtitdetail = commonDao.queryByNamedSql(MYBATIS_NS+"queryProdDtitdetail", hashmap);
		req.addRspData(ProdDtitdetail.removeContent());
	}
	/**
	 * ��Ʒ���� 
	 * @Title: deployProdDtit 
	 * @Description: TODO
	 * @return: void
	 * @throws JDOMException 
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void deployProdDtit() throws JDOMException{
		try {
			HashMap<String, Object> hashmap = (HashMap<String, Object>) req.getReqDataMap();
			if(!( hashmap.get("trprcd")  instanceof String )){
				List<String> trprcdlist = (List) hashmap.get("trprcd");
				String trprcdString="";
				if(trprcdlist != null){
					for (Iterator iterator = trprcdlist.iterator(); iterator.hasNext();) {
						String trprcd = (String) iterator.next();
						trprcdString = trprcdString+trprcd+",";
					}
					hashmap.put("trprcd", trprcdString.substring(0, trprcdString.length()-1));
				}
			}
			
			commonDao.updateByNamedSql(MYBATIS_NS+"deployProdDtit", hashmap);
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("navTabId", "proddtit_main");
			req.addRspData("callbackType", "closeCurrent");
		} catch (BimisException e) {
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ��");
			log.logError("�����Ʒ������Ϣ������"+e.getMessage());
		}
		
	}
	
	/**
	 * ���������Ϣ
	 * @Title: saveAdjustProdDtit 
	 * @Description: TODO
	 * @return: void
	 * @throws JDOMException 
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void saveAdjustProdDtit() throws JDOMException {
		try {
			HashMap<String, Object> hashmap = (HashMap<String, Object>) req.getReqDataMap();
			String module = (String) hashmap.get("module");
			commonDao.beginTransaction();
			commonDao.deleteByNamedSql(MYBATIS_NS+"deleteProdDtitMap", hashmap);
			if( hashmap.get("productcd")  instanceof String ){
				HashMap<String, Object> sys_dtit_map = new HashMap<String, Object>();
				String [] prodps = hashmap.get("productcd").toString().split(","); //��Ʒ
				sys_dtit_map.put("prodcd", hashmap.get("prodcd"));
				sys_dtit_map.put("stacid", hashmap.get("stacid"));
				sys_dtit_map.put("dtitcd", hashmap.get("dtitcd-"+hashmap.get("index").toString()));
				//����
				for (int i = 1; i <= 10; i++) {
					if(i<prodps.length && !StringUtil.isNullOrEmpty(prodps[i])){
						sys_dtit_map.put("prodp"+i,prodps[i].trim());
					}else{
						sys_dtit_map.put("prodp"+i, "*");
					}
				}
				commonDao.insertByNamedSql(MYBATIS_NS+"saveSysDtitMap",sys_dtit_map);
			}else{
				List prodpList = (List) hashmap.get("productcd");
				List indexList = (List) hashmap.get("index");
				//�������ݵ� sys_dtit_map 
				for (int j = 0; j < prodpList.size(); j++) {
				  HashMap<String, Object> sys_dtit_map = new HashMap<String, Object>();
				    sys_dtit_map.put("prodcd", hashmap.get("prodcd"));
					String prodp = (String) prodpList.get(j);
					String [] prodps = prodp.split(","); //��Ʒ����
					//����
					for (int i = 1; i <= 10; i++) {
						if( i<prodps.length && !StringUtil.isNullOrEmpty(prodps[i])){
							sys_dtit_map.put("prodp"+i,prodps[i].trim());
						}else{
							sys_dtit_map.put("prodp"+i, "*");
						}
					}
					sys_dtit_map.put("dtitcd", hashmap.get("dtitcd-"+indexList.get(j)));
					commonDao.insertByNamedSql(MYBATIS_NS+"saveSysDtitMap",sys_dtit_map);
				  }
			}
			 //�������ݵ�sys_dtit
			Iterator iter = hashmap.entrySet().iterator();
			while (iter.hasNext()) {
				Map.Entry entry = (Map.Entry) iter.next();
				Object key = entry.getKey();
				Object val = entry.getValue();
				//�����������
				if (key.toString().startsWith("dtitcd-")) {
					String index = key.toString().split("-")[1];
					Iterator iter1 = hashmap.entrySet().iterator();
					while (iter1.hasNext()) {
						Map.Entry entry1 = (Map.Entry) iter1.next();
						Object key1 = entry1.getKey();
						Object val1 = entry1.getValue();
						if (key1.toString().startsWith("itemcd-") && key1.toString().split("-")[2].equals(index)) {
							HashMap<String, Object> sys_dtit = new HashMap<String, Object>();
							sys_dtit.put("stacid", hashmap.get("stacid"));
							sys_dtit.put("dtitcd", val);
							sys_dtit.put("trprcd", key1.toString().split("-")[1]);
							sys_dtit.put("itemcd",  val1.toString());
							sys_dtit.put("reitem", "0");
							sys_dtit.put("usedtp", "1");
							sys_dtit.put("efctdt", "20100101");
							sys_dtit.put("inefdt", "20501231");
							sys_dtit.put("module", module);
							Iterator iter2 = hashmap.entrySet().iterator();
							while (iter2.hasNext()) {
								Map.Entry entry2= (Map.Entry) iter2.next();
								Object key2 = entry2.getKey();
								Object val2= entry2.getValue();
								if(key2.toString().startsWith("itemna-"+key1.toString().split("-")[1]) 
										&& key2.toString().split("-")[2].equals(index)){
									sys_dtit.put("desctx", val2.toString().split("-")[1]);
								 }
							}
							//�Ѵ�������£�������������
							int result = commonDao.updateByNamedSql(MYBATIS_NS+"updaetSysDtit",sys_dtit);
							if(result == 0 ){
								commonDao.insertByNamedSql(MYBATIS_NS+"saveSysDtit",sys_dtit);
							}
						}
					}
				}
		    }
			commonDao.commitTransaction();
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("navTabId", "proddtit_main");
			req.addRspData("callbackType", "closeCurrent");
		} catch (BimisException e) {
			commonDao.rollBack();
			log.logError("�����Ʒ����������Ϣ������"+e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ��");
			req.addRspData("navTabId", "");
			req.addRspData("callbackType", "");
		}
		
	}
	/**
	 * ��ѯ��������
	 * @Title: querySysDtitMap 
	 * @Description: TODO
	 * @return: void
	 */
	public void querySysDtitMap() throws JDOMException{
		try {
			String prodcd = req.getReqDataStr("prodcd");//��Ʒ
			String prodp = req.getReqDataStr("prodp");//����
			String prodpArray[] = prodp.split(",");
			HashMap<String,String> sysdtitmap = new HashMap<String, String>();
			sysdtitmap.put("prodcd", prodcd);
			for (int i = 0 ;i < prodpArray.length; i++) {
				if(StringUtil.isNullOrEmpty(prodpArray[i])){
					sysdtitmap.put("prodp"+(i+1), "*");
				}else{
					sysdtitmap.put("prodp"+(i+1), prodpArray[i]);
				}
			}
			sysdtitmap.put("stacid", req.getReqDataStr("stacid"));
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"querySysDtitMap", sysdtitmap);
			req.addRspData(e.removeContent());
		} catch (BimisException e) {
			e.printStackTrace();
		}
	}
	/**
	 * ͨ����������ѯ��Ŀ��Ϣ
	 * @Title: getItemByTypecd 
	 * @Description: TODO
	 * @return: void
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void getItemByTypecd() throws JDOMException{
		try {
			HashMap<String, Object> hashmap = (HashMap<String, Object>) req.getReqDataMap();
			hashmap.put("stacid", SessionParaUtils.getStacid());
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getItemByTypecd", hashmap);
			req.addRspData(e.removeContent());
		} catch (BimisException e) {
			e.printStackTrace();
		}

	}
	/**
	 * /���浥�к�����������
	 * @throws JDOMException 
	 * @throws BimisException 
	 * @Title: saveDtit 
	 */
	public void  saveDtit() throws JDOMException{
		try{
			HashMap<String ,String > sys_dtit =  new HashMap<String, String>();
			String dtitcd  = req.getReqDataStr("dtitcd");
			String module  = req.getReqDataStr("module");
			sys_dtit.put("dtitcd", dtitcd);
			sys_dtit.put("stacid", req.getReqDataStr("stacid"));
			sys_dtit.put("module", module);
			String itemcds  = req.getReqDataStr("itemcd");
			String trprcds  = req.getReqDataStr("trprcds");
			String [] itemcdArray = itemcds.split(",");
			String [] trprcdArray = trprcds.split(",");
			commonDao.beginTransaction();
			for(int i = 0 ;i< trprcdArray.length;i++){
				sys_dtit.put("itemcd",itemcdArray[i].split("-")[0]);
				sys_dtit.put("reitem", "0");
				sys_dtit.put("usedtp", "1");
				sys_dtit.put("efctdt", "20100101");
				sys_dtit.put("inefdt", "20501231");
				sys_dtit.put("trprcd", trprcdArray[i]);
				sys_dtit.put("desctx", itemcdArray[i].split("-")[1]);
				//�Ѵ�������£�������������
				int result = commonDao.updateByNamedSql(MYBATIS_NS+"updaetSysDtit",sys_dtit);
				if(result == 0 ){
					commonDao.insertByNamedSql(MYBATIS_NS+"saveSysDtit",sys_dtit);
				}
			}
			commonDao.commitTransaction();
			req.addRspData("flag", "0");
			req.addRspData("msg", "�����ɹ�");
		}catch (BimisException e) {
			commonDao.rollBack();
			log.logError(e);
			req.addRspData("flag", "-1");
			req.addRspData("msg", "����ʧ�ܣ�"+e.getErrmsg());
		}
	}
	/**
	 * ɾ��������Ϣ
	 * @Title: deleteProdDtit 
	 * @Description: TODO
	 * @return: void
	 * @throws JDOMException 
	 */
	@SuppressWarnings("rawtypes")
	public void deleteProdDtit() throws JDOMException{
		
		try {
			commonDao.beginTransaction();
			String prodcd = req.getReqDataStr("prodcd");
			HashMap<String ,String > delMap =  new HashMap<String, String>();
			if(StringUtil.isNullOrEmpty(prodcd)){
				List<String> prodtit = req.getReqDataTexts("proddtits");
			
				for (Iterator iterator = prodtit.iterator(); iterator.hasNext();) {
					String string = (String) iterator.next();
					 delMap.put("stacid", string.split("-")[0]);
					 delMap.put("prodcd", string.split("-")[1]);
					 commonDao.deleteByNamedSql(MYBATIS_NS+"deleteProdDtitConf", delMap);
					 commonDao.deleteByNamedSql(MYBATIS_NS+"deleteProdDtitMap", delMap);
				 }
			}else{
			String stacid = req.getReqDataStr("stacid");
			delMap.put("stacid", stacid);
			delMap.put("prodcd", prodcd);
			commonDao.deleteByNamedSql(MYBATIS_NS+"deleteProdDtitConf", delMap);
		    commonDao.deleteByNamedSql(MYBATIS_NS+"deleteProdDtitMap", delMap);
			}
			commonDao.commitTransaction();
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
		} catch (Exception e) {
			log.logError(e);
			commonDao.rollBack();
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ��");
			
		}
	}
	
	
	/**
	 * 
	 * @Title: exportSysDtitMap 
	 * @date: 2018��3��28�� ����10:12:33 
	 * @Description: ������Ʒ������Ϣ
	 * @return: void
	 */
	@SuppressWarnings({ "unchecked" })
	public void exportSysDtitMap(){
		try {
			HashMap<String, Object> hashmap = new HashMap<String, Object>();
			String stacid = req.getReqDataStr("stacid"); //����ID
			String prodcd = req.getReqDataStr("prodcd"); //��Ʒ����
			hashmap.put("stacid", stacid);
			hashmap.put("prodcd", prodcd);
			List<Object> resultObject = getSysDtitInto(hashmap);
            String title = "��Ʒ����������Ϣ";
            ExportExcel ex = new ExportExcel(title, (String[])resultObject.get(0), (List<String[]>)resultObject.get(1));
            ex.export();
            req.addRspFilePathName(ex.getFilename(), title+DatetimeUtil.formatDate(new Date(), "yyyyMMddHHmmss")+".xls");
		} catch (Exception e) {
			log.logError(e);
		} 
	}
	
	/**
	 * 
	 * @param hashmap 
	 * @Title: getSysDtitInto 
	 * @date: 2017-11-3 ����2:52:54 
	 * @Description: ���뵼��ʱ����ȡ������Ϣ
	 * @return: void
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<Object>  getSysDtitInto(HashMap<String, Object> hashmap) throws BimisException{
		List<Object> resultObject = new ArrayList<>();
		HashMap<String, String> resultMap = new HashMap<String, String>();
		List<HashMap<String,String>> descarteslist = new ArrayList<HashMap<String,String>>();
		List<HashMap<String,String>> trprList = new ArrayList<HashMap<String,String>>();
		List<String> prgptpList = new ArrayList<String>();
		String [] prodps ={"1","2","3","4","5","6","7","8","9","a"};
		Element element = commonDao.queryByNamedSql(MYBATIS_NS+"queryProdDtitInfo",hashmap);
		hashmap.put("prodna", element.getChild("Record").getChildTextNormalize("prodna"));
		for (int i = 0; i < prodps.length; i++) {
			String tpkd = element.getChild("Record").getChildTextNormalize("p"+prodps[i]+"tpkd");
			if(StringUtils.isNotEmpty(element.getChild("Record").getChildTextNormalize("p"+prodps[i]+"tpkd"))){
				prgptpList.add(tpkd);
			}
		}
		String trprgp = element.getChild("Record").getChildTextNormalize("trprgp");
		String module = element.getChild("Record").getChildTextNormalize("module");
		hashmap.put("prgptpList", prgptpList);
		//��������ϸʱ
		if(prgptpList.size()>0){
			//�õ���ϸ���ݵĵѿ�����
			descarteslist= getDescartes(hashmap,trprgp);
		}else{
			 resultMap.put("stacid", (String) hashmap.get("stacid"));
			 String pordcd = (String) hashmap.get("prodcd");
			 resultMap.put("productinfo", pordcd.substring(0, pordcd.length()-1));
			 resultMap.put("productinfona", element.getChild("Record").getChildTextNormalize("prodna"));
			 String[] trprgpArray = trprgp.split(","); 
			 for (int i = 0; i < prodps.length; i++) {
				 String prodp = element.getChild("Record").getChildTextNormalize("prodp"+prodps[i]);
				 if(prodp.equals("0")){
					 hashmap.put("prodp"+(i+1), "*");
				 }else{
					 hashmap.put("prodp"+(i+1), prodp);
				 }
			 }
			 //���������
			 for (int j = 0; j < trprgpArray.length; j++) {
				 hashmap.put("trprcd", trprgpArray[j]);//�������
				 List<HashMap<String,String>>  temp = (List<HashMap<String, String>>) commonDao.
							queryByNamedSqlForList(MYBATIS_NS+"querySysDtitMap", hashmap);
				 if(temp.size()>0){
					 resultMap.put("itemcd"+trprgpArray[j], temp.get(0).get("itemcd")); //��Ŀ����
					 resultMap.put("itemna"+trprgpArray[j], temp.get(0).get("desctx")); //��Ŀ����
					 resultMap.put("typecd", temp.get(0).get("typecd")); ///�������
				 }
			}
			 descarteslist.add(resultMap);
		}
		hashmap.put("module", module);
        if (StringUtils.isNotEmpty(trprgp)) {
        	String[] trprgpArray = trprgp.split(","); 
        	hashmap.put("trprgpArray", trprgpArray);
        	trprList = (List<HashMap<String, String>>) 
        			commonDao.queryByNamedSqlForList(MYBATIS_NS+"queryTrprList",hashmap);
		}
        
        String []  rowsName =new String[3+trprList.size()];
        List<String[]> dataObject = new ArrayList<>();
        //������
        rowsName[0]="��Ʒ���Դ���";
        rowsName[1]="��Ʒ��Ϣ";
        rowsName[2]="���������";
        int title_index = 3;
        for (Iterator iterator = trprList.iterator(); iterator.hasNext();) {
			HashMap<String, String> trpr = (HashMap<String, String>) iterator.next();
			rowsName[title_index]=trpr.get("trprna")+"��Ŀ";
			title_index = title_index +1;
		}
        for (int i = 0; i < descarteslist.size(); i++) {
        	HashMap<String, String> rowdata = (HashMap<String, String>) descarteslist.get(i);
        	String [] row_data  = new String[3+trprList.size()];
        	String productinfo = rowdata.get("productinfo");
        	row_data[0]=productinfo;
        	row_data[1]=rowdata.get("productinfona");
        	if(rowdata.containsKey("typecd")){
        		row_data[2]=rowdata.get("typecd");
        		int index = 3;
            	for (Iterator iterator = trprList.iterator(); iterator.hasNext();) {
    				HashMap<String, String> row_trpr = (HashMap<String, String>) iterator.next();
    				if(rowdata.containsKey("itemcd"+row_trpr.get("trprcd"))){
    					row_data[index]=rowdata.get("itemcd"+row_trpr.get("trprcd"));
    				}else{
    					row_data[index]="";
    				}
    				index = index +1;
    			}
        	}
        	dataObject.add(row_data);
		}
        resultObject.add(rowsName);
        resultObject.add(dataObject);
		return resultObject;
	}
	
	
	/**
	 * @Title: importProddtit 
	 * @date: 2018��3��28�� ����2:05:46 
	 * @Description:�����Ʒ������Ϣ
	 * @throws JDOMException
	 * @return: void
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void importProddtit() throws JDOMException{
		try {
            Element ele = req.getReqData();
            Element filename = (Element) ele.getChildren("filename").get(0);
            // ���ݿ��е��ļ���־
            String fileid = filename.getAttributeValue("fileid");
            BimisFile file = BimisFile.getInfo(JrafSession.getCurrentRootSession(), Long.parseLong(fileid));// ��ȡ�ļ��������
            InputStream is = file.getFileDataAsStream(); // ����ļ���
            String fileStr = file.getFileExt(); // ��ȡ����Excel�ĺ�׺��
            if (!fileStr.equals("xls") && !fileStr.equals("xlsx")) {// �ļ�����Excel
                req.addRspData("retCode", "300");
                req.addRspData("retMessage", "��ѡ���ʽΪ.xls����.xlsx���ļ�����!");
                return;
            }
            Workbook wbs = null;
            if (fileStr.equals("xls")) {
                wbs = new HSSFWorkbook(is);
            } else if (fileStr.equals("xlsx")) {
                wbs = new XSSFWorkbook(is);
            }
            //����ʱ����Ĳ��������ף���Ʒ��Ϣ
            HashMap<String, Object> param = new HashMap<String, Object>();
			String stacid = req.getReqDataStr("stacid"); //����ID
			String prodcd = req.getReqDataStr("prodcd"); //��Ʒ����
			param.put("stacid", stacid);
			param.put("prodcd", prodcd);
			//��ѯ��Ʒ������Ϣ
			Element element = commonDao.queryByNamedSql(MYBATIS_NS+"queryProdDtitInfo",param);
			String trprgp = element.getChild("Record").getChildTextNormalize("trprgp");//�������
			String module = element.getChild("Record").getChildTextNormalize("module");//ģ��
			String[] trprgpArray = trprgp.split(","); //�������
			param.put("trprgpArray", trprgpArray);
			param.put("module", module);
			//��ѯ���������Ϣ
//			List<HashMap<String,String>> trprList = (List<HashMap<String, String>>) 
//        					commonDao.queryByNamedSqlForList(MYBATIS_NS+"queryTrprList",param);
            List<String[]> ExcelValue = ExcelUtil.getExcelValue(wbs.getSheetAt(0));
            List<HashMap<String,String>> sysDtitMapList = new ArrayList<>();
            List<HashMap<String,String>> sysDtitList = new ArrayList<>();
            if(ExcelValue.get(0).length != trprgpArray.length+3){
            	  req.addRspData("retCode", "300");
                  req.addRspData("retMessage", "����ģ�����Ʒ�������ò�һ��!");
                  return;
            }
            commonDao.beginTransaction();
            for (int k=0;k<ExcelValue.size();k++) {
            	 HashMap<String, String> sys_dtit_map = new HashMap<String, String>();
            	 //��������
            	 String[] sysdtitRow = ExcelValue.get(k);
            	 //��һ��Ϊ��Ʒ������Ϣ
            	 String prodp = (String) sysdtitRow[0];
				 String [] prodps = prodp.split(",");//��Ʒ����
				 sys_dtit_map.put("prodcd", prodcd);
				//��Ʒ����
				 for (int i = 1; i <= 10; i++) {
					if( i<prodps.length && !StringUtil.isNullOrEmpty(prodps[i])){
						sys_dtit_map.put("prodp"+i,prodps[i].trim());
					}else{
						sys_dtit_map.put("prodp"+i, "*");
					}
				 }
				 //�ڶ���Ϊ�������
				 String dtitcd = sysdtitRow[2];
				 //���������δ��д����Ĭ��Ϊ�������ݲ���Ч
				 if(StringUtil.isNullOrEmpty(dtitcd)){
					 continue;
				 }
				 sys_dtit_map.put("dtitcd", sysdtitRow[2]);
				 sysDtitMapList.add(sys_dtit_map); 
				 int index= 0;
            	 for (int i = 3; i < sysdtitRow.length; i++) {
            		 HashMap<String, String> sys_dtit = new HashMap<String, String>();
            		 String trprcd = trprgpArray[index];
            		 String itemcd = sysdtitRow[i];
            		 sys_dtit.put("prodna", sysdtitRow[1]);
            		 sys_dtit.put("stacid", stacid);
            		 sys_dtit.put("dtitcd", dtitcd);
            		 sys_dtit.put("trprcd", trprcd);
            		 if(StringUtil.isNullOrEmpty(itemcd)){
            			 throw new BimisException("-1", "��Ʒ��"+prodp+"��"+itemcd+"��Ŀ����Ϊ�գ�");
            		 }
            		 sys_dtit.put("itemcd", itemcd);
            		 sys_dtit.put("reitem", "0");
					 sys_dtit.put("usedtp", "1");
					 sys_dtit.put("efctdt", "20100101");
					 sys_dtit.put("inefdt", "20501231");
					 sys_dtit.put("desctx", getItemnaByitemcd(sys_dtit));
            		 sysDtitList.add(sys_dtit);
            		 index = index+1;
				 }
            	
			}
            if(sysDtitMapList.size() == 0){
            	 throw new BimisException("-1", "����ģ�岻��Ϊ�գ�");
            }
            //�����Ʒ����������Ϣ
            for (Iterator iterator = sysDtitList.iterator(); iterator.hasNext();) {
				HashMap<String, String> sysdtit = (HashMap<String, String>) iterator.next();
				int count = commonDao.updateByNamedSql(MYBATIS_NS+"updaetSysDtit", sysdtit);
				if(count == 0){
					commonDao.insertByNamedSql(MYBATIS_NS+"saveSysDtit", sysdtit);
				}
			}
            commonDao.deleteByNamedSql(MYBATIS_NS+"deleteProdDtitMap", sysDtitMapList.get(0));
            for (Iterator iterator = sysDtitMapList.iterator(); iterator.hasNext();) {
				HashMap<String, String> sysdtitmap = (HashMap<String, String>) iterator.next();
					commonDao.insertByNamedSql(MYBATIS_NS+"saveSysDtitMap", sysdtitmap);
			}
            commonDao.commitTransaction();
            req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("callbackType", "closeCurrent");
			req.addRspData("navTabId", "proddtit_adjust");//
        } catch(Exception e){
        	commonDao.rollBack();
        	log.logError(e);
        	req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ��"+e.getMessage());
			req.addRspData("forwardUrl", "");
     }
	}
	
	/**
	 * @Title: getItemnaByitemcd 
	 * @date: 2018��3��28�� ����2:06:56 
	 * @Description:  ��ȡ��Ŀ����
	 * @param object
	 * @throws BimisException
	 * @return: String
	 */
	private String getItemnaByitemcd(HashMap<String,String> object) throws BimisException {
		String itemna = "";
		Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getItemnaByitemcd", object);
		if(e.getChild("Record") != null){
			itemna = e.getChild("Record").getChildText("itemna");
		}else{
			throw new BimisException("-1", "��Ʒ��"+object.get("prodna")+"��"+object.get("itemcd")+"��Ŀ�����ڣ�");
		}
		return itemna;
	}
}
