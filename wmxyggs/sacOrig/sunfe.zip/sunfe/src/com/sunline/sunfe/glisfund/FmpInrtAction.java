package com.sunline.sunfe.glisfund;

import java.util.Map;




import org.jdom.Element;
import org.jdom.JDOMException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.sunfe.util.MybatisPathUtil;
import com.sunline.sunfe.util.StringUtils;

/**
 * @author ����
 * @Email xiongl@sunline.cn
 * @Time 2018��1��3��
 * @��������ã�������Ϣ
 */
@SuppressWarnings("unchecked")
public class FmpInrtAction extends Actor {
	private static final Logger logger = LoggerFactory.getLogger(FmpInrtAction.class);

	/**
	 * @throws JDOMException
	 * @�˷��������ã���ѯ������Ϣ��Ϣ
	 */
	public void queryFmpInrtInfo() throws JDOMException {
		try {
			Map<String, Object> map = req.getReqDataMap();
			String pageNo = req.getReqDataStr("pageNum");
			if (StringUtils.isNotEmpty(pageNo))
				req.setReqPageNo(Integer.parseInt(pageNo));
			Element e = commonDao.queryByNamedSqlWithPage(MybatisPathUtil.FMP_INRT + "queryFmpInrtlistPage", req.getReqPageInfo(), map);
			req.addRspData(e.removeContent());
			new PublicFmbCntrInfoUtil(commonDao).addReqInfoTo(map, req);
		} catch (JDOMException | BimisException e) {
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "��ѯʧ��" + e.getMessage());
		}
	}
}
