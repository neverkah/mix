package com.sunline.sunfe.entity;

import java.math.BigDecimal;
/**
 * ����˻�
 * @ClassName: com.sunline.sungl.entity.GlbDeptBook 
 * @Description: TODO����˻��� Glb_Dept_Book
 * @author: luoyd
 * @date: 2017��4��5�� ����5:26:36
 */
public class GlbDeptBook {

	private int 	stacid; // ����
	private String 	acctdt; // ��������
	private String 	systid; // Դϵͳ��ʶ
	private String 	acctno; // �˻���
	private String 	subacc; // �˻����
	private String 	brchcd; // ��������
	private String 	accttp; // "1����ϸ�˻� 2�������˻�"
	private String 	typecd; // ������
	private String 	crcycd; // ����
	private BigDecimal 	captal; // ����
	private BigDecimal 	intret; // Ӧ����Ϣ
	private String 	trprcd; // �������(�˶�ʱ)
	private String 	itemcd; // ���˿�Ŀ
	private String 	prodcd; // ��Ʒ����
	private String 	loanp1; // ��Ʒ����1
	private String 	loanp2; // ��Ʒ����2
	private String 	loanp3; // ��Ʒ����3
	private String 	loanp4; // ��Ʒ����4
	private String 	loanp5; // ��Ʒ����5
	private String 	loanp6; // ��Ʒ����6
	private String 	loanp7; // ��Ʒ����7
	private String 	loanp8; // ��Ʒ����8
	private String 	loanp9; // ��Ʒ����9
	private String 	loanpa; // ��Ʒ����10
	
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getAcctdt() {
		return acctdt;
	}
	public void setAcctdt(String acctdt) {
		this.acctdt = acctdt;
	}
	public String getSystid() {
		return systid;
	}
	public void setSystid(String systid) {
		this.systid = systid;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public String getSubacc() {
		return subacc;
	}
	public void setSubacc(String subacc) {
		this.subacc = subacc;
	}
	public String getBrchcd() {
		return brchcd;
	}
	public void setBrchcd(String brchcd) {
		this.brchcd = brchcd;
	}
	public String getAccttp() {
		return accttp;
	}
	public void setAccttp(String accttp) {
		this.accttp = accttp;
	}
	public String getTypecd() {
		return typecd;
	}
	public void setTypecd(String typecd) {
		this.typecd = typecd;
	}
	public String getCrcycd() {
		return crcycd;
	}
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	public BigDecimal getCaptal() {
		return captal;
	}
	public void setCaptal(BigDecimal captal) {
		this.captal = captal;
	}
	public BigDecimal getIntret() {
		return intret;
	}
	public void setIntret(BigDecimal intret) {
		this.intret = intret;
	}
	public String getTrprcd() {
		return trprcd;
	}
	public void setTrprcd(String trprcd) {
		this.trprcd = trprcd;
	}
	public String getItemcd() {
		return itemcd;
	}
	public void setItemcd(String itemcd) {
		this.itemcd = itemcd;
	}
	public String getProdcd() {
		return prodcd;
	}
	public void setProdcd(String prodcd) {
		this.prodcd = prodcd;
	}
	public String getLoanp1() {
		return loanp1;
	}
	public void setLoanp1(String loanp1) {
		this.loanp1 = loanp1;
	}
	public String getLoanp2() {
		return loanp2;
	}
	public void setLoanp2(String loanp2) {
		this.loanp2 = loanp2;
	}
	public String getLoanp3() {
		return loanp3;
	}
	public void setLoanp3(String loanp3) {
		this.loanp3 = loanp3;
	}
	public String getLoanp4() {
		return loanp4;
	}
	public void setLoanp4(String loanp4) {
		this.loanp4 = loanp4;
	}
	public String getLoanp5() {
		return loanp5;
	}
	public void setLoanp5(String loanp5) {
		this.loanp5 = loanp5;
	}
	public String getLoanp6() {
		return loanp6;
	}
	public void setLoanp6(String loanp6) {
		this.loanp6 = loanp6;
	}
	public String getLoanp7() {
		return loanp7;
	}
	public void setLoanp7(String loanp7) {
		this.loanp7 = loanp7;
	}
	public String getLoanp8() {
		return loanp8;
	}
	public void setLoanp8(String loanp8) {
		this.loanp8 = loanp8;
	}
	public String getLoanp9() {
		return loanp9;
	}
	public void setLoanp9(String loanp9) {
		this.loanp9 = loanp9;
	}
	public String getLoanpa() {
		return loanpa;
	}
	public void setLoanpa(String loanpa) {
		this.loanpa = loanpa;
	}


}
