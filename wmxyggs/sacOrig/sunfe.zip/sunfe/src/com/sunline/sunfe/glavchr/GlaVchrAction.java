package com.sunline.sunfe.glavchr;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.funcpub.privilege.service.PrivilegeService;
import com.sunline.funcpub.privilege.service.PrivilegeServiceManager;
import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.security.UserAuthenticator;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.util.StringUtil;
import com.sunline.jraf.util.XmlUtil;
import com.sunline.suncm.actor.common.DataDictParameter;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.util.ComAcpdUtil;
import com.sunline.suncm.util.ComParaUtil;
import com.sunline.sunfe.util.ReportUtil;

import net.sf.jasperreports.engine.JRException;

/**
 * �˲�������ƾ֤��ѯ
 */
public class GlaVchrAction extends Actor {

	/**
	 * ��־
	 */
	private static Log log = LogFactory.getLog(GlaVchrAction.class);
	
	/**
	 * MYBATIS�����ռ�
	 */
	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.glavchr.";
	
	private final static String JASPER_PATH = "/sunfe/jasper/vchrPrint.jasper"; //ƾ֤��ӡ��ʽ�ļ�·��
	private final static String JRXML_PATH = "/sunfe/jasper/GlaVchrQuery_print.jrxml";
	private final static String DATA_SOURCE = "sunline.database"; //����Դ����
	
	/**
	 * �����ļ�����
	 */
	public static final String PDF = "pdf";
	public static final String EXCEL = "xls";

	/**
	 * ƾ֤��ѯ
	 * 
	 * @throws BimisException
	 * @throws JDOMException
	 */
	@SuppressWarnings("unchecked")
	public void getGlaVchr() throws BimisException, JDOMException{
		String stacid = SessionParaUtils.getStacid();
		String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid));
		//��õ�ǰ�����¿�����ά��
	 	List<?> used = getEnableDimensions(stacid);
		HashMap<String, Object> paramMap = (HashMap<String, Object>)req.getReqDataMap();
		paramMap.put("stacid", stacid);
		paramMap.put("glisdt", glisdt);
		String soursq = (String) paramMap.get("soursq");
		String tranbr = (String) paramMap.get("tranbr");
		// �жϿ�ʼ���ںͽ�������
		String glavchrDateMode = (String) paramMap.get("glavchrDateMode");
		String startDate = (String) paramMap.get("startDate");
		String endDate = (String) paramMap.get("endDate");
		String hisStartDate = (String) paramMap.get("hisStartDate");
		String hisEndDate = (String) paramMap.get("hisEndDate");
		String lastDay = ComAcpdUtil.getLastDay(stacid, glisdt);
		if (startDate == null || startDate.trim().isEmpty()) {
			startDate = glisdt;
		}if (endDate == null || endDate.trim().isEmpty()) {
			endDate = glisdt;
		}if (hisStartDate == null || hisStartDate.trim().isEmpty()) {
			hisStartDate = lastDay;
		}if (hisEndDate == null || hisEndDate.trim().isEmpty()) {
			hisEndDate = lastDay;
		}if("1".equals(glavchrDateMode)){
			paramMap.put("startDate", startDate);
			paramMap.put("endDate", endDate);			
		}else{
			paramMap.put("startDate", hisStartDate);
			paramMap.put("endDate", hisEndDate);			
		}
		paramMap.put("glavchrDateMode", glavchrDateMode);
		//�жϽ��
		String tranam = (String) paramMap.get("tranam");
		if (tranam != null && !(tranam.trim().isEmpty())) {
			tranam = tranam.replace(",", "").trim();
			Pattern pattern = Pattern.compile("^[0-9]+(.[0-9]*)?$");
			Matcher match = pattern.matcher(tranam);
			if (match.matches())
				paramMap.put("tranam", tranam);
			else
				paramMap.put("tranam", null);
		}
		//�ж��Ƿ��ж�ά��ѯ����
		String glaacctkey = (String) paramMap.get("glaacctkey");
		if (glaacctkey != null && !"".equals(glaacctkey) ) {
			paramMap = getAcctAssisPara(paramMap);
		}
		Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS + "getGlavchrlistPage", req.getReqPageInfo(), paramMap);
		req.addRspData(e.removeContent());
		req.addRspData("Results2", XmlUtil.createDataObjectElement(used).removeContent()); //������ʹ�õ�ά����Ϣ
		req.addRspData("glisdt", glisdt);
		req.addRspData("startDate", startDate);
		req.addRspData("endDate", endDate);
		req.addRspData("hisStartDate", hisStartDate);
		req.addRspData("hisEndDate", hisEndDate);
		req.addRspData("dateMode", glavchrDateMode);
		req.addRspData("soursq", soursq);
		req.addRspData("tranbr", tranbr);
		req.addRspData("width", (100+used.size()*7)+"");
	}

	/**
	 * ƾ֤��ϸ����ˮ��ϸ��ѯ
	 * @throws JDOMException
	 * @throws BimisException
	 */
	@SuppressWarnings("unchecked")
	public void getSourceData() throws JDOMException, BimisException{
		HashMap<String, Object> hashmap = (HashMap<String, Object>) req.getReqDataMap();
		String stacid = SessionParaUtils.getStacid();
		String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
		hashmap.put("stacid", stacid);
		hashmap.put("glisdt", glisdt);
		String[] startedStr = this.getUsedComitex();// ��ȡ��ά�����Ѿ�����ά����Ϣ
		if (startedStr != null && startedStr.length != 0) {
			req.addRspData("assimpStr", startedStr[0]);// �����ֶ�ƴ��
			req.addRspData("acexcdStr", startedStr[1]);// ��������ƴ��
			req.addRspData("acexnaStr", startedStr[2]);// �Ƿ���ʾƴ��
		}
		Element glavchr = commonDao.queryByNamedSqlWithPage(MYBATIS_NS + "getVchrlistPage", req.getReqPageInfo(), hashmap);
		Element loanbusi = commonDao.queryByNamedSqlWithPage(MYBATIS_NS + "getLoanBusilistPage", req.getReqPageInfo(), hashmap);
		List<?> used = getUsedDimensions(stacid);
		req.addRspData(glavchr.removeContent());
		req.addRspData("Results2", loanbusi.removeContent());
		req.addRspData("Results3", XmlUtil.createDataObjectElement(used).removeContent());
	}
	public void getLoanbusi() throws JDOMException, BimisException{
		@SuppressWarnings("unchecked")
		HashMap<String, Object> hashmap = (HashMap<String, Object>) req.getReqDataMap();
		String stacid = SessionParaUtils.getStacid();
		String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
		hashmap.put("stacid", stacid);
		hashmap.put("glisdt", glisdt);
		Element loanbusi = commonDao.queryByNamedSqlWithPage(MYBATIS_NS + "getLoanBusilistPage", req.getReqPageInfo(), hashmap);
		req.addRspData(loanbusi.removeContent());
	}
	
	/**
	 * ��ѯ�Ѿ�����ά��
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String[] getUsedComitex() {
		String[] result = new String[3];
		String assimpStr = "", acexcdStr = "", acexnaStr = "";
		HashMap<String, String> hashmap = new HashMap<String, String>();
		try {
			String stacid = SessionParaUtils.getStacid();// ����
			hashmap.put("stacid", stacid);
			// ��ѯ�Ѿ�����ά��
			List<HashMap<String, Object>> listUsedDimensions = (List<HashMap<String, Object>>) getUsedDimensions(stacid);
			if (listUsedDimensions.size() == 0) {
				return null;
			}
			for (int i = 0; i < listUsedDimensions.size(); i++) {
				assimpStr += "-" + listUsedDimensions.get(i).get("ASSIMP");
				acexcdStr += "-" + listUsedDimensions.get(i).get("ACEXCD");
				acexnaStr += "-" + listUsedDimensions.get(i).get("ACEXNA");
			}
			result[0] = assimpStr.substring(1);
			result[1] = acexcdStr.substring(1);
			result[2] = acexnaStr.substring(1);
		} catch (Exception e) {
			getLog().logError(e);
		}
		return result;
	}
	
	/**
	 * ƾ֤���ݵ�����IReport��ʽ������
	 * @throws BimisException
	 * @throws JDOMException
	 */
	@SuppressWarnings("unchecked")
	public void doGlavchrExportExcel() throws BimisException, JDOMException {
		HashMap<String, Object> hashmap = (HashMap<String, Object>) req.getReqDataMap();
		String stacid = SessionParaUtils.getStacid();
		String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
		hashmap.put("stacid", stacid);
		hashmap.put("glisdt", glisdt);
		String tranam = (String) hashmap.get("tranam");
		if (tranam != null && !(tranam.trim().isEmpty())) {
			tranam = tranam.replace(",", "").trim();
			Pattern pattern = Pattern.compile("^[0-9]+(.[0-9]*)?$");
			Matcher match = pattern.matcher(tranam);
			if (match.matches())
				hashmap.put("tranam", tranam);
			else
				hashmap.put("tranam", null);
		}
		String exportTypeGlavchr = (String) hashmap.get("exportTypeGlavchr"); //��������
		if (exportTypeGlavchr==null || "xlspdf".indexOf(exportTypeGlavchr)<0 ) {
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "�������ʹ�����ѡ�񵼳�EXCEL��PDF��");
			return;
		}

		String startDate = (String) hashmap.get("startDate"); //��ʼ����
		String endDate = (String) hashmap.get("endDate"); //��������
		
		String glavchrDateMode = (String) hashmap.get("glavchrDateMode");
		String hisStartDate = (String) hashmap.get("hisStartDate");
		String hisEndDate = (String) hashmap.get("hisEndDate");
		String lastDay = ComAcpdUtil.getLastDay(stacid, glisdt);
		if (startDate == null || startDate.trim().isEmpty()) {
			startDate = glisdt;
		}if (endDate == null || endDate.trim().isEmpty()) {
			endDate = glisdt;
		}if (hisStartDate == null || hisStartDate.trim().isEmpty()) {
			hisStartDate = lastDay;
		}if (hisEndDate == null || hisEndDate.trim().isEmpty()) {
			hisEndDate = lastDay;
		}if("0".equals(glavchrDateMode)){
			startDate=hisStartDate;
			endDate=hisEndDate;
			hashmap.put("p_tablename", "gla_vchr_h");
			hashmap.put("startDate", hisStartDate);
			hashmap.put("endDate", hisEndDate);
		}else{
			hashmap.put("p_tablename", "gla_vchr");
		}
		
		String systid = (String) hashmap.get("systid"); //ϵͳ
		String transq = (String) hashmap.get("transq"); //������ˮ
		String tranbr = (String) hashmap.get("tranbr"); //���׻���
		String acctbr = (String) hashmap.get("acctbr"); //�������
		String itemcd = (String) hashmap.get("itemcd"); //��Ŀ
		String crcycd = (String) hashmap.get("crcycd"); //����
		String soursq = (String) hashmap.get("soursq"); //ҵ����ˮ
		String usercd = (String) hashmap.get("usercd"); //�Ƶ���
		String smrytx = (String) hashmap.get("smrytx"); //ժҪ
		String glaacct = (String) hashmap.get("glaacct"); //��ά������
		String glaacctna = (String) hashmap.get("glaacctna"); //��ά������
		
		String currentRows = getCurrentVchrRows(hashmap); //��ȡ��ǰ����������
        if (Integer.parseInt(currentRows)==0) {
			req.addRspData("retCode", "500");
			req.addRspData("retMessage", "û���ҵ����ݣ�������ѡ��������");
			return;
		}
		
		//��������Sql���
		String condition = "and a.stacid="+stacid;
		if( startDate != null && !(startDate.trim().isEmpty())){
			condition += " and a.trandt >= '"+startDate+"'";
		}if( endDate != null && !(endDate.trim().isEmpty())){
			condition += " and a.trandt <= '"+endDate+"'";
		}if( systid != null && !(systid.trim().isEmpty())){
			condition += " and a.systid = '"+systid+"'";
		}if( transq != null && !(transq.trim().isEmpty())){
			condition += " and a.transq = '"+transq+"'";
		}if( tranbr != null && !(tranbr.trim().isEmpty())){
			condition += " and a.tranbr = '"+tranbr+"'";
		}if( acctbr != null && !(acctbr.trim().isEmpty())){
			condition += " and a.acctbr = '"+acctbr+"'";
		}if( itemcd != null && !(itemcd.trim().isEmpty())){
			condition += " and a.itemcd = '"+itemcd+"'";
		}if( crcycd != null && !(crcycd.trim().isEmpty())){
			condition += " and a.crcycd = '"+crcycd+"'";
		}if( soursq != null && !(soursq.trim().isEmpty())){
			condition += " and a.soursq = '"+soursq+"'";
		}if( usercd != null && !(usercd.trim().isEmpty())){
			condition += " and a.usercd = '"+usercd+"'";
		}if( smrytx != null && !(smrytx.trim().isEmpty())){
			condition += " and a.smrytx like '%"+usercd+"%'";
		}
		//�ж��Ƿ��ж�ά��ѯ����
		String glaacctkey = (String) hashmap.get("glaacctkey");
		if (glaacctkey != null && !"".equals(glaacctkey) ) {
			if( glaacct != null && !glaacct.isEmpty()){
				String[] arrNa = glaacctna.split(",");
				String[] arr = glaacct.split(",");
				for(int i=0;i<arr.length;i++){
					//��һ����ȡ��arrNa�ﲻ��Up��β��key(acctno,prsncd)
					if(!"*".equals(arr[i])&&!arrNa[i].endsWith("Up")){
						condition+=" and a."+arrNa[i]+" >='"+arr[i]+"'";
					}else if(!"*".equals(arr[i])&&arrNa[i].endsWith("Up")){
						condition+=" and a."+arrNa[i].substring(0, 6)+" <='"+arr[i]+"'";
					}
				}
			}
		}
		//����Ȩ�޿��ƴ���
		@SuppressWarnings("deprecation")
		boolean  boo =UserAuthenticator.isSuperUser();
		if(!boo){
			List<String> stacList = getPrivileges("stac");
			List<String> deptList = getPrivileges("dept");
			
			if(stacList.size()<=0){
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "��ǰ�û�û����������Ȩ����Ϣ��");
				return;
			}else if(deptList.size()<=0){
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "��ǰ�û�û�����û���Ȩ����Ϣ��");
				return;
			}else{
				String stacStr = "";
				String deptStr = "";
				for (Iterator iterator = stacList.iterator(); iterator.hasNext();) {
					String string = (String) iterator.next();
					stacStr+="'"+string+"',";
				}
				for (Iterator iterator = deptList.iterator(); iterator.hasNext();) {
					String string = (String) iterator.next();
					deptStr+="'"+string+"',";					
				}
				
				condition+= " and a.stacid in ("+stacStr.substring(0, stacStr.length()-1)+")"; //����Ȩ��
				condition+= " and a.acctbr in ("+deptStr.substring(0, deptStr.length()-1)+")"; //����Ȩ��
			}
		}
		hashmap.put("p_condition", condition);
		//����ʹ�õ�ά��
	 	List<?> used = getEnableDimensions(stacid);
	 	for (int i = 0; i < used.size(); i++) {
			HashMap<String, Object> map = (HashMap<String, Object>) used.get(i);
			String assimp = (String) map.get("ASSIMP");
			String acexna = (String) map.get("ACEXNA");
			hashmap.put(assimp, assimp);
			hashmap.put(assimp+"Value", assimp);
			hashmap.put(assimp+"Name", acexna);
		}
	 	hashmap.put("p_stacid", stacid);
		String fileName = "";
		try {
			fileName = ReportUtil.doPrintDynamic("glavchr", exportTypeGlavchr, JRXML_PATH, hashmap, DATA_SOURCE);
		} catch (IOException e) {
			e.printStackTrace();
		}
	    if (fileName != null && fileName.length() != 0) {
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("fileName", fileName);
		} else {
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ƾ֤���ݺ�ģ���ļ�");
		}
	}
	

	/**
	 * ��������ƾ֤��ϢPDF�ļ�
	 * @throws JDOMException
	 * @throws JRException
	 * @throws BimisException
	 */
	@SuppressWarnings("unchecked")
	public void doGlavchrPrintPdf() throws JDOMException, JRException, BimisException {
		HashMap<String, Object> hashmap = (HashMap<String, Object>) req.getReqDataMap();
		String stacid = SessionParaUtils.getStacid();
		String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
		hashmap.put("stacid", stacid);
		hashmap.put("glisdt", glisdt);
		//��ʼ���ںͽ�������
		String glavchrDateMode = (String) hashmap.get("glavchrDateMode");
		String startDate = (String) hashmap.get("startDate");
		String endDate = (String) hashmap.get("endDate");
		String hisStartDate = (String) hashmap.get("hisStartDate");
		String hisEndDate = (String) hashmap.get("hisEndDate");
		String lastDay = ComAcpdUtil.getLastDay(stacid, glisdt);
		if (startDate == null || startDate.trim().isEmpty()) {
			startDate = glisdt;
		}if (endDate == null || endDate.trim().isEmpty()) {
			endDate = glisdt;
		}if (hisStartDate == null || hisStartDate.trim().isEmpty()) {
			hisStartDate = lastDay;
		}if (hisEndDate == null || hisEndDate.trim().isEmpty()) {
			hisEndDate = lastDay;
		}if(glavchrDateMode != null && "1".equals(glavchrDateMode)){
			hashmap.put("startDate", startDate);
			hashmap.put("endDate", endDate);
		}else{
			hashmap.put("startDate", hisStartDate);
			hashmap.put("endDate", hisEndDate);
		}
		hashmap.put("glavchrDateMode", glavchrDateMode);
		
		String tranam = (String) hashmap.get("tranam");
		if (tranam != null && !(tranam.trim().isEmpty())) {
			tranam = tranam.replace(",", "").trim();
			Pattern pattern = Pattern.compile("^[0-9]+(.[0-9]*)?$");
			Matcher match = pattern.matcher(tranam);
			if (match.matches())
				hashmap.put("tranam", tranam);
			else
				hashmap.put("tranam", null);
		}
		String maxRows = ComParaUtil.getParavl(stacid, "vchr_print_max_rows"); //��ȡϵͳ���ε������������
		String currentRows = getCurrentVchrRows(hashmap); //��ȡ��ǰ����������
		if(maxRows==null || "".equals(maxRows)){
			req.addRspData("retCode", "500");
			req.addRspData("retMessage", "��ǰ����û�����õ��δ�ӡ�����������");	
			return;
		}if (Integer.parseInt(currentRows)==0) {
			req.addRspData("retCode", "500");
			req.addRspData("retMessage", "û���ҵ����ݣ�������ѡ��������");
			return;
		}if(Integer.parseInt(currentRows)>Integer.parseInt(maxRows)){
			req.addRspData("retCode", "500");
			req.addRspData("retMessage", "��ӡ�������ѳ���ϵͳ���õĵ��δ�ӡ�������"+maxRows);
			return;
		}
		// ��ȡƾ֤��ˮ
		ArrayList<HashMap<String, Object>> dataList = (ArrayList<HashMap<String, Object>>) commonDao
				.queryByNamedSqlForList(MYBATIS_NS + "tranData", hashmap);
		ArrayList<HashMap<String, Object>> printList = vchrDataBuilder(dataList, glavchrDateMode, stacid);
        //��ӡƾ֤����
		String pdfFile = ReportUtil.doPrint("vchrPrint", JASPER_PATH, printList);
		if (pdfFile != null && pdfFile.length() != 0) {
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("pdf", pdfFile);
		} else {
			req.addRspData("retCode", "404");
			req.addRspData("retMessage", "����ƾ֤���ݺ�jasperģ���ļ�");
		}
	}
	
	/**
	 * ��ȡ��ǰ��ӡƾ֤����
	 * @param map
	 * @return
	 * @throws BimisException
	 */
	public String getCurrentVchrRows(HashMap<String,Object> map) throws BimisException{
		Element element = commonDao.queryByNamedSql(MYBATIS_NS + "getCurrentVchrRows", map);
	    String rows = element.getChild("Record").getChildTextNormalize("vchrRows");
	    return rows;
	}
	
	/**
	 * ����ƾ֤��Ϣ����PDF
	 * @Title: proofPrinter
	 * @return: void
	 * @throws JDOMException
	 * @throws JRException
	 * @throws BimisException
	 */
	@SuppressWarnings("unchecked")
	public void doVchrSinglePrintPdf() throws JDOMException, JRException, BimisException {
		HashMap<String, Object> hashmap = (HashMap<String, Object>) req.getReqDataMap();
		String param = (String) hashmap.get("param");
		HashMap<String, Object> paramMap = new HashMap<String, Object>();
		String stacid = SessionParaUtils.getStacid();
		String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
		paramMap.put("stacid", stacid);
		paramMap.put("glisdt", glisdt);
		if (param != null && !(param.trim().equals(""))) {
			String[] strArray = param.split("&");
			for (int i = 1; i < strArray.length; i++) {
				String item = strArray[i];
				String[] itemArray = item.split("=");
                if(itemArray.length == 2){
                	paramMap.put(itemArray[0], itemArray[1]);
                }
			}
		}
		String trandt = (String) paramMap.get("trandt");
		String mode ="";
		if(Integer.parseInt(glisdt)>Integer.parseInt(trandt)){
			mode = "0";
			paramMap.put("glavchrDateMode", mode);
		}else{
			mode = "1";
			paramMap.put("glavchrDateMode", mode);
		}
		String maxRows = ComParaUtil.getParavl(stacid, "vchr_print_max_rows"); //��ȡϵͳ���ε������������
		String currentRows = getCurrentVchrRows(paramMap); //��ȡ��ǰ����������
		if(maxRows==null || "".equals(maxRows)){
			req.addRspData("retCode", "500");
			req.addRspData("retMessage", "��ǰ����û�����õ��δ�ӡ�����������");
			return;
		}if (Integer.parseInt(currentRows)==0) {
			req.addRspData("retCode", "500");
			req.addRspData("retMessage", "û���ҵ����ݣ�������ѡ��������");
			return;
		}if(Integer.parseInt(currentRows)>Integer.parseInt(maxRows)){
			req.addRspData("retCode", "500");
			req.addRspData("retMessage", "��ӡ�������ѳ���ϵͳ���õĵ��δ�ӡ�������"+maxRows);
			return;
		}

		// ��ȡƾ֤��ˮ
		ArrayList<HashMap<String, Object>> dataList = (ArrayList<HashMap<String, Object>>) commonDao
				.queryByNamedSqlForList(MYBATIS_NS + "tranData", paramMap);
		ArrayList<HashMap<String, Object>> printList = vchrDataBuilder(dataList, mode, stacid);
        //��ӡƾ֤����
		String pdfFile = ReportUtil.doPrint("vchrPrint", JASPER_PATH, printList);
		if (pdfFile != null && pdfFile.length() != 0) {
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("pdf", pdfFile);
		} else {
			req.addRspData("retCode", "404");
			req.addRspData("retMessage", "����ƾ֤���ݺ�jasperģ���ļ�");
		}
	}

	@SuppressWarnings("unchecked")
	private HashMap<String, Object> getTranUser(HashMap<String,Object> map) throws BimisException{
		List<?> list = commonDao.queryByNamedSqlForList(MYBATIS_NS + "getTranUser", map);
		if(list.size()>0)
		    return (HashMap<String, Object>) list.get(0);
		else
			return null;
    }
	
	/**
	 * ��װƾ֤��ʽ�ļ���Ӧ��List
	 * @Title: vchrDataBuilder 
	 * @param tranList Ҫ��װ����ˮ���ݼ���
	 * @return: ArrayList<HashMap<String,Object>>
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	protected ArrayList<HashMap<String, Object>> vchrDataBuilder(ArrayList<HashMap<String, Object>> dataList, String mode, String stacid) throws BimisException{
		// ����ÿҳƾ֤����������¼��Ϊ5
		final int pageCount = 5;
		ArrayList<HashMap<String, Object>> printList = new ArrayList<HashMap<String, Object>>();
		for (HashMap<String, Object> item : dataList) {
			item.put("glavchrDateMode", mode);
			HashMap<String, Object> userMap = getTranUser(item);
			String trandt = (String) item.get("trandt");
			String transq = (String) item.get("transq");
			String psaunacd = "";
			String psauna = "";
			String usercd = "";
			String username = "";
			String acsrnm = "";
			if(userMap!=null){
				psaunacd = (String) userMap.get("psauus"); //�����˴���
				psauna = getNameByCode(psaunacd,"user"); //������
				usercd = (String) userMap.get("usercd"); //�����˴���
				username = getNameByCode(usercd,"user"); //�Ƶ���
			}
			ArrayList<HashMap<String, Object>> vchrData = (ArrayList<HashMap<String, Object>>) commonDao
					.queryByNamedSqlForList(MYBATIS_NS + "vchrData", item);
					// ����ҳ��
					int vchrLen = vchrData.size();
					int maxPage = vchrLen % pageCount == 0 ? vchrLen / pageCount : vchrLen / pageCount + 1;
					BigDecimal drtsamsum = new BigDecimal(0.00);// �跽�ϼ�
					BigDecimal crtsamsum = new BigDecimal(0.00);// �����ϼ�
					String crcycd = (String)item.get("crcycd"); // ���ִ���
					String brchcd = (String)item.get("tranbr"); // ��������
					
					String makercd = SessionParaUtils.getUsercd();//�Ƶ��˴���
					String maker = getNameByCode(makercd,"user"); //�Ƶ���
					String crcyna = getNameByCode(crcycd,"crcy"); //����
					String brchna = getNameByCode(brchcd,"brch"); //����
					for (int page = 1; page <= maxPage; page++) {
						HashMap<String, Object> itemNew = new HashMap<String, Object>();
						itemNew.put("trandt", trandt);
						itemNew.put("transq", transq);
						itemNew.put("userna", username);
						itemNew.put("acsrnm", acsrnm);
						itemNew.put("crcyna0", crcyna);
						itemNew.put("brchna", brchna);
						itemNew.put("page", page+"");
						itemNew.put("pages", maxPage+"");
						itemNew.put("psauna", psauna);
						itemNew.put("makeer", maker);
						int j = (page-1)*pageCount;
						for (int i = j; i < vchrLen && i < pageCount * page; i++) {
							int index = i % pageCount;
							String itemcd = (String) vchrData.get(i).get("itemcd");
							String codecd = stacid+"-"+itemcd;
							String itemna = getNameByCode(codecd,"item");
							itemNew.put("itemna" + index, itemcd+"-"+itemna);
							itemNew.put("smrytx" + index, vchrData.get(i).get("smrytx"));
							itemNew.put("acctbr" + index, vchrData.get(i).get("acctbr"));
                            String derection = (String) vchrData.get(i).get("amntcd"); //�������
							if (derection.equalsIgnoreCase("D") || derection.equalsIgnoreCase("R")) {
								// �跽���
								itemNew.put("drtsam" + index, vchrData.get(i).get("tranam"));
								drtsamsum = drtsamsum.add((BigDecimal) vchrData.get(i).get("tranam"));
							} else {
								// �������
								itemNew.put("crtsam" + index, vchrData.get(i).get("tranam"));
								crtsamsum = crtsamsum.add((BigDecimal) vchrData.get(i).get("tranam"));
							}
						}
						// ĩҳ���ϻ���
						if (page == maxPage) {
							itemNew.put("drtsamsum", drtsamsum);
							itemNew.put("crtsamsum", crtsamsum);
						}
						printList.add(itemNew);
					}
				}
		return printList;
	}
	
	private String getNameByCode(String code,String dictName){
		String username = (String) new DataDictParameter().getOptions("suncm,"+dictName).get(code);
		if(!StringUtil.isNullOrEmpty(username)){
			return username;
		}
		return code;
	}
	
	/**
	 * ���Ӷ�ά��ѯ������
	 * @param paraMap
	 * @return
	 */
	public HashMap<String,Object> getAcctAssisPara(HashMap<String,Object> paraMap){
		String glaacct = (String) paraMap.get("glaacct");
		String glaacctna = (String) paraMap.get("glaacctna");
		String[] arr = glaacct.split(",");
		String[] arrna = glaacctna.split(",");
		for(int i=0;i<arr.length;i++){
			if("*".equals(arr[i])){
				arr[i]="";
			}
			paraMap.put(arrna[i], arr[i]);
		}
		return paraMap;
	}
	
	@SuppressWarnings("unchecked")
	public void linkToOpenList() throws JDOMException {
		try {
			Map<String, Object> paramMap = req.getReqDataMap();
			StringBuffer strHtml = new StringBuffer();
			String itemcd = req.getReqDataStr("itemcd");// ��Ŀ
			String stacid = SessionParaUtils.getStacid();
			paramMap.put("stacid", stacid);
			String str = "";
			int num = 0;
			//����Ƿ�������ά��
			String linkid = PubUtil.getLinkid(Integer.valueOf(stacid));
			List<HashMap<String, Object>> dimensions = (List<HashMap<String, Object>>) getEnableDimensions(SessionParaUtils.getStacid());
			if (dimensions.size()==0&&!StringUtil.isNullOrEmpty(linkid)) {
				dimensions = (List<HashMap<String, Object>>) getEnableDimensions(linkid);
			}
			// ��Ŀ��Ϊ��ʱ�����ݿ�Ŀ��ʾ��ά
			if (!"".equals(itemcd)) {
				int count = dimensions.size();
				for (int i = 0; i <count;  i++) {
					String assimp = (String) dimensions.get(i).get("ASSIMP");
					String acexna = (String) dimensions.get(i).get("ACEXNA");
					String acexcd = (String) dimensions.get(i).get("ACEXCD");
					HashMap<String, Object> map = dimensions.get(i);
					map.put("itemcd", itemcd);
					Element list =  commonDao.queryByNamedSql(MYBATIS_NS + "getUsedDisByItem", map);
					String para = list.getChild("Record").getChild("para").getText();

					if(Integer.parseInt(para)>0){
						String temp = assimp.substring(0, 4);
						String index = assimp.substring(5, 6);
						if (!"assi".equals(temp)) {
							str += "<tr>" + "<td class='form-label' style='width:100px'>" + acexna + "</td>" + " <td class='form-value'><input type='text' style='width:160px;' readonly='true' required name='" + temp + "'/><input id='acexna" + num + "' class='acexna' type='hidden' style='width:160px;' readonly='true' required name='" + assimp + "'/>" + "<a class='btnLook' title='��ά������Դ��Ϣ' width='850' height='550' lookupgroup='' " + "href='/sunfe/glavchr/gla" + temp + "LookupSingle.jsp?lookupid=" + assimp + "&amp;lookupname=" + temp + "&amp;itemcd="+itemcd+"&amp;'></a>" + "</td>"
									+ " <td class='form-value'><input type='text'  style='width:160px;' readonly='true' required name='" + temp + "Up'/><input id='acexnaUp" + num + "' class='acexna' type='hidden' style='width:160px;' readonly='true' required name='" + assimp + "Up'/>" + "<a class='btnLook' title='��ά������Դ��Ϣ' width='850' height='550' lookupgroup='' " + "href='/sunfe/glavchr/gla" + temp + "LookupSingle.jsp?lookupid=" + assimp + "Up&amp;lookupname=" + temp + "Up&amp;itemcd="+itemcd+"&amp;'></a>" + "</td>" + "</tr>";
						} else {
							// ��������
							str += "<tr>" + "<td class='form-label' >" + acexna + "</td>" + "<td class='form-value'>" + "<input type='text' style='width:160px;' readonly='true' required name='" + temp +index+ "'/><input id='acexna" + num + "' class='acexna' type='hidden' style='width:160px;' readonly='true' required name='" + assimp + "'/>" + "<a class='btnLook' title='��ά������Դ��Ϣ' width='850' height='550' lookupgroup='' " + "href='/sunfe/glavchr/assis_Select.jsp?lookupid=" + assimp + "&amp;lookupname=" + temp + index+"&amp;itemcd="+itemcd+"&amp;'></a>" + "</td>"

									+ " <td class='form-value'><input type='text' style='width:160px;' readonly='true' required name='" + temp +index+ "Up'/><input id='acexna" + num + "' class='acexna' type='hidden' style='width:160px;' readonly='true' required name='" + assimp + "Up'/>" + "<a class='btnLook' title='��ά������Դ��Ϣ' width='850' height='550' lookupgroup='' " + "href='/sunfe/glavchr/assis_Select.jsp?lookupid=" + assimp + "Up&amp;lookupname=" + temp + index+"Up&amp;itemcd="+itemcd+"&amp;'></a>" + "</td>" + "</tr>";
						}
						num++;
					}
				}
			} else {
				// ��ѯ����ά��
				for (int i = 0; i < dimensions.size(); i++) {
					String assimp = (String) dimensions.get(i).get("ASSIMP");
					String acexna = (String) dimensions.get(i).get("ACEXNA");
					String acexcd = (String) dimensions.get(i).get("ACEXCD");
					String index = assimp.substring(5, 6);

					HashMap<String, Object> map = dimensions.get(i);
					Element list =  commonDao.queryByNamedSql(MYBATIS_NS + "getUsedDisByItem", map);
					String para = list.getChild("Record").getChild("para").getText();
					if(Integer.parseInt(para)>0){
						String temp = assimp.substring(0, 4);
						if (!"assi".equals(temp)) {
							str += "<tr>" + "<td class='form-label' style='width:100px'>" + acexna + "</td>" + " <td class='form-value'><input  type='text' style='width:160px;' readonly='true' required name='" + temp + "'/><input id='acexna" + num + "' class='acexna' title='" + acexna + "' type='hidden' style='width:160px;' readonly='true' required name='" + assimp + "'/>" + "<a class='btnLook' title='��ά������Դ��Ϣ' width='850' height='550' lookupgroup='' " + "href='/sunfe/glavchr/gla" + temp + "LookupSingle.jsp?lookupid=" + assimp + "&amp;lookupname=" + temp + "'></a>" + "</td>"
									+ " <td class='form-value'><input  type='text' style='width:160px;' readonly='true' required name='" + temp + "Up'/><input id='acexnaUp" + num + "' class='acexna' type='hidden' style='width:160px;' readonly='true' required name='" + assimp + "Up'/>" + "<a class='btnLook' title='��ά������Դ��Ϣ' width='850' height='550' lookupgroup='' " + "href='/sunfe/glavchr/gla" + temp + "LookupSingle.jsp?lookupid=" + assimp + "Up&amp;lookupname=" + temp + "Up&amp;'></a>" + "</td>" + "</tr>";
						} else {
							// ��������
							str += "<tr>" + "<td class='form-label' >" + acexna + "</td>" + "<td class='form-value'>" + "<input type='text' style='width:160px;' readonly='true' required name='" + temp +index+ "'/><input id='acexna" + num + "' class='acexna'  type='hidden' style='width:160px;' readonly='true' required name='" + assimp + "'/>" + "<a class='btnLook' title='��ά������Դ��Ϣ' width='850' height='550' lookupgroup='' " + "href='/sunfe/glavchr/assis_Select.jsp?lookupid=" + assimp + "&amp;lookupname=" + temp +index+ "&amp;'></a>" + "</td>"
									+ " <td class='form-value'><input type='text' style='width:160px;' readonly='true' required name='" + temp +index+ "Up'/><input id='acexnaUp" + num + "' class='acexna' type='hidden' style='width:160px;' readonly='true' required name='" + assimp + "Up'/>" + "<a class='btnLook' title='��ά������Դ��Ϣ' width='850' height='550' lookupgroup='' " + "href='/sunfe/glavchr/assis_Select.jsp?lookupid=" + assimp + "Up&amp;lookupname=" + temp + index+"Up&amp;'></a>" + "</td>" + "</tr>";
						}
						num++;
					}
				}
			}
			req.addRspData("strHtml", strHtml.append(str).toString());

		} catch (Exception e) {
			getLog().logError(e);
		}
	}

	/**
	 * ��ȡ��ǰ�������õĶ�ά������
	 * @param commonDao
	 * @param stacid
	 * @return
	 * @throws BimisException
	 */
	public static List<?> getEnableDimensions(String stacid) throws BimisException {
		CommonDao commonDao = new CommonDao(JrafSession.getCurrentRootSession());
		return commonDao.queryByNamedSqlForList(MYBATIS_NS + "getEnableDimensions", stacid);
	}
	
	/**
	 * ��ȡʵ��ʹ�õĶ�ά������
	 * @param commonDao
	 * @param stacid
	 * @return
	 * @throws BimisException
	 */
	@SuppressWarnings("unchecked")
	public static List<?> getUsedDimensions(String stacid) throws BimisException {
		CommonDao commonDao = new CommonDao(JrafSession.getCurrentRootSession());
		List<HashMap<String,Object>> dimensions = (List<HashMap<String, Object>>) getEnableDimensions(stacid);
		List<HashMap<String,Object>> used = new ArrayList<HashMap<String,Object>>();
		for (int i = 0; i < dimensions.size(); i++) {
			HashMap<String,Object> map = dimensions.get(i);
			Element e = commonDao.queryByNamedSql(MYBATIS_NS + "getUsedDimensions", map);
			String countStr = e.getChild("Record").getChild("paraCount").getText();
			if(Integer.parseInt(countStr)>0){
				used.add(map);
			}
		}
		return used;
	}
	
	/**
	 * ��ȡ�û���Ȩ���б�
	 * @param commonDao
	 * @param stacid
	 * @return
	 * @throws BimisException
	 */
	public static String getSysPrivAsgn(String usercd) throws BimisException {
		CommonDao commonDao = new CommonDao(JrafSession.getCurrentRootSession());
		Element e = commonDao.queryByNamedSql(MYBATIS_NS + "getSysPrivAsgn", usercd);
		String countStr = e.getChild("Record").getChild("privCount").getText();
		return countStr;
	}
	
	public static List<String> getPrivileges(String privilegeType) throws BimisException {
		
		PrivilegeServiceManager manager = new PrivilegeServiceManager("pcmc",privilegeType);
		PrivilegeService service = manager.getPrivilegeService();
		List<String> privcdList = service.queryGrantedPrivilegeData(SessionParaUtils.getUsercd());
		return privcdList;
	}
}
