package com.sunline.sunfe.loanbusihangup;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.JsonUtil;
import com.sunline.jraf.util.Log;
import com.sunline.jraf.util.XmlUtil;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.suncm.util.Sequence;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.StringUtils;
import com.sunline.sunfe.core.bean.ComItemBean;
import com.sunline.sunfe.entity.AccountingItem;
import com.sunline.sunfe.entity.GlaVoucher;

/**
 * ������ˮ���������ֹ�����
 * �����ռ佻����ˮ�������������к�����ˮ��������
 * @author livejianan
 *
 */
public class BusiHangHandleAction extends Actor {

	private static Log log = new Log(BusiHangHandleAction.class);
	private static String MYBATIS_NS = "com.sunline.sunfe.mybatis.busiHangHandle.";

	/**
	 * ������ˮ���˲�ѯ
	 * @Title: queryBusiHang
	 * @return: void
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	public void queryBusiHang() throws Exception {
		Map<String, Object> para = req.getReqDataMap();
		String stacid = SessionParaUtils.getStacid();
		para.put("stacid", stacid);
		//������ˮ��¼�����٣�����Ҫ��ҳ
		List<HashMap<String,Object>> busiDataList = (List<HashMap<String,Object>>) commonDao.queryByNamedSqlForList(MYBATIS_NS + "queryBusiHang", para);
		
		List<HashMap<String,Object>> listMapResult = new ArrayList<HashMap<String,Object>>();
		for(int i= 0 ;i< busiDataList.size();i++){
			String hstatus = (String) busiDataList.get(i).get("STATUS");
			String trdata = (String) busiDataList.get(i).get("TRDATA");
			List<HashMap<String,Object>> jlistmap = JsonUtil.convertJson2ListMap(trdata);
			for(HashMap<String,Object> jmap:jlistmap) {
				jmap.put("hstatus", hstatus);
			}                 
			listMapResult.addAll(jlistmap);
		}
		
		Element busiDict = commonDao.queryByNamedSql(MYBATIS_NS + "queryBusiDict", para);
		req.addRspData("Results2", busiDict.removeContent());
		Element xmlResult = XmlUtil.createDataObjectElement(listMapResult);
		req.addRspData(xmlResult.removeContent());
	}
	
	@SuppressWarnings("unchecked")
	public String getBusiHangStatus(String stacid,String systid,String trandt,String transq) throws BimisException{
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("stacid", stacid);
		map.put("systid", systid);
		map.put("trandt", trandt);
		map.put("transq", transq);
		List<HashMap<String,Object>> busiDataList = (List<HashMap<String,Object>>) commonDao.queryByNamedSqlForList(MYBATIS_NS + "queryBusiHang", map);
		String status = (String) busiDataList.get(0).get("STATUS");
		return status;
	}
	
	@SuppressWarnings("unchecked")
	public String getBusiHangCrcycd(String stacid,String systid,String trandt,String transq) throws Exception{
		String crcycds="";
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("stacid", stacid);
		map.put("systid", systid);
		map.put("trandt", trandt);
		map.put("transq", transq);
		List<HashMap<String,Object>> busiDataList = (List<HashMap<String,Object>>) commonDao.queryByNamedSqlForList(MYBATIS_NS + "queryBusiHang", map);
		
		String trdata = (String) busiDataList.get(0).get("TRDATA");
		List<HashMap<String,Object>> jlistmap = JsonUtil.convertJson2ListMap(trdata);
		for(HashMap<String,Object> jmap:jlistmap) {
			crcycds += jmap.get("crcycd")+",";
		} 
		return crcycds;
	}

	/***������˴���
	 * @throws Exception ****/
	@SuppressWarnings("unchecked")
	public void handleHangup() throws Exception{
		Map<String, Object> hs = req.getReqDataMap();
		
		String rowNo = (String) hs.get("handleRows");
		int count = Integer.parseInt(rowNo);
		String systid = (String) hs.get("handleSystid");
		String tranbr = (String) hs.get("handleTranbr");
		String smrytx = (String) hs.get("dealReason");
		String trandt = (String) hs.get("handleTrandt");
		String transq = (String) hs.get("handleTransq");
		String trantp = (String) hs.get("handleTrantp");
		
		String stacid = SessionParaUtils.getStacid();
		String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid));
		String usercd = SessionParaUtils.getUsercd();
		String newTransq = getTransq(stacid, glisdt, tranbr, usercd); //��������ˮ��
		
		//�ж��Ƿ����Ѵ�����¼
		String flag = getBusiHangStatus(stacid,systid,trandt,transq);
		if("1".equals(flag)){
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "�Ѿ��������ô���");
			return;
		}
		
		String tranamDT = (String) hs.get("tranamDTHang");//  �ܽ跽���
		String tranamCT = (String) hs.get("tranamCTHang");// �ܴ������
		tranamDT=tranamDT.replaceAll(",", "");
		tranamCT=tranamCT.replaceAll(",", "");
		if(tranamDT == null || tranamCT == null || "".equals(tranamDT) || "".equals(tranamCT) 
			||!tranamDT.equals(tranamCT)){
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ȷ������");
			return;
		}
		
		//���ԭ��ˮ�ı��ּ��ϣ����˴�����¼���ֱ�������ڴ˼�����
		String crcycds = getBusiHangCrcycd(stacid,systid,trandt,transq);
		
		ArrayList<HashMap<String,Object>> glavchr = new ArrayList<HashMap<String,Object>>();
		for (int i = 0; i < count; i++) {
			HashMap<String,Object> map = new HashMap<String, Object>();
			String acctbr = (String) hs.get("acctbr"+i);
			String crcycd = (String) hs.get("crcycd"+i);
			
			if(acctbr==null || "".equals(acctbr)){
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "�����������Ϊ�գ�����");
				return;
			}
			
			if(crcycd==null || "".equals(crcycd)){
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "���ֲ���Ϊ�գ�����");
				return;
			}
			
			if(crcycds.indexOf(crcycd)==-1) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "���ֲ���ȷ������");
				return;
			}
			
			String amntcd = "";
			BigDecimal tranam = BigDecimal.valueOf(0.0);
			BigDecimal zear=BigDecimal.valueOf(0.0);
			
           String tranamDStr = (String) hs.get("tranamD"+i);
           String tranamCStr = (String) hs.get("tranamC"+i);
           
           if("".equals(tranamDStr) && "".equals(tranamCStr)) {
        	req.addRspData("retCode", "300");
   			req.addRspData("retMessage", "�������ȷ������");
   			return;
           }
            
           BigDecimal tranamD = BigDecimal.valueOf(0.0);
           BigDecimal tranamC = BigDecimal.valueOf(0.0);
           if(!("".equals(tranamDStr))){
        	   tranamD = new BigDecimal(tranamDStr.replace(",", ""));
           }
           if(!("".equals(tranamCStr))){
        	   tranamC = new BigDecimal(tranamCStr.replace(",", ""));
           }
			if(tranamD.compareTo(zear)!=0){
				tranam = tranamD;
				amntcd = "D";
			}
			if(tranamC.compareTo(zear)!=0){
				tranam = tranamC;
				amntcd = "C";
			}
			
			if(tranam.compareTo(zear)==0) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "���˴������Ϊ0��������");
				return;
			}
			
			String itemcd = (String) hs.get("itemcd"+i);
			
			if(itemcd==null || "".equals(itemcd)){
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "��Ŀ����Ϊ�գ�����");
				return;
			}
			
			map.put("newtransq", newTransq);
			map.put("stacid", Integer.parseInt(stacid));
			map.put("systid", systid);
			map.put("tranbr", tranbr);
			map.put("crcycd", crcycd);
			map.put("smrytx", smrytx);
			map.put("trandt", trandt);
			map.put("transq", transq);
			map.put("trantp", trantp);
			
			map.put("acctbr", acctbr);
			map.put("tranam", tranam);
			map.put("amntcd", amntcd);
			map.put("itemcd", itemcd);
			glavchr.add(map);
		}
		
	try {
		commonDao.beginTransaction();
		generateAndSaveGlaVoucher(glavchr);
		
		HashMap<String,Object> uphs = new HashMap<String,Object>();
		uphs.put("stacid", stacid);
		uphs.put("systid", systid);
		uphs.put("trandt", trandt);
		uphs.put("transq", transq);
		
		commonDao.updateByNamedSql(MYBATIS_NS + "updateBusiHang", uphs);
		commonDao.commitTransaction();
		
		req.addRspData("retCode", "200");
		req.addRspData("retMessage", "���˴����ɹ���");
		}catch(Exception e) {
			ResultUtils.setRspData(req, "300", "���˴���ʧ�ܣ��������ݣ�", "");
			//�쳣�ǻع�
			commonDao.rollBack();
			log.logError(e);
		}
	}
	
	/**
	 * @Title: generateAndSaveGlaVoucher 
	 * @Description: ���������¼����ˮ��Ϣ
	 * @throws Exception 
	 */
	private void generateAndSaveGlaVoucher(List<HashMap<String,Object>> glavchrs) throws Exception{
		
		List<GlaVoucher> glaVoucherList = new ArrayList<GlaVoucher>();
		for(int i=0;i<glavchrs.size();i++){
			HashMap<String,Object> busiMap = glavchrs.get(i);
			
			int stacid = (Integer) busiMap.get("stacid");
			String transq = (String) busiMap.get("newtransq");
			String systid = (String) busiMap.get("systid");
			String sourdt = (String) busiMap.get("trandt");
			String soursq = (String) busiMap.get("transq");
			String tranbr  = (String) busiMap.get("tranbr");
			String trantp = (String) busiMap.get("trantp");
			
			String acctbr = (String) busiMap.get("acctbr");
			String itemcd = (String) busiMap.get("itemcd");
			String crcycd = (String) busiMap.get("crcycd");
			String amntcd = (String) busiMap.get("amntcd");
			BigDecimal tranam = (BigDecimal) busiMap.get("tranam");
			String smrytx = (String) busiMap.get("smrytx");
			
			// ��ȡ��Ŀ��Ϣ
			AccountingItem itemInfo = ComItemBean.getAccountingItemByPrimaryKey(stacid,itemcd);
			
			
			GlaVoucher glaVoucher = new GlaVoucher();
			
			
			glaVoucher.setStacid(stacid);// ���ױ��
			glaVoucher.setSystid(systid);// ϵͳ��ʶ
			glaVoucher.setTrandt(PubUtil.getGlisdt(stacid));// ��������
			glaVoucher.setTransq(transq);// ������ˮ
			glaVoucher.setVchrsq(String.valueOf(i));//��Ʊ���
			glaVoucher.setTranbr(tranbr);// ���׻���
			glaVoucher.setAcctbr(acctbr);// �������
			glaVoucher.setItemcd(itemcd);// ��Ŀ����
			glaVoucher.setCrcycd(crcycd);// ���ִ���
			glaVoucher.setTrantp(trantp);// ��������
			glaVoucher.setAmntcd(amntcd);// �������
			glaVoucher.setTranam(tranam);// ���׽��
			//glaVoucher.setTranbl((BigDecimal) glaGlisMap.get("onlnbl"));// �������
			glaVoucher.setIoflag(itemInfo.getIoflag());
			//glaVoucher.setBlncdn((String) glaGlisMap.get("blncdn"));// ��ǰ����
			glaVoucher.setSmrytx(smrytx);// ժҪ
			glaVoucher.setExchcn(BigDecimal.ZERO);// �м��
			glaVoucher.setExchus(BigDecimal.ZERO);// ������
			glaVoucher.setUsercd(SessionParaUtils.getUsercd());// �û�����
			glaVoucher.setSourdt(sourdt);// ҵ������
			glaVoucher.setSoursq(soursq);// ҵ����ˮ
			glaVoucher.setSourst(systid);// Դϵͳ��ʶ
			glaVoucher.setSrvcsq(String.valueOf(i));// Դ��Ʊ���
			//glaVoucher.setBearbl((BigDecimal) glaGlisMap.get("bearbl"));// ��ǰ���
			//glaVoucher.setBeardn((String) glaGlisMap.get("beardn"));// ��ǰ����
			glaVoucher.setToitem("");// �Է���Ŀ
			//glaVoucher.setAcctno(glaAeuvDetl.getAcctno());
			glaVoucher.setTranst("0");
			
			glaVoucherList.add(glaVoucher);
		}
	
		saveGlaVoucherBatch(commonDao,glaVoucherList);
	}
	
	@SuppressWarnings("rawtypes")
	public static void saveGlaVoucherBatch(CommonDao commonDao, List glaVoucherList) throws BimisException {
		int batchCount = 20;
		int insertRecordCount = 0;
		try {
			int ednIdx = 0;
			for (int beginIdx = 0; beginIdx < glaVoucherList.size();) {
				ednIdx = beginIdx + batchCount >= glaVoucherList.size() ? glaVoucherList.size() : beginIdx + batchCount;
				List subGlaVoucherList = glaVoucherList.subList(beginIdx, ednIdx);
				beginIdx += batchCount;
				insertRecordCount += commonDao.insertByNamedSql(MYBATIS_NS +"insertEntitiesBatch",subGlaVoucherList);
			}

			if (insertRecordCount != glaVoucherList.size()) {
				log.logError("��Ʊ���ʧ��");
				throw new BimisException("9999", (new StringBuilder())
						.append("��Ʊ���ʧ��,��Ʊ�б�������[")
						.append(glaVoucherList.size()).append("]����������[")
						.append(insertRecordCount).append("]��һ��").toString());
			}
		} catch (Exception ex) {
			log.logError("��Ʊ���ʧ��", ex);
			throw new BimisException("9999", "��Ʊ���ʧ��:", ex);
		}
	}
	
	//�����ˮ��
	public  String getTransq(String stacid, String glisdt,String tranbr,String usercd) throws BimisException {
		Sequence sequence;
		String transq = "";
		try {
			sequence = SequenceUtils.createSequence(String.valueOf(stacid), glisdt, "transq", tranbr, usercd, 1);
			transq = sequence.getSqueno();
			if(StringUtils.isEmpty(transq)){
				log.logError("��ȡ������ˮʧ��,���������ϵ");
				throw new BimisException("999","��ȡ������ˮʧ��,���������ϵ");
			}
			return transq;
		} catch (Exception e) {
			log.logError("��ȡ������ˮʧ��,���������ϵ");
			throw new BimisException("999","��ȡ������ˮʧ��,���������ϵ");
		}
	}
	
}
