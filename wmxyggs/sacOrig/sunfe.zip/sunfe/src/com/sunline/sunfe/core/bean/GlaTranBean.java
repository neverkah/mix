package com.sunline.sunfe.core.bean;

import java.math.BigDecimal;

import java.util.Date;

import org.apache.log4j.Logger;
import org.jfree.util.Log;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.sunfe.entity.GlaAeuv;
import com.sunline.sunfe.entity.GlaTran;
import com.sunline.sunfe.util.PkgUtil;
import com.sunline.suncm.util.Sequence;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.suncm.util.StringUtils;

/**
 * 
 * @ClassName: GlaTranBean
 * @Description: ������ˮ��
 * @author: zhangdq
 * @date: 2017-2-27 ����10:02:04
 */
public class GlaTranBean {
	private static final Logger logger = Logger.getLogger(GlaTranBean.class);

	/**
	 * 
	 * @Title: registerTran
	 * @Description: �Ǽ�ע�ύ����ˮ
	 * @param commonDao
	 * @param glaAeuv
	 * @param pckgdt
	 * @throws BimisException
	 * @return: String
	 */
	public static String registerTran(CommonDao commonDao, GlaAeuv glaAeuv, String crcycd, String pckgdt) throws BimisException {
		if (StringUtils.isEmpty(glaAeuv.getTrantp())) {
			Log.error("�������ͣ�1 �ֹ��� 2 ϵͳ�ˣ�����Ϊ��");
			throw new BimisException("999", "�������ͣ�1 �ֹ��� 2 ϵͳ�ˣ�����Ϊ��");
		}
		if (StringUtils.isEmpty(glaAeuv.getSoursq())) {
			Log.error("�������岻��Ϊ��");
			throw new BimisException("999", "�������岻��Ϊ��");
		}
		String transq = "";
		if (StringUtils.isEmpty(glaAeuv.getTransq())) {
			Sequence sequence;
			try {
				sequence = SequenceUtils.createSequence(glaAeuv.getStacid() + "", glaAeuv.getSourdt(), "transq", glaAeuv.getTranbr(), SessionParaUtils.getUsercd(), 1);
				transq = sequence.getSqueno();
				if (StringUtils.isEmpty(transq)) {
					logger.error("��ȡ������ˮʧ��,���������ϵ");
					throw new BimisException("999", "��ȡ������ˮʧ��,���������ϵ");
				}
			} catch (Exception e) {
				logger.error("��ȡ������ˮʧ��,���������ϵ");
				throw new BimisException("999", "��ȡ������ˮʧ��,���������ϵ");
			}
		}
		// �Ǽǽ�����ˮ
		GlaTran glaTran = new GlaTran();
		glaTran.setTransq(transq);
		glaTran.setTranti(new Date());
		glaTran.setStacid(glaAeuv.getStacid());
		glaTran.setTrandt(glaAeuv.getSourdt());
		glaTran.setTranbr(glaAeuv.getTranbr());

		glaTran.setUsercd(glaAeuv.getUsercd());
		glaTran.setSourdt(glaAeuv.getSourdt());
		glaTran.setSoursq(glaAeuv.getSoursq());

		glaTran.setAcctbr("");
		glaTran.setTrantp(glaAeuv.getTrantp());
		glaTran.setCrcycd(crcycd);
		glaTran.setDcmtno("");
		glaTran.setDcmttp("");

		glaTran.setPrcscd(glaAeuv.getPrcscd());
		glaTran.setTranam(BigDecimal.ZERO);
		glaTran.setItemcd("");
		glaTran.setPsauus(glaAeuv.getPsauus());

		glaTran.setStrkst(glaAeuv.getStrkst() == null ? "0" : glaAeuv.getStrkst());

		glaTran.setOdtrdt("");
		glaTran.setOdtrsq("");
		glaTran.setAcsrnm(0);

		glaTran.setSystid(glaAeuv.getSourst());
		glaTran.setMenuid("");
		glaTran.setAuthus("");
		glaTran.setMainbd(glaAeuv.getSoursq());
		glaTran.setSystid(glaAeuv.getSourst());
		glaTran.setMenuid("");
		glaTran.setAuthus("");
		glaTran.setPckgsq(PkgUtil.getPkgstr(pckgdt, "user_bsnssq"));
		glaTran.setBookno(PkgUtil.getPkgstr(pckgdt, "bookno"));

		glaTran.setClertg("0");
		glaTran.setClerno("");

		commonDao.insertByNamedSql("com.sunline.sunfe.mybatis.glatran.saveGlaTran", glaTran);

		return transq;
	}
}
