package com.sunline.sunfe.entity;

/**
 * ���ղ����java bean
 * @author zhangdq
 *
 */
public class ComEdct {
	private int stacid; //���ױ��
	private String edcttp; //�������
	private int edstep;    //���ղ���
	private String procna; //�������ȫ·��
	private String status; //״̬��1 ��ʹ�� 0 δʹ�ã�
	private String proctg; //�Ƿ�ִ�У�1 ��ִ�� 0 δִ�У�
	private String remark; //��ע
	
	public int getStacid() {
		return stacid;
	}
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	public String getEdcttp() {
		return edcttp;
	}
	public void setEdcttp(String edcttp) {
		this.edcttp = edcttp;
	}
	public int getEdstep() {
		return edstep;
	}
	public void setEdstep(int edstep) {
		this.edstep = edstep;
	}
	public String getProcna() {
		return procna;
	}
	public void setProcna(String procna) {
		this.procna = procna;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getProctg() {
		return proctg;
	}
	public void setProctg(String proctg) {
		this.proctg = proctg;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
}
