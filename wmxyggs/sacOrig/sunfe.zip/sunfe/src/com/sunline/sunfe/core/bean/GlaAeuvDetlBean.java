package com.sunline.sunfe.core.bean;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.suncm.util.Constants;
import com.sunline.sunfe.entity.GlaAcct;
import com.sunline.sunfe.entity.GlaAeuvDetl;
import com.sunline.sunfe.entity.GlaGlis;
import com.sunline.sunfe.util.ComItexUtil;

/**
 * 
 * @ClassName: GlaAeuvDetlBean
 * @Description: ��Ʒ�¼��ϸ
 * @author: zhangdq
 * @date: 2017-2-27 ����10:00:50
 */
public class GlaAeuvDetlBean implements Cloneable {

	/**
	 * ��־������
	 */
	private static Log log = LogFactory.getLog(GlaAeuvDetlBean.class);
	/**
	 * mybatis �����ļ��������ռ�
	 */
	private final static String MYBATIS_GAD = "com.sunline.sunfe.mybatis.glaaeuvdetl.";

	/**
	 * 
	 * @Title: setDefaultAssistInfo
	 * @Description: ���ö�ά������Ĭ����Ϣ
	 * @param glaAeuvDetl
	 * @throws BimisException
	 * @return: void
	 */
	public static void setAssistDefaultInfo(GlaAeuvDetl glaAeuvDetl)
			throws BimisException {
		int stacid = glaAeuvDetl.getStacid();
		// ��ƿ�ĿԤ�õ�6�����������δ���ã�������Ĭ��ֵ 
		if (!ComItexUtil.isValide(stacid, "centcd")) {
			glaAeuvDetl.setCentcd(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "custcd")) {
			glaAeuvDetl.setCustcd(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "prsncd")) {
			glaAeuvDetl.setPrsncd(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "prlncd")) {
			glaAeuvDetl.setPrlncd(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "prducd")) {
			glaAeuvDetl.setPrducd(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "acctno")) {
			glaAeuvDetl.setAcctno(Constants.DEFAULT_VALUE_START);
		}

		// ��ƿ�Ŀ10���Զ��帨��������
		if (!ComItexUtil.isValide(stacid, "assis0")) {
			glaAeuvDetl.setAssis0(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "assis1")) {
			glaAeuvDetl.setAssis1(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "assis2")) {
			glaAeuvDetl.setAssis2(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "assis3")) {
			glaAeuvDetl.setAssis3(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "assis4")) {
			glaAeuvDetl.setAssis4(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "assis5")) {
			glaAeuvDetl.setAssis5(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "assis6")) {
			glaAeuvDetl.setAssis6(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "assis7")) {
			glaAeuvDetl.setAssis7(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "assis8")) {
			glaAeuvDetl.setAssis8(Constants.DEFAULT_VALUE_START);
		}
		if (!ComItexUtil.isValide(stacid, "assis9")) {
			glaAeuvDetl.setAssis9(Constants.DEFAULT_VALUE_START);
		}
	}

	/**
	 * 
	 * @Title: getGlaAeuvDetlKey
	 * @Description: ƴװ��¼��ϸ������
	 * @param glaAeuvDetl
	 * @return: String
	 */
	public static String getGlaAeuvDetlKey(GlaAeuvDetl glaAeuvDetl) {
		return String.valueOf(glaAeuvDetl.getStacid()).concat(Constants.MIDTAG)
				.concat(glaAeuvDetl.getSourst()).concat(Constants.MIDTAG)
				.concat(glaAeuvDetl.getSourdt()).concat(Constants.MIDTAG)
				.concat(glaAeuvDetl.getSoursq()).concat(Constants.MIDTAG)
				.concat(String.valueOf(glaAeuvDetl.getDispsq()));
	}

	/**
	 * 
	 * @Title: clone
	 * @Description: ����һ����Ʒ�¼��ϸ���󣬲��ı�ԭ����
	 * @param glaAeuvDetl
	 * @return: GlaAeuvDetl
	 */
	public static GlaAeuvDetl clone(final GlaAeuvDetl glaAeuvDetl) {
		GlaAeuvDetl cloneObject = new GlaAeuvDetl();
		cloneObject.setStacid(glaAeuvDetl.getStacid());
		cloneObject.setSourst(glaAeuvDetl.getSourst());
		cloneObject.setSourdt(glaAeuvDetl.getSourdt());
		cloneObject.setSoursq(glaAeuvDetl.getSoursq());
		cloneObject.setDispsq(glaAeuvDetl.getDispsq());
		cloneObject.setAcctbr(glaAeuvDetl.getAcctbr());
		cloneObject.setItemcd(glaAeuvDetl.getItemcd());
		cloneObject.setAmntcd(glaAeuvDetl.getAmntcd());
		cloneObject.setTranam(glaAeuvDetl.getTranam());
		cloneObject.setTrannm(glaAeuvDetl.getTrannm());
		cloneObject.setSmrytx(glaAeuvDetl.getSmrytx());
		cloneObject.setCentcd(glaAeuvDetl.getCentcd());
		cloneObject.setPrsncd(glaAeuvDetl.getPrsncd());
		cloneObject.setCustcd(glaAeuvDetl.getCustcd());
		cloneObject.setPrducd(glaAeuvDetl.getPrducd());
		cloneObject.setPrlncd(glaAeuvDetl.getPrlncd());
		cloneObject.setAcctno(glaAeuvDetl.getAcctno());
		cloneObject.setAssis0(glaAeuvDetl.getAssis0());
		cloneObject.setAssis1(glaAeuvDetl.getAssis1());
		cloneObject.setAssis2(glaAeuvDetl.getAssis2());
		cloneObject.setAssis3(glaAeuvDetl.getAssis3());
		cloneObject.setAssis4(glaAeuvDetl.getAssis4());
		cloneObject.setAssis5(glaAeuvDetl.getAssis5());
		cloneObject.setAssis6(glaAeuvDetl.getAssis6());
		cloneObject.setAssis7(glaAeuvDetl.getAssis7());
		cloneObject.setAssis8(glaAeuvDetl.getAssis8());
		cloneObject.setAssis9(glaAeuvDetl.getAssis9());
		cloneObject.setCnvtmd(glaAeuvDetl.getCnvtmd());
		cloneObject.setCvtrmb(glaAeuvDetl.getCvtrmb());
		cloneObject.setCvtusd(glaAeuvDetl.getCvtusd());
		cloneObject.setCrcycd(glaAeuvDetl.getCrcycd());
		cloneObject.setAcctcd(glaAeuvDetl.getAcctcd());

		return cloneObject;
	}

	/**
	 * 
	 * @Title: saveGlaAeuvDetlBatch 
	 * @Description: ���������Ʒ�¼��ϸ
	 * @param commonDao
	 * @param glaAeuvDetlList
	 * @throws BimisException
	 * @return: void
	 */
	public static void saveGlaAeuvDetlBatch(CommonDao commonDao,
			List<GlaAeuvDetl> glaAeuvDetlList) throws BimisException {
		for (GlaAeuvDetl glaAeuvDetl : glaAeuvDetlList) {
			setAssistDefaultInfo(glaAeuvDetl);
		}

		// �����ύ����
		int batchCount = 1000;
		int insertRecordCount = 0;
		try {
			int ednIdx = 0;
			for (int beginIdx = 0; beginIdx < glaAeuvDetlList.size();) {
				ednIdx = beginIdx + batchCount < glaAeuvDetlList.size() ? beginIdx
						+ batchCount : glaAeuvDetlList.size();

				List<GlaAeuvDetl> subglaAeuvDetlList = glaAeuvDetlList.subList(beginIdx,
						ednIdx);
				beginIdx = beginIdx + batchCount;
				insertRecordCount += commonDao.insertByNamedSql(MYBATIS_GAD
						+ "saveGlaAeuvDetlBatch", subglaAeuvDetlList);
				;
			}
			if (insertRecordCount != glaAeuvDetlList.size()) {
				log.error("��Ʒ�¼��ϸ��Ϣ���ʧ��");
				throw new BimisException("9999", "��Ʒ�¼��ϸ��Ϣ���ʧ��");
			}
		} catch (Exception ex) {
			log.error("��Ʒ�¼��ϸ��Ϣ���ʧ��");
			throw new BimisException("9999", "��Ʒ�¼��ϸ��Ϣ���ʧ��",ex);
		}
	}
	// ��¼��ϸ��¼ͨ���˻������Ӷ�ά��Ϣ
	public static void appendMultiAeuvDetlByGlaAcct(GlaAeuvDetl glaAeuvDetl,GlaAcct glaAcct
			) {
		glaAeuvDetl.setCentcd(glaAcct.getCentcd()==null?"*":glaAcct.getCentcd());
		glaAeuvDetl.setPrsncd(glaAcct.getPrsncd()==null?"*":glaAcct.getPrsncd());
		glaAeuvDetl.setCustcd(glaAcct.getCustcd()==null?"*":glaAcct.getCustcd());
		glaAeuvDetl.setPrducd(glaAcct.getPrducd()==null?"*":glaAcct.getPrducd());
		glaAeuvDetl.setPrlncd(glaAcct.getPrlncd()==null?"*":glaAcct.getPrlncd());
		glaAeuvDetl.setAcctno(glaAcct.getAcctno()==null?"*":glaAcct.getAcctno());
		glaAeuvDetl.setAssis0(glaAcct.getAssis0()==null?"*":glaAcct.getAssis0());
		glaAeuvDetl.setAssis1(glaAcct.getAssis1()==null?"*":glaAcct.getAssis1());
		glaAeuvDetl.setAssis2(glaAcct.getAssis2()==null?"*":glaAcct.getAssis2());
		glaAeuvDetl.setAssis3(glaAcct.getAssis3()==null?"*":glaAcct.getAssis3());
		glaAeuvDetl.setAssis4(glaAcct.getAssis4()==null?"*":glaAcct.getAssis4());
		glaAeuvDetl.setAssis5(glaAcct.getAssis5()==null?"*":glaAcct.getAssis5());
		glaAeuvDetl.setAssis6(glaAcct.getAssis6()==null?"*":glaAcct.getAssis6());
		glaAeuvDetl.setAssis7(glaAcct.getAssis7()==null?"*":glaAcct.getAssis7());
		glaAeuvDetl.setAssis8(glaAcct.getAssis8()==null?"*":glaAcct.getAssis8());
		glaAeuvDetl.setAssis9(glaAcct.getAssis9()==null?"*":glaAcct.getAssis9());
	}  
	// ��¼��ϸ��¼ͨ���˻������Ӷ�ά��Ϣ
	public static void appendMultiAeuvDetlByGlaGlis(GlaAeuvDetl glaAeuvDetl,GlaGlis glaGlis
			) {
		glaAeuvDetl.setCentcd(glaGlis.getCentcd()==null?"*":glaGlis.getCentcd());
		glaAeuvDetl.setPrsncd(glaGlis.getPrsncd()==null?"*":glaGlis.getPrsncd());
		glaAeuvDetl.setCustcd(glaGlis.getCustcd()==null?"*":glaGlis.getCustcd());
		glaAeuvDetl.setPrducd(glaGlis.getPrducd()==null?"*":glaGlis.getPrducd());
		glaAeuvDetl.setPrlncd(glaGlis.getPrlncd()==null?"*":glaGlis.getPrlncd());
		glaAeuvDetl.setAcctno(glaGlis.getAcctno()==null?"*":glaGlis.getAcctno());
		glaAeuvDetl.setAssis0(glaGlis.getAssis0()==null?"*":glaGlis.getAssis0());
		glaAeuvDetl.setAssis1(glaGlis.getAssis1()==null?"*":glaGlis.getAssis1());
		glaAeuvDetl.setAssis2(glaGlis.getAssis2()==null?"*":glaGlis.getAssis2());
		glaAeuvDetl.setAssis3(glaGlis.getAssis3()==null?"*":glaGlis.getAssis3());
		glaAeuvDetl.setAssis4(glaGlis.getAssis4()==null?"*":glaGlis.getAssis4());
		glaAeuvDetl.setAssis5(glaGlis.getAssis5()==null?"*":glaGlis.getAssis5());
		glaAeuvDetl.setAssis6(glaGlis.getAssis6()==null?"*":glaGlis.getAssis6());
		glaAeuvDetl.setAssis7(glaGlis.getAssis7()==null?"*":glaGlis.getAssis7());
		glaAeuvDetl.setAssis8(glaGlis.getAssis8()==null?"*":glaGlis.getAssis8());
		glaAeuvDetl.setAssis9(glaGlis.getAssis9()==null?"*":glaGlis.getAssis9());
	} 
}
