package com.sunline.sunfe.dayend.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.dayend.IDayEndProcesser;
import com.sunline.sunfe.glisfund.PublicFmbCntrInfoUtil;

/**
 * @author ����
 * @Email xiongl@sunline.cn
 * @Time 2017��12��25��
 * @��������ã��ϴ��ͬ�����Զ�֧ȡ/�½��ͬ�����Զ��黹
 */
public class DayEndAutoreturnProcesser extends IDayEndProcesser {
	private static final Logger logger = LoggerFactory.getLogger(DayEndAutoreturnProcesser.class);
	private String stacid;
	private boolean flag;
	private String usercd;
	private String sourdt;
	private String prcscd = "gls_autopy";
	private String sourst = "90";// ����Դϵͳ��Դ��ʶ
	private String prscna;
	private CommonDao commonDao;
	private PublicFmbCntrInfoUtil publicFmbCntrInfo;

	/**
	 * @throws BimisException
	 * @�˷��������ã���ȡ��ʼ������
	 */
	@Override
	public void preProcess() throws BimisException {
		commonDao = this.getCommonDao();
		stacid = SessionParaUtils.getStacid();
		sourdt = PubUtil.getGlisdt(Integer.parseInt(stacid));
		publicFmbCntrInfo = new PublicFmbCntrInfoUtil(commonDao);
		// �ж��Ƿ�������
		flag = publicFmbCntrInfo.isNormalDay(stacid, sourdt);
		if (flag) {
			usercd = SessionParaUtils.getUsercd();
			prscna = String.valueOf(publicFmbCntrInfo.prcsnaInfo(Integer.valueOf(stacid), prcscd).get("functx"));
		}
	}

	/**
	 * @throws BimisException
	 * @�˷��������ã�ִ���ϴ�֧ȡ���½�黹
	 */
	@Override
	public void processing() throws BimisException {
		if (!flag)
			throw new BimisException("502", "��ǰϵͳʱ�䡾" + sourdt + "�����ǻ������ʱ��");
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("stacid", stacid);
		// ��ȡ��Ч�ĺ�ͬ��Ϣ
		map.put("transt", "2");
		// ��ȡ��ͬ���������Ƿ�Ϊϵͳ����
		map.put("matudt", sourdt);
		try {
			List<Map<String, Object>> list = publicFmbCntrInfo.selectFmbCntrInfos(map);
			commonDao.beginTransaction();
			// �������ӻ�Ʒ�¼
			for (int i = 0, length = list.size(); i < length; i++) {
				map = publicFmbCntrInfo.loadMapInfo(list.get(i), stacid, sourdt, prscna, usercd, prcscd, sourst, "0", "autoreturn", "2", "0", "0", "bsnssq", list.get(i).get("brchno") + "");
				publicFmbCntrInfo.insertGlaAeuvInfo(map);
				map.put("aebscd", map.get("cntrtp") + "B");
				publicFmbCntrInfo.insertGlaAeuvDetl(map);
				map.put("soursq", map.get("soursq") + "");
				publicFmbCntrInfo.comAccounting(map);
				map.put("datatp", "2");
				map.put("aplysq", "999999");
				map.put("transt", "2");
				publicFmbCntrInfo.insertDoubleFmBDrrt(map);
				publicFmbCntrInfo.updateFmbCntr(map);
				map.clear();
			}
			publicFmbCntrInfo.executeBatch(publicFmbCntrInfo.insertGlaAuve);
			publicFmbCntrInfo.executeBatch(publicFmbCntrInfo.insertGlaAuveDeltl);
			publicFmbCntrInfo.executeBatch(publicFmbCntrInfo.insertFmbDrrt);
			commonDao.commitTransaction();
		} catch (Exception e) {
			commonDao.rollBack();
			logger.error(e.getMessage());
			throw new BimisException("500", e.getMessage());
		} finally {
			publicFmbCntrInfo.closePreparedStatement(publicFmbCntrInfo.insertGlaAuve);
			publicFmbCntrInfo.closePreparedStatement(publicFmbCntrInfo.insertGlaAuveDeltl);
			publicFmbCntrInfo.closePreparedStatement(publicFmbCntrInfo.insertFmbDrrt);
		}
	}

	/**
	 * @throws BimisException
	 * @�˷��������ã�
	 */
	@Override
	public void processed() throws BimisException {
	}

}
