package com.sunline.sunfe.conf;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.services.Actor;
import com.sunline.sunfe.util.StringUtils;

/**
 * ��Ʒ��Ӧ����ӳ��������� && DtitMapAction
 * Author: luoyd
 * creation time: 2016-12-19
 * @author ASUS
 *
 */
public class DtitMapAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.dtitmap.";
	
	/**
	 * ��ѯ��Ʒ��Ӧ����ӳ�� && queryDtitMapListPage
	 * 
	 */
	public void queryDtitMapListPage(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String prodcd = req.getReqDataStr("prodcd");
			String prodpa = req.getReqDataStr("prodpa");
			String pageNo = req.getReqDataStr("pageNum");
			if (StringUtils.isNotEmpty(pageNo)) {
				req.setReqPageNo(Integer.parseInt(pageNo));
			}
			hashmap.put("prodcd", prodcd);
			hashmap.put("prodpa", prodpa);
			
			Element element = commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryDtitMaplistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(element.removeContent());
		} catch (JDOMException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * ��ѯ��Ʒ��Ӧ����ӳ����Ϣ����
	 */
	public void queryDtitMapInfo(){
		try 
		{
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String prodcd = req.getReqDataStr("prodcd");//���Դ���
			String prodp1 = req.getReqDataStr("prodp1");//����1
			String prodp2 = req.getReqDataStr("prodp2");//����2
			String prodp3 = req.getReqDataStr("prodp3");//����3
			String prodp4 = req.getReqDataStr("prodp4");//����4
			String prodp5 = req.getReqDataStr("prodp5");//����5
			String prodp6 = req.getReqDataStr("prodp6");//����6
			String prodp7 = req.getReqDataStr("prodp7");//����7
			String prodp8 = req.getReqDataStr("prodp8");//����8
			String prodp9 = req.getReqDataStr("prodp9");//����9
			String dtitcd = req.getReqDataStr("dtitcd");//�������
			
			hashmap.put("prodcd", prodcd);
			hashmap.put("prodp1", prodp1.trim());
			hashmap.put("prodp2", prodp2.trim());
			hashmap.put("prodp3", prodp3.trim());
			hashmap.put("prodp4", prodp4.trim());
			hashmap.put("prodp5", prodp5.trim());
			hashmap.put("prodp6", prodp6.trim());
			hashmap.put("prodp7", prodp7.trim());
			hashmap.put("prodp8", prodp8.trim());
			hashmap.put("prodp9", prodp9.trim());
			hashmap.put("dtitcd", dtitcd); 
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryDtitMapInfo", hashmap);	
            req.addRspData(e.removeContent());        //���ؽ����װ	
		} catch (Exception e) {
			e.printStackTrace();
		}
	 }	
	
	/**
	 *  ��Ʒ��Ӧ����ӳ����Ϣ��Ϣ¼��
	 */
	public void addDtitMap(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			commonDao.beginTransaction();
			String prodcd = req.getReqDataStr("prodcd");//���Դ���
			String prodp1 = req.getReqDataStr("prodp1");//����1
			String prodp2 = req.getReqDataStr("prodp2");//����2
			String prodp3 = req.getReqDataStr("prodp3");//����3
			String prodp4 = req.getReqDataStr("prodp4");//����4
			String prodp5 = req.getReqDataStr("prodp5");//����5
			String prodp6 = req.getReqDataStr("prodp6");//����6
			String prodp7 = req.getReqDataStr("prodp7");//����7
			String prodp8 = req.getReqDataStr("prodp8");//����8
			String prodp9 = req.getReqDataStr("prodp9");//����9
			String prodpa = req.getReqDataStr("prodpa");//��������
			String dtitcd = req.getReqDataStr("dtitcd");//�������
			
			hashmap.put("prodcd", prodcd);
			hashmap.put("prodp1", prodp1.trim());
			hashmap.put("prodp2", prodp2.trim());
			hashmap.put("prodp3", prodp3.trim());
			hashmap.put("prodp4", prodp4.trim());
			hashmap.put("prodp5", prodp5.trim());
			hashmap.put("prodp6", prodp6.trim());
			hashmap.put("prodp7", prodp7.trim());
			hashmap.put("prodp8", prodp8.trim());
			hashmap.put("prodp9", prodp9.trim());
			hashmap.put("prodpa", prodpa.trim());
			hashmap.put("dtitcd", dtitcd);
			
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistDtitMap", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "�ò�Ʒ��Ӧ����ӳ���Ѵ��ڣ�");
					return;
				}
			}
			
			commonDao.insertByNamedSql(MYBATIS_NS+"addDtitMap", hashmap);
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("navTabId", "");
			req.addRspData("callbackType", "closeCurrent");
			req.addRspData("forwardUrl", "");
			commonDao.commitTransaction();
			
		} catch (Exception e) {
			commonDao.rollBack();
			e.printStackTrace();
		}	
		
	}
	
	/**
	 * ɾ����Ʒ��Ӧ����ӳ�� && deleteDtitMap
	 * 
	 */
    public void deleteDtitMap() {
		 try {
	        	HashMap<String, String> param = new HashMap<String, String>();
	            List<String> dtitpacdList = req.getReqDataTexts("dtitpacd");
	            commonDao.beginTransaction();
	            for (int i=0;i<dtitpacdList.size();i++) {
	            	 param.clear();
	                 String [] array = dtitpacdList.get(i).split("-");
	                 param.put("prodcd", array[0]);
	                 param.put("dtitcd", array[1]);
	                 param.put("prodpa", array[2]);
	                 param.put("prodp1", array[3]);
	                 param.put("prodp2", array[4]);
	                 param.put("prodp3", array[5]);
	                 param.put("prodp4", array[6]);
	                 param.put("prodp5", array[7]);
	                 param.put("prodp6", array[8]);
	                 param.put("prodp7", array[9]);
	                 param.put("prodp8", array[10]);
	                 param.put("prodp9", array[11]);
	                 commonDao.deleteByNamedSql(MYBATIS_NS+"deleteDtitMap", param);
	            }
	            commonDao.commitTransaction();
	            req.addRspData("retCode", "200");
				req.addRspData("retMessage", "�����ɹ�");
				req.addRspData("navTabId", "dtitmap_main");
				req.addRspData("callbackType", "");
				req.addRspData("forwardUrl", "");
			} catch (Exception e) {
				commonDao.rollBack();
				try {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage",e.toString().substring(e.toString().lastIndexOf("Cause")));
					req.addRspData("navTabId", "dtitmap_main");
					req.addRspData("callbackType", "");
					req.addRspData("forwardUrl", "");
				} catch (JDOMException e1) {
					e1.printStackTrace();
				}
				e.printStackTrace();
			  }
		}	
	/**
	 *  ��Ʒ��Ӧ����ӳ����Ϣ��Ϣ�޸�
	 */
	public void updateDtitMapInfo(){
		
	   try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			commonDao.beginTransaction();
			String prodcd = req.getReqDataStr("prodcd");//���Դ���
			String prodp1 = req.getReqDataStr("prodp1");//����1
			String prodp2 = req.getReqDataStr("prodp2");//����2
			String prodp3 = req.getReqDataStr("prodp3");//����3
			String prodp4 = req.getReqDataStr("prodp4");//����4
			String prodp5 = req.getReqDataStr("prodp5");//����5
			String prodp6 = req.getReqDataStr("prodp6");//����6
			String prodp7 = req.getReqDataStr("prodp7");//����7
			String prodp8 = req.getReqDataStr("prodp8");//����8
			String prodp9 = req.getReqDataStr("prodp9");//����9 
			String prodpa = req.getReqDataStr("prodpa");//��������
			String dtitcd = req.getReqDataStr("dtitcd");//�������
			String prodcd01 = req.getReqDataStr("prodcd01");//�����Դ���
			String prodp11 = req.getReqDataStr("prodp11");//������1
			String prodp22 = req.getReqDataStr("prodp22");//������2
			String prodp33 = req.getReqDataStr("prodp33");//������3
			String prodp44 = req.getReqDataStr("prodp44");//������4
			String prodp55 = req.getReqDataStr("prodp55");//������5
			String prodp66 = req.getReqDataStr("prodp66");//������6
			String prodp77 = req.getReqDataStr("prodp77");//������7
			String prodp88 = req.getReqDataStr("prodp88");//������8
			String prodp99 = req.getReqDataStr("prodp99");//������9
			String prodpa01 = req.getReqDataStr("prodpa01");//����������
			String dtitcd01 = req.getReqDataStr("dtitcd01");//�ɺ������
			
			
			hashmap.put("prodcd", prodcd);
			hashmap.put("prodp1", prodp1.trim());
			hashmap.put("prodp2", prodp2.trim());
			hashmap.put("prodp3", prodp3.trim());
			hashmap.put("prodp4", prodp4.trim());
			hashmap.put("prodp5", prodp5.trim());
			hashmap.put("prodp6", prodp6.trim());
			hashmap.put("prodp7", prodp7.trim());
			hashmap.put("prodp8", prodp8.trim());
			hashmap.put("prodp9", prodp9.trim());
			hashmap.put("prodpa", prodpa.trim());
			hashmap.put("dtitcd", dtitcd);
			hashmap.put("prodcd01", prodcd01);
			hashmap.put("prodp11", prodp11.trim());
			hashmap.put("prodp22", prodp22.trim());
			hashmap.put("prodp33", prodp33.trim());
			hashmap.put("prodp44", prodp44.trim());
			hashmap.put("prodp55", prodp55.trim());
			hashmap.put("prodp66", prodp66.trim());
			hashmap.put("prodp77", prodp77.trim());
			hashmap.put("prodp88", prodp88.trim());
			hashmap.put("prodp99", prodp99.trim());
			hashmap.put("prodpa01", prodpa01.trim());
			hashmap.put("dtitcd01", dtitcd01);
			
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistDtitMap", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "�ò�Ʒ��Ӧ����ӳ���Ѵ��ڣ��޸�ʧ�ܣ�");
					return;
				}
			}
			
			commonDao.insertByNamedSql(MYBATIS_NS+"updateDtitMap", hashmap);
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("navTabId", "");
			req.addRspData("callbackType", "closeCurrent");
			req.addRspData("forwardUrl", "");
			commonDao.commitTransaction();
			
		} catch (Exception e) {
			commonDao.rollBack();
			e.printStackTrace();
		}	
		
	}
}
