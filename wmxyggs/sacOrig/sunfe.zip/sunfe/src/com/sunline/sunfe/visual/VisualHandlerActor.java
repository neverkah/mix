package com.sunline.sunfe.visual;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.jdom.JDOMException;

import com.sunline.jraf.util.DatetimeUtil;
import com.sunline.jraf.util.JsonUtil;
import com.sunline.jraf.util.XmlUtil;
import com.sunline.jraf.services.Actor;
import com.sunline.suncm.util.Constants;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.SessionParaUtils;

public class VisualHandlerActor extends Actor {

	public String MY_BATIS_VISUALHANDLER = "com.sunline.sunfe.mybatis.visualhandler.";

	public void getDataNum() throws Exception {
		Map hashMap = new HashMap<String, Object>();
		List<Integer> lst = new ArrayList<Integer>();
		for (int dataCount = 0; dataCount < 4; dataCount++) {
			int sumSuccData = 0;
			hashMap.put("dataCount", dataCount);
			List<Integer> sucData = (List<Integer>) commonDao
					.queryByNamedSqlForList(MY_BATIS_VISUALHANDLER
							+ "getSuccessGlibalg", hashMap);
			if (sucData.size() > 0) {
				for (int data = 0; data < sucData.size(); data++) {
					Integer sumData = sucData.get(data);
					sumSuccData = sumSuccData + sumData;
				}
				lst.add(sumSuccData);
			} else {
				lst.add(null);
			}
		}

		Map map = new HashMap<String, Object>();
		List<Integer> errList = new ArrayList<Integer>();
		for (int errData = 0; errData < 4; errData++) {
			int sumErrorData = 0;
			map.put("errData", errData);
			List<Integer> errorData = (List<Integer>) commonDao
					.queryByNamedSqlForList(MY_BATIS_VISUALHANDLER
							+ "getErrGlibalg", map);
			if (errorData.size() > 0) {
				for (int data = 0; data < errorData.size(); data++) {
					Integer sumData = errorData.get(data);
					sumErrorData = sumErrorData + sumData;
				}
				errList.add(sumErrorData);
			} else {
				errList.add(0);
			}
		}
		List<Integer> impList = new ArrayList<Integer>();
		List<Integer> proList = new ArrayList<Integer>();
		List<Integer> parList = new ArrayList<Integer>();
		List<Integer> entList = new ArrayList<Integer>();
		impList.add(lst.get(0));
		impList.add(errList.get(0));
		proList.add(lst.get(1));
		proList.add(errList.get(1));
		parList.add(lst.get(2));
		parList.add(errList.get(2));
		entList.add(lst.get(3));
		entList.add(errList.get(3));
		req.addRspData("result", JsonUtil.convertObject2Json(lst));
		req.addRspData("errResult", JsonUtil.convertObject2Json(errList));

		req.addRspData("impResult", JsonUtil.convertObject2Json(impList));
		req.addRspData("proResult", JsonUtil.convertObject2Json(proList));
		req.addRspData("parResult", JsonUtil.convertObject2Json(parList));
		req.addRspData("entResult", JsonUtil.convertObject2Json(entList));
	}

	public void getAllStepName() throws Exception {
		Map hashMap = new HashMap<String, Object>();
		String stacid = SessionParaUtils.getStacid();
		hashMap.put("stacid", stacid);
		List<HashMap> step = (List<HashMap>) commonDao
				.queryByNamedSqlForList(
						MY_BATIS_VISUALHANDLER + "getXStepName", hashMap);
		List<Map> stepName=new ArrayList<Map>();
		Integer startedEdstep=0;//��ȡ���������õ����ղ���
		/*Map StepMap=new HashMap();
		if(step.size()>0){
			for(HashMap paramMap:step){
				 startedEdstep= Integer.parseInt(paramMap.get("edstep").toString()) ;
				String remark=paramMap.get("remark").toString();
				StepMap.put(startedEdstep, remark);
				stepName.add(StepMap);
			}
		}*/
		List<HashMap> stepList=new ArrayList<HashMap>();
		List<HashMap> statusList=new ArrayList<HashMap>();
		List<HashMap> duratiList=new ArrayList<HashMap>();
		List<HashMap> errorMsgList=new ArrayList<HashMap>();
		Map map = new HashMap<String, Object>();
		String batcdt = PubUtil.getGlisdt(Integer.parseInt(SessionParaUtils
				.getStacid()));
		map.put("stacid", stacid);
		map.put("batcdt", batcdt);
		List<HashMap> stepInfo = commonDao.getSqlSession().selectList(
				MY_BATIS_VISUALHANDLER + "getStepInfo", map);
		HashMap<Integer,Object> statusMap=new HashMap<Integer,Object>();
		HashMap<Integer,Object> duratiMap=new HashMap<Integer,Object>();
		HashMap<Integer,Object> errorMsgMap=new HashMap<Integer,Object>();
		HashMap<Integer,Object> stepMap=new HashMap<Integer,Object>();
		if (stepInfo.size() > 0) {
				for(HashMap pMap:stepInfo){
					//������ִ�й������ղ���
					Integer stepValue=Integer.parseInt(pMap.get("edstep").toString());
					String remark=(String) pMap.get("remark");
					String status=(String) pMap.get("status");
					Integer durati=Integer.parseInt(pMap.get("durati").toString()) ;
					String errorMsg=(String) pMap.get("erortx");
						if(!statusMap.containsKey(pMap.get("edstep").toString())){
						stepMap.put(stepValue,remark);
						statusMap.put(stepValue, status);
						duratiMap.put(stepValue, durati);
						errorMsgMap.put(stepValue, errorMsg);
						}
				}
		}
		stepList.add(stepMap);
		statusList.add(statusMap);
		duratiList.add(duratiMap);
		errorMsgList.add(errorMsgMap);
		List<String> stepNameList=new ArrayList<String>();
		List<Integer> stepOfStatus=new ArrayList<Integer>();
		List<Integer> stepOfValue=new ArrayList<Integer>();
		List<String> stepOfError=new ArrayList<String>();
		if(stepList.size()>0){
			for(HashMap<Integer, String> stepParamMap:stepList){
				for (Map.Entry<Integer, String> entry : stepParamMap.entrySet()) {
					         System.out.println("key= " + entry.getKey() + " and value= "
					                    + entry.getValue());
					         stepNameList.add(entry.getValue()); 
					         }	
			}
			for(HashMap<Integer, String> stepParamMap:statusList){
				for (Map.Entry<Integer, String> entry : stepParamMap.entrySet()) {
					         System.out.println("key= " + entry.getKey() + " and value= "
					                    + entry.getValue());
					         stepOfStatus.add(Integer.parseInt(entry.getValue())); 
					         }	
			}
			for(HashMap<Integer, Integer> stepParamMap:duratiList){
				for (Map.Entry<Integer, Integer> entry : stepParamMap.entrySet()) {
					         System.out.println("key= " + entry.getKey() + " and value= "
					                    + entry.getValue());
					         stepOfValue.add(Integer.parseInt(entry.getValue().toString())); 
					         }	
			}
			for(HashMap<Integer, String> stepParamMap:errorMsgList){
				for (Map.Entry<Integer, String> entry : stepParamMap.entrySet()) {
					         System.out.println("key= " + entry.getKey() + " and value= "
					                    + entry.getValue());
					         stepOfError.add(entry.getValue()); 
					         }	
			}
		}
		req.addRspData("stepName", JsonUtil.convertObject2Json(stepNameList));
		req.addRspData("stepOfStatus", JsonUtil.convertObject2Json(stepOfStatus));
		req.addRspData("stepOfValue", JsonUtil.convertObject2Json(stepOfValue));
		req.addRspData("stepOfError", JsonUtil.convertObject2Json(stepOfError));
	}

	/**
	 * @Title: getDataFileTps
	 * @Description: ��ѯ�����ļ���������(ÿ���Ӵ��������ݼ�¼��)
	 * @return: void
	 * @throws Exception
	 * @throws
	 */

	public void getDataFileTps() throws Exception {

		HashMap hashMap = new HashMap();
		// ����
		Integer imTps = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "qryImtps", hashMap);
		// ���ݼӹ�
		Integer prTps = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "qryPrtps", hashMap);
		// ����
		Integer paTps = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "qryPatps", hashMap);
		// ����
		Integer enTps = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "qryEntps", hashMap);

		List<Integer> lstTps = new ArrayList<Integer>();

		lstTps.add(imTps);
		lstTps.add(prTps);
		lstTps.add(paTps);
		lstTps.add(enTps);
		req.addRspData("tps", JsonUtil.convertObject2Json(lstTps));
	}

	/**
	 * @desc��ȡ���������ݼӹ������������ˡ�ʵʱ������ˮ������ʵʱ������ˮ���ˡ�����������¼
	 * @time 2017-10-11 15:00
	 */
	public void getRecoder() throws Exception {
		List<HashMap> lst = new ArrayList<HashMap>();
		String stacid = SessionParaUtils.getStacid();// ͨ��session��ȡ��ǰ����ID,stacid
		// ��������ID��ȡ��ǰ��������batcdt
		String batcdt = PubUtil.getGlisdt(Integer.parseInt(SessionParaUtils
				.getStacid()));
		// ����һ��map������Ҫ�����ݷ���map�н��в�ѯ
		HashMap hashMap = new HashMap();
		hashMap.put("stacid", stacid);
		hashMap.put("batcdt", batcdt);
		 String ymd=DatetimeUtil.formatDate(new Date(),DatetimeUtil.DATE_FORMAT_YMD);
		hashMap.put("batcdtStart",ymd+" 00:00:00");
		
		hashMap.put("batcdtEnd", ymd + " 23:59:59");
		hashMap.put("respms", Constants.EXECUTE_SUCC);
		// ��ѯ����ɹ�������
		Integer impSuc = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForImpSuc", hashMap);
		hashMap.put("impSuc", impSuc);

		// ��ѯ����ʧ�ܵ�����
		Integer impErr = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForImpErr", hashMap);
		hashMap.put("impErr", impErr);

		// ��ѯ���ݼӹ��ɹ�������
		Integer prsSuc = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForPrsSuc", hashMap);
		hashMap.put("prsSuc", prsSuc);

		// ��ѯ���ݼӹ�ʧ�ܵ�����
		Integer prsErr = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForPrsErr", hashMap);
		hashMap.put("prsErr", prsErr);

		// ��ѯ�������������ɹ�������
		Integer pasSuc = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForPasSuc", hashMap);
		hashMap.put("pasSuc", pasSuc);

		// ��ѯ������������ʧ�ܵ�����
		Integer pasErr = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForPasErr", hashMap);
		hashMap.put("pasErr", pasErr);

		// ��ѯ�����������˳ɹ�������
		Integer ensSuc = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForEnsSuc", hashMap);
		hashMap.put("ensSuc", ensSuc);

		// ��ѯ������������ʧ�ܵ�����
		Integer ensErr = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForEnsErr", hashMap);
		hashMap.put("ensErr", ensErr);

		// ��ѯʵʱ������ˮ�����ɹ�������
		Integer intPasSuc = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForIntPasSuc", hashMap);
		hashMap.put("intPasSuc", intPasSuc);

		// ��ѯʵʱ������ˮ����ʧ�ܵ�����
		Integer intPasErr = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForIntPasErr", hashMap);
		hashMap.put("intPasErr", intPasErr);

		// ��ѯʵʱ��Ʊ��ˮ�����ɹ�������
		Integer intVchrSuc = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForIntVchrSuc", hashMap);
		hashMap.put("intVchrSuc", intVchrSuc);

		// ��ѯʵʱ��Ʊ��ˮ����ʧ�ܵ�����
		Integer intVchrErr = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForIntVchrErr", hashMap);
		hashMap.put("intVchrErr", intVchrErr);

		// ���������ɹ���ʧ�ܵ�������¼
		Integer dayEndSuc = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForDayEndSuc", hashMap);
		hashMap.put("dayEndSuc", dayEndSuc);

		Integer dayEndErr = commonDao.getSqlSession().selectOne(
				MY_BATIS_VISUALHANDLER + "queryForDayEndErr", hashMap);
		hashMap.put("dayEndErr", dayEndErr);
		lst.add(hashMap);

		req.addRspData(XmlUtil.createDataObjectElement(lst).removeContent());
	}

	/**
	 * @desc �����ݿ��com_daybusi_tps��ȡ�������������������ݲ�����������TPS���ܷ���
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	public void getAllTpsData() throws Exception {
		HashMap map = new HashMap();
		String trandt = req.getReqDataStr("dataDealTime");

		String stacid = SessionParaUtils.getStacid();// ͨ��session��ȡ��ǰ����ID,stacid
		map.put("stacid", stacid);// �ֶ�1������id
		// ��������ID��ȡ��ǰ��������batcdt
		String batcdt = PubUtil.getGlisdt(Integer.parseInt(SessionParaUtils
				.getStacid()));
		if ("".equals(trandt) || null == trandt) {
			trandt = batcdt;
		}
		map.put("trandt", trandt);// �ֶ�2����ѯ����
		Date ds = DatetimeUtil.convertStrToDate(trandt,
				DatetimeUtil.DATE_FORMAT_YMD);
		Date de = DatetimeUtil.convertStrToDate(
				String.valueOf((Integer.parseInt(trandt) + 1)),
				DatetimeUtil.DATE_FORMAT_YMD);
		Timestamp dStart = new Timestamp(ds.getTime());
		Timestamp dEnd = new Timestamp(de.getTime());
		map.put("dStart", dStart);
		map.put("dEnd", dEnd);
		String tranType = req.getReqDataStr("tranType");
		if ("".equals(tranType) || null == tranType) {
			throw new Exception(tranType + "��������tranTypeΪ��!");
		}
		/**
		 * �ֶ�3����ѯ���� enumeration 0�����ݼӹ��������� 1��������ˮ�������� 2�������ˮ�������� 3��������ˮʵʱ����
		 * 4�������ˮʵʱ����
		 */
		map.put("tranType", Integer.parseInt(tranType));
		List<HashMap> lst = commonDao.getSqlSession().selectList(
				MY_BATIS_VISUALHANDLER + "queryForTpsData", map);
		int trannm = 0;
		List list = new ArrayList<>();
		List<HashMap> result = new ArrayList<>();
		if (lst.size() > 0) {
			HashMap hash = new HashMap();
			DecimalFormat df = new DecimalFormat("0.00");
			for (Float i = new Float(0d); i < 24;) {
				if (Float.parseFloat(df.format(i)) < (float) (i.intValue() + 0.60)) {
					hash.put(Float.parseFloat(df.format(i)), null);
					i = (float) (i + 0.05);
				} else {
					hash.put((float) (i.intValue() + 1.00), null);
					i = (float) (i + 0.05);
				}
			}
			// System.out.print(hm);
			List<Entry<Float, String>> bList = new LinkedList<Entry<Float, String>>(
					hash.entrySet());
			Collections.sort(bList, new Comparator<Entry<Float, String>>() {

				public int compare(Entry<Float, String> ele1,
						Entry<Float, String> ele2) {

					return ele1.getKey().compareTo(ele2.getKey());
				}
			});
			System.out.print("aList" + bList);
			HashMap mp = new HashMap();
			System.out.println("��ǰ������" + lst.size());
			String tranCurrent = null;
			String nm = null;
			for (HashMap hashMap : lst) {
				Iterator it = hashMap.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry entry = (Entry) it.next();
					if ("TRANNM".equals(entry.getKey())) {
						nm = entry.getValue().toString();
					} else {
						tranCurrent = entry.getValue().toString()
								.replace(":", ".");
					}
				}
				mp.put(Float.parseFloat(tranCurrent), nm);
			}
			// ͨ����ѯ����������map��ƴ�ӵ�map�ϲ���װȫ��24Сʱ������
			hash.putAll(mp);
			System.out.print(hash);
			Set<Entry<Float, String>> mapEntries = hash.entrySet();
			List<Entry<Float, String>> aList = new LinkedList<Entry<Float, String>>(
					mapEntries);

			Collections.sort(aList, new Comparator<Entry<Float, String>>() {

				@Override
				public int compare(Entry<Float, String> ele1,
						Entry<Float, String> ele2) {

					return ele1.getKey().compareTo(ele2.getKey());
				}
			});

			for (Entry<Float, String> entry : aList) {
				HashMap aMap = new HashMap();
				aMap.put("xData", entry.getKey().toString());
				aMap.put("trannm", entry.getValue());
				result.add(aMap);
			}
			/*
			 * if(list.size()>0){ HashMap<String,String> m=new
			 * HashMap<String,String>(); for(int i=1;i<lst.size();i++){ String
			 * nextNm=(String) list.get(2*i); String thisNm=(String)
			 * list.get(2*(i-1));
			 * trannm=Integer.parseInt(nextNm)-Integer.parseInt(thisNm); String
			 * nextTime=(String) list.get(2*i+1); String currentTime=(String)
			 * list.get(2*i-1); String[] nextTimeSplit=nextTime.split(":");
			 * String[] currentTimeSplit=currentTime.split(":"); //ÿ��*����ȥȥִ�е�����
			 * int
			 * decrease=(Integer.parseInt(nextTimeSplit[0])-Integer.parseInt(
			 * currentTimeSplit
			 * [0]))*60+(Integer.parseInt(nextTimeSplit[1])-Integer
			 * .parseInt(currentTimeSplit[1])); m.put(String.valueOf(trannm),
			 * nextNm); result.add(m); } }
			 */
		} else {
			result = null;
		}
		req.addRspData("tranType", tranType);
		req.addRspData("tpsData", JsonUtil.convertObject2Json(result));
	}

}
