/**
 * TODO
 * @ClassName: MlcfAction.java
 * @Description: 
 * @author: huangziq
 * @date: 2017-8-9����4:07:57
 */
package com.sunline.sunfe.glavchr;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.funcpub.tools.bean.ZTree;
import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.JsonUtil;
import com.sunline.jraf.util.StringUtil;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.SessionParaUtils;

/**
 * ��ά���˺�����Դ
 * 
 * @author huangziq
 * 
 */
public class ExsrAction extends Actor {

	private final String MYBATIS_NS = "com.sunline.sunfe.mybatis.comexsr.";
	
	
	public void getComExsrTree() throws Exception {
		String id = this.req.getReqDataStr("id");
		String level = this.req.getReqDataStr("level");
		List<ZTree> treeList = getPrdparaTree(id, level);
		this.req.addRspData("exsrtree", JsonUtil.convertObject2Json(treeList));
	}
	
	/**
	 * ǰ̨��ǩsc:optʹ��
	 * sc optd type xml 
	 */
	@SuppressWarnings("unchecked")
	public void getComExsrInfo() {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();// ����
			String sourcd = hashmap.get("sourcd");
			hashmap.put("stacid", stacid);
			if (sourcd==null||"".equals(sourcd)) {
				return;
			}
			int count = commonDao.getSqlSession().selectOne(MYBATIS_NS+"getCountSourcd", hashmap);
			if (count==0) {
				String linkid = PubUtil.getLinkid(Integer.valueOf(stacid));
				if (!StringUtil.isNullOrEmpty(linkid)) {
					hashmap.put("stacid", linkid);
				}
			}
			// ��ѯ��ά�������á����������
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getComExsrByAcexcd", hashmap);
			req.addRspData(e.removeContent());
		} catch (Exception e) {
			getLog().logError(e);
		}
	}

	/**
	 * ��ȡ������Դ��
	 * 
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public List<ZTree> getPrdparaTree(String id, String level) throws Exception {
		ZTree treeObj = null;
		List<ZTree> treeList = new ArrayList<ZTree>();
		HashMap<String, String> paMap = new HashMap<String, String>();
		Element typeElement = null;
		boolean isParent;
		try {
			paMap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			paMap.put("stacid", stacid);
			// ��ȡacexna
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getComItexByAcexcd", paMap);
			if (e.getChildren().size() == 0) {
				req.addRspData("retCode", "500");
				req.addRspData("retMessage", "����ظ���������Դ");
				return null;
			}
			String treeName = e.getChild("Record").getChildText("acexna");

			// ��ʼ�� ZTree
			if ((id == null) || ("".equals(id)) || ("-1".equals(id))) {// 0
				if (!"-1".equals(id)) {
					treeList.add(new ZTree("-1", "", treeName, "", "ajax", "", 0, true));
				}
				// ��ѯ����
				List<HashMap<String, Object>> itemTypeList = (List<HashMap<String, Object>>) commonDao.queryByNamedSqlForList(MYBATIS_NS + "getComExsrTopByAcexcd", paMap);
				if (null != itemTypeList && itemTypeList.size() > 0) {
					for (HashMap<String, Object> itemType : itemTypeList) {
						treeList.add(new ZTree((String) itemType.get("sourcd"), "-1", (String) itemType.get("sourna"), "", "ajax", "", 1, true,true,false,null));
					}
				}
			} else {// ��0
				List oneLevelMenuList = new ArrayList();
				paMap.put("sprrcd", id);
				oneLevelMenuList = this.commonDao.queryByNamedSql(MYBATIS_NS + "getComExsrBySprrcd", paMap).removeContent();

				if ((oneLevelMenuList != null) && (oneLevelMenuList.size() > 0)) {
					Iterator a = oneLevelMenuList.iterator();
					while (a.hasNext()) {
						typeElement = (Element) a.next();
						String detltg = typeElement.getChildText("detltg"); // �ж��Ƿ�Ϊĩ��//0��ĩ��// 1Ϊĩ��
						if ("1".equals(detltg)) {
							isParent = false;
						} else {
							isParent = true;
						}
						treeObj = new ZTree(typeElement.getChildTextTrim("sourcd"), typeElement.getChildTextTrim("sprrcd"), typeElement.getChildTextTrim("sourna"), "", "ajax", "exsrBox",
								Integer.valueOf(level) + 1, isParent);
						treeList.add(treeObj);
					}
				}
			}
		} catch (Exception e) {
			getLog().logError(e);
		}
		return treeList;
	}
	
	/*
	 * ͨ����Ʒ�����ȡ��Ʒ��Ϣ
	 */
	@SuppressWarnings("unchecked")
	public void getExsrBySourcd() {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req
					.getReqDataMap();
			hashmap.put("stacid", SessionParaUtils.getStacid());
			Element element = commonDao.queryByNamedSql(MYBATIS_NS
					+ "getExsrBySourcd", hashmap);
			req.addRspData(element.removeContent());
		} catch (Exception e) {
			getLog().logError(e);
		}
	}

	/*
	 * ��ȡ���в�Ʒ�嵥
	 */
	@SuppressWarnings("unchecked")
	public void getExsrList() {
		try {
			HashMap<String, Object> hashmap = (HashMap<String, Object>) req
					.getReqDataMap();
			hashmap.put("stacid", SessionParaUtils.getStacid());
			Element element = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getExsrlistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(element.removeContent());
		} catch (Exception e) {
			getLog().logError(e);
		}
	}

}
