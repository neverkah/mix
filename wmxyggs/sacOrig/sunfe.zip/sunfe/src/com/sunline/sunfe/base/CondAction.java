package com.sunline.sunfe.base;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.sunfe.util.StringUtils;
public class CondAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.cond.";
	Log log = new Log("PftpAction");
	/**
	 * ��ѯϵͳ�����嵥 & queryCondListPage
	 */
	public void queryCondListPage(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String condcd = req.getReqDataStr("condcd");//��������
			String condna = req.getReqDataStr("condna");//��������
			condcd = StringUtils.repalceCharecter(condcd);

			String pageNo = req.getReqDataStr("pageNum");
			if (StringUtils.isNotEmpty(pageNo)) {
				req.setReqPageNo(Integer.parseInt(pageNo));
			}
			hashmap.put("condcd", condcd);
			hashmap.put("condna", condna);
			hashmap.put("vermod", "0");
			
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryCondlistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (Exception e) {
			log.logError(e);
		}
	}
	/**
	 * ���� ��Ϣ
	 */
	public void queryCondInfo()  //06����id��  �� ��¼
	{
		try 
		{
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String condcd = req.getReqDataStr("condcd");
			hashmap.put("condcd", condcd);
			hashmap.put("vermod", "0");
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryCondInfo", hashmap);	
            req.addRspData(e.removeContent());        //���ؽ����װ	
            Element templateEle = commonDao.queryByNamedSql(MYBATIS_NS+"queryDetlBycondcdlistPage",hashmap);
            req.addRspData("Results2",templateEle.removeContent());   //���ؽ����װ
		} catch (Exception e) {
			log.logError(e);
		}
	 }	
	/**
	 * ����ϵͳ���� & addCond
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addCond() throws JDOMException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap(); 
			HashMap<String, String> hashmap2 = new HashMap<String, String>(); 
			
			String condcd = req.getReqDataStr("condcd");//ϵͳ����
			String vermod = req.getReqDataStr("vermod");//�汾ģʽ
			String module = req.getReqDataStr("module");//ģ��
			String projcd = req.getReqDataStr("projcd");//��Ŀ���
			List<String> index_list = req.getReqDataTexts("index");
			//У��ϵͳ�����Ƿ��Ѵ���
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistCond", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "ϵͳ���������Ѵ��ڣ�");
					return;
				}
			}
			commonDao.beginTransaction();
		    commonDao.insertByNamedSql(MYBATIS_NS+"addCond",hashmap);
		    if(index_list.size()>0&&index_list!=null){
		    	for(int i=0;i<index_list.size();i++){
					   hashmap2.clear();
					   String index = index_list.get(i);
					   if(!"".equals(index)&&index!=null){
						   hashmap2.put("sortno", req.getReqDataStr("sortno"+index));
						   hashmap2.put("vermod", vermod);
						   hashmap2.put("module", module);
						   hashmap2.put("projcd", projcd);
						   hashmap2.put("condcd", condcd);
						   hashmap2.put("ladstr", req.getReqDataStr("ladstr"+index));
						   hashmap2.put("fildcd", req.getReqDataStr("fildcd"+index));
						   hashmap2.put("cmptyp", req.getReqDataStr("cmptyp"+index));
						   hashmap2.put("cmpcod", req.getReqDataStr("cmpcod"+index));
						   hashmap2.put("cmpval", req.getReqDataStr("cmpval"+index));
						   hashmap2.put("radstr", req.getReqDataStr("radstr"+index));
						   hashmap2.put("oprcod", req.getReqDataStr("oprcod"+index));
						   hashmap2.put("funccd", req.getReqDataStr("funccd"+index));
						   hashmap2.put("nulret", "0");
						   hashmap2.put("cdesctx", req.getReqDataStr("cdesctx"+index));
							List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistCondDetl", hashmap2);
							if(sumList!=null && sumList.size()>0) {
								Map sumMap = (HashMap)sumList.get(0);
								int sum = Integer.valueOf(sumMap.get("CC").toString());
								if(sum > 0) {
									commonDao.rollBack();
									req.addRspData("retCode", "300");
									req.addRspData("retMessage", "˳����Ѵ��ڣ�");
									return;
								}
							}
						   commonDao.insertByNamedSql(MYBATIS_NS+"insertCondDetl", hashmap2);
					   }
				   }
			   }
		    	ResultUtils.setRspData(req, "200",  "�����ɹ�", "cond_main", "closeCurrent", "");
		    	commonDao.commitTransaction();
			} catch (BimisException e) {
				commonDao.rollBack();
			    ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			    log.logError(e);
			}		
	}
	/**
	 * �޸�ϵͳ���� & updateCond
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void updateCond() throws JDOMException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap(); 
			HashMap<String, String> hashmap2 = new HashMap<String, String>(); 
			commonDao.beginTransaction();
			String condcd = req.getReqDataStr("condcd");//ϵͳ����
			String module = req.getReqDataStr("module");//ģ��
			String projcd = req.getReqDataStr("projcd");//��Ŀ���
			
			 List<String> index_list = req.getReqDataTexts("index");	
		     commonDao.updateByNamedSql(MYBATIS_NS+"updateCond",hashmap);//����ϵͳ����
			 commonDao.updateByNamedSql(MYBATIS_NS+"updateCondDetl",hashmap);
			 hashmap.put("vermod", "0");
			 commonDao.insertByNamedSql(MYBATIS_NS+"addCond",hashmap);
			 
		     if(index_list.size()>0&&index_list!=null){
			    	for(int i=0;i<index_list.size();i++){
						   hashmap2.clear();
						   String index = index_list.get(i);
						   if(!"".equals(index)&&index!=null){
							   hashmap2.put("sortno", req.getReqDataStr("sortno"+index));
							   hashmap2.put("vermod", "0");
							   hashmap2.put("module", module);
							   hashmap2.put("projcd", projcd);
							   hashmap2.put("condcd", condcd);
							   hashmap2.put("ladstr", req.getReqDataStr("ladstr"+index));
							   hashmap2.put("fildcd", req.getReqDataStr("fildcd"+index));
							   hashmap2.put("cmptyp", req.getReqDataStr("cmptyp"+index));
							   hashmap2.put("cmpcod", req.getReqDataStr("cmpcod"+index));
							   hashmap2.put("cmpval", req.getReqDataStr("cmpval"+index));
							   hashmap2.put("radstr", req.getReqDataStr("radstr"+index));
							   hashmap2.put("oprcod", req.getReqDataStr("oprcod"+index));
							   hashmap2.put("funccd", req.getReqDataStr("funccd"+index));
							   hashmap2.put("nulret", "0");
							   hashmap2.put("cdesctx", req.getReqDataStr("cdesctx"+index));
								List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistCondDetl", hashmap2);
								if(sumList!=null && sumList.size()>0) {
									Map sumMap = (HashMap)sumList.get(0);
									int sum = Integer.valueOf(sumMap.get("CC").toString());
									if(sum > 0) {
										req.addRspData("retCode", "300");
										req.addRspData("retMessage", "˳����Ѵ��ڣ�");
										return;
									}
								}
							   commonDao.insertByNamedSql(MYBATIS_NS+"insertCondDetl", hashmap2);
						   }
					   }
				   }
		    	ResultUtils.setRspData(req, "200",  "�����ɹ�", "cond_main", "closeCurrent", "");
			    commonDao.commitTransaction();
			}catch (BimisException e) {
				commonDao.rollBack();
			    ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			    log.logError(e);
			}		
		}

	/**
	 * ɾ��ϵͳ������Ϣ & deleteCond
	 * @throws JDOMException 
	 */
	public void deleteCond() throws JDOMException{
		try {
			List<String> condcdList = req.getReqDataTexts("condcds");
			if (condcdList != null && condcdList.size() > 0) {
				commonDao.beginTransaction();
				HashMap<String, List<String>> hashmap = new HashMap<String, List<String>>();
				hashmap.put("condcdList", condcdList);
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteDetl", hashmap);//ɾ��������ϸ
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteCond", hashmap);//ɾ��ϵͳ����
				}
				commonDao.commitTransaction();
				ResultUtils.setRspData(req, "200",  "�����ɹ�", "cond_main", "", "");
		} catch (BimisException e) {
				commonDao.rollBack();
			   ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "pftp_main", "", "");
		}
	}
}
