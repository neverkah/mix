package com.sunline.sunfe.monitor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jdom.Element;

public class ExcelUtilOfMonitor {

	private static final String XLS_TYPE = "XLS";

	private static final String XLSX_TYPE = "XLSX";

	private ExcelUtilOfMonitor() {
	}

	/**
	 * @Title: createWorkbookByType
	 * @Description: ��һ���������ļ��������ɶ�Ӧ��Workbook
	 * @param type
	 *            ͨ����xls xlsx����excel�ļ�
	 * @return
	 * @return: Workbook
	 * @author: zhangdq
	 * @date: 2016��09��09�� 17��13
	 */
	public static Workbook createWorkbookByType(String type) {
		Workbook workbook = null;
		if (XLS_TYPE.equals(type)) {
			workbook = new HSSFWorkbook();
		} else if (XLSX_TYPE.equals(type)) {
			workbook = new XSSFWorkbook();
		}
		return workbook;
	}

	/**
	 * @Title: createSheet
	 * @Description: �ڶ���������workbook��Ӧ��sheet������
	 * @param workbook
	 * @param sheetNo
	 *            sheet����ţ�һ��workbook�����ж��������
	 * @param sheetName
	 *            sheet������
	 * @return
	 * @return: Sheet
	 * @author: zhangdq
	 * @date: 2016��09��09�� 17��13
	 */
	public static Sheet createSheet(Workbook workbook, int sheetNo,
			String sheetName) {
		Sheet sheet = null;
		if (workbook != null) {
			sheet = workbook.createSheet();
			if (sheetName == "" || sheetName == null) {
				sheetName = "sheet" + sheetNo;
			}
			workbook.setSheetName(sheetNo, sheetName);
		}
		return sheet;
	}

	/**
	 * @Title: createCellStyle
	 * @Description: ������������workbook�ı����е�Ԫ����ʽ
	 * @param workbook
	 * @return
	 * @return: CellStyle
	 * @author: zhangdq
	 * @date: 2016��09��09�� 17��13
	 */
	public static CellStyle createCellStyleOfHeader(Workbook workbook) {
		CellStyle cellStyle = null;
		if (workbook != null) {
			cellStyle = workbook.createCellStyle();
			Font font = workbook.createFont();
			font.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
			font.setColor(HSSFFont.COLOR_NORMAL);
			cellStyle.setFont(font);
			cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			cellStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
			cellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
			cellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);

		}
		return cellStyle;
	}

	/**
	 * @Title: createCellStyle
	 * @Description: ������������workbook�������е�Ԫ����ʽ
	 * @param workbook
	 * @return
	 * @return: CellStyle
	 * @author: zhangdq
	 * @date: 2016��09��09�� 17��13
	 */
	public static CellStyle createCellStyleOfData(Workbook workbook) {
		CellStyle cellStyle = null;
		if (workbook != null) {
			cellStyle = workbook.createCellStyle();
			Font font = workbook.createFont();
			font.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
			font.setColor(HSSFFont.COLOR_NORMAL);
			cellStyle.setFont(font);
			cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
			cellStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		}
		return cellStyle;
	}

	/**
	 * @Title: createHeader
	 * @Description: ���Ĳ������ɶ�Ӧsheet��ͷ��Ϣ������sheet�ĵ�һ�У�
	 * @param sheet
	 * @param excelHeader
	 * @param cellStyle
	 * @return: void
	 * @author: zhangdq
	 * @date: 2016��09��09�� 17��13
	 */
	public static void createHeader(Sheet sheet, ArrayList<String> excelHeader,
			CellStyle cellStyle) {
		if (sheet != null && excelHeader != null) {
			Row titleRow = sheet.createRow(0);
			for (int i = 0; i < excelHeader.size(); i++) {
				sheet.setColumnWidth(i, excelHeader.get(i).length() * 2 * 256);
				Cell cell = titleRow.createCell(i, 0);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(excelHeader.get(i));
			}
		}
	}

	/**
	 * @Title: createData
	 * @Description: ���岽������Ӧsheet������
	 * @param sheet
	 * @param excelHeader
	 * @param cellStyle
	 * @return: void
	 * @author: zhangdq
	 * @date: 2016��09��09�� 17��13
	 */
	public static void createData(Sheet sheet, ArrayList<String> excelHeader,
			List<Element> excelData, CellStyle cellStyle) {
		if (sheet != null && excelHeader != null && excelData != null) {
			for (int i = 0; i < excelData.size(); i++) {
				Row dataRow = sheet.createRow(i + 1);
				Element record = (Element) excelData.get(i);
				for (int j = 0; j < excelHeader.size(); j++) {
					sheet.setColumnWidth(i, 2000);
					Cell cell = dataRow.createCell(j, 0);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(record.getChildTextTrim(excelHeader
							.get(j)));
				}
			}
		}
	}

	/**
	 * @Title: downloadExcel
	 * @Description: ���岽��ͨ��workbook�ṩ��write�������������ɵ�excelд����������
	 * @param workbook
	 * @param outPath
	 * @return: void
	 * @author: zhangdq
	 * @date: 2016��09��09�� 17��13
	 */
	private static void downloadExcel(Workbook workbook, String outPath) {
		OutputStream os = null;
		try {
			os = new FileOutputStream(new File(outPath));
			workbook.write(os);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// �ṩͳһ�Ĺ����ӿڷ���
	public static void createExcelModel(ExcelModel excelModel, String outPath) {
		if (excelModel != null && outPath != null) {
			Workbook workbook = createWorkbookByType(XLS_TYPE);
			Sheet sheet = createSheet(workbook, 0, excelModel.getSheetName());
			CellStyle cellStyleOfHeader = createCellStyleOfHeader(workbook);
			CellStyle cellStyleOfData = createCellStyleOfData(workbook);
			createHeader(sheet, excelModel.getExcelHeader(), cellStyleOfHeader);
			createData(sheet, excelModel.getExcelHeader(),
					excelModel.getExcelData(), cellStyleOfData);
			downloadExcel(workbook, outPath);
		}
	}
}