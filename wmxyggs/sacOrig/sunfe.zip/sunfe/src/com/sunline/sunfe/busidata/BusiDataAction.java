package com.sunline.sunfe.busidata;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jdom.Element;
import org.jdom.JDOMException;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.services.BimisFile;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.util.DatetimeUtil;
import com.sunline.jraf.util.StringUtil;
import com.sunline.suncm.util.ExcelUtil;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.engine.BusiGLDeal;
import com.sunline.sunfe.engine.BusiGLTest;
import com.sunline.sunfe.util.ExportExcel;

/**
 * ��ˮ��׼ ҵ�������ݲ�ѯ�ӿ�
 * 
 * @ClassName: BusiDataAction
 * @author: livejianan
 * @date: 2017-5-9 ����3:40:40
 */
public class BusiDataAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.busidata.";

	
	/**
	 * ������־��ѯ
	 * 
	 * @Title: getEoorLog
	 * @return: void
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void getEoorLog() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req
					.getReqDataMap();
			
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getEoorLog", hashmap);
			req.addRspData(e.removeContent());
		} catch (JDOMException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	/**
	 * ͨ�ý��ײ�ѯ
	 * 
	 * @Title: getLoanBusidata
	 * @return: void
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void getLoanBusidata() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			String trandt = hashmap.get("trandt");
			if(trandt==null || trandt.trim().equals("")){
				trandt = glisdt;
			}
			hashmap.put("trandt", trandt);
			Element e = commonDao
					.queryByNamedSqlWithPage(MYBATIS_NS
							+ "getLoanBusisdatalistPage", req.getReqPageInfo(),
							hashmap);
			req.addRspData(e.removeContent());
			if(hashmap.get("tranbr")!=null && !hashmap.get("tranbr").toString().trim().equals("")){
    			req.addRspData("tranbr",hashmap.get("tranbr"));
    		}
			req.addRspData("glisdt",glisdt);
			req.addRspData("trandt",trandt);
		} catch (JDOMException e) {
			getLog().logError(e);
		}
		
	}

	/**
	 * ͨ��Ԫ���׼���Ӧ��¼��ѯ
	 * @Title: getLoanGlavchr 
	 * @throws BimisException
	 * @return: void
	 */
	@SuppressWarnings("unchecked")
	public void getLoanGlavchr() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			hashmap.put("glisdt", glisdt);
			//Դ��ˮ
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+ "getLoanBusisdata", hashmap);
			String prodcd = e.getChild("Record").getChildText("prodcd");
			String prcscd = e.getChild("Record").getChildText("prcscd");
			String module = e.getChild("Record").getChildText("module");
			req.addRspData(e.removeContent());
			hashmap.put("prcscd", prcscd);
			hashmap.put("module", module);
			Element modudata = commonDao.queryByNamedSql(MYBATIS_NS+"getDataByModule", hashmap);
			req.addRspData("Results4", modudata.removeContent());
			//��¼
			Element vchr = commonDao.queryByNamedSql(MYBATIS_NS+ "getGlavchr", hashmap);
			req.addRspData("Results2", vchr.removeContent());
			hashmap.put("prodcd", prodcd);
			Element dtitconf =commonDao.queryByNamedSql(MYBATIS_NS+"queryProdDtitInfo", hashmap);
			req.addRspData("Results3", dtitconf.removeContent());

		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}
	 
	/**
	 * ����ҵ��Ԫ���ײ�ѯ
	 * 
	 * @Title: getLoanBusidata
	 * @Description: TODO
	 * @return: void
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void getLanBusidata() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req
					.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			String trandt = hashmap.get("trandt");
			if(trandt==null || trandt.trim().equals("")){
				trandt = glisdt;
			}
			hashmap.put("trandt", trandt);
			Element e = commonDao
					.queryByNamedSqlWithPage(MYBATIS_NS
							+ "getLanBusisdatalistPage", req.getReqPageInfo(),
							hashmap);
			req.addRspData(e.removeContent());
			if(hashmap.get("tranbr")!=null && !hashmap.get("tranbr").toString().trim().equals("")){
    			req.addRspData("tranbr",hashmap.get("tranbr"));
    		}
			req.addRspData("glisdt",glisdt);
			req.addRspData("trandt",trandt);
		} catch (JDOMException e) {
			// TODO Auto-generated catch block
			getLog().logError(e);
		}
	}

	/**
	 * ����ҵ��Ԫ���׼���Ӧ��¼��ѯ
	 * @Title: getLoanGlavchr 
	 * @Description: TODO
	 * @throws BimisException
	 * @return: void
	 */
	public void getLanGlavchr() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			hashmap.put("glisdt", glisdt);
			Element e = commonDao.queryByNamedSql(MYBATIS_NS
					+ "getLanBusisdata", hashmap);
			String prodcd = e.getChild("Record").getChildText("prodcd");
			req.addRspData(e.removeContent());
			Element vchr = commonDao.queryByNamedSql(MYBATIS_NS
					+ "getGlavchr", hashmap);
			req.addRspData("Results2", vchr.removeContent());
			hashmap.put("prodcd", prodcd);
			Element dtitconf =commonDao.queryByNamedSql(MYBATIS_NS+"queryProdDtitInfo", hashmap);
			req.addRspData("Results3", dtitconf.removeContent());

		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}
	
	
	
	
	
	

	/**
	 * ǰ̨��ǩ sc:optd ͨ����Ʒ�����ȡ��Ʒ��
	 * @Title: getProna 
	 * @throws JDOMException
	 * @throws BimisException
	 * @return: void
	 */
	public void getProna() throws JDOMException, BimisException{
		String prodcd = req.getReqDataStr("prodcd");
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put("prodcd", prodcd);
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getProductName",hs);
			req.addRspData(e.removeContent());// ���ؽ����װ
	}
	
	public void getProperty() throws JDOMException, BimisException{
			String loanp = req.getReqDataStr("loanp");
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put("loanp", loanp);
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getProperty",hs);
			req.addRspData(e.removeContent());// ���ؽ����װ
	}
	
	public void getGroup() throws JDOMException, BimisException{
		String param = req.getReqDataStr("param");
			HashMap<String, String> hs = new HashMap<String, String>();
			hs.put("param", param);
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getGroup",hs);
			req.addRspData(e.removeContent());// ���ؽ����װ
	}
	
	@SuppressWarnings("unchecked")
	public void groupProperty1() throws JDOMException, BimisException{
			HashMap<String, String> hs = (HashMap<String, String>) req.getReqDataMap();
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getProperty1",hs);
			req.addRspData(e.removeContent());// ���ؽ����װ
	}
	@SuppressWarnings("unchecked")
	public void groupProperty2() throws JDOMException, BimisException{
			HashMap<String, String> hs = (HashMap<String, String>) req.getReqDataMap();
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getProperty2",hs);
			req.addRspData(e.removeContent());// ���ؽ����װ
	}
	@SuppressWarnings("unchecked")
	public void groupProperty3() throws JDOMException, BimisException{
			HashMap<String, String> hs = (HashMap<String, String>) req.getReqDataMap();
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getProperty3",hs);
			req.addRspData(e.removeContent());// ���ؽ����װ
	}
	@SuppressWarnings("unchecked")
	public void groupProperty4() throws JDOMException, BimisException{
			HashMap<String, String> hs = (HashMap<String, String>) req.getReqDataMap();
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getProperty4",hs);
			req.addRspData(e.removeContent());// ���ؽ����װ
	}
	@SuppressWarnings("unchecked")
	public void groupProperty9() throws JDOMException, BimisException{
			HashMap<String, String> hs = (HashMap<String, String>) req.getReqDataMap();
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getProperty9",hs);
			req.addRspData(e.removeContent());// ���ؽ����װ
	}
	@SuppressWarnings("unchecked")
	public void groupPropertya() throws JDOMException, BimisException{
			HashMap<String, String> hs = (HashMap<String, String>) req.getReqDataMap();
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getPropertya",hs);
			req.addRspData(e.removeContent());// ���ؽ����װ
	}
	public void groupProperty() throws JDOMException, BimisException{
		Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getProperty",req.getReqDataStr("property"));
		req.addRspData(e.removeContent());// ���ؽ����װ
}
	
	/**
	 * ƾ֤����
	 * 
	 * @Title: getVchBusidata
	 * @Description: 
	 * @return: void
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void getVchBusidata() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			String trandt = hashmap.get("trandt");
			if(trandt==null || trandt.trim().equals("")){
				trandt = glisdt;
			}
			hashmap.put("trandt", trandt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getVchBusisdatalistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			if(hashmap.get("tranbr")!=null && !hashmap.get("tranbr").toString().trim().equals("")){
    			req.addRspData("tranbr",hashmap.get("tranbr"));
    		}
			req.addRspData("glisdt",glisdt);
			req.addRspData("trandt",trandt);
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	@SuppressWarnings("unchecked")
	public void getVchGlavchr() throws BimisException {
		try {
			String stacid = SessionParaUtils.getStacid();
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("glisdt", glisdt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getVchBusisdata", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			Element vchr = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getGlavchr", req.getReqPageInfo(), hashmap);
			req.addRspData("Results2", vchr.removeContent());

		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	public void getIvtBusidata() throws BimisException {
		try {
			@SuppressWarnings("unchecked")
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			String trandt = hashmap.get("trandt");
			if(trandt==null || trandt.trim().equals("")){
				trandt = glisdt;
			}
			hashmap.put("trandt", trandt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getIvtBusisdatalistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			if(hashmap.get("tranbr")!=null && !hashmap.get("tranbr").toString().trim().equals("")){
    			req.addRspData("tranbr",hashmap.get("tranbr"));
    		}
			req.addRspData("glisdt",glisdt);
			req.addRspData("trandt",trandt);
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	@SuppressWarnings("unchecked")
	public void getIvtGlavchr() throws BimisException {

		try {
			String stacid = SessionParaUtils.getStacid();
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("glisdt", glisdt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getIvtBusisdata", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			Element vchr = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getGlavchr", req.getReqPageInfo(), hashmap);
			req.addRspData("Results2", vchr.removeContent());

		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	@SuppressWarnings("unchecked")
	public void getGpvBusidata() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			String trandt = hashmap.get("trandt");
			if(trandt==null || trandt.trim().equals("")){
				trandt = glisdt;
			}
			hashmap.put("trandt", trandt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getGpvBusisdatalistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			if(hashmap.get("tranbr")!=null && !hashmap.get("tranbr").toString().trim().equals("")){
    			req.addRspData("tranbr",hashmap.get("tranbr"));
    		}
			req.addRspData("glisdt",glisdt);
			req.addRspData("trandt",trandt);
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	@SuppressWarnings("unchecked")
	public void getGpvGlavchr() throws BimisException {
		try {
			String stacid = SessionParaUtils.getStacid();
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("glisdt", glisdt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getGpvBusisdata", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			Element vchr = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getGlavchr", req.getReqPageInfo(), hashmap);
			req.addRspData("Results2", vchr.removeContent());

		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	@SuppressWarnings("unchecked")
	public void getDepBusidata() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			String trandt = hashmap.get("trandt");
			if(trandt==null || trandt.trim().equals("")){
				trandt = glisdt;
			}
			hashmap.put("trandt", trandt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getDepBusisdatalistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			if(hashmap.get("tranbr")!=null && !hashmap.get("tranbr").toString().trim().equals("")){
    			req.addRspData("tranbr",hashmap.get("tranbr"));
    		}
			req.addRspData("glisdt",glisdt);
			req.addRspData("trandt",trandt);
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	@SuppressWarnings("unchecked")
	public void getDepGlavchr() throws BimisException {
		try {
			String stacid = SessionParaUtils.getStacid();
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("glisdt", glisdt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getDepBusisdata", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			Element vchr = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getGlavchr", req.getReqPageInfo(), hashmap);
			req.addRspData("Results2", vchr.removeContent());

		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	public void getCsaBusidata() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req
					.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			String trandt = hashmap.get("trandt");
			if(trandt==null || trandt.trim().equals("")){
				trandt = glisdt;
			}
			hashmap.put("trandt", trandt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getCsaBusisdatalistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			if(hashmap.get("tranbr")!=null && !hashmap.get("tranbr").toString().trim().equals("")){
    			req.addRspData("tranbr",hashmap.get("tranbr"));
    		}
			req.addRspData("glisdt",glisdt);
			req.addRspData("trandt",trandt);
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	public void getCsaGlavchr() throws BimisException {
		
		try {
			String stacid = SessionParaUtils.getStacid();
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("glisdt", glisdt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getCsaBusisdata", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			Element vchr = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getGlavchr", req.getReqPageInfo(), hashmap);
			req.addRspData("Results2", vchr.removeContent());

		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	public void getBbkBusidata() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req
					.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			String trandt = hashmap.get("trandt");
			if(trandt==null || trandt.trim().equals("")){
				trandt = glisdt;
			}
			hashmap.put("trandt", trandt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getBbkBusisdatalistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			if(hashmap.get("tranbr")!=null && !hashmap.get("tranbr").toString().trim().equals("")){
    			req.addRspData("tranbr",hashmap.get("tranbr"));
    		}
			req.addRspData("glisdt",glisdt);
			req.addRspData("trandt",trandt);
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	public void getBbkGlavchr() throws BimisException {

		try {
			String stacid = SessionParaUtils.getStacid();
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("glisdt", glisdt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getBbkBusisdata", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			Element vchr = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getGlavchr", req.getReqPageInfo(), hashmap);
			req.addRspData("Results2", vchr.removeContent());

		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	public void getAsbBusidata() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req
					.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			String trandt = hashmap.get("trandt");
			if(trandt==null || trandt.trim().equals("")){
				trandt = glisdt;
			}
			hashmap.put("trandt", trandt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getAsbBusisdatalistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			if(hashmap.get("tranbr")!=null && !hashmap.get("tranbr").toString().trim().equals("")){
    			req.addRspData("tranbr",hashmap.get("tranbr"));
    		}
			req.addRspData("glisdt",glisdt);
			req.addRspData("trandt",trandt);
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	public void getAsbGlavchr() throws BimisException {

		try {
			String stacid = SessionParaUtils.getStacid();
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("glisdt", glisdt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getAsbBusisdata", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			Element vchr = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getGlavchr", req.getReqPageInfo(), hashmap);
			req.addRspData("Results2", vchr.removeContent());

		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	@SuppressWarnings("unchecked")
	public void getAfeBusidata() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			String trandt = hashmap.get("trandt");
			if(trandt==null || trandt.trim().equals("")){
				trandt = glisdt;
			}
			hashmap.put("trandt", trandt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getAfeBusisdatalistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			if(hashmap.get("tranbr")!=null && !hashmap.get("tranbr").toString().trim().equals("")){
    			req.addRspData("tranbr",hashmap.get("tranbr"));
    		}
			req.addRspData("glisdt",glisdt);
			req.addRspData("trandt",trandt);
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	@SuppressWarnings("unchecked")
	public void getAfeGlavchr() throws BimisException {

		try {
			String stacid = SessionParaUtils.getStacid();
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("glisdt", glisdt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getAfeBusisdata", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			Element vchr = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getGlavchr", req.getReqPageInfo(), hashmap);
			req.addRspData("Results2", vchr.removeContent());

		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	public void getCmbBusidata() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req
					.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			String trandt = hashmap.get("trandt");
			if(trandt==null || trandt.trim().equals("")){
				trandt = glisdt;
			}
			hashmap.put("trandt", trandt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getCmbBusisdatalistPage", req.getReqPageInfo(), hashmap);
			List<?> liste = e.removeContent();
			req.addRspData(liste);
			/*List<?> list = commonDao.queryByNamedSqlForListWithPage(MYBATIS_NS
					+ "getCmbBusisdatalistPage", req.getReqPageInfo(), hashmap);
			req.addRspData(list);*/
			if(hashmap.get("tranbr")!=null && !hashmap.get("tranbr").toString().trim().equals("")){
    			req.addRspData("tranbr",hashmap.get("tranbr"));
    		}
			req.addRspData("glisdt",glisdt);
			req.addRspData("trandt",trandt);
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}
	
	
	@SuppressWarnings("unchecked")
	public void getCmbPckgdt() throws BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req
					.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			Element e = commonDao.queryByNamedSql(MYBATIS_NS
					+ "getCmbBusisdata", hashmap);
			List<?> liste = e.removeContent();
			req.addRspData(liste);
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}

	public void getCmbGlavchr() throws BimisException {

		try {
			String stacid = SessionParaUtils.getStacid();
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("glisdt", glisdt);
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getCmbBusisdata", req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
			Element vchr = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
					+ "getGlavchr", req.getReqPageInfo(), hashmap);
			req.addRspData("Results2", vchr.removeContent());

		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}
	
	
	/**
	 * @Title: loanBusiAddMain 
	 * @date: 2018��3��31�� ����1:41:19 
	 * @Description: ͨ����ˮ¼�����
	 * @throws BimisException
	 * @return: void
	 */
	@SuppressWarnings("unchecked")
	public void loanBusiAddMain() throws BimisException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			Element e = commonDao.
					queryByNamedSqlWithPage(MYBATIS_NS+ "loanBusiAddMainlistPage", req.getReqPageInfo(),hashmap);
			req.addRspData(e.removeContent());
		} catch (JDOMException e) {
			getLog().logError(e);
		}
	}
	
	/**
	 * @Title: getDataByModule 
	 * @date: 2018��3��31�� ����2:50:45 
	 * @Description:  ѡ���׳�����ϵͳ�Զ����ݽ��׳���ѯ���е����ݽṹ��Ϣ
	 * @throws BimisException
	 * @return: void
	 */
	@SuppressWarnings("unchecked")
	public void getDataByModule() throws BimisException{
		try{
		Map<String, Object> hashMap = req.getReqDataMap();
		Element e = commonDao.queryByNamedSql(MYBATIS_NS+"getDataByModuleExcludPrimeryKey", hashMap);
		req.addRspData(e.removeContent());
	} catch (JDOMException e) {
		getLog().logError(e);
	}
	}
	
	/**
	 * @Title: addLoanBusi 
	 * @date: 2018��3��31�� ����1:43:34 
	 * @Description: ͨ�ý�����ˮ¼��
	 * @throws BimisException
	 * @throws JDOMException
	 * @return: void
	 */
	@SuppressWarnings({ "unchecked"})
	public void addLoanBusi() throws BimisException, JDOMException{
		try{
			HashMap<String, String> hashMap = (HashMap<String, String>) req.getReqDataMap();
			List<HashMap<String,String>> result = getFormData(hashMap);
			commonDao.beginTransaction();
			insertLoanbusi(result);
			commonDao.commitTransaction();
			ResultUtils.setRspData(req, "200",  "�����ɹ�", "loanBusiAddMain", "closeCurrent", "");
		} catch (Exception e) {
			getLog().logError(e);
			commonDao.rollBack();
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ�ܣ�"+e.getMessage());
		}
	}

		/**
		 * @Title: insertLoanbusi 
		 * @date: 2018��4��2�� ����12:50:58 
		 * @Description: ������ˮ����
		 * @param result
		 * @throws BimisException
		 * @return: void
		 */
     @SuppressWarnings({ "rawtypes", "unchecked" })
	private void insertLoanbusi(List<HashMap<String, String>> result) throws BimisException {
         int count = 1;
         String transq = result.get(0).get("transq");
         for (Iterator iterator = result.iterator(); iterator.hasNext();) {
				HashMap<String, String> params = (HashMap<String, String>) iterator.next();
				if(!transq.equals(params.get("transq"))){
					throw new BimisException("-1",  "¼�����ˮ�ű���Ψһ��");
				}
				 if(!StringUtil.isNumber(params.get("trandt"))||params.get("trandt").length() != 8){
					throw new BimisException("-1",  "¼��ĵ�"+count+"���������ڳ��ȱ���Ϊ8λ��");
				}
				//У����ˮΨһ��
				List<HashMap<String,String>> LoanBusi = (List<HashMap<String, String>>) commonDao.queryByNamedSqlForList
						(MYBATIS_NS+"checkLoanBusi",params);
				if(LoanBusi.size()>0){
					throw new BimisException("-1",  "��"+count+"�и���ˮ�Ѵ��ڣ�");
				}
				params.put("bathid", "manual");
				params.put("chrexj", "manual");
				//������ˮ
				HashMap<String,Object> para = new HashMap<String, Object>();
				para.put("loanbusi", params);
				commonDao.insertByNamedSql(MYBATIS_NS+"insertLoanBusi", para);
				count++;
			}
	}



	/**
      * 
      * @Title: getRequiredColumn 
      * @date: 2018��3��31�� ����3:35:47 
      * @Description: ��ѯloan_busi����Ϊ�յ��ֶ�
      * @throws BimisException
      * @return: ArrayList<String>
      */
	@SuppressWarnings("unchecked")
	private ArrayList<String> getRequiredColumn() throws BimisException {
		ArrayList<String>  column = (ArrayList<String>) commonDao.
				   queryByNamedSqlForList(MYBATIS_NS+"getRequiredColumn", null);
		return column;
	}
	
	/**
	 * 
	 * @Title: exportLoanBusiTmpl 
	 * @date: 2018��4��1�� ����11:48:27 
	 * @Description: ����ͨ�ý���ģ��
	 * @return: void
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void exportLoanBusiTmpl() throws JDOMException{
		try {
			Map<String, Object> hashMap = req.getReqDataMap();
			// ͨ�����׳����õ�������ֶ�
			List<HashMap<String,String>> data = (List<HashMap<String, String>>) 
					commonDao.queryByNamedSqlForList(MYBATIS_NS+"getDataByModuleExcludPrimeryKey", hashMap);
			
			String [] rowName = new String[data.size()+3];//���������
			rowName[0] = "��Դϵͳ";
			rowName[1] = "��������";
			rowName[2] = "������ˮ��";
			for(int i = 0; i < data.size();i++){
				HashMap<String, String> temp = data.get(i);
				rowName[i+3] = temp.get("varina");
			}
			String title = "������ˮ����";//sheetҳ����
			
			ExportExcel ex = new ExportExcel(title, rowName, null);
			ex.export();
			req.addRspFilePathName(ex.getFilename(), title+DatetimeUtil.formatDate(new Date(), "yyyyMMddHHmmss")+".xls");
		} catch (Exception e) {
			getLog().logError(e);
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ�ܣ�");
		}
	 }
	
	
	/**
	 * 
	 * @Title: importLoanbusi 
	 * @date: 2018��4��2�� ����12:12:35 
	 * @Description: ����ͨ�ý�����ˮ
	 * @return: void
	 * @throws JDOMException 
	 * @throws IOException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void importLoanbusi() throws JDOMException{
		try {
			//ǰ̨������ģ��ͽ��׳���
			HashMap<String, String> param  = (HashMap<String, String>) req.getReqDataMap();
            Element ele = req.getReqData();
            Element filename = (Element) ele.getChildren("filename").get(0);
            // ���ݿ��е��ļ���־
            String fileid = filename.getAttributeValue("fileid");
            BimisFile file = BimisFile.getInfo(JrafSession.getCurrentRootSession(), Long.parseLong(fileid));// ��ȡ�ļ��������
            InputStream is = file.getFileDataAsStream(); // ����ļ���
            String fileStr = file.getFileExt(); // ��ȡ����Excel�ĺ�׺��
            if (!fileStr.equals("xls") && !fileStr.equals("xlsx")) {// �ļ�����Excel
                req.addRspData("retCode", "300");
                req.addRspData("retMessage", "��ѡ���ʽΪ.xls����.xlsx���ļ�����!");
                return;
            }
            Workbook wbs = null;
            if (fileStr.equals("xls")) {
                wbs = new HSSFWorkbook(is);
            } else if (fileStr.equals("xlsx")) {
                wbs = new XSSFWorkbook(is);
            }
            //���������
            List<String[]> ExcelValue = ExcelUtil.getExcelValue(wbs.getSheetAt(0));
            // ͨ�����׳����õ�������ֶ�
            List<HashMap<String,String>> data = (List<HashMap<String, String>>) 
					commonDao.queryByNamedSqlForList(MYBATIS_NS+"getDataByModuleExcludPrimeryKey", param);
            if(ExcelValue.size() == 0){
            	throw new BimisException("-1",  "�����ģ�岻��Ϊ�գ�");
            }
            if(ExcelValue.get(0).length != data.size()+3 ){
            	throw new BimisException("-1",  "�����ģ������ѡ���׳�����ģ�����ݽṹ��һ�£�");
            }
            //������ֶ������ֶδ���
            String[] rowid = new String[data.size()];
            String[] rowna = new String[data.size()];
            for(int i = 0; i < data.size();i++){
				HashMap<String, String> temp = data.get(i);
				rowna[i] = temp.get("varina");
				rowid[i] = temp.get("varicd");
			}
            //��ˮ���б����ֶ�
            ArrayList<String> requried_chr = getRequiredColumn();
            //��ȡ��������
            String stacid  = SessionParaUtils.getStacid();
            List<HashMap<String,String>> result = new ArrayList<HashMap<String,String>>();
            int j = 1;
            String prcscd = param.get("prcscd");
            for (Iterator iterator = ExcelValue.iterator(); iterator.hasNext();) {
            	 HashMap<String, String> temp = new HashMap<String, String>();
				 String[] rowdata = (String[]) iterator.next();
				 temp.put("systid", rowdata[0]);
				 temp.put("trandt", rowdata[1]);
				 temp.put("transq", rowdata[2]);
				 for ( int i = 0;i < rowid.length; i++) {
		            	temp.put(rowid[i], rowdata[i+3]);
					}
				 temp.put("serino", String.valueOf(j));
				 temp.put("stacid", stacid);
				 temp.put("prcscd", prcscd);
				 if(!StringUtil.isNumber(temp.get("trandt"))||temp.get("trandt").length() != 8){
						throw new BimisException("-1",  "¼��ĵ�"+j+"����ˮ���ںų��ȱ���Ϊ8λ���֣�");
				 }
				 //У������ֶ�
				 for(String key :requried_chr){
						if(!temp.containsKey(key.toLowerCase())){
							throw new BimisException("-1",  "��"+j+"����ˮ���ֶΡ�"+key.toLowerCase()+"������Ϊ�գ�");
						}
				 }
				 result.add(temp);
				 j++;
			}
            commonDao.beginTransaction();
			insertLoanbusi(result);
			commonDao.commitTransaction();
            ResultUtils.setRspData(req, "200",  "�����ɹ�", "loanBusiAddMain", "closeCurrent", result.get(0).get("transq"));
	  }catch(Exception e){
		  commonDao.rollBack();
		  getLog().logError(e);  
		  req.addRspData("retCode", "300");
		  req.addRspData("retMessage", "����ʧ�ܣ�"+e.getMessage());
	  }
	 }
	
	/**
	 * 
	 * @Title: testLoanbusi 
	 * @date: 2018��4��2�� ����1:05:15 
	 * @Description: ���Խ�����ˮ�ܷ���ȷ����
	 * @return: void
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void loanbusiDeal() throws JDOMException{
		try {
			HashMap<String,String>  param = (HashMap<String, String>) req.getReqDataMap();
			List<HashMap<String,String>> result = getFormData(param);
			String transq = result.get(0).get("transq");
			for (Iterator iterator = result.iterator(); iterator.hasNext();) {
				HashMap<String, String> hashMap = (HashMap<String, String>) iterator.next();
				if(!hashMap.get("transq").equals(transq)){
					throw new BimisException("-1",  "¼�����ˮ�ű���Ψһ��");
				}
			}
			String bussinessInfo =  JSON.toJSONString(result,
					SerializerFeature.DisableCircularReferenceDetect);
			String action = param.get("action");
			String resultconde = "";
			String status = "";
			String retCode = "";
			String retMessage = "";
			if(action.equals("test")){
				//��ȡ�������������Է���
				BusiGLTest service = new BusiGLTest();
				//���û��������������ˮ
				resultconde = service.exec(bussinessInfo);
				JSONObject response = JSONObject.parseObject(resultconde);
				if(!response.containsKey("errcode")){
					resultconde = "EXE0000";
				}else{
					resultconde = response.getString("errmsg");
				}
			}else if(action.equals("deal")){
				BusiGLTest service = new BusiGLTest();
				//���û��������������ˮ�ܷ�����ɹ�,�ɹ���������ˮ�����ݿ⣬�ύ����������
				resultconde = service.exec(bussinessInfo);
				JSONObject response = JSONObject.parseObject(resultconde);
				if(!response.containsKey("errcode")){
					resultconde = "EXE0000";
					//��ȡ������������������
					BusiGLDeal servicedeal = new BusiGLDeal();
					//���û��������������ˮ
					servicedeal.exec(bussinessInfo);
					//����Ϊ�ύ���ҽ����ɹ�ʱ�����������
					insertLoanbusi(result);
				}else{
					resultconde = response.getString("errmsg");
				}
			}
			if (!resultconde.startsWith("EXE0000")) {
				 status = "2";
				 retCode = "300";
				 retMessage = "����ʧ�ܣ�"+resultconde;
			}else{
				 status = "1";
				 retCode = "200";
				 retMessage = "�����ɹ�";
			}
			HashMap<String,String> updatemp = result.get(0);
			updatemp.put("status", status);
			commonDao.beginTransaction();
			commonDao.updateByNamedSql(MYBATIS_NS+"updateLoanBusiStatus", updatemp);
			commonDao.commitTransaction();
			ResultUtils.setRspData(req, retCode, retMessage, "loanBusiAddMain", "", "");
		} catch (Exception e) {
			  commonDao.rollBack();
			  getLog().logError(e);  
			  req.addRspData("retCode", "300");
			  req.addRspData("retMessage", "����ʧ��:"+e.getMessage());
		}
		
	}

	/**
	 * @Title: testLoanbusi 
	 * @date: 2018��4��2�� ����1:05:15 
	 * @Description: ���Խ�����ˮ�ܷ���ȷ����
	 * @return: void
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void loanbusiDealSingle() throws JDOMException{
		try {
			//��ȡ��������
			HashMap<String,String>  param = (HashMap<String, String>) req.getReqDataMap();
			List<HashMap<String,String>> result_temp =  (List<HashMap<String, String>>) 
					commonDao.queryByNamedSqlForList(MYBATIS_NS+"getLoanBusiDetail", param);
			
			List<HashMap<String,Object>> result = new ArrayList<HashMap<String,Object>>();
			//ת��ΪСд
			for (Iterator iterator = result_temp.iterator(); iterator.hasNext();) {
				HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
				HashMap<String, Object> newMap  = new HashMap<String, Object>();
				 Iterator iter = hashMap.entrySet().iterator();
				    while (iter.hasNext()) {
				        Map.Entry entry = (Map.Entry) iter.next();
				        String key = (String) entry.getKey();
				        newMap.put(key.toLowerCase(), entry.getValue());
				    }
			   result.add(newMap); 
			}
			String bussinessInfo =  JSON.toJSONString(result,
					SerializerFeature.DisableCircularReferenceDetect);
			param.put("bussinessInfo", bussinessInfo);
			HashMap<String,String> resultMap = loanbusiExec(param);
			HashMap<String,Object> updatemp = result.get(0);
			updatemp.put("status", resultMap.get("status"));
			commonDao.beginTransaction();
			commonDao.updateByNamedSql(MYBATIS_NS+"updateLoanBusiStatus", updatemp);
			commonDao.commitTransaction();
			ResultUtils.setRspData(req, resultMap.get("retCode"),  resultMap.get("retMessage"), "loanBusiAddMain", "", "");
		} catch (Exception e) {
			 commonDao.rollBack();
			 getLog().logError(e);  
			 req.addRspData("retCode", "300");
			 req.addRspData("retMessage", "����ʧ�ܣ�");
		}
		
	}

	
	/**
	 * @Title: loanbusiExec 
	 * @date: 2018��4��9�� ����7:26:36 
	 * @Description: ���û�������������
	 * @param param
	 * @throws BimisException
	 * @return: HashMap<String,String> �������
	 */
	private HashMap<String, String> loanbusiExec(HashMap<String, String> param) throws BimisException {
		String action = param.get("action");
		String bussinessInfo = param.get("bussinessInfo");
		String resultconde = "";
		String status = "";
		String retCode = "";
		String retMessage = "";
		HashMap<String ,String> resultmap = new HashMap<String, String>();
		if(action.equals("test")){
			//��ȡ�������������Է���
			BusiGLTest service = new BusiGLTest();
			//���û��������������ˮ
			resultconde = service.exec(bussinessInfo);
			JSONObject response = JSONObject.parseObject(resultconde);
			if(!response.containsKey("errcode")){
				resultconde = "EXE0000";
			}else{
				resultconde = response.getString("errmsg");
			}
		}else if(action.equals("deal")){
			//��ȡ������������������
			BusiGLDeal service = new BusiGLDeal();
			//���û��������������ˮ
			resultconde = service.exec(bussinessInfo);
		}
		if (!resultconde.startsWith("EXE0000")) {
			 status = "2";
			 retCode = "300";
			 retMessage = "����ʧ�ܣ�"+resultconde;
		}else{
			 status = "1";
			 retCode = "200";
			 retMessage = "�����ɹ�";
		}
		resultmap.put("retCode", retCode);
		resultmap.put("retMessage", retMessage);
		resultmap.put("status", status);
		return resultmap;
		
	}

	/**
	 * 
	 * @Title: getFormData 
	 * @date: 2018��4��2�� ����1:09:56 
	 * @Description: ��ȡ��������
	 * @param param
	 * @throws Exception
	 * @return: List<HashMap<String,String>>
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private List<HashMap<String,String>> getFormData(HashMap<String,String> param) throws Exception{
		//����ˮ�������ֶ�
		ArrayList<String> requried_chr = getRequiredColumn();
		List<String> index = req.getReqDataTexts("tr_index");
		String prcscd = param.get("prcscd");
		//���ݽ��׳���ѯ���е����ݽṹ��Ϣ
		List<HashMap<String,String>> e = (List<HashMap<String, String>>) commonDao.queryByNamedSqlForList
							(MYBATIS_NS+"getDataByModuleExcludStacid",param);
		//ǰ̨¼����������ݽ����
		List<HashMap<String,String>> result = new ArrayList<HashMap<String,String>>();
		HashMap<String, String> varina = new HashMap<String, String>();
		String stacid = SessionParaUtils.getStacid();
		for (int i = 1; i < index.size(); i++) {
			HashMap<String, String> paramMap = new HashMap<String, String>();
			for (Iterator iterator = e.iterator(); iterator.hasNext();) {
				HashMap<String, String> dataMap = (HashMap<String, String>) iterator.next();
				String key = dataMap.get("varicd");
				String value  = param.get("varicd_"+key+"_"+index.get(i));
				if(!StringUtil.isNullOrEmpty(value)){
					paramMap.put(key, value);
				}
				varina.put(key, dataMap.get("varina"));
			}
			paramMap.put("transq", param.get("varicd_transq_"+index.get(i)));
			paramMap.put("systid", param.get("varicd_systid_"+index.get(i)));
			paramMap.put("trandt", param.get("varicd_trandt_"+index.get(i)));
			paramMap.put("serino", index.get(i));//���
			paramMap.put("prcscd", prcscd);
			paramMap.put("stacid", stacid);
			for(String key :requried_chr){
				if(!paramMap.containsKey(key.toLowerCase())){
					throw new BimisException("-1",  "��"+i+"����ˮ���ֶΡ�"+key.toLowerCase()+"������Ϊ�գ�");
				}
			}
			result.add(paramMap);
		}
		return  result;
	}
	
	/**
	 * 
	 * @Title: deleteLoanBusi 
	 * @date: 2018��4��2�� ����5:25:07 
	 * @Description: ɾ���ֹ�¼��Ľ�����ˮ
	 * @return: void
	 * @throws JDOMException 
	 */
	@SuppressWarnings("rawtypes")
	public void deleteLoanBusi() throws JDOMException{
		try {
			List<String> loans = req.getReqDataTexts("loans");
			commonDao.beginTransaction();
			for (Iterator iterator = loans.iterator(); iterator.hasNext();) {
				HashMap<String, String> paramMap = new HashMap<String, String>();
				String loan = (String) iterator.next();
				String [] loan_key = loan.split("-");
				paramMap.put("stacid", SessionParaUtils.getStacid());
				paramMap.put("systid", loan_key[1]);
				paramMap.put("trandt", loan_key[2]);
				paramMap.put("transq", loan_key[3]);
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteLoanBusi", paramMap);
			}
			commonDao.commitTransaction();
			ResultUtils.setRspData(req, "200",  "�����ɹ�", "loanBusiAddMain", "", "");
		} catch (Exception e) {
			 commonDao.rollBack();
			 getLog().logError(e);  
			 req.addRspData("retCode", "300");
			 req.addRspData("retMessage", "����ʧ�ܣ�");
		}
	}
}
