package com.sunline.sunfe.base;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.sunfe.util.StringUtils;
public class BeanAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.bean.";
	Log  log = new Log("BeanAction");
 /**
  * ��ѯ���̶����б�	
  */
 @SuppressWarnings("unchecked")
public void queryBeanListPage(){
	try {
		HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();;
		hashmap.put("vermod", "0");//Ĭ�ϲ�ѯ���°汾����
		hashmap.put("beanid",  StringUtils.repalceCharecter(hashmap.get("beanid")));
		Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryBeanlistPage",req.getReqPageInfo(), hashmap);
		req.addRspData(ement.removeContent());
	} catch (JDOMException e) {
		log.logError(e);
	}
  }	
 
  /**
   * ����ID��ѯ��������
   */
  public void queryBeanInfo(){
	 try {
		 HashMap<String, String> hashmap = new HashMap<String, String>();
		 hashmap.put("beanid", req.getReqDataStr("beanid"));
		 hashmap.put("vermod", "0");
		 hashmap.put("projcd", req.getReqDataStr("projcd"));
		 Element ement =commonDao.queryByNamedSql(MYBATIS_NS+"queryBeanInfo", hashmap);
		 req.addRspData(ement.removeContent());
	 } catch (Exception e) {
		 log.logError(e);
	 }
 }	
	
/**
 * �������̶���
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public void addBean(){
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			//���ݹ��̶������beanid���ж�,�Ƿ����д��ڵĹ��̶���
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistBean", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "���̶������Ѵ��ڣ�");
					return;
				}
			}
			    commonDao.insertByNamedSql(MYBATIS_NS+"addBean",hashmap);
			    ResultUtils.setRspData(req, "200", "�����ɹ�", "bean_main","closeCurrent");
				commonDao.commitTransaction();
			} catch (Exception e) {
			    ResultUtils.setRspData(req, "300", "����ʧ��", "","");
				commonDao.rollBack();
				log.logError(e);
		  }
      }	
  /**
   * ���¹��̶���
   * @throws JDOMException 
   */
  @SuppressWarnings("unchecked")
public void updateBean() throws JDOMException{
	  try {
		  HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
		    commonDao.beginTransaction();
		    commonDao.updateByNamedSql(MYBATIS_NS+"updateBean", hashmap);
		    hashmap.put("vermod", "0");
		    commonDao.insertByNamedSql(MYBATIS_NS+"addBean",hashmap);
			commonDao.commitTransaction();
		    ResultUtils.setRspData(req, "200", "�����ɹ�", "bean_main","closeCurrent","","");
		} catch (BimisException e) {
			commonDao.rollBack();
			log.logError(e);
			ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "bean_main","","");
		}
    }	
    
    /**
     * ɾ��ҵ����̶���
     * @throws JDOMException 
     */
	@SuppressWarnings("rawtypes")
	public void deleteBean() throws JDOMException{
		try {
			List<String> beanidList = req.getReqDataTexts("beanids");
			if (beanidList != null && beanidList.size() > 0) {
				commonDao.beginTransaction();
				for (Iterator iterator = beanidList.iterator(); iterator.hasNext();) {
				HashMap<String,String> hashmap = new HashMap<String, String>();
					String string = (String) iterator.next();
					hashmap.put("beanid", string.split("-")[0].trim());
					hashmap.put("projcd", string.split("-")[1].trim());
					commonDao.deleteByNamedSql(MYBATIS_NS+"deleteBean", hashmap);
				}
				}
				commonDao.commitTransaction();
			    ResultUtils.setRspData(req, "200", "�����ɹ�", "bean_main","","");
		} catch (BimisException e) {
				commonDao.rollBack();
				ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "bean_main","","");
				log.logError(e);
		}
	}
}
