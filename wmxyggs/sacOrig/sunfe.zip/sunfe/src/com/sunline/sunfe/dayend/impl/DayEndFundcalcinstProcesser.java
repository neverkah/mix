package com.sunline.sunfe.dayend.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sunline.jraf.BimisException;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.Sequence;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.suncm.util.StringUtils;
import com.sunline.sunfe.core.bean.ComBrchBean;
import com.sunline.sunfe.core.bean.GlaAeuvBean;
import com.sunline.sunfe.dayend.IDayEndProcesser;
import com.sunline.sunfe.entity.ComBrch;
import com.sunline.sunfe.entity.FmsInst;
import com.sunline.sunfe.entity.GlaAeuv;
import com.sunline.sunfe.glisfund.GlisfundManage;
import com.sunline.sunfe.glisfund.PublicFmbCntrInfoUtil;
import com.sunline.sunfe.util.ClpConfUtil;
import com.sunline.sunfe.util.PkgUtil;

/**
 * @ClassName: DayEndFundcalcinstProcesser
 * @Description: �ʽ��ͬ��Ϣ
 * @author: huangzhongjie
 * @date: 2018��1��11�� ����1:57:50
 */
public class DayEndFundcalcinstProcesser extends IDayEndProcesser {
	private  Log log = LogFactory.getLog(DayEndFundcalcinstProcesser.class);
	private PublicFmbCntrInfoUtil fmbCntrInfoUtil;

	@Override
	public void preProcess() throws BimisException {
		getCommonDao();
		fmbCntrInfoUtil = new PublicFmbCntrInfoUtil(commonDao);
	}

	@Override
	public void processing() throws BimisException {
		try {
			commonDao.beginTransaction();
			fundcalcinst();
			commonDao.commitTransaction();
		} catch (Exception e) {
			log.error(e);
			commonDao.rollBack();
			throw new BimisException("-1", "�����ʽ��ͬ��Ϣ����" + e.getMessage());
		} finally {
			closeSession();
		}

	}

	private void fundcalcinst() throws Exception {
		String pi_Pckgdt = getPram();
		String l_Stacid = null;
		String l_User_Brchcd = null;

		String l_Tranus = null;

		if (StringUtils.isNotEmpty(pi_Pckgdt)) {
			l_Stacid = PkgUtil.getPkgstr(pi_Pckgdt, "user_stacid");
			l_User_Brchcd = PkgUtil.getPkgstr(pi_Pckgdt, "user_brchcd");
			l_Tranus = PkgUtil.getPkgstr(pi_Pckgdt, "user_usercd");
		} else {
			l_Stacid = SessionParaUtils.getStacid();
			l_User_Brchcd = SessionParaUtils.getDeptcd();
			l_Tranus = SessionParaUtils.getUsercd();
		}

		int stacid = Integer.valueOf(l_Stacid);
		String glisdt = PubUtil.getGlisdt(Integer.valueOf(l_Stacid));
		if (!fmbCntrInfoUtil.isNormalDay(l_Stacid, glisdt)) {
			return;
		}
		String l_Prcscd = "gls_fndclin";
		String l_Acetna = fmbCntrInfoUtil.prcsnaInfo(stacid, l_Prcscd).get("functx").toString();

		Map mapParam = new HashMap();

		mapParam.put("transt", "2");
		mapParam.put("matudt", glisdt);

		List<Map> lstFmbCntr = commonDao.getSqlSession().selectList("com.sunline.sunfe.mybatis.fmbcntr.queryFmbCntrInterest", mapParam);

		for (Map map : lstFmbCntr) {
			String brchno = map.get("brchno").toString();
			ComBrch comBrch = ComBrchBean.getComBrchAcctByPrimaryKey(stacid, brchno);


			// ��ͬ����
			String cntrtp = map.get("cntrtp").toString();

			// ��ͬ���
			String cntrcl = map.get("cntrcl").toString();

			// ����
			String crcycd = map.get("crcycd").toString();
			
			// �ϼ���������
			String upprbr = ClpConfUtil.getClerBrch(stacid, brchno,crcycd);
			
			// ��ͬ��
			String cntrno = map.get("cntrno").toString();

			// ����
			String termcd = map.get("termcd").toString();

			// ���
			BigDecimal cntrbl = new BigDecimal(map.get("cntrbl").toString());

			// ִ������
			BigDecimal instrt = new BigDecimal(map.get("instrt").toString());

			// ��Ϣ���
			BigDecimal instam = new BigDecimal(map.get("instam").toString());

			// ��Ϣ����
			String bgindt = map.get("bgindt").toString();

			if (instam.compareTo(BigDecimal.ZERO) > 0) {
				// ������ˮ
				Sequence sequence = SequenceUtils.createSequence(l_Stacid, glisdt, "bsnssq", brchno, l_Tranus, 1);

				String soursq = sequence.getSqueno();

				// �Ǽ�gla_aeuv
				GlaAeuv glaAeuv = new GlaAeuv();

				glaAeuv.setStacid(stacid);
				glaAeuv.setSourst("90");
				glaAeuv.setSourdt(glisdt);
				glaAeuv.setSoursq(soursq);
				glaAeuv.setTranbr(upprbr); // ��������Ϊ���׻���
				glaAeuv.setAcetna(l_Acetna);
				glaAeuv.setUsercd(l_Tranus);
				glaAeuv.setPrcscd(l_Prcscd);
				glaAeuv.setTrantp("2");// ϵͳ��
				glaAeuv.setTranst("0");
				glaAeuv.setStrkst("0");

				GlaAeuvBean.saveGlaAeuv(commonDao, glaAeuv);

				// ����
				String transq = fmbCntrInfoUtil.fundCmbk(stacid, glaAeuv.getSourst(), glaAeuv.getSourdt(), soursq, brchno, upprbr, cntrtp,
						cntrtp + "D", crcycd, instam, BigDecimal.ZERO, BigDecimal.ZERO, cntrno);

				// �Ǽ��ڲ��ʽ���Ϣ�ǼǱ�
				FmsInst fmsInst = new FmsInst();
				fmsInst.setStacid(stacid);
				fmsInst.setTrandt(glisdt);
				fmsInst.setTransq(transq);
				fmsInst.setInsttp(cntrtp);
				fmsInst.setBrchno(brchno);
				fmsInst.setCntrno(cntrno);
				fmsInst.setCrcycd(crcycd);
				fmsInst.setInrttp(cntrcl);
				fmsInst.setTermcd(termcd);
				fmsInst.setBgindt(bgindt);
				fmsInst.setAcmlbl(cntrbl);
				fmsInst.setInrtrt(instrt);
				fmsInst.setInstam(instam);
				GlisfundManage.registerAcpt(commonDao, glisdt, fmsInst);
			}

		}
	}

	@Override
	public void processed() throws BimisException {

	}

}
