package com.sunline.sunfe.base;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.sunfe.util.StringUtils;
public class IntfAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.intf.";
	Log log = new Log("IntfAction");
	/**
	 * ��ѯ�ӿ��嵥 & queryIntfListPage
	 */
	public void queryIntfListPage(){
		try {
			@SuppressWarnings("unchecked")
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("intfcd",  StringUtils.repalceCharecter(hashmap.get("intfcd")));
			hashmap.put("vermod", "0");
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryIntflistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			log.logError(e);
		}
	}
	/**
	 * ���ݽӿڴ���intfcd���ҽӿ���Ϣ
	 */
	public void queryIntfById()  //06����id��  �� ��¼
	{
		try 
		{
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String intfcd = req.getReqDataStr("intfcd");
			hashmap.put("intfcd", intfcd);
			hashmap.put("vermod", "0");
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryIntfById", hashmap);	
            req.addRspData(e.removeContent());        //���ؽ����װ	
            Element templateEle = commonDao.queryByNamedSql(MYBATIS_NS+"queryIntfDetlByIntfcd",hashmap);
            req.addRspData("Results2",templateEle.removeContent());   //���ؽ����װ
		} catch (Exception e) {
			log.logError(e);
		}
	 }	
	/**
	 * �����ӿڶ�����Ϣ & addIntf
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void addIntf() throws JDOMException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap(); //��
			HashMap<String, String> hashmap2 = new HashMap<String, String>();  //��
			commonDao.beginTransaction();
			List<String> inottg_list = req.getReqDataTexts("inottg");
			List<String> fildlv_list = req.getReqDataTexts("fildlv");
			List<String> fildcd_list = req.getReqDataTexts("fildcd");
			List<String> fildna_list = req.getReqDataTexts("fildna");
			List<String> fenname_list = req.getReqDataTexts("fenname");
			List<String> nulflg_list = req.getReqDataTexts("nulflg");
			List<String> dftval_list = req.getReqDataTexts("dftval");
			List<String> tagcds_list = req.getReqDataTexts("tagcds");
			List<String> fdesctx_list = req.getReqDataTexts("fdesctx");
			
			//���ݽӿڴ���intfcd���ж�,�Ƿ����д��ڵĽӿڶ���
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistIntf", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "�ӿڴ����Ѵ��ڣ�");
					return;
				}
			}
			int result = commonDao.insertByNamedSql(MYBATIS_NS+"addIntf",hashmap);
		    if(fildcd_list.size()>0&&fildcd_list!=null){
				   
		    	for(int i=0;i<fildcd_list.size();i++){
					   hashmap2.clear();
					   String fildcd = fildcd_list.get(i);
					   if(!"".equals(fildcd)&&fildcd!=null){
						   hashmap2.put("fildcd", fildcd);
						   hashmap2.put("vermod", "0");
						   hashmap2.put("module", hashmap.get("module"));
						   hashmap2.put("projcd", hashmap.get("projcd"));
						   hashmap2.put("intfcd", hashmap.get("intfcd"));
						   hashmap2.put("inottg", inottg_list.get(i));
						   hashmap2.put("fildlv", fildlv_list.get(i));
						   hashmap2.put("fildna", fildna_list.get(i));
						   hashmap2.put("fenname", fenname_list.get(i));
						   hashmap2.put("nulflg", nulflg_list.get(i));
						   hashmap2.put("dftval", dftval_list.get(i));
						   hashmap2.put("tagcds", tagcds_list.get(i));
						   hashmap2.put("fdesctx", fdesctx_list.get(i));
						 //�����ֶ���fildcd���ж�,�Ƿ����д��ڵĽӿ���ϸ����
							List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistIntfDetl", hashmap2);
							if(sumList!=null && sumList.size()>0) {
								Map sumMap = (HashMap)sumList.get(0);
								int sum = Integer.valueOf(sumMap.get("CC").toString());
								if(sum > 0) {
									req.addRspData("retCode", "300");
									req.addRspData("retMessage", "�ֶ����Ѵ��ڣ�");
									return;
								}
							}
						   result = commonDao.insertByNamedSql(MYBATIS_NS+"insertIntfDetl", hashmap2);
					   }
				   }
			   }
			   if(result > 0){
				   ResultUtils.setRspData(req, "200", "�����ɹ�", "intf_main", "closeCurrent", "");
				   commonDao.commitTransaction();
			   }else{
				   ResultUtils.setRspData(req, "300", "����ʧ��", "", "", "");
			   }
			} catch (BimisException e) {
				   ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "", "", "");
				   log.logError(e);
		  }
	}
	
	/**
	 * �޸Ľӿڶ�����Ϣ & updateIntf
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void updateIntf() throws JDOMException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			HashMap<String, String> hashmap2 = new HashMap<String, String>();
			HashMap<String, String> hashmap3 = new HashMap<String, String>();
			commonDao.beginTransaction();
			
			List<String> inottg_list = req.getReqDataTexts("inottg");
			List<String> fildlv_list = req.getReqDataTexts("fildlv");
			List<String> fildcd_list = req.getReqDataTexts("fildcd");
			List<String> fildna_list = req.getReqDataTexts("fildna");
			List<String> fenname_list = req.getReqDataTexts("fenname");
			List<String> nulflg_list = req.getReqDataTexts("nulflg");
			List<String> dftval_list = req.getReqDataTexts("dftval");
			List<String> tagcds_list = req.getReqDataTexts("tagcds");
			List<String> fdesctx_list = req.getReqDataTexts("fdesctx");
			
//			ԭ��¼�汾�ż�1������һ���汾Ϊ0�ļ�¼
			int result = commonDao.updateByNamedSql(MYBATIS_NS+"updateIntf", hashmap);//���½ӿڶ�����Ϣ
			hashmap.put("vermod", "0");
			commonDao.insertByNamedSql(MYBATIS_NS+"addIntf",hashmap);

			commonDao.updateByNamedSql(MYBATIS_NS+"updateIntfDetl", hashmap);
			
			hashmap3.put("intfcd", hashmap.get("intfcd")); 
			
			if(fildcd_list.size()>0&&fildcd_list!=null){
			    	for(int i=0;i<fildcd_list.size();i++){
						   hashmap2.clear();
						   String fildcd = fildcd_list.get(i);
						   if(!"".equals(fildcd)&&fildcd!=null){
							   hashmap2.put("fildcd", fildcd);
							   hashmap2.put("vermod", "0");
							   hashmap2.put("module", hashmap.get("module"));
							   hashmap2.put("projcd", hashmap.get("projcd"));
							   hashmap2.put("intfcd", hashmap.get("intfcd"));
							   hashmap2.put("inottg", inottg_list.get(i));
							   hashmap2.put("fildlv", fildlv_list.get(i));
							   hashmap2.put("fildna", fildna_list.get(i));
							   hashmap2.put("fenname", fenname_list.get(i));
							   hashmap2.put("nulflg", nulflg_list.get(i));
							   hashmap2.put("dftval", dftval_list.get(i));
							   hashmap2.put("tagcds", tagcds_list.get(i));
							   hashmap2.put("fdesctx", fdesctx_list.get(i));
							   //��ɾ��  ����������    ---������ͬ���޸�  ��ͬ�Ͳ���
							   List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistIntfDetl", hashmap2);
								if(sumList!=null && sumList.size()>0) {
									Map sumMap = (HashMap)sumList.get(0);
									int sum = Integer.valueOf(sumMap.get("CC").toString());
									if(sum > 0) {
										commonDao.rollBack();
										req.addRspData("retCode", "300");
										req.addRspData("retMessage", "�ֶ����Ѵ��ڣ�");
										return;
									}
								}
							   result = commonDao.insertByNamedSql(MYBATIS_NS+"insertIntfDetl", hashmap2);
						   }
				   }
			 }
			 if(result > 0){
				   ResultUtils.setRspData(req, "200", "�����ɹ�", "", "closeCurrent", "");
				   commonDao.commitTransaction();
			   }else{
				   ResultUtils.setRspData(req, "300", "����ʧ��", "", "", "");
			   }
		} catch (BimisException e) {
				commonDao.rollBack();
			    ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "", "", "");
			    log.logError(e);
		}
	}
	
	/**
	 * ɾ���ӿ���Ϣ & deleteIntf
	 * @throws JDOMException 
	 */
	public void deleteIntf() throws JDOMException{
		try {
			List<String> intfcdList = req.getReqDataTexts("intfcds");
			commonDao.beginTransaction();
			if (intfcdList != null && intfcdList.size() > 0) {
				HashMap<String, List<String>> hashmap = new HashMap<String, List<String>>();
				hashmap.put("intfcdList", intfcdList);
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteIntfDetl", hashmap);//ɾ���ӿ���ϸ������Ϣ
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteIntf", hashmap);//ɾ���ӿڶ�����Ϣ
				}
				commonDao.commitTransaction();
			ResultUtils.setRspData(req, "200", "�����ɹ�", "intf_main", "", "");
		} catch (BimisException e) {
				commonDao.rollBack();
			    ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "intf_main", "", "");
			    log.logError(e);
		}
	}
}
