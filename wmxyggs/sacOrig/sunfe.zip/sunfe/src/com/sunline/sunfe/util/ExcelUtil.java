package com.sunline.sunfe.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFDataFormatter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.tools.zip.ZipEntry;
import org.jdom.Element;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.util.FileUtil;


public class ExcelUtil {
	/**
	 * ˽�л�������
	 */
	private static Log logger = LogFactory.getLog(ExcelTemplate.class);
	private static String TEMPLATEPATH = "excel"+File.separator;
	private ExcelUtil() {

	}
	/**
	 * ����ģ�嵼��excel�ļ�
	 * @param datas �������ݼ�
	 * @param templateFileName ģ���ļ�����ֻ����97-2003��excel�ļ�
	 * @param title �����ļ��ı���
	 * @param fieldNameMap ���������ֶμ��ֶζ�Ӧ��������Map���壬keyΪ�ֶ�����valueΪ�ֶζ�Ӧ��������ʾ����
	 * @return  ���ɵ�excel�ļ�ȫ·������
	 * @throws BimisException 
	 * @throws IOException
	 */
	public static String exportExcel(List<Element> datas,
			String templateFileName, String title,
			Map<String, String> fieldNameMap) throws BimisException,
			IOException {
		return exportExcel(datas, templateFileName, title, fieldNameMap, 0);
	}
	
	/**
	 * ����ָ��sheetҳǩ����
	 * @param datas
	 * @param templateFileName
	 * @param title
	 * @param fieldNameMap
	 * @param sheetIdx
	 * @return
	 * @throws BimisException
	 * @throws IOException
	 */
	public static String exportExcel(List<Element> datas,
			String templateFileName, String title,
			Map<String, String> fieldNameMap, int sheetIdx) throws BimisException,
			IOException {
		ExcelTemplate excel = ExcelTemplate.newInstance(templateFileName);
		return excel.exportExcel(datas, title, fieldNameMap, sheetIdx);
	}
	
    /**
     * ����excelģ�嵼������
     * @param templateFileName ģ���ļ���
     * @param dataFileName ����������ļ�����������.xls��ʽ��������Ҫ��ģ���ļ���ʽһ��
     * @return List<Map<String,Object>>���ݼ�
     * @throws Exception
     */
	public static List<Map<String, Object>> importExcel(
			String templateFileName, String dataFileName) throws Exception {
		ExcelTemplate excel = ExcelTemplate.newInstance(templateFileName);
		return excel.importExcel(dataFileName);
	}
	/**
     * ����excelģ�嵼������
     * @param templateFileName ģ���ļ���
     * @param in �ļ�����������������ļ���ʽ������.xls
     * @return List<Map<String,Object>>���ݼ�
     * @throws Exception
     */
	public static List<Map<String, Object>> importExcel(
			String templateFileName, InputStream in) throws Exception {
		ExcelTemplate excel = ExcelTemplate.newInstance(templateFileName);
		return excel.importExcel(in);
	}
	
	public static String exportZipFile(List<String> srcfile,String title) throws BimisException,
	IOException {
	String path = FileUtil.getWebPath() + TEMPLATEPATH + "down"+File.separator;
	String fileName = path
			+title
			+ ".zip";
	File zipfile = new File(fileName);
	
	zipFiles(srcfile,zipfile);
	return fileName ;
}
	
	 public  static void zipFiles(List<String> srcfile, File zipfile) {  
	        byte[] buf = new byte[1024];  
	        try {  
	            // Create the ZIP file  
	            ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipfile));  
	            
	            // Compress the files  
	            for (int i = 0; i < srcfile.size(); i++) {  
	                File file = new File(srcfile.get(i));  
	                FileInputStream in = new FileInputStream(file);  
	                // Add ZIP entry to output stream.  
	                out.putNextEntry(new ZipEntry(file.getName()));  
	                // Transfer bytes from the file to the ZIP file  
	                int len;  
	                while ((len = in.read(buf)) > 0) {  
	                    out.write(buf, 0, len);  
	                }  
	                // Complete the entry  
	                out.closeEntry();  
	                in.close();  
	            }  
	            // Complete the ZIP file  
	            out.close();  
	        } catch (IOException e) {  
	        	logger.error("ZipUtil zipFiles exception:"+e);  
	        }  
	    }  
	 
	 
	 /**
	     * ��ȡ�������������
	     * 
	     * @param sheet
	     * @return
	     */

	    public static List<String[]> getExcelValue(Sheet sheet) {
	        int rownum = sheet.getLastRowNum();
	        int colnum = sheet.getRow(0).getPhysicalNumberOfCells();//��ȡҪ���������
	         Row row = null;
	        Cell cell = null;
	        List<String[]> excelValue = new ArrayList<String[]>();        
	        for (int i = 1; i <= rownum; i++) {// ������,��һ��ʼ����Ϊ��һ��������
	            row = sheet.getRow(i);
	            if (null == row) {
	                continue;
	            } 
	            String[] rowArray = new String[colnum];//��������ÿһ�е�ֵ
	            for (int j = 0; j < colnum; j++) {
	                cell = row.getCell(j);
	                String cellValue = getCellValue(cell);// ��Ԫ���ֵ
	                rowArray[j] = cellValue;
	            }
	            excelValue.add(rowArray);
	        }
	        return excelValue;
	    }

	    /**
	     * ����cell���� ȡcellֵ����
	     */
	    public static String getCellValue(Cell cell) {
	        String value = null;
	        if (null == cell) {
	            return null;
	        }
	        int cellType = cell.getCellType();
	        switch (cellType) {
	        case Cell.CELL_TYPE_NUMERIC:
	            HSSFDataFormatter dataFormatter = new HSSFDataFormatter();
	            String cellFormatted = dataFormatter.formatCellValue(cell);
	            value = cellFormatted; // ��ֹС�������
	            break;
	        case Cell.CELL_TYPE_BOOLEAN:
	            value = "" + cell.getBooleanCellValue();
	            break;
	        case Cell.CELL_TYPE_STRING:
	            value = cell.getStringCellValue();
	            break;
	        case Cell.CELL_TYPE_FORMULA:
	            value = cell.getCellFormula();
	            break;
	        case Cell.CELL_TYPE_BLANK:
	            break;
	        default:
	            value = cell.getRichStringCellValue().getString();
	            break;
	        }
	        if (value != null) {
	            value = value.trim();
	        }
	        return value;
	    }
}
