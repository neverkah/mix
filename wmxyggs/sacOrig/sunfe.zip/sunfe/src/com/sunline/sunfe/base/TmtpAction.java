package com.sunline.sunfe.base;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.sunfe.util.StringUtils;

public class TmtpAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.tmtp.";
	Log log = new Log("TmtpAction");
	/**
	 * ��ѯģ�������嵥 & queryTmtpListPage
	 */
	@SuppressWarnings("unchecked")
	public void queryTmtpListPage(){
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("tmpltp", StringUtils.repalceCharecter(hashmap.get("tmpltp")));
			hashmap.put("vermod", "0");
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryTmtplistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			log.logError(e);
		}
	}
	/**
	 * ����ģ������tmpltp���ҹ���������Ϣ
	 */
	public void queryTmtpById(){
		try 
		{
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String tmpltp = req.getReqDataStr("tmpltp");
			hashmap.put("tmpltp", tmpltp);
			hashmap.put("vermod", "0");
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryTmtpById", hashmap);	
            req.addRspData(e.removeContent());        //���ؽ����װ	
            Element templateEle = commonDao.queryByNamedSql(MYBATIS_NS+"queryTmplBytmpltplistPage",hashmap);
            req.addRspData("Results2",templateEle.removeContent());   //���ؽ����װ
		} catch (Exception e) {
			log.logError(e);
		}
	 }	
	
	/**
	 * ��ѯģ���б� & sys_tmpl
	 */
	public void queryTmplListPage(){
		try 
		{
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String tmpltp = req.getReqDataStr("tmpltp");
			String tmplna = req.getReqDataStr("tmplna");
			String pageNo = req.getReqDataStr("pageNum");
			
			if (StringUtils.isNotEmpty(pageNo)) {
				req.setReqPageNo(Integer.parseInt(pageNo));
			}
			hashmap.put("tmpltp", tmpltp);
			hashmap.put("vermod", "0");
			hashmap.put("tmplna", tmplna);
			
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryTmplBytmpltplistPage",req.getReqPageInfo(), hashmap);	
            req.addRspData(e.removeContent());        //���ؽ����װ	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * ����ģ������ & addTmtp
	 */
	@SuppressWarnings("rawtypes")
	public void addTmtp(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>(); 
			HashMap<String, String> hashmap2 = new HashMap<String, String>(); 
			commonDao.beginTransaction();
			String tmpltp = req.getReqDataStr("tmpltp");//ģ������
			String tmtpna = req.getReqDataStr("tmtpna");//ģ����������
			String levltp = req.getReqDataStr("levltp");//ģ�����ͼ���
			String enname = req.getReqDataStr("enname");//Ӣ������
			String desctx = req.getReqDataStr("desctx");//˵��
			String vermod = req.getReqDataStr("vermod");//�汾ģʽ
			String module = req.getReqDataStr("module");//ģ��
			String projcd = req.getReqDataStr("projcd");//��Ŀ���
			
			List<String> tmplid_list = req.getReqDataTexts("tmplid");
			List<String> tmplna_list = req.getReqDataTexts("tmplna");
			List<String> efctdt_list = req.getReqDataTexts("efctdt");
			List<String> inefdt_list = req.getReqDataTexts("inefdt");
			List<String> tdesctx_list = req.getReqDataTexts("tdesctx");
			List<String> tenname_list = req.getReqDataTexts("tenname");
			
			hashmap.put("tmpltp", tmpltp.trim());
			hashmap.put("tmtpna", tmtpna.trim());
			hashmap.put("levltp", levltp.trim());
			hashmap.put("enname", enname.trim());
			hashmap.put("desctx", desctx.trim());
			hashmap.put("vermod", vermod);
			hashmap.put("module", module);
			hashmap.put("projcd", projcd);
			//У��ģ�������Ƿ��Ѵ���
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTmtp", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "ģ�������Ѵ��ڣ�");
					return;
				}
			}
		    int result = commonDao.insertByNamedSql(MYBATIS_NS+"addTmtp",hashmap);
			
			if(tmplid_list.size()!=0 && tmplid_list!=null){
				for(int i=0;i<tmplid_list.size();i++){
					   hashmap2.clear();
					   String tmplid = tmplid_list.get(i);
					   if(!"".equals(tmplid)&&tmplid!=null){
						   hashmap2.put("tmplid", tmplid);
						   hashmap2.put("vermod", vermod);
						   hashmap2.put("module", module);
						   hashmap2.put("projcd", projcd);
						   hashmap2.put("tmpltp", tmpltp);
						   hashmap2.put("tmplna", tmplna_list.get(i));
						   hashmap2.put("efctdt", efctdt_list.get(i));
						   hashmap2.put("inefdt", inefdt_list.get(i));
						   hashmap2.put("tenname", tenname_list.get(i));
						   hashmap2.put("tdesctx", tdesctx_list.get(i));
						 //�����ֶ���tmplid���ж�,�Ƿ����д��ڵĽӿ���ϸ����
							List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTmpl", hashmap2);
							if(sumList!=null && sumList.size()>0) {
								Map sumMap = (HashMap)sumList.get(0);
								int sum = Integer.valueOf(sumMap.get("CC").toString());
								if(sum > 0) {
									req.addRspData("retCode", "300");
									req.addRspData("retMessage", "��ģ��ID��ģ�������Ѵ��ڣ�");
									return;
								}
							}
						   result = commonDao.insertByNamedSql(MYBATIS_NS+"insertTmpl", hashmap2);
					   }
				 }   
			  }
			  if(result > 0){
				   req.addRspData("retCode", "200");
				   req.addRspData("retMessage", "�����ɹ�");
				   req.addRspData("navTabId", "");
				   req.addRspData("callbackType", "closeCurrent");
				   req.addRspData("forwardUrl", "");
				   commonDao.commitTransaction();
			   }else{
				   req.addRspData("retCode", "300");
					req.addRspData("retMessage", "����ʧ��");
					req.addRspData("navTabId", "");
					req.addRspData("callbackType", "closeCurrent");
					req.addRspData("forwardUrl", "");
			   }
			} catch (Exception e) {
				try {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage",e.toString().substring(e.toString().lastIndexOf("Cause")));
					req.addRspData("navTabId", "");
					req.addRspData("callbackType", "closeCurrent");
					req.addRspData("forwardUrl", "");
				} catch (JDOMException e1) {
					e1.printStackTrace();
				}
				e.printStackTrace();
			}		
	}
	/**
	 * �޸�ģ������ & updateTmtp
	 * @throws JDOMException 
	 */
	@SuppressWarnings("rawtypes")
	public void updateTmtp() throws JDOMException{
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>(); 
			HashMap<String, String> hashmap2 = new HashMap<String, String>(); 
			HashMap<String, String> hashmap3 = new HashMap<String, String>(); 
			commonDao.beginTransaction();
			String tmpltp = req.getReqDataStr("tmpltp");//ģ������
			String tmtpna = req.getReqDataStr("tmtpna");//ģ����������
			String levltp = req.getReqDataStr("levltp");//ģ�����ͼ���
			String enname = req.getReqDataStr("enname");//Ӣ������
			String desctx = req.getReqDataStr("desctx");//˵��
			String vermod = req.getReqDataStr("vermod");//�汾ģʽ
			String module = req.getReqDataStr("module");//ģ��
			String projcd = req.getReqDataStr("projcd");//��Ŀ���
			
			List<String> tmplid_list = req.getReqDataTexts("tmplid");
			List<String> tmplna_list = req.getReqDataTexts("tmplna");
			List<String> efctdt_list = req.getReqDataTexts("efctdt");
			List<String> inefdt_list = req.getReqDataTexts("inefdt");
			List<String> tdesctx_list = req.getReqDataTexts("tdesctx");
			List<String> tenname_list = req.getReqDataTexts("tenname");
			
			hashmap.put("tmpltp", tmpltp);
			hashmap.put("tmtpna", tmtpna.trim());
			hashmap.put("levltp", levltp.trim());
			hashmap.put("enname", enname.trim());
			hashmap.put("desctx", desctx.trim());
			hashmap.put("vermod", vermod);
			hashmap.put("module", module);
			hashmap.put("projcd", projcd);
			
			commonDao.updateByNamedSql(MYBATIS_NS+"updateTmtp",hashmap);//����ģ������
			hashmap.put("vermod", "0");
			commonDao.insertByNamedSql(MYBATIS_NS+"addTmtp",hashmap);
			
			hashmap3.put("tmpltp", tmpltp);
			hashmap3.put("projcd", projcd);
			commonDao.updateByNamedSql(MYBATIS_NS+"updateTmpl", hashmap3);//��ɾ������������  ģ��
			
			if(tmplid_list.size()!=0 && tmplid_list!=null){
		    	
				for(int i=0;i<tmplid_list.size();i++){
					   hashmap2.clear();
					   String tmplid = tmplid_list.get(i);
					   if(!"".equals(tmplid)&&tmplid!=null){
						   hashmap2.put("tmplid", tmplid);
						   hashmap2.put("vermod", "0");
						   hashmap2.put("module", module);
						   hashmap2.put("projcd", projcd);
						   hashmap2.put("tmpltp", tmpltp);
						   hashmap2.put("tmplna", tmplna_list.get(i));
						   hashmap2.put("efctdt", efctdt_list.get(i));
						   hashmap2.put("inefdt", inefdt_list.get(i));
						   hashmap2.put("tenname", tenname_list.get(i));
						   hashmap2.put("tdesctx", tdesctx_list.get(i));
						 //�����ֶ���tmplid���ж�,�Ƿ����д��ڵĽӿ���ϸ����
							List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTmpl", hashmap2);
							if(sumList!=null && sumList.size()>0) {
								Map sumMap = (HashMap)sumList.get(0);
								int sum = Integer.valueOf(sumMap.get("CC").toString());
								if(sum > 0) {
									req.addRspData("retCode", "300");
									req.addRspData("retMessage", "ģ��ID�Ѵ��ڣ�");
									return;
								}
							}
						  commonDao.insertByNamedSql(MYBATIS_NS+"insertTmpl", hashmap2);//����ģ��
					   }
				 }   
			  } 
				commonDao.commitTransaction();
			   ResultUtils.setRspData(req, "200",  "�����ɹ�", "tmtp_main", "closeCurrent", "");
			  
			} catch (BimisException e) {
				commonDao.rollBack();
				log.logError(e);
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			}
	}

	/**
	 * ɾ��ģ��������Ϣ & deleteTmtp
	 * @throws JDOMException 
	 */
	public void deleteTmtp() throws JDOMException{
		try {
			List<String> tmpltpList = req.getReqDataTexts("tmpltps");
			if (tmpltpList != null && tmpltpList.size() > 0) {
				commonDao.beginTransaction();
				HashMap<String, List<String>> hashmap = new HashMap<String, List<String>>();
				hashmap.put("tmpltpList", tmpltpList);
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTmpl", hashmap);
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTmtp", hashmap);
				}
				commonDao.commitTransaction();
				ResultUtils.setRspData(req, "200",  "�����ɹ�", "tmtp_main", "", "");
		} catch (BimisException e) {
				commonDao.rollBack();
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "tmtp_main", "", "");
				log.logError(e);
		}
	}
}
