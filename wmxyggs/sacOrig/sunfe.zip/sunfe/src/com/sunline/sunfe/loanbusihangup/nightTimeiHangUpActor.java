package com.sunline.sunfe.loanbusihangup;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.JsonUtil;
import com.sunline.jraf.util.Log;
import com.sunline.jraf.util.StringUtil;
import com.sunline.jraf.util.XmlUtil;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.Sequence;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.StringUtils;
import com.sunline.sunfe.core.bean.ComItemBean;
import com.sunline.sunfe.entity.AccountingItem;
import com.sunline.sunfe.entity.GlaVoucher;
import com.sunline.sunfe.util.DatetimeUtil;

public class nightTimeiHangUpActor extends Actor {
	private static Log log = new Log(nightTimeiHangUpActor.class);
	private static String MYBATIS_NS = "com.sunline.sunfe.mybatis.busiHangHandle.";
	private String MYBATIS_NS2 = "com.sunline.suncm.mybatis.nighthangup.";

	/**
	 * ������ˮ���˲�ѯ
	 * 
	 * @Title: getHangUpList
	 * @throws JDOMException
	 * @return: void
	 */
	@SuppressWarnings("unchecked")
	public void queryBusiHang() throws Exception {
		Map<String, Object> para = req.getReqDataMap();
		String stacid = SessionParaUtils.getStacid();
		para.put("stacid", stacid);

		String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
		String lastday = DatetimeUtil.getPrirDay(glisdt);

		para.put("glisdt", lastday);
		// ������ˮ��¼�����٣�����Ҫ��ҳ
		List<HashMap<String, Object>> busiDataList = (List<HashMap<String, Object>>) commonDao
				.queryByNamedSqlForList(MYBATIS_NS + "queryBusiHang", para);

		List<HashMap<String, Object>> listMapResult = new ArrayList<HashMap<String, Object>>();
		for (int i = 0; i < busiDataList.size(); i++) {
			String trdata = (String) busiDataList.get(i).get("TRDATA");
			String hstatus = (String) busiDataList.get(i).get("STATUS");
			List<HashMap<String, Object>> jlistmap = JsonUtil
					.convertJson2ListMap(trdata);
			for (HashMap<String, Object> jmap : jlistmap) {
				jmap.put("hstatus", hstatus);
			}
			listMapResult.addAll(jlistmap);
		}
		Element busiDict = commonDao.queryByNamedSql(MYBATIS_NS
				+ "queryBusiDict", para);
		req.addRspData("Results2", busiDict.removeContent());
		Element xmlResult = XmlUtil.createDataObjectElement(listMapResult);
		req.addRspData(xmlResult.removeContent());
		req.addReqData("lastday", lastday);
	}

	/**
	 * ������ˮ���˲�ѯ
	 * 
	 * @Title: GLA_CHK_Book
	 * @throws JDOMException
	 * @return: void
	 */
	@SuppressWarnings("unchecked")
	public void queryBooks() throws Exception {
		HashMap<String, String> hashmap = (HashMap<String, String>) req
				.getReqDataMap();
		String stacid = SessionParaUtils.getStacid();
		String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
	
		String lastday = DatetimeUtil.getPrirDay(glisdt);
		hashmap.put("lastday", lastday);
		hashmap.put("stacid", stacid);
		Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS2
				+ "queryBooks", req.getReqPageInfo(), hashmap);
		req.addRspData(e.removeContent());
		req.addRspData("retCode", "200");
	}

	@SuppressWarnings("unchecked")
	public String getBusiHangStatus(String stacid, String systid,
			String trandt, String transq) throws BimisException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("stacid", stacid);
		map.put("systid", systid);
		map.put("trandt", trandt);
		map.put("transq", transq);
		List<HashMap<String, Object>> busiDataList = (List<HashMap<String, Object>>) commonDao
				.queryByNamedSqlForList(MYBATIS_NS2 + "checkBusiHang", map);
		String status = "1";
		if (busiDataList.size() == 0) {
			status = "0";
		} else {
			status = "1";
		}
		return status;
	}

	/***
	 * ������˴���
	 * 
	 * @throws Exception
	 ****/
	@SuppressWarnings("unchecked")
	public void handleHangup() throws Exception {
		Map<String, Object> hs = req.getReqDataMap();

		String rowNo = (String) hs.get("handleRows");
		int count = Integer.parseInt(rowNo);
		String stacid = SessionParaUtils.getStacid();
		String systid = (String) hs.get("handleSystid");
		String tranbr = (String) hs.get("handleTranbr");
		String smrytx = (String) hs.get("dealReason");
		String trandt = (String) hs.get("handleTrandt");
		String transq = (String) hs.get("handleTransq");
		String trantp = (String) hs.get("handleTrantp");
		

		String bookitemcd = (String) hs.get("handleBookItemcd");// ���˿�Ŀ
		String bookhgitemcd = (String) hs.get("handleBookHgitem");// ���˿�Ŀ
		String bookamntcd = (String) hs.get("handleBookAmntcd");// ���׷���
		String bookcrcycd = (String) hs.get("handleBookCrcycd");// ���˱���
		String bookbrchcd = (String) hs.get("handleBookBrchcd");// ���˱���;

		List<?> parampList = this.req.getReqDataTexts("paramp");
		BigDecimal olddealam = BigDecimal.ZERO;
		BigDecimal oldtranam = BigDecimal.ZERO;
		if ((parampList != null) && (parampList.size() > 0)) {
			olddealam = new BigDecimal(
					parampList.get(0).toString().split("-")[0].trim())
					.setScale(BigDecimal.ROUND_HALF_UP, 2);
			;// ����ǰ���Ѵ������
			oldtranam = new BigDecimal(
					parampList.get(0).toString().split("-")[1].trim())
					.setScale(BigDecimal.ROUND_HALF_UP, 2);
			;// ���˽��
			bookitemcd = parampList.get(0).toString().split("-")[5].trim();// ���˿�Ŀ
			bookhgitemcd = parampList.get(0).toString().split("-")[6].trim();// ���˿�Ŀ
			bookamntcd = parampList.get(0).toString().split("-")[8].trim();// ���׷���
			bookcrcycd = parampList.get(0).toString().split("-")[7].trim();// ���˱���
			bookbrchcd = parampList.get(0).toString().split("-")[4].trim();// ���˱���
		}
		String booksStatus = null;

		boolean flag_chek = false;

		BigDecimal dealam = BigDecimal.ZERO;// �������

		for (int i = 0; i < count; i++) {
			String itemcd_vchr = (String) hs.get("itemcd" + i);

			if (itemcd_vchr == null || "".equals(itemcd_vchr)) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "��Ŀ����Ϊ�գ�����");
				return;
			}

			String tranamD = (String) hs.get("tranamD" + i);// �ܽ跽���
			String tranamC = (String) hs.get("tranamC" + i);// �ܴ������
			tranamD = tranamD.replaceAll(",", "");
			tranamC = tranamC.replaceAll(",", "");
			if (bookitemcd.equals(itemcd_vchr)) {
				if (tranamD == null || "".equals(tranamD)) {
					dealam = new BigDecimal(tranamC).setScale(
							BigDecimal.ROUND_HALF_UP, 2);
				} else {
					dealam = new BigDecimal(tranamD).setScale(
							BigDecimal.ROUND_HALF_UP, 2);
				}

				// �жϴ�������Ƿ���ڹ��˽��
				BigDecimal jueduidealam = dealam.abs();

				int m = oldtranam.compareTo(olddealam.add(jueduidealam));
				if (-1 == m) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "���������ڹ��˽�����");
					return;
				} else if (0 == m) {
					booksStatus = "1";
				} else {
					booksStatus = "2";
				}
				flag_chek = true;
			} else {
				flag_chek = true;
			}
		}
		if (!flag_chek) {
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "�������ȷ������");
			return;
		}

		// �ж��Ƿ����Ѵ�����¼
		String flag = getBusiHangStatus(stacid, systid, trandt, transq);
		if ("1".equals(flag)) {
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "�Ѿ��������ô���");
			return;
		}

		String tranamDT = (String) hs.get("tranamDT");// �ܽ跽���
		String tranamCT = (String) hs.get("tranamCT");// �ܴ������
		tranamDT = tranamDT.replaceAll(",", "");
		tranamCT = tranamCT.replaceAll(",", "");
		if (tranamDT == null || tranamCT == null || "".equals(tranamDT)
				|| "".equals(tranamCT) || !tranamDT.equals(tranamCT)) {
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "�������ȷ������");
			return;
		}

		// �跽����ܺ�
		BigDecimal sumtrnamDT = new BigDecimal(tranamDT).setScale(
				BigDecimal.ROUND_HALF_UP, 2);
		;
		// ����������ܺ�
		BigDecimal sumtrnamCT = new BigDecimal(tranamCT).setScale(
				BigDecimal.ROUND_HALF_UP, 2);
		;

		ArrayList<HashMap<String, Object>> glaVchrList = new ArrayList<HashMap<String, Object>>();
		int i = 1;
		for (i = 0; i < count; i++) {
			HashMap<String, Object> map = new HashMap<String, Object>();
			String acctbr = (String) hs.get("acctbr" + i);
			String crcycd = (String) hs.get("crcycd" + i);

			if (acctbr == null || "".equals(acctbr)) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "�����������Ϊ�գ�����");
				return;
			}

			if (crcycd == null || "".equals(crcycd)) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "���ֲ���Ϊ�գ�����");
				return;
			}

			String amntcd = "";
			BigDecimal tranam = BigDecimal.valueOf(0.0);
			BigDecimal zear = BigDecimal.valueOf(0.0);

			String tranamDStr = (String) hs.get("tranamD" + i);
			String tranamCStr = (String) hs.get("tranamC" + i);

			if ("".equals(tranamDStr) && "".equals(tranamCStr)) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "�������ȷ������");
				return;
			}

			BigDecimal tranamD = BigDecimal.valueOf(0.0);
			BigDecimal tranamC = BigDecimal.valueOf(0.0);
			if (!("".equals(tranamDStr))) {
				tranamD = new BigDecimal(tranamDStr.replace(",", "")).setScale(
						BigDecimal.ROUND_HALF_UP, 2);
			}
			if (!("".equals(tranamCStr))) {
				tranamC = new BigDecimal(tranamCStr.replace(",", "")).setScale(
						BigDecimal.ROUND_HALF_UP, 2);
			}
			if (tranamD.compareTo(zear) == 0) {
				tranam = tranamC;
				amntcd = "C";
			} else {
				tranam = tranamD;
				amntcd = "D";
			}

			String itemcd = (String) hs.get("itemcd" + i);

			map.put("stacid", Integer.parseInt(stacid));
			map.put("systid", systid);
			map.put("tranbr", tranbr);
			map.put("crcycd", crcycd);
			map.put("smrytx", smrytx);
			map.put("trandt", trandt);
			map.put("transq", transq);
			map.put("trantp", trantp);
			map.put("vchrsq", String.valueOf(i));

			map.put("acctbr", acctbr);
			map.put("tranam", tranam);
			map.put("amntcd", amntcd);
			map.put("itemcd", itemcd);

			// sumtrnamDT.add(tranamD);
			// sumtrnamCT.add(tranamC);
			glaVchrList.add(map);
		}

		/*
		 * 
		 * /* ���˿�Ŀ����
		 */
		if (!((parampList == null) || (parampList.size() == 0))) {

			HashMap<String, Object> item = new HashMap<String, Object>();

			item.put("stacid", Integer.parseInt(stacid));
			item.put("systid", systid);
			item.put("tranbr", tranbr);
			item.put("crcycd", bookcrcycd);
			item.put("smrytx", smrytx);
			item.put("trandt", trandt);
			item.put("transq", transq);
			item.put("trantp", trantp);
			item.put("acctbr", bookbrchcd);

			item.put("tranam", dealam.multiply(new BigDecimal(-1)));
			item.put("amntcd", bookamntcd);
			item.put("itemcd", bookitemcd);
			item.put("vchrsq", String.valueOf(i + 1));

			glaVchrList.add(item);
			/*
			 * ���˿�Ŀ����
			 */
			HashMap<String, Object> hgitem = new HashMap<String, Object>();

			hgitem.put("stacid", Integer.parseInt(stacid));
			hgitem.put("systid", systid);
			hgitem.put("tranbr", tranbr);
			hgitem.put("crcycd", bookcrcycd);
			hgitem.put("smrytx", smrytx);
			hgitem.put("trandt", trandt);
			hgitem.put("transq", transq);
			hgitem.put("trantp", trantp);

			hgitem.put("tranam", dealam.multiply(new BigDecimal(-1)));

			if ("D".equals(bookamntcd)) {
				hgitem.put("amntcd", "C");
			} else {
				hgitem.put("amntcd", "D");
			}
			hgitem.put("itemcd", bookhgitemcd);
			hgitem.put("acctbr", bookbrchcd);
			hgitem.put("vchrsq", String.valueOf(i + 2));

			glaVchrList.add(hgitem);

		}

		try {
			commonDao.beginTransaction();
			generateAndSaveGlaVoucher(glaVchrList);

			HashMap<String, Object> uphs = new HashMap<String, Object>();
			uphs.put("stacid", stacid);
			uphs.put("systid", systid);
			uphs.put("trandt", trandt);
			uphs.put("transq", transq);

			commonDao.updateByNamedSql(MYBATIS_NS + "updateBusiHang", uphs);

			if (!((parampList == null) || (parampList.size() == 0))) {
				uphs.put("dealam", olddealam.add(dealam));
				uphs.put("itemcd", bookitemcd);
				uphs.put("hgitem", bookhgitemcd);
				uphs.put("status", booksStatus);
				commonDao.updateByNamedSql(MYBATIS_NS2 + "updateCHKBook", uphs);
				
			}
			commonDao.commitTransaction();
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "���˴����ɹ���");
		} catch (Exception e) {
			ResultUtils.setRspData(req, "300", "���˴���ʧ�ܣ��������ݣ�", "");
			// �쳣�ǻع�
			commonDao.rollBack();
			log.logError(e);
		}
	}

	/**
	 * @Title: generateAndSaveGlaVoucher
	 * @Description: ���������¼����ˮ��Ϣ
	 * @throws Exception
	 */
	private void generateAndSaveGlaVoucher(
			List<HashMap<String, Object>> glavchrs) throws Exception {

		List<GlaVoucher> glaVoucherList = new ArrayList<GlaVoucher>();

		int stacid = (Integer) glavchrs.get(0).get("stacid");
		String glisdt = PubUtil.getGlisdt(stacid);
		String tranbr = (String) glavchrs.get(0).get("tranbr");
		String usercd = SessionParaUtils.getUsercd();

		Sequence sequence;
		String transq = "";
		try {
			sequence = SequenceUtils.createSequence(String.valueOf(stacid),
					glisdt, "transq", tranbr, usercd, 1);
			transq = sequence.getSqueno();
			if (StringUtils.isEmpty(transq)) {
				log.logError("��ȡ������ˮʧ��,���������ϵ");
				throw new BimisException("999", "��ȡ������ˮʧ��,���������ϵ");
			}
		} catch (Exception e) {
			log.logError("��ȡ������ˮʧ��,���������ϵ");
			throw new BimisException("999", "��ȡ������ˮʧ��,���������ϵ");
		}
		for (int i = 0; i < glavchrs.size(); i++) {
			HashMap<String, Object> busiMap = glavchrs.get(i);

			String systid = (String) busiMap.get("systid");
			String sourdt = (String) busiMap.get("trandt");
			String soursq = (String) busiMap.get("transq");
			tranbr = (String) busiMap.get("tranbr");

			String trantp = (String) busiMap.get("trantp");

			String vchrsq = (String) busiMap.get("vchrsq");
			String acctbr = (String) busiMap.get("acctbr");
			String itemcd = (String) busiMap.get("itemcd");
			String crcycd = (String) busiMap.get("crcycd");
			String amntcd = (String) busiMap.get("amntcd");
			BigDecimal tranam = (BigDecimal) busiMap.get("tranam");
			String smrytx = (String) busiMap.get("smrytx");

			// ��ȡ��Ŀ��Ϣ
			AccountingItem itemInfo = ComItemBean
					.getAccountingItemByPrimaryKey(stacid, itemcd);

			GlaVoucher glaVoucher = new GlaVoucher();

			glaVoucher.setStacid(stacid);// ���ױ��
			glaVoucher.setSystid(systid);// ϵͳ��ʶ
			glaVoucher.setTrandt(PubUtil.getGlisdt(stacid));// ��������
			glaVoucher.setTransq(transq);// ������ˮ
			glaVoucher.setVchrsq(vchrsq);// ��Ʊ���
			glaVoucher.setTranbr(tranbr);// ���׻���
			glaVoucher.setAcctbr(acctbr);// �������
			glaVoucher.setItemcd(itemcd);// ��Ŀ����
			glaVoucher.setCrcycd(crcycd);// ���ִ���
			glaVoucher.setTrantp(trantp);// ��������
			glaVoucher.setAmntcd(amntcd);// �������
			glaVoucher.setTranam(tranam);// ���׽��
			// glaVoucher.setTranbl((BigDecimal) glaGlisMap.get("onlnbl"));//
			// �������
			glaVoucher.setIoflag(itemInfo.getIoflag());
			// glaVoucher.setBlncdn((String) glaGlisMap.get("blncdn"));// ��ǰ����
			glaVoucher.setSmrytx(smrytx);// ժҪ
			glaVoucher.setExchcn(BigDecimal.ZERO);// �м��
			glaVoucher.setExchus(BigDecimal.ZERO);// ������
			glaVoucher.setUsercd(SessionParaUtils.getUsercd());// �û�����
			glaVoucher.setSourdt(sourdt);// ҵ������
			glaVoucher.setSoursq(soursq);// ҵ����ˮ
			glaVoucher.setSourst(systid);// Դϵͳ��ʶ
			glaVoucher.setSrvcsq(String.valueOf(i));// Դ��Ʊ���
			// glaVoucher.setBearbl((BigDecimal) glaGlisMap.get("bearbl"));//
			// ��ǰ���
			// glaVoucher.setBeardn((String) glaGlisMap.get("beardn"));// ��ǰ����
			glaVoucher.setToitem("");// �Է���Ŀ
			// glaVoucher.setAcctno(glaAeuvDetl.getAcctno());
			glaVoucher.setTranst("0");

			glaVoucherList.add(glaVoucher);
		}

		saveGlaVoucherBatch(commonDao, glaVoucherList);
	}

	@SuppressWarnings("rawtypes")
	public static void saveGlaVoucherBatch(CommonDao commonDao,
			List glaVoucherList) throws BimisException {
		int batchCount = 20;
		int insertRecordCount = 0;
		try {
			int ednIdx = 0;
			for (int beginIdx = 0; beginIdx < glaVoucherList.size();) {
				ednIdx = beginIdx + batchCount >= glaVoucherList.size() ? glaVoucherList
						.size() : beginIdx + batchCount;
				List subGlaVoucherList = glaVoucherList.subList(beginIdx,
						ednIdx);
				beginIdx += batchCount;
				insertRecordCount += commonDao.insertByNamedSql(MYBATIS_NS
						+ "insertEntitiesBatch", subGlaVoucherList);
			}

			if (insertRecordCount != glaVoucherList.size()) {
				log.logError("��Ʊ���ʧ��");
				throw new BimisException("9999", (new StringBuilder())
						.append("��Ʊ���ʧ��,��Ʊ�б�������[")
						.append(glaVoucherList.size()).append("]����������[")
						.append(insertRecordCount).append("]��һ��").toString());
			}
		} catch (Exception ex) {
			log.logError("��Ʊ���ʧ��", ex);
			throw new BimisException("9999", "��Ʊ���ʧ��:", ex);
		}
	}

}
