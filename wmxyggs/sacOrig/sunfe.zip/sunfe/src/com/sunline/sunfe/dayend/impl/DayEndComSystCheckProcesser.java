package com.sunline.sunfe.dayend.impl;

import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.sunfe.dayend.IDayEndProcesser;

/**
 * ������Χϵͳ׼��״̬���
 * @ClassName: DayEndComSystCheckProcesser 
 * @Description: TODO
 * @author: huangziq
 * @date: 2017-11-21 ����2:02:08
 */
public class DayEndComSystCheckProcesser extends IDayEndProcesser {
	
	/**
	 * log ��־˽�б���
	 */
	private static Log log = LogFactory.getLog(DayEndComSystCheckProcesser.class);

	@Override
	public void preProcess() throws BimisException {
		// TODO Auto-generated method stub

	}

	@Override
	public void processing() throws BimisException {
		// TODO Auto-generated method stub
		try {
			CommonDao commonDao = this.getCommonDao();
			HashMap<String, String> hashmap = new HashMap<String,String>();
			int stacid = getStacid();
			hashmap.put("stacid", String.valueOf(stacid));
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryNotPreparedSyst", hashmap);
			int count = e.removeContent().size();
			if (count > 0) {
				throw new BimisException("-1","��Χϵͳ׼��״̬��鲻ͨ��");
			}
		} catch (Exception e) {
			commonDao.rollBack();
			log.error("��Χϵͳ׼��״̬��鲻ͨ��:", e);
			throw new BimisException("-1", "��Χϵͳ׼��״̬��鲻ͨ��:"
					+ e.getMessage(),e);
		}finally {
			// ��عر����ÿһ�����ղ��趼��������һ���µ�session
			this.closeSession();
		}
	}

	@Override
	public void processed() throws BimisException {
		// TODO Auto-generated method stub
	}

}
