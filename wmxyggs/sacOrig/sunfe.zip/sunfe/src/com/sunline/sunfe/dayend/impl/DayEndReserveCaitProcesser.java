package com.sunline.sunfe.dayend.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.suncm.util.JrafSessionUtil;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.Sequence;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.core.bean.GlaAeuvBean;
import com.sunline.sunfe.dayend.IDayEndProcesser;
import com.sunline.sunfe.entity.GlaAeuv;
import com.sunline.sunfe.glisfund.GlisfundManage;
import com.sunline.sunfe.glisfund.PublicFmbCntrInfoUtil;

/**
 * @ClassName: DayEndReserveCaitProcesser
 * @Description: �ڲ��ʽ����
 * @author: huangzhongjie
 * @date: 2018��3��20�� ����2:32:36
 */

public class DayEndReserveCaitProcesser extends IDayEndProcesser {
	private static Log log = LogFactory.getLog(DayEndReserveCaitProcesser.class);
	private CommonDao commonDao;
	private PublicFmbCntrInfoUtil publicFmbCntrInfo;

	/**
	 * @throws BimisException
	 * @�˷��������ã�
	 */
	@Override
	public void preProcess() throws BimisException {

	}

	@Override
	public void processing() throws BimisException {

		try {

			commonDao = this.getCommonDao();
			publicFmbCntrInfo = new PublicFmbCntrInfoUtil(commonDao);

			commonDao.beginTransaction();

			reserveCait();

			commonDao.commitTransaction();
		} catch (Exception e) {
			commonDao.rollBack();
			log.error(e);
			e.printStackTrace();
			throw new BimisException("601", "�ڲ��ʽ�������" + e.getMessage());
		} finally {
			JrafSessionUtil.closeConnection(jrafSession);
		}
	}

	public void reserveCait() throws Exception {

		String sStacid = SessionParaUtils.getStacid();

		String user_Usercd = SessionParaUtils.getUsercd();

		int stacid = Integer.valueOf(sStacid);

		String trandt = PubUtil.getGlisdt(stacid);

		Map<String, Object> map = new HashMap<String, Object>();

		List<Map<String, Object>> list = publicFmbCntrInfo.selectGlaAcctAcmlbl(stacid);
		// ������
		BigDecimal instam = BigDecimal.ZERO;
		// ����
		BigDecimal instrt = BigDecimal.ZERO;
		for (Map<String, Object> mapGlaAcct : list) {
			// �ʽ�����
			String fundtp = mapGlaAcct.get("fundtp").toString();
			// ����
			String brchno = mapGlaAcct.get("brchno").toString();
			// ��Ŀ��
			String subscd = mapGlaAcct.get("subscd").toString();
			// ����
			String crcycd = mapGlaAcct.get("crcycd").toString();

			// �������
			BigDecimal onlnbl = new BigDecimal(mapGlaAcct.get("onlnbl").toString());
			// ����
			instrt = GlisfundManage.getCurrentInrt(stacid, fundtp, "101", subscd, crcycd, trandt);
			// ������Ϣ
			instam = GlisfundManage.calInterest(1, instrt, onlnbl);

			if (0 == instam.compareTo(BigDecimal.ZERO)) {
				continue;
			}

			// ������ˮ
			Sequence sequence = SequenceUtils.createSequence(sStacid, trandt, "bsnssq", brchno, user_Usercd, 1);

			String soursq = sequence.getSqueno();
			// ������
			String prcscd = "gls_reseca";

			// �������� ���������
			String acetna = publicFmbCntrInfo.prcsnaInfo(stacid, prcscd).get("functx").toString();

			// �Ǽ�gla_aeuv
			GlaAeuv glaAeuv = new GlaAeuv();

			glaAeuv.setStacid(stacid);
			glaAeuv.setSourst("90");
			glaAeuv.setSourdt(trandt);
			glaAeuv.setSoursq(soursq);
			glaAeuv.setTranbr(brchno); // �ϼ�����Ϊ���׻���
			glaAeuv.setAcetna(acetna);
			glaAeuv.setUsercd(user_Usercd);
			glaAeuv.setPrcscd(prcscd);
			glaAeuv.setTrantp("2");
			glaAeuv.setTranst("0");
			glaAeuv.setStrkst("0");

			GlaAeuvBean.saveGlaAeuv(commonDao, glaAeuv);

			publicFmbCntrInfo.fundCmbk(stacid, "90", trandt, soursq, subscd, brchno, null, "3C", crcycd, instam, BigDecimal.ZERO,
					BigDecimal.ZERO, null);

		}
	}

	/**
	 * @throws BimisException
	 * @�˷��������ã�
	 */
	@Override
	public void processed() throws BimisException {
	}

}
