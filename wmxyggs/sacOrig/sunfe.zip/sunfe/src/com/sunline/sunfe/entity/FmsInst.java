package com.sunline.sunfe.entity;

import java.math.BigDecimal;

/**
 * @ClassName: FmsInst
 * @Description: �ڲ��ʽ��Ϣ�Ǽǲ� ���ݿ����Fms_Inst
 * @author: huangzhongjie
 * @date: 2017��12��27�� ����11:24:39
 */
public class FmsInst {

	int stacid;
	String trandt; // ��������
	String transq; // ������ˮ
	String insttp; // ��Ϣ����
	String brchno; // ������
	String cntrno; // ��ͬ��
	String drrtno; // ֧ȡ�黹���
	String crcycd; // ����
	String inrttp; // ��������
	String termcd; // ����
	String bgindt; // ��Ϣ����
	BigDecimal acmlbl; // ��Ϣ����
	BigDecimal inrtrt; // ����


	BigDecimal instam; // ��Ϣ���

	public String getTrandt() {
		return trandt;
	}

	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}

	public String getTransq() {
		return transq;
	}

	public void setTransq(String transq) {
		this.transq = transq;
	}

	public String getInsttp() {
		return insttp;
	}

	public void setInsttp(String insttp) {
		this.insttp = insttp;
	}

	public String getBrchno() {
		return brchno;
	}

	public void setBrchno(String brchno) {
		this.brchno = brchno;
	}

	public String getCntrno() {
		return cntrno;
	}

	public void setCntrno(String cntrno) {
		this.cntrno = cntrno;
	}

	public String getDrrtno() {
		return drrtno;
	}

	public void setDrrtno(String drrtno) {
		this.drrtno = drrtno;
	}

	public String getCrcycd() {
		return crcycd;
	}

	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}

	public String getInrttp() {
		return inrttp;
	}

	public void setInrttp(String inrttp) {
		this.inrttp = inrttp;
	}

	public String getTermcd() {
		return termcd;
	}

	public void setTermcd(String termcd) {
		this.termcd = termcd;
	}

	public String getBgindt() {
		return bgindt;
	}

	public void setBgindt(String bgindt) {
		this.bgindt = bgindt;
	}

	public BigDecimal getAcmlbl() {
		return acmlbl;
	}

	public void setAcmlbl(BigDecimal acmlbl) {
		this.acmlbl = acmlbl;
	}

	public BigDecimal getInrtrt() {
		return inrtrt;
	}

	public void setInrtrt(BigDecimal inrtrt) {
		this.inrtrt = inrtrt;
	}

	public BigDecimal getInstam() {
		return instam;
	}

	public void setInstam(BigDecimal instam) {
		this.instam = instam;
	}
	
	public int getStacid() {
		return stacid;
	}

	public void setStacid(int stacid) {
		this.stacid = stacid;
	}

}
