package com.sunline.sunfe.loanbusihangup;

import java.util.HashMap;
import java.util.List;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.JsonUtil;
import com.sunline.jraf.util.Log;
import com.sunline.jraf.util.StringUtil;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.Sequence;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.suncm.util.PubUtil;

public class LoanBusiHangUpActor extends Actor {

	private String MYBATIS_NS = "com.sunline.suncm.mybatis.loanbusiwrongaccount.";

	/**
	 * ������ˮ���˲�ѯ
	 * 
	 * @Title: getHangUpList
	 * @throws JDOMException
	 * @return: void
	 */
	@SuppressWarnings({ "unchecked" })
	public void getHangUpList() throws JDOMException, BimisException {
		HashMap<String, String> hashmap = (HashMap<String, String>) req
				.getReqDataMap();
		String stacid = SessionParaUtils.getStacid();
		hashmap.put("stacid", stacid);
		hashmap.put("status", "2");
		String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
		hashmap.put("glisdt", glisdt);
		
		Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS
				+ "getHangUplistPage", req.getReqPageInfo(), hashmap);
		req.addRspData(e.removeContent());
		if (hashmap.get("tranbr") != null
				&& !hashmap.get("tranbr").toString().trim().equals("")) {
			req.addRspData("tranbr", hashmap.get("tranbr"));
		}
		req.addRspData("glisdt", glisdt);
	}

	/**
	 * ������ˮ���˹���
	 * 
	 * @Title: hungUpLoanBusi
	 * @throws JDOMException
	 * @throws BimisException
	 * @return: void
	 */
	@SuppressWarnings("unchecked")
	public void hungUpLoanBusi() throws JDOMException, BimisException {
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req
					.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			hashmap.put("stacid", stacid);
			hashmap.put("status", "2");
			String glisdt = PubUtil.getGlisdt(Integer.parseInt(stacid.trim()));
			commonDao.beginTransaction();
			/*
			 * �޸�loan_busiҪ���������״̬Ϊ1
			 */
			commonDao.updateByNamedSql(MYBATIS_NS + "updateLoanBusiStatus",
					hashmap);

			/*
			 * �������������Ϣ�������ݹ������busi_hang
			 */
			List list = commonDao.queryByNamedSqlForList(MYBATIS_NS
					+ "queryWrong", hashmap);//

			String wrongJsonStr = JsonUtil.convertObject2Json(list);
			
			hashmap.put("wrongJsonStr", wrongJsonStr);
			hashmap.put("status", "0");
			hashmap.put("tablcd", "loan_busi");

			commonDao
					.insertByNamedSql(MYBATIS_NS + "insertToBusiHang", hashmap);
			
			commonDao.commitTransaction();
			req.addRspData("retCode", "200");// ��Ӧ����
			req.addRspData("retMessage", "�����ɹ�");// ��Ӧ��Ϣ
		} catch (Exception e) {
			commonDao.rollBack();
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ��");
			getLog().logError(e);
		}

	}

	
	
	
}
