package com.sunline.sunfe.glisfund;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.suncm.util.PcmcKnpParaUtils;
import com.sunline.sunfe.util.MybatisPathUtil;
import com.sunline.sunfe.util.StringUtils;

/**
 * @author ����
 * @Email xiongl@sunline.cn
 * @Time 2018��1��3��
 * @��������ã��ϴ����¼
 */
@SuppressWarnings("unchecked")
public class FmpCntrAebsAction extends Actor {
	private static final Logger logger = LoggerFactory.getLogger(FmpCntrAebsAction.class);

	/**
	 * @throws JDOMException
	 * @�˷��������ã���ѯ�ϴ����¼
	 */
	public void queryFmpCntrAebsInfo() throws JDOMException {
		try {
			Map<String, Object> map = req.getReqDataMap();
			String pageNo = req.getReqDataStr("pageNum");
			if (StringUtils.isNotEmpty(pageNo))
				req.setReqPageNo(Integer.parseInt(pageNo));
			Element e = commonDao.queryByNamedSqlWithPage(MybatisPathUtil.FMP_CNTR_AEBS + "queryFmpCntrAebsInfolistPage", req.getReqPageInfo(), map);
			req.addRspData(e.removeContent());
			new PublicFmbCntrInfoUtil(commonDao).addReqInfoTo(map, req);
		} catch (JDOMException | BimisException e) {
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "��ѯʧ��" + e.getMessage());
		}
	}

	/**
	 * @throws JDOMException
	 * @�˷��������ã������ϴ����¼
	 */
	public void addFmpCntrAebs() throws JDOMException {
		try {
			Map<String, String> map = req.getReqDataMap();
			String aebscdna = PcmcKnpParaUtils.getPcmcKnpParaDataByParacd("fe", "aebscd", map.get("aebscd"));
			String aebslvna = PcmcKnpParaUtils.getPcmcKnpParaDataByParacd("fe", "aebslv", map.get("aebslv"));
			Map mapFmpCntrAebs = commonDao.getSqlSession().selectOne(MybatisPathUtil.FMP_CNTR_AEBS + "queryFmpCntrAebsInfolistPage", map);
			if (null != mapFmpCntrAebs) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", MessageFormat.format("�������Ϊ[{0}]�ϴ��½�㼶Ϊ[{1}]�ķ�¼�����Ѿ�����", aebscdna, aebslvna));
				return;
			}

			String aebscd = req.getReqDataStr("aebscd");

			String aebsna = PcmcKnpParaUtils.getPcmcKnpParaDataByParacd("fe", "aebscd", aebscd);
			map.put("aebsna", aebsna);
			commonDao.insertByNamedSql(MybatisPathUtil.FMP_CNTR_AEBS + "insertFmpCntrAebs", map);
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "���ӳɹ���");
			req.addRspData("callbackType", "closeCurrent");
		} catch (Exception e) {
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "����ʧ��" + e.getMessage());
		}
	}

	/**
	 * @throws JDOMException
	 * @�˷��������ã�ɾ���ϴ����¼
	 */
	public void deleteFmpCntrAebs() throws JDOMException {
		try {
			Map<String, String> map = req.getReqDataMap();
			commonDao.deleteByNamedSql(MybatisPathUtil.FMP_CNTR_AEBS + "deleteFmpCntrAebs", map);
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "ɾ���ɹ���");
		} catch (JDOMException | BimisException e) {
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "ɾ��ʧ��" + e.getMessage());
		}
	}

	/**
	 * @throws JDOMException
	 * @�˷��������ã��޸��ϴ����¼
	 */
	public void updateFmpCntrAebs() throws JDOMException {
		try {
			Map<String, String> map = req.getReqDataMap();
			commonDao.queryByNamedSql(MybatisPathUtil.FMP_CNTR_AEBS+"queryFmpCntrAebsInfolistPage", map);
			int updeate=commonDao.updateByNamedSql(MybatisPathUtil.FMP_CNTR_AEBS + "updateFmpCntrAebs", map);
			if(updeate==0) {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "û����Ҫ�޸ĵ����ݣ�");
				req.addRspData("callbackType", "closeCurrent");
			}
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�޸ĳɹ���");
			req.addRspData("callbackType", "closeCurrent");
		} catch (JDOMException | BimisException e) {
			logger.error(e.getMessage());
			req.addRspData("retCode", "300");
			req.addRspData("retMessage", "�޸�ʧ��" + e.getMessage());
		}
	}
}
