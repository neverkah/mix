package com.sunline.sunfe.conf;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.sunline.jraf.services.Actor;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.SessionParaUtils;

/**
 * ����ͼ��
 * 
 */
public class ClpConfActor extends Actor {

	private static final String CLPCONF = "com.sunline.sunfe.mybatis.clpconf.";

	/**
	 * ��ҳ��ѯ����ͼ��
	 * 
	 * @throws JDOMException
	 */
	@SuppressWarnings("unchecked")
	public void getClpConfList() throws JDOMException {
		try {
			Map<String, Object> paramMap = req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			paramMap.put("stacid", stacid);
			Element e = commonDao.queryByNamedSqlWithPage(CLPCONF
					+ "quereClpConflistPage", req.getReqPageInfo(), paramMap);
			req.addRspData(e.removeContent());
		} catch (Exception e) {
			getLog().logError(e);
		}
	}

	/**
	 * ��������ͼ��
	 * 
	 * @throws JDOMException
	 */
	public void addClpConf() throws JDOMException {
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			commonDao.beginTransaction();
			String stacid = SessionParaUtils.getStacid();
			String clerod = req.getReqDataStr("clerod");
			String clerty = req.getReqDataStr("clerty");
			String clerbr = req.getReqDataStr("clerbr");
			String brchtp = req.getReqDataStr("brchtp");
			String crcycds="";
			List<String> crcycdList = req.getReqDataTexts("crcycd");
			if(crcycdList!=null&&crcycdList.size()>0){
				for(String crcycd:crcycdList){
					crcycds=crcycds+crcycd+"=";
				}
				crcycds=crcycds.substring(0, crcycds.length()-1);
			}else{
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "����ʧ�ܣ�����δѡ��");
				return;
			}
			
			List<String> rowNo_list = req.getReqDataTexts("rowNo");//

			if(rowNo_list.size()>0&&rowNo_list!=null){
				boolean flag=false;
			    	for(int i=0;i<rowNo_list.size();i++){
			    		hashmap.clear();
						hashmap.put("stacid", stacid);
						hashmap.put("clerod", clerod);
						hashmap.put("clerty", clerty);
						hashmap.put("clerbr", clerbr);
						hashmap.put("brchtp", brchtp);
		    		    String brchcd = req.getReqDataStr("brchcd"+rowNo_list.get(i));//
					  
						hashmap.put("brchcd", brchcd);
						@SuppressWarnings("unchecked")
						List<Map<String, String>>  lists=(List<Map<String, String>>) commonDao.queryByNamedSqlForList(CLPCONF + "selectByPrimaryKey",hashmap);
						for(Map<String, String> map:lists) {
							String crcycd=map.get("crcycd");
							if(!StringUtils.isEmpty(crcycd)){
								if(crcycd.indexOf("=")>0){
									String[] temp=crcycd.split("=");
									for(String cell:temp){
										if(crcycdList.contains(cell)){
											flag=true;
											break;
										}
									}
								}else{
									if(crcycdList.contains(crcycd)){
										flag=true;
									}
								}
							}
							if(flag){
								req.addRspData("retCode", "300");
								req.addRspData("retMessage", "����ʧ�ܣ�������ͼ���Ѵ���");
								return;
							}
						}
						hashmap.put("crcycd", crcycds);
						commonDao.insertByNamedSql(CLPCONF + "insert", hashmap);
				   }
			   }
			ResultUtils.setRspData(req, "200", "�����ɹ�", "ClpConf", "closeCurrent");
			commonDao.commitTransaction();
		} catch (Exception e) {
			commonDao.rollBack();
			getLog().logError(e);
			ResultUtils.setRspData(req, "300", "����ʧ��", "");
		}
	}

	/**
	 * ɾ������ͼ��
	 */
	public void deleteClpConf() {
		try {
			List<?> parampList = this.req.getReqDataTexts("paramp");
			if ((parampList != null) && (parampList.size() > 0)) {
				this.commonDao.beginTransaction();
				for (int i = 0; i < parampList.size(); ++i) {
					String paramp = (String) parampList.get(i);
					String[] split = paramp.split("-");
					int stacid = Integer.parseInt(split[0]);
					String brchcd = split[1];
					HashMap<String, Object> hashmap = new HashMap<String, Object>();
					hashmap.put("stacid", stacid);
					hashmap.put("brchcd", brchcd);
					hashmap.put("crcycd", split[2]);
					this.commonDao.deleteByNamedSql(CLPCONF
							+ "deleteByPrimaryKey", hashmap);
				}
				this.commonDao.commitTransaction();
				ResultUtils.setRspData(req, "200", "�����ɹ�", "", "");
			}
		} catch (Exception e) {
			this.commonDao.rollBack();
			ResultUtils.setRspData(req, "200", "����ʧ��", "", "");
			getLog().logError(e);
		}
	}

	/**
	 * ��������ͼ��
	 * 
	 * @throws JDOMException
	 */
	@SuppressWarnings("unchecked")
	public void updateClpConf() throws JDOMException {
		try {
			Map<String, Object> paramMap = req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			paramMap.put("stacid", stacid);
			String crcycds="";
			List<String> crcycdList = req.getReqDataTexts("crcycd");
			if(crcycdList!=null&&crcycdList.size()>0){
				for(String crcycd:crcycdList){
					crcycds=crcycds+crcycd+"=";
				}
				crcycds=crcycds.substring(0, crcycds.length()-1);
			}else{
				req.addRspData("retCode", "300");
				req.addRspData("retMessage", "����ʧ�ܣ�����δѡ��");
				return;
			}
			HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap.put("stacid", stacid);
			hashmap.put("brchcd",  req.getReqDataStr("brchcd"));
			hashmap.put("oldcrcycd",  req.getReqDataStr("oldcrcycd"));
			List<Map<String, String>>  lists=(List<Map<String, String>>) commonDao.queryByNamedSqlForList(CLPCONF + "selectByPrimaryKey",hashmap);
			for(Map<String, String> map:lists) {
				boolean flag=false;
				String crcycd=map.get("crcycd");
				if(!StringUtils.isEmpty(crcycd)){
					if(crcycd.indexOf("=")>0){
						String[] temp=crcycd.split("=");
						for(String cell:temp){
							if(crcycdList.contains(cell)){
								flag=true;
								break;
							}
						}
					}else{
						if(crcycdList.contains(crcycd)){
							flag=true;
						}
					}
				}
				if(flag){
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "����ʧ�ܣ�������ͼ���Ѵ���");
					return;
				}
			}
			paramMap.put("crcycd", crcycds);
			commonDao
					.updateByNamedSql(CLPCONF + "updateByPrimaryKey", paramMap);
			ResultUtils.setRspData(req, "200", "�����ɹ�", "ClpConf", "closeCurrent");
		} catch (Exception e) {
			getLog().logError(e);
			ResultUtils.setRspData(req, "300", "����ʧ��", "", "");
		}
	}

	/**
	 * ������ѯ����ͼ��
	 */
	@SuppressWarnings("unchecked")
	public void selectClpConfByPrimaryKey() throws JDOMException {
		try {
			Map<String, Object> paramMap = req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			paramMap.put("stacid", stacid);
			Element e = commonDao.queryByNamedSql(CLPCONF
					+ "selectByPrimaryKey", paramMap);
			if(e!=null&&e.getChild("Record")!=null){
				String crcycds=e.getChild("Record").getChildText("crcycd");
				req.addRspData("oldcrcycd",crcycds);
			}
			req.addRspData(e.removeContent());
		} catch (Exception e) {
			getLog().logError(e);
			ResultUtils.setRspData(req, "300", "����ʧ��", "", "closeCurrent");
		}
	}

	/**
	 * ������ɾ������ͼ��
	 * 
	 * @throws JDOMException
	 */
	@SuppressWarnings("unchecked")
	public void deleteClpConfByPrimaryKey() throws JDOMException {
		try {
			Map<String, Object> paramMap = req.getReqDataMap();
			String stacid = SessionParaUtils.getStacid();
			paramMap.put("stacid", stacid);
			commonDao
					.deleteByNamedSql(CLPCONF + "deleteByPrimaryKey", paramMap);
			ResultUtils.setRspData(req, "200", "�����ɹ�", "");
		} catch (Exception e) {
			getLog().logError(e);
			ResultUtils.setRspData(req, "300", "����ʧ��", "", "closeCurrent");
		}
	}

}
