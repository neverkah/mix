package com.sunline.sunfe.base;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.jraf.util.StringUtil;
import com.sunline.suncm.util.PcmcKnpParaUtils;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.util.StringUtils;

public class PrtpAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.prtp.";
	Log log = new Log("PrtpAction");

	/**
	 * ��ѯϵͳ���������� & queryPrtpListPage
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void queryPrtpListPage() throws BimisException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String prgptp = StringUtils.repalceCharecter(hashmap.get("prgptp"));
			hashmap.put("prgptp", prgptp);
			hashmap.put("vermod", "0");
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryPrtplistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			log.logError(e);
		}
		
	}
	
	/**
	 * ���Ҵ���
	 * ��ѯ�����嵥 & queryPrtpSearch
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void queryPrtpSearch() throws JDOMException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("vermod", "0");
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryPrtpSearchlistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (Exception e) {
			log.logError(e);
		}
		
	}
	
	/**
	 * ���ݹ�������proftp���ҹ���������Ϣ
	 */
	@SuppressWarnings("unchecked")
	public void queryPrtpById()  //06����id��  �� ��¼
	{
		try 
		{
			HashMap<String, String> hashmap =(HashMap<String, String>) req.getReqDataMap();
			hashmap.put("vermod", "0");
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryPrtpById", hashmap);	
            req.addRspData(e.removeContent());        //���ؽ����װ	
            Element templateEle = commonDao.queryByNamedSql(MYBATIS_NS+"queryPropByprgptplistPage",hashmap);
            req.addRspData("Results2",templateEle.removeContent());   //���ؽ����װ
		} catch (Exception e) {
			e.printStackTrace();
		}
	 }	
	/**
	 * ���ݹ�������proftp���ҹ�����Ϣ
	 */
	@SuppressWarnings("unchecked")
	public void queryProfByprgptpListPage()  //06����id��  �� ��¼
	{
		try 
		{
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();	 
			hashmap.put("vermod", "0");
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryProfByprgptpListPage",req.getReqPageInfo(), hashmap);	
			req.addRspData(e.removeContent());        //���ؽ����װ	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	/**
	 * ����ϵͳ���������� & addPrtp
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addPrtp() throws JDOMException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();	
			HashMap<String, String> hashmap2 = new HashMap<String, String>(); //��
			commonDao.beginTransaction();
			List<String> propcd_list = req.getReqDataTexts("propcd");
			List<String> pdesctx_list = req.getReqDataTexts("pdesctx");
			List<String> smrytx_list = req.getReqDataTexts("smrytx");
			//�ж��Ƿ��Ѵ��ڹ�������
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistPrtp", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "���������ʹ���Ϊ: ["+hashmap.get("prgptp")+"]�Ѵ��ڣ�");
					return;
				}
			}
			hashmap.put("projcd", hashmap.get("projcd"));
			commonDao.insertByNamedSql(MYBATIS_NS+"insertPrtp",hashmap);
			if(propcd_list.size()!=0 && propcd_list!=null){
				for(int i=0;i<propcd_list.size();i++){
					   hashmap2.clear();
					   String propcd = propcd_list.get(i);
					   if(!"".equals(propcd)&&propcd!=null){
						   hashmap2.put("prgptp", hashmap.get("prgptp"));
						   hashmap2.put("vermod", "0");
						   hashmap2.put("module", hashmap.get("module"));
						   hashmap2.put("propcd", propcd);
						   hashmap2.put("projcd", hashmap.get("projcd"));
						   hashmap2.put("pdesctx",pdesctx_list.get(i));
						   hashmap2.put("smrytx",smrytx_list.get(i));
						 //���������Դ���propcd���ж�,�Ƿ����д��ڵ�ϵͳ������������ϸ����
							List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistProp", hashmap2);
							if(sumList!=null && sumList.size()>0) {
								Map sumMap = (HashMap)sumList.get(0);
								int sum = Integer.valueOf(sumMap.get("CC").toString());
								if(sum > 0) {
									String projectna = PcmcKnpParaUtils.getPcmcKnpParaDataByParacd("GL","GL_PROJCD", hashmap.get("projcd"));
									req.addRspData("retCode", "300");
									req.addRspData("retMessage", "���������ʹ���Ϊ: ["+hashmap.get("prgptp")+"] ���Դ���Ϊ: ["+propcd+"] ��Ŀ���Ϊ: ["+projectna+"] �Ѵ��ڣ�");
									return;
								}
							}
						   commonDao.insertByNamedSql(MYBATIS_NS+"insertProp", hashmap2);
					   }
				 }   
			  }
				ResultUtils.setRspData(req, "200",  "�����ɹ�", "prtp_main", "closeCurrent", "");
				commonDao.commitTransaction();
			} catch (BimisException e) {
				commonDao.rollBack();
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
				log.logError(e);
			}		
	}
	
	/**
	 * �޸�ϵͳ����������������Ϣ & updatePrtp
	 * @throws JDOMException 
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public void updatePrtp() throws JDOMException{
  
	try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			HashMap<String, String> hashmap2 = new HashMap<String, String>();
			commonDao.beginTransaction();
			String prgptp = req.getReqDataStr("prgptp");//ϵͳ����������
			String prgpna = req.getReqDataStr("prgpna");//��������������
			String prtpkd = req.getReqDataStr("prtpkd");//��������������
			String desctx = req.getReqDataStr("desctx");//˵��
			String module = req.getReqDataStr("module");//ģ��
			String projcd = req.getReqDataStr("projcd");//��Ŀ���
			
			String delpropcd = req.getReqDataStr("delpropcd");
			
			List<String> propcd_list = req.getReqDataTexts("propcd");
			List<String> pdesctx_list = req.getReqDataTexts("pdesctx");
			List<String> smrytx_list = req.getReqDataTexts("smrytx");

			hashmap.put("prgptp", prgptp.trim());
			hashmap.put("prgpna", prgpna.trim());
			hashmap.put("prtpkd", prtpkd);
			hashmap.put("desctx", desctx.trim());
			hashmap.put("module", module);
			hashmap.put("projcd", projcd);	
			
			//����ϵͳ��������������
		    commonDao.updateByNamedSql(MYBATIS_NS+"updatePrtp", hashmap);	
			hashmap.put("vermod", "0");
			commonDao.insertByNamedSql(MYBATIS_NS+"insertPrtp",hashmap);

		    commonDao.updateByNamedSql(MYBATIS_NS+"updatePrtpDetl", hashmap);	
		    
		    if(propcd_list.size()!=0 && propcd_list!=null){
				for(int i=0;i<propcd_list.size();i++){
					   hashmap2.clear();
					   String propcd = propcd_list.get(i);
					   if(!"".equals(propcd)&&propcd!=null){
						   hashmap2.put("prgptp", prgptp);
						   hashmap2.put("vermod", "0");
						   hashmap2.put("module", module);
						   hashmap2.put("propcd", propcd);
						   hashmap2.put("projcd", projcd);
						   hashmap2.put("pdesctx",pdesctx_list.get(i));
						   hashmap2.put("smrytx",smrytx_list.get(i));
						 //���������Դ���propcd���ж�,�Ƿ����д��ڵ�ϵͳ������������ϸ����
							List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistProp", hashmap2);
							if(sumList!=null && sumList.size()>0) {
								Map sumMap = (HashMap)sumList.get(0);
								int sum = Integer.valueOf(sumMap.get("CC").toString());
								if(sum > 0) {
									String projectna = PcmcKnpParaUtils.getPcmcKnpParaDataByParacd("GL","GL_PROJCD",projcd);
									req.addRspData("retCode", "300");
									req.addRspData("retMessage", "���������ʹ���Ϊ: ["+prgptp+"] ���Դ���Ϊ: ["+propcd+"] ��Ŀ���Ϊ: ["+projectna+"] �Ѵ��ڣ�");
									return;
								}
							}
						    commonDao.insertByNamedSql(MYBATIS_NS+"insertProp", hashmap2);
					   }
				 }   
			  }
		     //ɾ����Ʒ��������ϸʱ��ɾ�����������ñ�sys_dtit_map
		     if(!StringUtil.isNullOrEmpty(delpropcd)){
		    	 String [] propcds = delpropcd.split(",");
		    	 for(String propcd:propcds){
		    		 commonDao.deleteByNamedSql(MYBATIS_NS+"delRelDtitMap", propcd);
		    	 }
		     }
				ResultUtils.setRspData(req, "200",  "�����ɹ�", "prtp_main", "closeCurrent", "");
			    commonDao.commitTransaction();
			} catch (BimisException e) {
				commonDao.rollBack();
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
				log.logError(e);
			}		
	}
	/**
	 * ɾ��ϵͳ������������Ϣ & deletePrtp
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void deletePrtp() throws JDOMException{
		try {
			String prgptpList = req.getReqDataStr("prgptps");
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String [] prgptpArray = prgptpList.split(",");
			String stacid = SessionParaUtils.getStacid();
			commonDao.beginTransaction();
			for (int i=0;i<prgptpArray.length;i++) {
				hashmap.clear();	            	  	            	 
           	    String [] array = prgptpArray[i].split("-");	
				hashmap.put("prgptp", array[0]);
				hashmap.put("projcd", array[1]);
				hashmap.put("stacid", stacid);
				List<String>  prodcdList =  (List<String>) 
						commonDao.queryByNamedSqlForList(MYBATIS_NS+"getSysDtitProdByPrgp", hashmap);
				//ɾ�������Ĳ�Ʒ��������
				for (Iterator iterator = prodcdList.iterator(); iterator.hasNext();) {
					String prodcd = (String) iterator.next();
					hashmap.put("prodcd", prodcd);
					commonDao.deleteByNamedSql(MYBATIS_NS+"deleteSysDtitConfByPrgp", hashmap);
					commonDao.deleteByNamedSql(MYBATIS_NS+"deleteSysDtitMapByPrgp", hashmap);
				}
				commonDao.deleteByNamedSql(MYBATIS_NS+"deletePrtpByTp", hashmap);
				commonDao.deleteByNamedSql(MYBATIS_NS+"deletePropByTp", hashmap);
			}
			
			commonDao.commitTransaction();
			ResultUtils.setRspData(req, "200",  "�����ɹ�", "prtp_main", "", "");
		} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
		}		
	}
	/**
	 * ��ѯ���Թ����ĺ������ñ�sys_dtit_map
	 * @Title: getProDtitMapByPrtp 
	 * @date: 2018-3-12 ����2:38:29 
	 * @return: void
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void getProDtitMapByPrtp(){
		try{
			 String resultMsg = "";
			 String prodnas = "";
			 HashMap<String,String> param = (HashMap<String, String>) req.getReqDataMap();
			 List<String>  prodnaList =  (List<String>) 
					commonDao.queryByNamedSqlForList(MYBATIS_NS+"getProDtitMapByPrtp", param);
			 if(prodnaList.size()>0){
				 for (Iterator iterator = prodnaList.iterator(); iterator.hasNext();) {
					String prodna = (String) iterator.next();
					prodnas +=prodna+"��";
				  }
				  resultMsg ="��Ʒ"+prodnas.substring(0, prodnas.length()-1)+"��ʹ������"+param.get("propcd")+"�����˺�����룬��"+prodnaList.size()+"���������������һ��ɾ�����Ƿ�ȷ��ɾ����";
			 }
			 ResultUtils.setRspData(req, "200", resultMsg ,"", "", "");
		}catch (Exception e) {
			ResultUtils.setRspData(req, "300",  "����ʧ��!","", "", "");
			log.logError(e);
		}
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void getSysDtitConfByPrtp() throws JDOMException{
		 try {
			String resultMsg = "";
			String prodnas = "";
			HashMap<String,String> param = (HashMap<String, String>) req.getReqDataMap();
			List<String>  prodnaList =  (List<String>) 
						commonDao.queryByNamedSqlForList(MYBATIS_NS+"getSysDtitConfByPrtp", param);
			if(prodnaList.size()>0){
				 for (Iterator iterator = prodnaList.iterator(); iterator.hasNext();) {
					String prodna = (String) iterator.next();
					prodnas +=prodna+"��";
				  }
				  resultMsg ="��Ʒ"+prodnas.substring(0, prodnas.length()-1)+"��ʹ��������"+param.get("prgptp")+"�����˺�����룬��"+prodnaList.size()+"���������������һ��ɾ�����Ƿ�ȷ��ɾ����";
			 }
			ResultUtils.setRspData(req, "200", resultMsg ,"", "", "");
		} catch (BimisException e) {
			ResultUtils.setRspData(req, "300",  "����ʧ��!","", "", "");
			log.logError(e);
		}
		
	}
}
