package com.sunline.sunfe.util;

import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.JrafSession;

/**
 * COM_PARA ���ײ����� ȡֵ������
 * 
 * @author zhangdq
 * 
 */
public class ComParaUtil {

	private static Log log = LogFactory.getLog(ComParaUtil.class);

	/**
	 * 
	 * @param stacid
	 *            ����id
	 * @param parana
	 *            ������
	 * @return
	 * @throws BimisException
	 */
	public static String getParavl(String stacid, String parana)
			throws BimisException {
		CommonDao commonDao = new CommonDao(JrafSession.getCurrentRootSession());
		// ����ֵ
		String paravl = null;
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap.put("stacid", stacid);
			hashmap.put("parana", parana);
			Element element = commonDao.queryByNamedSql(
					"com.sunline.sunfe.mybatis.compara.getComPara", hashmap);
			if (element.getChild("Record") != null) {
				paravl = element.getChild("Record").getChildTextNormalize(
						"paravl");
			}
		} catch (Exception e) {
			log.error("��ȡ���ײ���ʧ��", e);
		}
		return paravl;
	}
}
