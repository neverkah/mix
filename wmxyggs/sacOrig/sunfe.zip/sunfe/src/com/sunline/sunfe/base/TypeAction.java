package com.sunline.sunfe.base;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.services.Actor;
import com.sunline.sunfe.util.StringUtils;

/**
 * ��Ŀ���������� & TypeAction
 *
 */
public class TypeAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.type.";
	
	/**
	 * ��ѯ��Ʒ����嵥 & queryTypeListPage
	 */
	public void queryTypeListPage(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String typena = req.getReqDataStr("typena");//�������
			String typecd = req.getReqDataStr("typecd");//������
			String usedtg = req.getReqDataStr("usedtg");//ʹ��״̬
			String pageNo = req.getReqDataStr("pageNum");
			
			
			if (StringUtils.isNotEmpty(pageNo)) {
				req.setReqPageNo(Integer.parseInt(pageNo));
			}
			hashmap.put("typena", typena);
			hashmap.put("typecd", typecd);
			hashmap.put("usedtg", usedtg);
			
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryTypelistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			e.printStackTrace();
		}
		
	}
	/**
	 * ���Ҵ���
	 * ��ѯ��Ʒ����嵥 & queryTypeSearch
	 */
	public void queryTypeSearch(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String typena = req.getReqDataStr("typena");//�������
			String systid = req.getReqDataStr("systid");//Դϵͳ
			String typecd = req.getReqDataStr("typecd");//������
			String pageNo = req.getReqDataStr("pageNum");
			
			
			if (StringUtils.isNotEmpty(pageNo)) {
				req.setReqPageNo(Integer.parseInt(pageNo));
			}
			hashmap.put("typena", typena);
			hashmap.put("typecd", typecd);
			hashmap.put("systid", systid);
			
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryTypeSearchlistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * �����������ѯ��Ʒ������� & queryTypeInfo
	 */
	public void queryTypeInfo(){
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String typecd = req.getReqDataStr("typecd");
			String prtp01 = req.getReqDataStr("prtp01");
			String prtp02 = req.getReqDataStr("prtp02");
			String prtp03 = req.getReqDataStr("prtp03");
			String prtp04 = req.getReqDataStr("prtp04");
			String prtp05 = req.getReqDataStr("prtp05");

			hashmap.put("typecd", typecd);
			hashmap.put("prtp01", prtp01);
			hashmap.put("prtp02", prtp02);
			hashmap.put("prtp03", prtp03);
			hashmap.put("prtp04", prtp04);
			hashmap.put("prtp05", prtp05);
			
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryTypeInfo",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			e.printStackTrace();
		}
		
	}
	/**
	 * ������Ʒ��� & addType
	 */
	public void addType(){
			
			try {
				HashMap<String, String> hashmap = new HashMap<String, String>();
				commonDao.beginTransaction();
				
				String typecd = req.getReqDataStr("typecd");//������
				String typena = req.getReqDataStr("typena");//�������
				String patype = req.getReqDataStr("patype");//����������
				String detltg = req.getReqDataStr("detltg");//ĩ����ʶ
				String usedtg = req.getReqDataStr("usedtg");//ʹ��״̬
				String systid = req.getReqDataStr("systid");//Դϵͳ����
				String prodcd = req.getReqDataStr("prodcd");//��Ȳ�Ʒ����
				String prodna = req.getReqDataStr("prodna");//��Ʒ����
				String desctx = req.getReqDataStr("desctx");//����˵��
				String prtp01 = req.getReqDataStr("prtp01");
				String prtp03 = req.getReqDataStr("prtp03");
				String prtp04 = req.getReqDataStr("prtp04");
				String prtp05 = req.getReqDataStr("prtp05");
				String prtp02 = req.getReqDataStr("prtp02");
				
				hashmap.put("typecd", typecd);
				hashmap.put("typena", typena);
				hashmap.put("patype", patype);
				hashmap.put("detltg", detltg);
				hashmap.put("systid", systid);
				hashmap.put("usedtg", usedtg);
				hashmap.put("prodcd", prodcd);
				hashmap.put("prodna", prodna);
				hashmap.put("desctx", desctx);
				hashmap.put("prtp01", prtp01);
				hashmap.put("prtp02", prtp02);
				hashmap.put("prtp03", prtp03);
				hashmap.put("prtp04", prtp04);
				hashmap.put("prtp05", prtp05);
				
				List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistType", hashmap);
				if(countList!=null && countList.size()>0) {
					Map countMap = (HashMap)countList.get(0);
					int count = Integer.valueOf(countMap.get("CC").toString());
					if(count > 0) {
						req.addRspData("retCode", "300");
						req.addRspData("retMessage", "��Ʒ�������Ѵ��ڣ�");
						return;
					}
				}
				
				commonDao.insertByNamedSql(MYBATIS_NS+"addType", hashmap);
				req.addRspData("retCode", "200");
				req.addRspData("retMessage", "�����ɹ�");
				req.addRspData("navTabId", "");
				req.addRspData("callbackType", "closeCurrent");
				req.addRspData("forwardUrl", "");
				commonDao.commitTransaction();
				
			} catch (Exception e) {
				commonDao.rollBack();
				e.printStackTrace();
			}	
		}
	
	public void updateType(){
		
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			commonDao.beginTransaction();
			
			String typecd = req.getReqDataStr("typecd");//������
			String typena = req.getReqDataStr("typena");//�������
			String patype = req.getReqDataStr("patype");//����������
			String detltg = req.getReqDataStr("detltg");//ĩ����ʶ
			String usedtg = req.getReqDataStr("usedtg");//ʹ��״̬
			String systid = req.getReqDataStr("systid");//Դϵͳ����
			String prodcd = req.getReqDataStr("prodcd");//��Ȳ�Ʒ����
			String prodna = req.getReqDataStr("prodna");//��Ʒ����
			String desctx = req.getReqDataStr("desctx");//����˵��
			String prtp01 = req.getReqDataStr("prtp01");
			String prtp03 = req.getReqDataStr("prtp03");
			String prtp04 = req.getReqDataStr("prtp04");
			String prtp05 = req.getReqDataStr("prtp05");
			String prtp02 = req.getReqDataStr("prtp02");
			
			hashmap.put("typecd", typecd);
			hashmap.put("typena", typena);
			hashmap.put("patype", patype);
			hashmap.put("detltg", detltg);
			hashmap.put("systid", systid);
			hashmap.put("usedtg", usedtg);
			hashmap.put("prodcd", prodcd);
			hashmap.put("prodna", prodna);
			hashmap.put("desctx", desctx);
			hashmap.put("prtp01", prtp01);
			hashmap.put("prtp02", prtp02);
			hashmap.put("prtp03", prtp03);
			hashmap.put("prtp04", prtp04);
			hashmap.put("prtp05", prtp05);
			
			
			commonDao.insertByNamedSql(MYBATIS_NS+"updateType", hashmap);
			commonDao.commitTransaction();
			req.addRspData("retCode", "200");
			req.addRspData("retMessage", "�����ɹ�");
			req.addRspData("navTabId", "type_main");
			req.addRspData("callbackType", "closeCurrent");
			req.addRspData("forwardUrl", "");
		} catch (Exception e) {
			commonDao.rollBack();
			try {
				req.addRspData("retCode", "300");
				req.addRspData("retMessage",e.toString().substring(e.toString().lastIndexOf("Cause")));
				req.addRspData("navTabId", "type_main");
				req.addRspData("callbackType", "closeCurrent");
				req.addRspData("forwardUrl", "");
			} catch (JDOMException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		  }
	}
	
	/**
	 * ɾ����Ʒ�����Ϣ & deleteType
	 */
	public void deleteType(){
		try {
			List<String> typecdList = req.getReqDataTexts("typecds");
			if (typecdList != null && typecdList.size() > 0) {
				commonDao.beginTransaction();
				HashMap<String, List<String>> hashmap = new HashMap<String, List<String>>();
				hashmap.put("typecdList", typecdList);
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteType", hashmap);
				}
				commonDao.commitTransaction();
				req.addRspData("retCode", "200");
				req.addRspData("retMessage", "�����ɹ�");
				req.addRspData("navTabId", "type_main");
				req.addRspData("callbackType", "closeCurren");
				req.addRspData("forwardUrl", "");
		} catch (Exception e) {
			try {
				commonDao.rollBack();
				req.addRspData("retCode", "300");
				req.addRspData("retMessage",e.toString().substring(e.toString().lastIndexOf("Cause")));
				req.addRspData("navTabId", "type_main");
				req.addRspData("callbackType", "");
				req.addRspData("forwardUrl", "");
			} catch (JDOMException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}
} 
