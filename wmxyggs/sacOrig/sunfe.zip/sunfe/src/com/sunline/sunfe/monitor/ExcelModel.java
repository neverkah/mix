package com.sunline.sunfe.monitor;  

import java.util.ArrayList;
import java.util.List;

import org.jdom.Element;
  
public class ExcelModel {  
    /** 
     * @Description: excel��sheet���������� 
     */  
    private String sheetName;  
    
    /** 
     * @Description: ��Ҫ���ɵ�excel�ĵ�һ���ֶ� 
     */  
    private ArrayList<String> excelHeader;  
    
    /** 
     * @Description: ��Ҫ����excel������
     */  
    private List<Element> excelData; 
    
    
    public String getSheetName() {  
        return sheetName;  
    }  
    public void setSheetName(String sheetName) {  
        this.sheetName = sheetName;  
    }  
    
    public ArrayList<String> getExcelHeader() {  
        return excelHeader;  
    }  
    public void setExcelHeader(ArrayList<String> excelHeader) {  
        this.excelHeader = excelHeader;  
    }  
  
    public List<Element> getExcelData() {  
        return excelData;  
    }  
    public void setExcelData(List<Element> excelData) {  
        this.excelData = excelData;  
    }  
}  