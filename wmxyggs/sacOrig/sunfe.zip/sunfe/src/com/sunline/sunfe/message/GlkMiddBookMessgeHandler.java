package com.sunline.sunfe.message;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.JrafSession;
import com.sunline.suncm.util.JrafSessionUtil;
import com.sunline.suncm.util.StringUtils;
import com.sunline.sundp.gw.base.server.DealMessageImpl;
import com.sunline.sundp.gw.base.util.PropList;

/**
 * @ClassName: GlkMiddBook
 * @Description: ������Ŀ�����
 * @author: huangzhongjie
 * @date: 2017��11��14�� ����2:18:35
 */

public class GlkMiddBookMessgeHandler implements DealMessageImpl {

	private String MY_BATIS_NS_GLKMIDDBOOK = "com.sunline.sunfe.mybatis.glkmiddbook.";

	@Override
	public Map dealMessage(Map message) {

		JrafSession jrafSession = null;

		try {
			jrafSession = JrafSessionUtil.getJrafSession(null);

			CommonDao commonDao = new CommonDao(jrafSession);

			Map hashMapParam = new HashMap();
			if (null != message.get("stacid")) {
				hashMapParam.put("stacid", Integer.valueOf(message.get("stacid").toString()));
			}

			if (null != message.get("trandt")) {
				hashMapParam.put("trandt", message.get("trandt").toString());
			}

			if (null != message.get("systid")) {
				hashMapParam.put("systid", message.get("systid").toString());
			}

			List<Map> glkMiddBookSummList = commonDao.getSqlSession().selectList(
					MY_BATIS_NS_GLKMIDDBOOK + "getGlkMiddBookSummList", hashMapParam);
			PropList propList = new PropList();

			for (Map map : glkMiddBookSummList) {
				propList.add(map);
			}
			message.put("glkMiddBookSummList", propList);
			System.out.println("GlkMiddBookMessgeHandler end ");
		}

		finally {
			JrafSessionUtil.closeConnection(jrafSession);
		}

		return message;
	}

}
