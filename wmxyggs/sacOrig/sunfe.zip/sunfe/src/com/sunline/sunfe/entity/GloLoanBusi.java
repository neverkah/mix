package com.sunline.sunfe.entity;

import java.math.BigDecimal;

public class GloLoanBusi {
	private int stacid;
	private String systid;
	private String trandt;
	private String transq;
	private String tranbr;
	private String acctbr;
	private String prcscd;
	private String trantp;
	private String crcycd;
	private String loantp;
	
	private BigDecimal captam = BigDecimal.ZERO;
	private BigDecimal dwinam = BigDecimal.ZERO;
	private BigDecimal chinam = BigDecimal.ZERO;
	private BigDecimal ltinam = BigDecimal.ZERO;
	
	private String toctty;
	private String vchrtp;
	private String loanno;
	private String status;
	private String loanp1;
	private String loanp2;
	private String loanp3;
	private String loanp4;
	private String loanp5;
	private String loanp6;
	private String loanp7;
	private String loanp8;
	private String loanp9;
	private String loanpa;
	private String bathid;
	/**
	 * @return the systid
	 */
	
	public String getSystid() {
		return systid;
	}
	/**
	 * @param systid the systid to set
	 */
	
	public void setSystid(String systid) {
		this.systid = systid;
	}
	/**
	 * @return the trandt
	 */
	
	public String getTrandt() {
		return trandt;
	}
	/**
	 * @param trandt the trandt to set
	 */
	
	public void setTrandt(String trandt) {
		this.trandt = trandt;
	}
	/**
	 * @return the transq
	 */
	
	public String getTransq() {
		return transq;
	}
	/**
	 * @param transq the transq to set
	 */
	
	public void setTransq(String transq) {
		this.transq = transq;
	}
	/**
	 * @return the tranbr
	 */
	
	public String getTranbr() {
		return tranbr;
	}
	/**
	 * @param tranbr the tranbr to set
	 */
	
	public void setTranbr(String tranbr) {
		this.tranbr = tranbr;
	}
	/**
	 * @return the acctbr
	 */
	
	public String getAcctbr() {
		return acctbr;
	}
	/**
	 * @param acctbr the acctbr to set
	 */
	
	public void setAcctbr(String acctbr) {
		this.acctbr = acctbr;
	}
	/**
	 * @return the prcscd
	 */
	
	public String getPrcscd() {
		return prcscd;
	}
	/**
	 * @param prcscd the prcscd to set
	 */
	
	public void setPrcscd(String prcscd) {
		this.prcscd = prcscd;
	}
	/**
	 * @return the trantp
	 */
	
	public String getTrantp() {
		return trantp;
	}
	/**
	 * @param trantp the trantp to set
	 */
	
	public void setTrantp(String trantp) {
		this.trantp = trantp;
	}
	/**
	 * @return the crcycd
	 */
	
	public String getCrcycd() {
		return crcycd;
	}
	/**
	 * @param crcycd the crcycd to set
	 */
	
	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}
	/**
	 * @return the loantp
	 */
	
	public String getLoantp() {
		return loantp;
	}
	/**
	 * @param loantp the loantp to set
	 */
	
	public void setLoantp(String loantp) {
		this.loantp = loantp;
	}
	/**
	 * @return the captam
	 */
	
	/**
	 * @return the toctty
	 */
	
	public String getToctty() {
		return toctty;
	}
	/**
	 * @param toctty the toctty to set
	 */
	
	public void setToctty(String toctty) {
		this.toctty = toctty;
	}
	/**
	 * @return the vchrtp
	 */
	
	public String getVchrtp() {
		return vchrtp;
	}
	/**
	 * @param vchrtp the vchrtp to set
	 */
	
	public void setVchrtp(String vchrtp) {
		this.vchrtp = vchrtp;
	}
	/**
	 * @return the loanno
	 */
	
	public String getLoanno() {
		return loanno;
	}
	/**
	 * @param loanno the loanno to set
	 */
	
	public void setLoanno(String loanno) {
		this.loanno = loanno;
	}
	/**
	 * @return the status
	 */
	
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the loanp1
	 */
	
	public String getLoanp1() {
		return loanp1;
	}
	/**
	 * @param loanp1 the loanp1 to set
	 */
	
	public void setLoanp1(String loanp1) {
		this.loanp1 = loanp1;
	}
	/**
	 * @return the loanp2
	 */
	
	public String getLoanp2() {
		return loanp2;
	}
	/**
	 * @param loanp2 the loanp2 to set
	 */
	
	public void setLoanp2(String loanp2) {
		this.loanp2 = loanp2;
	}
	/**
	 * @return the loanp3
	 */
	
	public String getLoanp3() {
		return loanp3;
	}
	/**
	 * @param loanp3 the loanp3 to set
	 */
	
	public void setLoanp3(String loanp3) {
		this.loanp3 = loanp3;
	}
	/**
	 * @return the loanp4
	 */
	
	public String getLoanp4() {
		return loanp4;
	}
	/**
	 * @param loanp4 the loanp4 to set
	 */
	
	public void setLoanp4(String loanp4) {
		this.loanp4 = loanp4;
	}
	/**
	 * @return the loanp5
	 */
	
	public String getLoanp5() {
		return loanp5;
	}
	/**
	 * @param loanp5 the loanp5 to set
	 */
	
	public void setLoanp5(String loanp5) {
		this.loanp5 = loanp5;
	}
	/**
	 * @return the loanp6
	 */
	
	public String getLoanp6() {
		return loanp6;
	}
	/**
	 * @param loanp6 the loanp6 to set
	 */
	
	public void setLoanp6(String loanp6) {
		this.loanp6 = loanp6;
	}
	/**
	 * @return the loanp7
	 */
	
	public String getLoanp7() {
		return loanp7;
	}
	/**
	 * @param loanp7 the loanp7 to set
	 */
	
	public void setLoanp7(String loanp7) {
		this.loanp7 = loanp7;
	}
	/**
	 * @return the loanp8
	 */
	
	public String getLoanp8() {
		return loanp8;
	}
	/**
	 * @param loanp8 the loanp8 to set
	 */
	
	public void setLoanp8(String loanp8) {
		this.loanp8 = loanp8;
	}
	/**
	 * @return the loanp9
	 */
	
	public String getLoanp9() {
		return loanp9;
	}
	/**
	 * @param loanp9 the loanp9 to set
	 */
	
	public void setLoanp9(String loanp9) {
		this.loanp9 = loanp9;
	}
	/**
	 * @return the loanpa
	 */
	
	public String getLoanpa() {
		return loanpa;
	}
	/**
	 * @param loanpa the loanpa to set
	 */
	
	public void setLoanpa(String loanpa) {
		this.loanpa = loanpa;
	}
	
	 /**
	 * @return the stacid
	 */
	 
	public int getStacid() {
		return stacid;
	}
	
	 /**
	 * @param stacid the stacid to set
	 */
	 
	public void setStacid(int stacid) {
		this.stacid = stacid;
	}
	/**
	 * @return the captam
	 */
	
	public BigDecimal getCaptam() {
		return captam;
	}
	/**
	 * @param captam the captam to set
	 */
	
	public void setCaptam(BigDecimal captam) {
		this.captam = captam;
	}
	/**
	 * @return the dwinam
	 */
	
	public BigDecimal getDwinam() {
		return dwinam;
	}
	/**
	 * @param dwinam the dwinam to set
	 */
	
	public void setDwinam(BigDecimal dwinam) {
		this.dwinam = dwinam;
	}
	/**
	 * @return the chinam
	 */
	
	public BigDecimal getChinam() {
		return chinam;
	}
	/**
	 * @param chinam the chinam to set
	 */
	
	public void setChinam(BigDecimal chinam) {
		this.chinam = chinam;
	}
	/**
	 * @return the ltinam
	 */
	
	public BigDecimal getLtinam() {
		return ltinam;
	}
	/**
	 * @param ltinam the ltinam to set
	 */
	
	public void setLtinam(BigDecimal ltinam) {
		this.ltinam = ltinam;
	}
	
	 /**
	 * @return the bathid
	 */
	 
	public String getBathid() {
		return bathid;
	}
	
	 /**
	 * @param bathid the bathid to set
	 */
	 
	public void setBathid(String bathid) {
		this.bathid = bathid;
	}

}
