package com.sunline.sunfe.entity;

import java.math.BigDecimal;



 /** 
 * @ClassName: FmbCntr 
 * @Description: ��ͬ ��Ӧ���ݿ��Fmb_Cntr
 * @author: huangzhongjie
 * @date: 2017��12��25�� ����5:05:04  
 */
 
public class FmbCntr {

	private int stacid; // ����
	private String cntrno; // ��ͬ��
	private String aplydt; // ��������
	private String aplysq; // ������ˮ
	private String brchno; // �������
	private String upprbr; // ��������
	private String userid; // �����Ա
	private String cntrtp; // ��ͬ����(1-�ϴ� 2-�½�)
	private String cntrcl; // ��ͬ���(11-�����ϴ� 12-ר���ϴ� 13-ͬҵ�ϴ� 21-�����½� 22-ר���½�
							// 23-��Ϣ�½�)
	private String crcycd; // ����
	private String termcd; // ����
	private BigDecimal instrt; // ִ������
	private BigDecimal cntram; // ��ͬ���
	private BigDecimal cntrbl; // ���
	private String bgindt; // ��Ϣ����
	private String matudt; // ������
	private String renwtg; // ��ǩ��ʶ(0-�� 1-��)
	private String transt; // ��ͬ״̬(0-�ر� 1-¼�� 2-��Ч 3-���� 9-����)
	private String acptdt; // ��������
	private String acptsq; // ������ˮ
	private String remark; // ����ժҪ
	private Long wkflid; // ����id

	public int getStacid() {
		return stacid;
	}

	public void setStacid(int stacid) {
		this.stacid = stacid;
	}

	public String getCntrno() {
		return cntrno;
	}

	public void setCntrno(String cntrno) {
		this.cntrno = cntrno;
	}

	public String getAplydt() {
		return aplydt;
	}

	public void setAplydt(String aplydt) {
		this.aplydt = aplydt;
	}

	public String getAplysq() {
		return aplysq;
	}

	public void setAplysq(String aplysq) {
		this.aplysq = aplysq;
	}

	public String getBrchno() {
		return brchno;
	}

	public void setBrchno(String brchno) {
		this.brchno = brchno;
	}

	public String getUpprbr() {
		return upprbr;
	}

	public void setUpprbr(String upprbr) {
		this.upprbr = upprbr;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getCntrtp() {
		return cntrtp;
	}

	public void setCntrtp(String cntrtp) {
		this.cntrtp = cntrtp;
	}

	public String getCntrcl() {
		return cntrcl;
	}

	public void setCntrcl(String cntrcl) {
		this.cntrcl = cntrcl;
	}

	public String getCrcycd() {
		return crcycd;
	}

	public void setCrcycd(String crcycd) {
		this.crcycd = crcycd;
	}

	public String getTermcd() {
		return termcd;
	}

	public void setTermcd(String termcd) {
		this.termcd = termcd;
	}

	public BigDecimal getInstrt() {
		return instrt;
	}

	public void setInstrt(BigDecimal instrt) {
		this.instrt = instrt;
	}

	public BigDecimal getCntram() {
		return cntram;
	}

	public void setCntram(BigDecimal cntram) {
		this.cntram = cntram;
	}

	public BigDecimal getCntrbl() {
		return cntrbl;
	}

	public void setCntrbl(BigDecimal cntrbl) {
		this.cntrbl = cntrbl;
	}

	public String getBgindt() {
		return bgindt;
	}

	public void setBgindt(String bgindt) {
		this.bgindt = bgindt;
	}

	public String getMatudt() {
		return matudt;
	}

	public void setMatudt(String matudt) {
		this.matudt = matudt;
	}

	public String getRenwtg() {
		return renwtg;
	}

	public void setRenwtg(String renwtg) {
		this.renwtg = renwtg;
	}

	public String getTranst() {
		return transt;
	}

	public void setTranst(String transt) {
		this.transt = transt;
	}

	public String getAcptdt() {
		return acptdt;
	}

	public void setAcptdt(String acptdt) {
		this.acptdt = acptdt;
	}

	public String getAcptsq() {
		return acptsq;
	}

	public void setAcptsq(String acptsq) {
		this.acptsq = acptsq;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Long getWkflid() {
		return wkflid;
	}

	public void setWkflid(Long wkflid) {
		this.wkflid = wkflid;
	}

}
