package com.sunline.sunfe.test;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;
import org.junit.Test;

import com.sunline.bimis.pcmc.db.PcmcDeptHome;
import com.sunline.funcpub.entity.PcmcDeptManager;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.security.UserAuthenticator;
import com.sunline.jraf.services.BimisUser;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.services.JrafSessionFactory;
import com.sunline.jraf.util.FileUtil;
import com.sunline.sunfe.dayend.StepProcesserThread;
import com.sunline.sunfe.dayend.impl.DayEndAutolendProcesser;
//import com.sunline.sungl.util.PkgGlisAcct;

/**
 * 
 * @ClassName: DayEndGlisSummaryProcesserTest
 * @Description: TODO
 * @author: livejianan
 * @date: 2017-3-30 ����9:00:39
 */
public class DayEndAutolendProcesserTest {

	/**
	 * log ��־˽�б���
	 */
	private static final Log log = LogFactory.getLog(DayEndAutolendProcesserTest.class);
	
	@Test
	public  static void test() {
		FileUtil.setHomePath("E:/kjyq/imps/web/WEB-INF/sunline"); // �޸�Ϊ���imps·��
		FileUtil.setWebPath("E:/kjyq/imps/web");// �޸�Ϊ���imps·��

		PropertyConfigurator.configure("E:/kjyq/imps/web/WEB-INF/classes/log4j.properties");  
		BimisUser user1 = new BimisUser();
		user1.setAttribute("stacid","1");
		user1.setDeptcode("601101");
		user1.setUserCode("admin");
		
		/*user1.setAttribute("stacid", stacid);
		user1.setAttribute("deptCode", deptCode);
		user1.setAttribute("userCode", userCode);*/
		UserAuthenticator ua = new UserAuthenticator(user1);

		StepProcesserThread hostTask = null;

		JrafSession jrafSession = null;

		UserAuthenticator.setAuthenticator(ua);
	//	JrafSession jrafSession = JrafSessionFactory.getInstance().openSession();
		//�������
		DayEndAutolendProcesser processer = new DayEndAutolendProcesser();
		long start = System.currentTimeMillis();
		try {
		//	 jrafSession = 	JrafSessionFactory.getInstance().openSession();
		//	CommonDao commonDao = new CommonDao(jrafSession);
			processer.preProcess();
			processer.processing();
			processer.processed();
			//CommonDao commonDao,String Pi_Stacid, String Pi_Sourst,
			//String Pi_Sourdt, String Pi_Soursq
		//	PkgGlisAcct.com_Accounting(commonDao, "1", "90", "20171231", "6000000000000162");
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		long end =System.currentTimeMillis();
		log.debug("***�������˿�ʼʱ�����"+start+"***����ʱ�����"+end+"***����ʱ�䣺"+(end-start)+"����***");
	}
	
	public static void main(String[] args) {
		test();
	}

}
