package com.sunline.sunfe.schedule;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.services.JrafSessionFactory;
import com.sunline.suncm.util.Sequence;
import com.sunline.suncm.util.SequenceUtils;
import com.sunline.suncm.util.PubUtil;
import com.sunline.sundp.model.GlaVoucher;
import com.sunline.sundp.model.GliVoucher;
import com.sunline.sundp.util.StringUtils;
import com.taobao.pamirs.schedule.IScheduleTaskDealSingle;
import com.taobao.pamirs.schedule.TaskItemDefine;
/**
 * �������+ebsģʽ
 * ����
 * @ClassName: VchrToEbsExecute 
 * @Description: TODO
 * @author: huangziq
 * @date: 2017-9-13 ����9:39:03
 */
public class VchrToEbsExecute implements IScheduleTaskDealSingle<Object> {

	private static Log log = LogFactory.getLog(VchrToEbsExecute.class);

	private String MYBATIS_NS_EBS = "com.sunline.sundp.mybatis.gltoebs.";

	@Override
	public List<Object> selectTasks(String taskParameter, String ownSign, int taskItemNum, List<TaskItemDefine> taskItemList, int eachFetchDataNum) throws Exception {
		log.debug("start VchrToEbsExecute selectTasks......");
		// ��ȡ���Ȳ���
		HashMap<String, String> map = StringUtils.String2Map(taskParameter);
		// ���ײ���
		String stacid = map.get("stacid");
		String transt = map.get("transt");
		List<Object> list = new ArrayList<Object>();

		log.debug("......end VchrToEbsExecute selectTasks......");
		ReturnData returnData = new ReturnData();
		returnData.setStacid(stacid);
		returnData.setTranst(transt);
		list.add(returnData);
		return list;
	}

	@Override
	public boolean execute(Object task, String ownSign) throws Exception {
		ReturnData returnData = (ReturnData) task;
		JrafSession jrafSession = this.getJrafSession(null);
		HashMap<String, Object> hashmap = new HashMap<String, Object>();
		CommonDao commonDao = null;
		int count;
		try {
			int stacid = Integer.valueOf(returnData.getStacid());
			hashmap.put("stacid",stacid );
			String acctdt = PubUtil.getAccdt(stacid);
			hashmap.put("sourdt", acctdt);
			this.toGlaVchr(hashmap);//gli �� gla
			commonDao = new CommonDao(jrafSession);
			/*commonDao.beginTransaction();
			// 1��gli_vchr transt = 0 (δ����), ���µ� gla_vchr ,
			count = commonDao.insertByNamedSql(MYBATIS_NS_EBS + "insertGla", hashmap);
			// ����gli_vchr ���� �ɹ�insert ��gla_vchr �ļ�¼ ״̬ transt = 1
			count = commonDao.updateByNamedSql(MYBATIS_NS_EBS + "updateGli", hashmap);
			commonDao.commitTransaction();*/
			
			// ��ѯXXT_AE_GL_INTERFACE status = 0 �ļ�¼,ͬʱ����gla_vchr ���Ӧ ����transt = 9 
			commonDao.beginTransaction();
			
			// ��ѯXXT_AE_GL_INTERFACE status = 2 �ļ�¼,ͬʱ����gla_vchr ����transt = 9 Ϊ  transt = 2(����״̬Ϊ����ʧ�� )
			// ��¼��־sys_vchr_eror;
			hashmap.put("transt", "2");
			hashmap.put("status", "2");
			count = commonDao.updateByNamedSql(MYBATIS_NS_EBS + "updateGlaToAccount", hashmap);
			count = commonDao.insertByNamedSql(MYBATIS_NS_EBS + "insertLogs", hashmap);
			// ��ѯXXT_AE_GL_INTERFACE status = 1 �ļ�¼,ͬʱ����gla_vchr ��  transt = 9 Ϊ  transt = 1(����״̬Ϊ���˳ɹ�);
			hashmap.put("transt", "1");
			hashmap.put("status", "1");
			count = commonDao.updateByNamedSql(MYBATIS_NS_EBS + "updateGlaToAccount", hashmap);
			commonDao.commitTransaction();
			
			commonDao.beginTransaction();
			// gla_vchr �� ebs ������ѡȡgla_vchr transt = 0 �ļ�¼ ��
			hashmap.put("status", "0");
			hashmap.put("transt", "0");
			
			//����ǰCOA��ֵ��֤ ��֤��ͨ���� transt ����Ϊ 2
			
			count = commonDao.insertByNamedSql(MYBATIS_NS_EBS + "coaValidateAcctbr", hashmap);
			if (count!=0) {
				commonDao.insertByNamedSql(MYBATIS_NS_EBS + "insertLogsAcctbr", hashmap);
			}
			
			count = commonDao.insertByNamedSql(MYBATIS_NS_EBS + "coaValidateCentcd", hashmap);
			if (count!=0) {
				commonDao.insertByNamedSql(MYBATIS_NS_EBS + "insertLogsCentcd", hashmap);
			}
			
			
			count = commonDao.insertByNamedSql(MYBATIS_NS_EBS + "coaValidateItemcd", hashmap);
			if (count!=0) {
				commonDao.insertByNamedSql(MYBATIS_NS_EBS + "insertLogsItemcd", hashmap);
			}
			
			count = commonDao.insertByNamedSql(MYBATIS_NS_EBS + "coaValidateAssis0", hashmap);
			if (count!=0) {
				commonDao.insertByNamedSql(MYBATIS_NS_EBS + "insertLogsAssis0", hashmap);
			}
			
			count = commonDao.insertByNamedSql(MYBATIS_NS_EBS + "coaValidateSystid", hashmap);
			if (count!=0) {
				commonDao.insertByNamedSql(MYBATIS_NS_EBS + "insertLogsSystid", hashmap);
			}
			
			count = commonDao.insertByNamedSql(MYBATIS_NS_EBS + "coaValidatePrducd", hashmap);
			if (count!=0) {
				commonDao.insertByNamedSql(MYBATIS_NS_EBS + "insertLogsPrducd", hashmap);
			}
			
			
			
			
			count = commonDao.insertByNamedSql(MYBATIS_NS_EBS + "insertEbsInterface", hashmap);// gla_vchr �� ebs ������ѡȡgla_vchr transt = 0 �ļ�¼ 
			if (count != 0) {//
				hashmap.put("transt", "0");
				commonDao.updateByNamedSql(MYBATIS_NS_EBS + "updateGla", hashmap);//��gla transt = 0 ״̬���Ϊ transt = 9
			}
			commonDao.commitTransaction();
		} catch (Exception e) {
			commonDao.rollBack();
			e.printStackTrace();
		}
		finally {
			closeConnection(jrafSession);
		}
		return true;
	}

	/**
	 * gli_vchr to gla_vchr
	 * 
	 * @Title: toGlaVchr
	 * @Description: TODO
	 * @param hashmap
	 * @param commonDao
	 * @return: void
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	private void toGlaVchr(HashMap<String, Object> hashmap) throws BimisException {
		JrafSession jrafSession = getJrafSession(null);
		CommonDao commonDao = new CommonDao(jrafSession);
		try {
			hashmap.put("transt", "0");
			List<GliVoucher> listGli = (List<GliVoucher>) commonDao.queryByNamedSqlForList(MYBATIS_NS_EBS + "getGliVchr", hashmap);
			if (listGli.size()==0) {
				return;
			}
			commonDao.beginTransaction();
			List<GlaVoucher> listGla = new ArrayList<GlaVoucher>();
			Sequence sequence = null;
			for (int i = 0; i < listGli.size(); i++) {
				hashmap.put("bathid", listGli.get(i).getBathid());
				List listGlo =  commonDao.queryByNamedSqlForList(MYBATIS_NS_EBS + "getGloByBathid", hashmap);
				if(listGlo.size()!=0){
					GlaVoucher glaVoucher = new GlaVoucher();
					glaVoucher = GlaVoucher.toGlaVchr(listGli.get(i));
					sequence = SequenceUtils.createSequence(hashmap.get("stacid").toString(),listGli.get(i).getSourdt(), "transq", listGli.get(i).getTranbr(), listGli.get(i).getUsercd(), 1);
					glaVoucher.setTransq(sequence.getSqueno());
					hashmap.put("itemcd", listGli.get(i).getItemcd());
					Element e = commonDao.queryByNamedSql(MYBATIS_NS_EBS + "getItemIoflag", hashmap);
					String ioflag = e.getChild("Record").getChildTextNormalize("ioflag").toUpperCase();
					glaVoucher.setIoflag(ioflag);
					listGla.add(glaVoucher);
					for (int j = i + 1; j < listGli.size(); j++) {
						if (listGli.get(i).getSoursq().equals(listGli.get(j).getSoursq())) {
							i = j;
							glaVoucher = GlaVoucher.toGlaVchr(listGli.get(j));
							glaVoucher.setTransq(sequence.getSqueno());
							hashmap.put("itemcd", listGli.get(j).getItemcd());
							e = commonDao.queryByNamedSql(MYBATIS_NS_EBS + "getItemIoflag", hashmap);
							ioflag = e.getChild("Record").getChildTextNormalize("ioflag").toUpperCase();
							glaVoucher.setIoflag(ioflag);
							listGla.add(glaVoucher);
						} else {
							break;
						}
					}
				}
			}
			if(listGla.size()!=0){
				commonDao.insertByNamedSql(MYBATIS_NS_EBS + "insertGla", listGla);
				commonDao.updateByNamedSql(MYBATIS_NS_EBS + "updateGli", null);
			}
			commonDao.commitTransaction();
		} catch (Exception e) {
			commonDao.rollBack();
			e.printStackTrace();
		}
		finally {
				closeConnection(jrafSession);
		}
	}
	
	
	private void toEbs(HashMap<String, Object> hashmap){
		JrafSession jrafSession = getJrafSession(null);
		CommonDao commonDao = new CommonDao(jrafSession);
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Override
	public Comparator<Object> getComparator() {
		// TODO Auto-generated method stub
		return null;
	}

	private JrafSession getJrafSession(JrafSession jrafSession) {
		try {
			if (jrafSession == null || jrafSession.getConnection() == null || jrafSession.getConnection().isClosed()) {
				jrafSession = JrafSessionFactory.getInstance().openSession();
			}
		} catch (Exception e) {
			log.error("���Ȼ�ȡJrafSessionʧ��", e);
		}
		return jrafSession;
	}

	/**
	 * �ر�����
	 * 
	 * @throws BimisException
	 */
	private void closeConnection(JrafSession jrafSession) throws BimisException {
		try {
			if (jrafSession != null && jrafSession.getConnection() != null && !jrafSession.getConnection().isClosed()) {
				jrafSession.close();
				jrafSession = null;
			}
		} catch (SQLException e) {
			log.error("�ر�JrafSessionʧ��", e);
			throw new BimisException("300", "�ر�JrafSessionʧ��");
		}
	}

	// selectTask���������������
	class ReturnData {

		// ���κ�
		private String batchId;
		private String stacid;
		private String plancd;
		private String systid;
		private String certno;
		private String transt;

		public String getCertno() {
			return certno;
		}

		public void setCertno(String certno) {
			this.certno = certno;
		}

		public String getSystid() {
			return systid;
		}

		public void setSystid(String systid) {
			this.systid = systid;
		}

		public String getPlancd() {
			return plancd;
		}

		public void setPlancd(String plancd) {
			this.plancd = plancd;
		}

		public String getStacid() {
			return stacid;
		}

		public void setStacid(String stacid) {
			this.stacid = stacid;
		}

		public String getBatchId() {
			return batchId;
		}

		public void setBatchId(String batchId) {
			this.batchId = batchId;
		}

		/**
		 * @return the transt
		 */

		public String getTranst() {
			return transt;
		}

		/**
		 * @param transt
		 *            the transt to set
		 */

		public void setTranst(String transt) {
			this.transt = transt;
		}
	}

}
