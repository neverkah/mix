package com.sunline.sunfe.schedule;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.services.JrafSessionFactory;
import com.sunline.sundp.util.DatabaseUtils;
import com.sunline.sundp.util.StringUtils;
import com.taobao.pamirs.schedule.IScheduleTaskDealMulti;
import com.taobao.pamirs.schedule.TaskItemDefine;

/**
 * ��˰�������ݺϲ���Ʊ��¼
 * @ClassName: PriceTaxMergeVchrExecute 
 * @Description: ��˰����gli_vchr��txa_vchr��ˮ��������ϲ���gla_vchr
 * @author: livejianan
 * @date: 2017-8-8 ����10:07:41
 */
public class PriceTaxMergeVchrExecute implements IScheduleTaskDealMulti<Object> {
	
	private static Log log = LogFactory.getLog(PriceTaxMergeVchrExecute.class);

	private static final String GLI_DEALST_SUCC = "3"; // gli_vchr�ϲ���˰�������ݳɹ���dealst״̬
	private static final String GLI_TRANST_SUCC = "1"; // gli_vchr�ϲ���˰�������ݳɹ���transt״̬
	private static final String GLI_TRANST_UNDEAL = "0";
	private static final String TXA_SUCC = "1"; // txa_vchr�ϲ���˰�������ݳɹ�״̬
	private String stacid = "";
	private String bsnsdt = "";
	
	private static final String INSERTGLAVCHR = "insert into gla_vchr (STACID,SYSTID,TRANDT,TRANSQ,VCHRSQ,TRANBR,ACCTBR,ITEMCD,CRCYCD," +
							"TRANTP,AMNTCD,TRANAM,USERCD,SOURDT,SOURSQ,SOURST,SRVCSQ,SOURAC,ASSIS0,ASSIS1,ASSIS2,ASSIS3,ASSIS4,ASSIS5,ASSIS6," +
							"ASSIS7,ASSIS8,ASSIS9,CENTCD,PRSNCD,CUSTCD,PRDUCD,PRLNCD,ACCTNO,IOFLAG,SMRYTX,EXCHCN,EXCHUS) "
							+ "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	private static final String UPDATEGLIVCHR = "update gli_vchr set dealst=?,transt=? where stacid=? and sourst=? and sourdt=? and soursq=? and vchrsq=?";
	
	private static final String UPDATETXAVCHR = "update txa_vchr set transt=? where stacid=? and systid=? and trandt=? and transq=? and vchrsq=? ";
	
	private static final String GETTXAVCHR = "select STACID, SYSTID, TRANDT, TRANSQ, VCHRSQ, TRANBR, ACCTBR, ITEMCD, " +
							"CRCYCD, CENTCD, PRSNCD, CUSTCD, PRDUCD, PRLNCD, ACCTNO, TRANTP, AMNTCD, TRANAM, SMRYTX, EXCHCN, EXCHUS, USERCD, TOITEM, ASSIS0, ASSIS1, " +
							"ASSIS2, ASSIS3, ASSIS4, ASSIS5, ASSIS6, ASSIS7, ASSIS8, ASSIS9, TRANST, TRSDAM, CRCYSD, SPERDT " +
							" FROM TXA_VCHR WHERE STACID = ? AND SYSTID = ? AND TRANDT = ? AND TRANSQ = ? ";
	
	private static final String GETTRANSQ = "SELECT  STACID,SYSTID,TRANDT,TRANSQ FROM TXA_VCHR " +
							"WHERE STACID=? AND TRANDT=? AND TRANST=?  GROUP BY STACID,SYSTID,TRANDT,TRANSQ";
	
	private static final String GETGLIVCHR = "SELECT /*+index (gli_vchr,PK_GLI_VHCR)*/ STACID, SOURST, SOURDT, SOURSQ , VCHRSQ, TRANBR, ACCTBR, " +
							"ITEMCD, CRCYCD, CENTCD, PRSNCD, CUSTCD, PRDUCD, PRLNCD, ACCTNO, TRANTP, AMNTCD, TRANAM, SMRYTX, EXCHCN, EXCHUS, USERCD," +
							"TRANDT, TOITEM, ASSIS0, ASSIS1, ASSIS2, ASSIS3, ASSIS4, ASSIS5, ASSIS6, ASSIS7, ASSIS8, ASSIS9, DEALST, PRCSCD," +
							"ITEMNA, PRCSNA, STRKST, STRKDT, STRKSQ, CRCYSD, TRANEQ, TAXBST, TRANNM, TRANST, BSNSSQ, DEALMG, BATHID " +
							" FROM GLI_VCHR WHERE STACID = ? AND SOURST = ? AND SOURDT = ? AND SOURSQ = ? AND TRANST = ?";
	@Override
	public List<Object> selectTasks(String taskParameter, String ownSign,
			int taskItemNum, List<TaskItemDefine> taskItemList,
			int eachFetchDataNum) throws Exception {
        log.debug("start PriceTaxMergeVchrExecute selectTasks......");
		HashMap<String, String> map = StringUtils.String2Map(taskParameter);
		stacid = map.get("stacid");
		log.debug("����������л�ȡ����Ϊ��" + stacid);
		bsnsdt = getBsnsdt(stacid);
		log.debug("�����������������ڣ�" + bsnsdt);
		//taskItemList�������̻߳��ֳ���������
		List<Object> result = new ArrayList<Object>();
		if (taskItemList.size() == 0) {
			return result;
		}
		List<String> condition = new ArrayList<String>();
		for (int i = 0; i < taskItemList.size(); i++) {
			condition.add(taskItemList.get(i).getTaskItemId());
		}
		ArrayList<Object> list = selectTransqs(stacid,bsnsdt,eachFetchDataNum,condition);
		log.debug("......end PriceTaxMergeVchrExecute selectTasks......");
		return list;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public boolean execute(Object[] tasks, String ownSign) throws Exception{
		log.debug("......start PriceTaxMergeVchrExecute execute......");
		PreparedStatement insertglavchr = null;
		PreparedStatement updateglivchr = null;
		PreparedStatement updatetxavchr = null;
		Connection conn = null;
		try{
			 conn = getConnection();
			 conn.setAutoCommit(false);
			 insertglavchr = conn.prepareStatement(INSERTGLAVCHR); //insert gla_vchr
			 updateglivchr = conn.prepareStatement(UPDATEGLIVCHR); //update gli_vchr
			 updatetxavchr = conn.prepareStatement(UPDATETXAVCHR); //update txa_vchr
			  for (int k = 0; k < tasks.length; k++) {
			 		HashMap<String,Object>  transq =(HashMap<String,Object> )tasks[k];
			 		List<HashMap<String, Object>> gliVchrlist = getGliVchr(transq,conn);
			 		List<HashMap<String, Object>> txaVchrlist = getTxaVchr(transq,conn);
			 		for (Iterator iterator = gliVchrlist.iterator(); iterator.hasNext();) {
						HashMap<String, Object> glivchr = (HashMap<String, Object>) iterator.next();
						String itemcdi = (String) glivchr.get("ITEMCD"); //��Ŀ
						String amntcdi = (String) glivchr.get("AMNTCD"); //����
						BigDecimal tranami =  (BigDecimal) glivchr.get("TRANAM"); //���
						String vchrsq = (String)glivchr.get("VCHRSQ");
						//��ѯ��˰��������ķ�¼
						glivchr.put("TRANSQ", glivchr.get("SOURSQ"));
						glivchr.put("SYSTID", glivchr.get("SOURST"));
					 	glivchr.put("TRANDT", bsnsdt);
						for (Iterator iterator1 = txaVchrlist.iterator(); iterator1.hasNext();) {
							HashMap<String, Object> txavchr = (HashMap<String, Object>) iterator1.next();
							String txa_vchrsq=(String) txavchr.get("VCHRSQ");
							if(txa_vchrsq.startsWith(vchrsq)){
								String itemcdj = (String) txavchr.get("ITEMCD");
								String amntcdj = (String) txavchr.get("AMNTCD");
								//�ж��Ƿ�ͬ�����Ŀ
								if(itemcdi.equals(itemcdj) && (amntcdi.equals(amntcdj))){
									BigDecimal tranamj = (BigDecimal) txavchr.get("TRANAM");
									tranami = tranami.add(tranamj);
									glivchr.put("TRANAM", tranami);
								}else{
									insertglavchrBath(insertglavchr,txavchr,glivchr);
								}
								//�޸�txa_vchr״̬
					    		updatetxavchr.setString(1, TXA_SUCC);
					    		updatetxavchr.setString(2, stacid);
					    		updatetxavchr.setString(3, (String) txavchr.get("SYSTID"));
					    		updatetxavchr.setString(4, bsnsdt);
					    		updatetxavchr.setString(5, (String) txavchr.get("TRANSQ"));
					    		updatetxavchr.setString(6, (String) txavchr.get("VCHRSQ"));
					    		updatetxavchr.addBatch();
								}
							}
						insertglavchrBath(insertglavchr,glivchr,glivchr);
						//�޸�gli_vchr״̬
			    		updateglivchr.setString(1, GLI_DEALST_SUCC);
			    		updateglivchr.setString(2, GLI_TRANST_SUCC);
			    		updateglivchr.setString(3, stacid);
			    		updateglivchr.setString(4, (String) glivchr.get("SYSTID"));
			    		updateglivchr.setString(5, bsnsdt);
			    		updateglivchr.setString(6, (String) glivchr.get("TRANSQ"));
			    		updateglivchr.setString(7, (String) glivchr.get("VCHRSQ"));
			    		updateglivchr.addBatch();
						}
					}
				insertglavchr.executeBatch();
				updateglivchr.executeBatch();
				updatetxavchr.executeBatch();
				conn.commit();
				log.debug("......end PriceTaxMergeVchrExecute execute......");
		}catch (Exception e) {
			log.error(e.getMessage(), e);
			if(null != conn ){
				conn.rollback();
			}else{
				log.error("ϵͳ�޷���ȡ�����ݿ����ӣ����飡");
			}
		}finally {
				try {
					if (insertglavchr != null) {
						insertglavchr.close();
					}
					if (updateglivchr != null) {
						updateglivchr.close();
					}
					if (updatetxavchr != null) {
						updatetxavchr.close();
					}
				} catch (Exception e) {
					log.error(e.getMessage());
				}
				closeConnection(conn);
		}
		return true;
	}
	
	
	private List<HashMap<String, Object>> getGliVchr(HashMap<String, Object> transq, Connection conn) {
		PreparedStatement insertglavchr = null;
        ResultSet rs = null;
		List<HashMap<String, Object>> gliVchrlist = new ArrayList<>();
		try {
			conn = getConnection();
			insertglavchr = conn.prepareStatement(GETGLIVCHR);
			insertglavchr.setString(1, stacid);
			insertglavchr.setString(2,  (String) transq.get("SYSTID"));
			insertglavchr.setString(3, bsnsdt);
			insertglavchr.setString(4,  (String) transq.get("TRANSQ"));
			insertglavchr.setString(5,  GLI_TRANST_UNDEAL);
			rs = insertglavchr.executeQuery();
			ResultSetMetaData md = rs.getMetaData();
		        int columnCount = md.getColumnCount();
		        while(rs.next()) {  
		        	HashMap<String, Object> gli_vchr = new HashMap<String,Object>();
		            for (int i = 1; i <= columnCount; i++) {  
		            	gli_vchr.put(md.getColumnName(i), rs.getObject(i));  
		            } 
		            gliVchrlist.add(gli_vchr);
		        }
		} catch (Exception ex) {
			log.error("���ڣ�"+bsnsdt+"��ˮ�ţ�"+transq.get("TRANSQ")+"getGliVchrִ���쳣��" + ex.getMessage());
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (insertglavchr != null) {
					insertglavchr.close();
				}
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		 return gliVchrlist;
	}


	private void insertglavchrBath(PreparedStatement insertglavchr,
			HashMap<String, Object> txaVchr, HashMap<String, Object> gliVchr) throws SQLException {
		insertglavchr.setString(1,  stacid);
		insertglavchr.setString(2, (String) txaVchr.get("SYSTID"));
		insertglavchr.setString(3,  bsnsdt);
		insertglavchr.setString(4, (String) txaVchr.get("TRANSQ"));
		insertglavchr.setString(5, (String) txaVchr.get("VCHRSQ"));
		insertglavchr.setString(6, (String) txaVchr.get("TRANBR"));
		insertglavchr.setString(7, (String) txaVchr.get("ACCTBR"));
		insertglavchr.setString(8, (String) txaVchr.get("ITEMCD"));
		insertglavchr.setString(9, (String) txaVchr.get("CRCYCD"));
		insertglavchr.setString(10,(String) txaVchr.get("TRANTP"));
		insertglavchr.setString(11,(String) txaVchr.get("AMNTCD"));
		insertglavchr.setBigDecimal(12, (BigDecimal) txaVchr.get("TRANAM"));
		insertglavchr.setString(13, (String) txaVchr.get("USERCD"));
		insertglavchr.setString(14, (String) gliVchr.get("TRANDT"));
		insertglavchr.setString(15, (String) gliVchr.get("TRANSQ"));
		insertglavchr.setString(16, (String) gliVchr.get("SYSTID"));
		insertglavchr.setString(17, (String) txaVchr.get("VCHRSQ"));
		insertglavchr.setString(18, stacid);
		insertglavchr.setString(19, (String) txaVchr.get("ASSIS0"));
		insertglavchr.setString(20, (String) txaVchr.get("ASSIS1"));
		insertglavchr.setString(21, (String) txaVchr.get("ASSIS2"));
		insertglavchr.setString(22, (String) txaVchr.get("ASSIS3"));
		insertglavchr.setString(23, (String) txaVchr.get("ASSIS4"));
		insertglavchr.setString(24, (String) txaVchr.get("ASSIS5"));
		insertglavchr.setString(25, (String) txaVchr.get("ASSIS6"));
		insertglavchr.setString(26, (String) txaVchr.get("ASSIS7"));
		insertglavchr.setString(27, (String) txaVchr.get("ASSIS8"));
		insertglavchr.setString(28, (String) txaVchr.get("ASSIS9"));
		insertglavchr.setString(29, (String) txaVchr.get("CENTCD"));
		insertglavchr.setString(30, (String) txaVchr.get("PRSNCD"));
		insertglavchr.setString(31, (String) txaVchr.get("CUSTCD"));
		insertglavchr.setString(32, (String) txaVchr.get("PRDUCD"));
		insertglavchr.setString(33, (String) txaVchr.get("PRLNCD"));
		insertglavchr.setString(34, (String) txaVchr.get("ACCTNO"));
		insertglavchr.setString(35, "I");
		insertglavchr.setString(36, (String) txaVchr.get("SMRYTX"));
		insertglavchr.setBigDecimal(37, (BigDecimal) txaVchr.get("EXCHCN"));
		insertglavchr.setBigDecimal(38, (BigDecimal) txaVchr.get("EXCHUS"));
		insertglavchr.addBatch();		
		
	}


//	@SuppressWarnings("unchecked")
//	private void mergeVchr(PreparedStatement insertglavchr,
//			PreparedStatement updateglivchr, ArrayList<Object> glaVchrs, HashMap<String, Object> gliVchr) throws SQLException {
//		for (int j = 0; j < glaVchrs.size(); j++) {
//			HashMap<String, Object>	glaVchr = (HashMap<String, Object>)glaVchrs.get(j);
//			insertglavchr.setString(1,  stacid);
//			insertglavchr.setString(2, (String) glaVchr.get("SYSTID"));
//			insertglavchr.setString(3,  bsnsdt);
//			insertglavchr.setString(4, (String) glaVchr.get("TRANSQ"));
//			insertglavchr.setString(5, (String) glaVchr.get("VCHRSQ"));
//			insertglavchr.setString(6, (String) glaVchr.get("TRANBR"));
//			insertglavchr.setString(7, (String) glaVchr.get("ACCTBR"));
//			insertglavchr.setString(8, (String) glaVchr.get("ITEMCD"));
//			insertglavchr.setString(9, (String) glaVchr.get("CRCYCD"));
//			insertglavchr.setString(10,(String) glaVchr.get("TRANTP"));
//			insertglavchr.setString(11,(String) glaVchr.get("AMNTCD"));
//			insertglavchr.setBigDecimal(12, (BigDecimal) glaVchr.get("TRANAM"));
//			insertglavchr.setString(13, (String) glaVchr.get("USERCD"));
//			insertglavchr.setString(14, (String) gliVchr.get("TRANDT"));
//			insertglavchr.setString(15, (String) gliVchr.get("TRANSQ"));
//			insertglavchr.setString(16, (String) gliVchr.get("SYSTID"));
//			insertglavchr.setString(17, (String) glaVchr.get("VCHRSQ"));
//			insertglavchr.setString(18, stacid);
//			insertglavchr.setString(19, (String) glaVchr.get("ASSIS0"));
//			insertglavchr.setString(20, (String) glaVchr.get("ASSIS1"));
//			insertglavchr.setString(21, (String) glaVchr.get("ASSIS2"));
//			insertglavchr.setString(22, (String) glaVchr.get("ASSIS3"));
//			insertglavchr.setString(23, (String) glaVchr.get("ASSIS4"));
//			insertglavchr.setString(24, (String) glaVchr.get("ASSIS5"));
//			insertglavchr.setString(25, (String) glaVchr.get("ASSIS6"));
//			insertglavchr.setString(26, (String) glaVchr.get("ASSIS7"));
//			insertglavchr.setString(27, (String) glaVchr.get("ASSIS8"));
//			insertglavchr.setString(28, (String) glaVchr.get("ASSIS9"));
//			insertglavchr.setString(29, (String) glaVchr.get("CENTCD"));
//			insertglavchr.setString(30, (String) glaVchr.get("PRSNCD"));
//			insertglavchr.setString(31, (String) glaVchr.get("CUSTCD"));
//			insertglavchr.setString(32, (String) glaVchr.get("PRDUCD"));
//			insertglavchr.setString(33, (String) glaVchr.get("PRLNCD"));
//			insertglavchr.setString(34, (String) glaVchr.get("ACCTNO"));
//			insertglavchr.setString(35, "I");
//			insertglavchr.setString(36, (String) glaVchr.get("SMRYTX"));
//			insertglavchr.setBigDecimal(37, (BigDecimal) glaVchr.get("EXCHCN"));
//			insertglavchr.setBigDecimal(38, (BigDecimal) glaVchr.get("EXCHUS"));
//			insertglavchr.addBatch();		
//			}
//			//�޸�gli_vchr״̬
//    		updateglivchr.setString(1, GLI_DEALST_SUCC);
//    		updateglivchr.setString(2, GLI_TRANST_SUCC);
//    		updateglivchr.setString(3, stacid);
//    		updateglivchr.setString(4, (String) gliVchr.get("SYSTID"));
//    		updateglivchr.setString(5, bsnsdt);
//    		updateglivchr.setString(6, (String) gliVchr.get("TRANSQ"));
//    		updateglivchr.setString(7, (String) gliVchr.get("VCHRSQ"));
//    		updateglivchr.addBatch();
//	}


	private List<HashMap<String, Object>> getTxaVchr(HashMap<String, Object> gliVchrtemp, Connection conn) throws Exception{
		PreparedStatement insertglavchr = null;
        ResultSet rs = null;
		List<HashMap<String, Object>> txaVchrlist = new ArrayList<>();
		try {
			conn = getConnection();
			insertglavchr = conn.prepareStatement(GETTXAVCHR);
			insertglavchr.setString(1, stacid);
			insertglavchr.setString(2,  (String) gliVchrtemp.get("SYSTID"));
			insertglavchr.setString(3, bsnsdt);
			insertglavchr.setString(4,  (String) gliVchrtemp.get("TRANSQ"));
			rs = insertglavchr.executeQuery();
			ResultSetMetaData md = rs.getMetaData();
		        int columnCount = md.getColumnCount();
		        while(rs.next()) {  
		        	HashMap<String, Object> txaVchr = new HashMap<String,Object>();
		            for (int i = 1; i <= columnCount; i++) {  
		            	txaVchr.put(md.getColumnName(i), rs.getObject(i));  
		            } 
		            txaVchrlist.add(txaVchr);
		        }
		    return txaVchrlist;
		} catch (Exception ex) {
			log.error("���ڣ�"+bsnsdt+"��ˮ�ţ�"+gliVchrtemp.get("SOURSQ")+"��ţ�"+gliVchrtemp.get("VCHRSQ")+"getTxaVchrִ���쳣��" + ex.getMessage());
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (insertglavchr != null) {
					insertglavchr.close();
				}
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		return null;
	}
	
//	private HashMap<String, Object> getGliVchr(Connection conn, HashMap<String, Object> map){
//		PreparedStatement getGliVchr = null;
//        ResultSet rs = null;
//		String sourst = (String) map.get("SOURST");
//		String soursq = (String) map.get("SOURSQ");	
//		String vchrsq = (String) map.get("VCHRSQ");
//		HashMap<String,Object> rowData = null;
//		try {
//			getGliVchr = conn.prepareStatement(GETGLIVCHR);
//			getGliVchr.setString(1, stacid);
//			getGliVchr.setString(2, sourst);
//			getGliVchr.setString(3, bsnsdt);
//			getGliVchr.setString(4, soursq);
//			getGliVchr.setString(5, vchrsq);
//			rs = getGliVchr.executeQuery();
//			 
//			ResultSetMetaData md = rs.getMetaData();
//		         int columnCount = md.getColumnCount();
//		        while(rs.next()) {  
//		            rowData = new HashMap<String,Object>();  
//		            for (int i = 1; i <= columnCount; i++) {  
//		                rowData.put(md.getColumnName(i), rs.getObject(i));  
//		            } 
//		            rowData.put("TRANSQ", rowData.get("SOURSQ"));
//		        }
//		    return rowData;
//		} catch (Exception ex) {
//			log.error("��ѯgli_vchr�쳣��" + ex.getMessage());
//		}finally {
//			try {
//				if (rs != null) {
//					rs.close();
//				}
//				if (getGliVchr != null) {
//					getGliVchr.close();
//				}
//			} catch (Exception e) {
//				log.error(e.getMessage());
//			}
//		}
//		return rowData;
//	}
	
	
	/**
	 * 
	 * @Title: selectTxaVchr 
	 * @Description: selectTxaVchr
	 * @param stacid
	 * @param systid
	 * @param bsnsdt
	 * @param condition 
	 * @param eachFetchDataNum 
	 * @return: ArrayList<Object>
	 * @throws Exception 
	 */
	private ArrayList<Object> selectTransqs(String stacid, String bsnsdt, int eachFetchDataNum, List<String> condition) throws Exception{
		PreparedStatement insertglavchr = null;
		ResultSet rs = null;
		log.fatal("��Ƭֵ="+condition);
		Connection conn = null;
		ArrayList<Object> taskList = new ArrayList<Object>();
		try {
			conn = getConnection();
			String sql = DatabaseUtils.generateBatchSql(GETTRANSQ, 0, eachFetchDataNum);
			insertglavchr = conn.prepareStatement(sql);
			insertglavchr.setString(1, stacid);
			insertglavchr.setString(2, bsnsdt);
			insertglavchr.setString(3, GLI_TRANST_UNDEAL);
			rs = insertglavchr.executeQuery();
			ResultSetMetaData md = rs.getMetaData();
		        int columnCount = md.getColumnCount();
		        while(rs.next()) {  
		        	HashMap<String,Object> rowData = new HashMap<String,Object>();  
		            for (int i = 1; i <= columnCount; i++) {  
		                rowData.put(md.getColumnName(i), rs.getObject(i));  
		            	} 
		            	String transq=(String) rowData.get("TRANSQ");
			        	if (!isMatchGliVchr(transq, condition)) {
							continue;
						}else{
							taskList.add(rowData); 
						}
		        }
		}catch (Exception ex) {
			log.error("��ѯ��������ˮ���쳣��" + ex.getMessage());
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (insertglavchr != null) {
					insertglavchr.close();
				}
			} catch (Exception e) {
				log.error(e.getMessage());
			}
			closeConnection(conn);
		}
		return taskList;
	}
	
	/**
	 * �������׻�ȡ��ǰҵ������
	 * @Title: getBsnsdt 
	 * @Description: ��ȡҵ������
	 * @param stacid
	 * @return: String
	 */
	private String getBsnsdt(String stacid) {
		String glisdt = "";
		PreparedStatement insertglavchr = null;
		ResultSet rs = null;
		String sql = "SELECT STACID, GLISDT FROM COM_STAC WHERE STACID = ? ";
		try {
			Connection conn = getConnection();
			insertglavchr = conn.prepareStatement(sql);
			insertglavchr.setString(1, stacid);
			rs = insertglavchr.executeQuery();
			if(rs.next()){
				glisdt = rs.getString(2);
			}
		} catch (Exception ex) {
			log.error("��ȡҵ������ʧ�ܣ� " + ex.getMessage());
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (insertglavchr != null) {
					insertglavchr.close();
				}
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		return glisdt;
	}
	
	private static ThreadLocal<JrafSession> jrafSessionHolder = new ThreadLocal<JrafSession>();
	
	private JrafSession getJrafSession() {
		JrafSession jrafSession = jrafSessionHolder.get();
		try {
            if (jrafSession == null) {
            	jrafSession = JrafSessionFactory.getInstance().openSession();
            	jrafSessionHolder.set(jrafSession);
            }
		} catch (Exception e) {
			log.error("���Ȼ�ȡJrafSessionʧ��", e);
		}
		return jrafSession;
	}

	private Connection getConnection() throws Exception{
		Connection conn = getJrafSession().getConnection();
		return conn;
	}
	
	private void closeConnection(Connection conn) throws Exception{
		if ( null != conn) {
			try{
				JrafSession jrafSession = jrafSessionHolder.get();
				if (jrafSession != null) {
					jrafSession.close();
					jrafSession = null;
					jrafSessionHolder.set(jrafSession);
				}
			}catch(Exception ex){
				log.debug("�ر����ݿ������쳣",ex);
			}
		}
	}
	
	/**
	 * �ж�transq�ֶ����һλ�����Ƿ��condition�ж������ͬ
	 * @param transq
	 * @param condition
	 * @return
	 */
	private boolean isMatchGliVchr(String transq, List<String> condition) throws BimisException {
		String str = Pattern.compile("[^0-9]").matcher(transq).replaceAll("");
		
		if (str == null || str.length() < 2) {
			str = "00";
		} else {
			str = str.substring(str.length() - 2);
		}
		
		return condition.contains(str);
	}


	@Override
	public Comparator<Object> getComparator() {
		return null;
	}
	
}
