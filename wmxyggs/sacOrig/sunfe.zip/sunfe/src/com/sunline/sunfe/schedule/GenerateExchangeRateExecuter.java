package com.sunline.sunfe.schedule;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Element;

import com.sunline.bdss.validator.util.DatetimeUtil;
import com.sunline.jraf.BimisException;
import com.sunline.jraf.db.CommonDao;
import com.sunline.jraf.services.JrafSession;
import com.sunline.jraf.services.JrafSessionFactory;
import com.sunline.sundp.entity.GliImpBean;
import com.sunline.sundp.entity.GloImdtBean;
import com.sunline.sundp.util.StringUtils;
import com.taobao.pamirs.schedule.IScheduleTaskDealSingle;
import com.taobao.pamirs.schedule.TaskItemDefine;

/**
 * �����������
 * 
 * @author li
 * 
 */
public class GenerateExchangeRateExecuter implements
		IScheduleTaskDealSingle<Object> {

	private static Log log = LogFactory
			.getLog(GenerateExchangeRateExecuter.class);
	private JrafSession jrafSession = null;
	private final String TOCRCY = "CNY";
	private final String DATACH = "gert";
	private final String USD_CRCYEN = "USD";
	private final String EXUNIT = "100";
	private boolean isGenNextDayRate;
	public final static String IMPORT_COMPLETED = "1";// �ɹ�
	public final static String IMPORT_FAILED = "2";// ʧ��
	public final static String IMPORT_ING = "0";// ���ݴ�����

	private final String FIND_COM_EXRT_BY_TRANDT = "select distinct crcycd,efctdt,inefdt,exrtst,exunit,middpr,crcyen "
			+ "from com_exrt where efctdt=? and inefdt>=? and exrtst='1' order by efctdt desc,inefdt desc";

	private final String FIND_COM_CVRT_BY_TRANDT = "select distinct crcycd,efctdt,crcyen,cvrtrt "
			+ "from com_cvrt where efctdt=(select max(efctdt) from com_cvrt where efctdt<=?) order by efctdt desc";

	private final String FIND_GLO_IMDT_BY_KEY_TYPE = "select stacid,sourst,sourdt,acctbr,bathid,"
			+ "usercd,brchcd,status,nextdt,currdt,switdt,plancd,datach, typecd "
			+ "from glo_imdt where STACID = ? and BATHID = ? and PLANCD = ? "
			+ "and TYPECD ='1'";

	private static final String INSERT_GLO_IMDT = "INSERT INTO GLO_IMDT (STACID, SOURST, SOURDT, "
			+ "ACCTBR, BATHID, USERCD, BRCHCD, STATUS, NEXTDT, CURRDT, SWITDT, PLANCD, DATACH, TYPECD) "
			+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	private static final String UPDATE_GLO_IMDT_STATUS = "UPDATE GLO_IMDT SET STATUS = ? WHERE"
			+ " STACID = ? AND BATHID = ? AND PLANCD = ? AND DATACH = ?AND TYPECD ='1'";

	// selectTask���������������
	class ReturnData {
		// ���κ�
		private String batchId;
		private String stacid;
		private String plancd;
		private String systid;
		private String certno;

		public String getCertno() {
			return certno;
		}

		public void setCertno(String certno) {
			this.certno = certno;
		}

		private GliImpBean impInfo;
		private GloImdtBean gloImdtInfo;

		public String getSystid() {
			return systid;
		}

		public void setSystid(String systid) {
			this.systid = systid;
		}

		public GliImpBean getImpInfo() {
			return impInfo;
		}

		public void setImpInfo(GliImpBean impInfo) {
			this.impInfo = impInfo;
		}

		public GloImdtBean getGloImdtInfo() {
			return gloImdtInfo;
		}

		public void setGloImdtInfo(GloImdtBean gloImdtInfo) {
			this.gloImdtInfo = gloImdtInfo;
		}

		public String getPlancd() {
			return plancd;
		}

		public void setPlancd(String plancd) {
			this.plancd = plancd;
		}

		public String getStacid() {
			return stacid;
		}

		public void setStacid(String stacid) {
			this.stacid = stacid;
		}

		public String getBatchId() {
			return batchId;
		}

		public void setBatchId(String batchId) {
			this.batchId = batchId;
		}
	}

	private JrafSession getJrafSession() {
		try {
			if (jrafSession == null || jrafSession.getConnection() == null
					|| jrafSession.getConnection().isClosed()) {
				jrafSession = JrafSessionFactory.getInstance().openSession();
			}
		} catch (Exception e) {
			log.error("���Ȼ�ȡJrafSessionʧ��", e);
		}
		return jrafSession;
	}

	private Connection getConnection() {
		Connection conn = null;
		try {
			conn = getJrafSession().getConnection();
			if (null == conn || conn.isClosed()) {
				log.debug("�޷���ȡ�����ݿ����ӣ�");
				throw new Exception("�޷���ȡ�����ݿ����ӣ�");
			}
		} catch (Exception e) {
			log.error("���Ȼ�ȡConnectionʧ��", e);
		}
		return conn;
	}

	private void closeConnection() {
		if (jrafSession != null) {
			jrafSession.close();
			jrafSession = null;
		}
	}

	/**
	 * ȡ�����׺ŵ�ҵ������
	 * 
	 * @param stacid
	 * @return
	 */
	private String getBsnsdt(String stacid) {
		Map<String, String> paMap = new HashMap<String, String>();
		CommonDao commonDao = new CommonDao(this.getJrafSession());
		String bsnsdt = null;
		try {
			paMap.put("stacid", stacid);
			Element element = commonDao.queryByNamedSql(
					"com.sunline.sundp.mybatis.stacinfo.queryStacInfoDetail",
					paMap);
			bsnsdt = ((Element) element.getChildren("Record").get(0))
					.getChildText("glisdt");
		} catch (BimisException e) {
			e.printStackTrace();
		}
		return bsnsdt;
	}

	/**
	 * �������л��ʱ�
	 * 
	 * @param stacid
	 * @return
	 * @throws Exception
	 */
	private List<Map<String, Object>> findComExrt(String trandt)
			throws Exception {
		Connection conn = getConnection();
		if (conn == null) {
			return null;
		}

		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			pst = conn.prepareStatement(FIND_COM_EXRT_BY_TRANDT);
			pst.setString(1, trandt);
			pst.setString(2, trandt);

			List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
			rs = pst.executeQuery();
			while (rs.next()) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("crcycd", rs.getString("crcycd"));
				map.put("middpr", rs.getBigDecimal("middpr"));
				map.put("exunit", rs.getBigDecimal("exunit"));
				map.put("crcyen", rs.getString("crcyen"));
				list.add(map);
			}
			return list;
		} catch (Exception ex) {
			log.error("��ѯ���л��ʱ�������" + ex.getMessage());
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pst != null) {
					pst.close();
				}
				// closeConnection();
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		return null;
	}

	/**
	 * ������������ʱ�
	 * 
	 * @param stacid
	 * @return
	 * @throws Exception
	 */
	private List<Map<String, Object>> findComCvrt(String trandt)
			throws Exception {
		Connection conn = getConnection();
		if (conn == null) {
			return null;
		}

		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			pst = conn.prepareStatement(FIND_COM_CVRT_BY_TRANDT);
			pst.setString(1, trandt);

			List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
			rs = pst.executeQuery();
			while (rs.next()) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("crcycd", rs.getString("crcycd"));
				map.put("cvrtrt", rs.getBigDecimal("cvrtrt"));
				list.add(map);
			}
			return list;
		} catch (Exception ex) {
			log.error("��ѯ��������ʱ�������" + ex.getMessage());
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pst != null) {
					pst.close();
				}
				// closeConnection();
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		return null;
	}

	/**
	 * ����״̬����ѯ
	 * 
	 * @param stacid
	 * @param plancd
	 * @param bathid
	 * @return
	 */
	private GloImdtBean getGloImdtInfo(String stacid, String plancd,
			String bathId) {
		Connection conn = getConnection();
		if (conn == null) {
			return null;
		}

		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			pst = conn.prepareStatement(FIND_GLO_IMDT_BY_KEY_TYPE);
			pst.setString(1, stacid);
			pst.setString(2, bathId);
			pst.setString(3, plancd);

			rs = pst.executeQuery();
			while (rs.next()) {
				GloImdtBean info = new GloImdtBean();
				info.setStacid(stacid);
				info.setAcctbr(rs.getString("acctbr"));
				info.setBathid(bathId);
				info.setBrchcd(rs.getString("brchcd"));
				info.setCurrdt(rs.getString("currdt"));
				info.setDatach(rs.getString("datach"));
				info.setNextdt(rs.getString("nextdt"));
				info.setPlancd(plancd);
				info.setSourdt(rs.getString("sourdt"));
				info.setSourst(rs.getString("sourst"));
				info.setStatus(rs.getString("status"));
				info.setSwitdt(rs.getString("switdt"));
				info.setUsercd(rs.getString("usercd"));
				info.setTypecd(rs.getString("typecd"));

				return info;
			}
		} catch (Exception ex) {
			log.error("��ѯ����״̬��������" + ex.getMessage());
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pst != null) {
					pst.close();
				}
				// closeConnection();
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		return null;
	}

	/**
	 * ���ɻ�������
	 * 
	 * @param stacid
	 * @param systid
	 * @param batchId
	 * @return
	 */
	private String generateExchangeRate(String stacid, String systid,
			String batchId) {
		log.debug("start GenerateExchangeRateExecuter.generateExchangeRate......");
		List<String> crcycdList = new ArrayList<String>();
		List<HashMap<String, String>> txbExrtList = new ArrayList<HashMap<String, String>>();
		CommonDao commonDao = new CommonDao(getJrafSession());
		List<Map<String, Object>> comExrtList;
		List<Map<String, Object>> comCvrtList;
		BigDecimal f = null;
		try {
			commonDao.beginTransaction();
			comExrtList = findComExrt(batchId);
			for (Map<String, Object> comExrt : comExrtList) {
				if (!crcycdList.contains((String) comExrt.get("crcycd"))) {
					HashMap<String, String> hashmap = new HashMap<String, String>();
					hashmap.put("trandt", batchId);
					hashmap.put("crcycd", (String) comExrt.get("crcycd"));
					hashmap.put("tocrcy", TOCRCY);
					hashmap.put("exunit", String.valueOf(comExrt.get("exunit")));
					BigDecimal f1 = (BigDecimal) comExrt.get("middpr");
					hashmap.put("exchrt", String.valueOf(f1));
					if (USD_CRCYEN.equals((String) comExrt.get("crcyen"))) {
						f = (BigDecimal) comExrt.get("middpr");
					}
					txbExrtList.add(hashmap);
					crcycdList.add((String) comExrt.get("crcycd"));
				}
			}
			if (f != null) {
				comCvrtList = findComCvrt(batchId);
				for (Map<String, Object> comCvrt : comCvrtList) {
					if (!crcycdList.contains((String) comCvrt.get("crcycd"))) {
						HashMap<String, String> hashmap = new HashMap<String, String>();
						hashmap.put("trandt", batchId);
						hashmap.put("crcycd", (String) comCvrt.get("crcycd"));
						hashmap.put("tocrcy", TOCRCY);
						hashmap.put("exunit", EXUNIT);
						BigDecimal m = (BigDecimal) comCvrt.get("cvrtrt");
						hashmap.put("exchrt", String.valueOf(m.multiply(f)));
						txbExrtList.add(hashmap);
						crcycdList.add((String) comCvrt.get("crcycd"));
					}
				}
			}
			if (txbExrtList.size() == 0) {
				commonDao.rollBack();
				return "null";
			}
			commonDao.deleteByNamedSql(
					"com.sunline.sundp.mybatis.exchangeratedata.deleterate",
					txbExrtList.get(0));
			String nextday=null;
			if (isGenNextDayRate) {
				Date date = DatetimeUtil.getDateByDay(DatetimeUtil
						.changeToDBDate(DatetimeUtil.changeToDate(txbExrtList
								.get(0).get("trandt"), "yyyyMMdd")), 1);
				Map<String, Object>hp=new HashMap<String, Object>();
				nextday=DatetimeUtil.formatDate(date, "yyyyMMdd");
				hp.put("trandt", nextday);
				commonDao
						.deleteByNamedSql(
								"com.sunline.sundp.mybatis.exchangeratedata.deleterate",
								hp);
			}

			for (HashMap<String, String> txbExrt : txbExrtList) {
				commonDao
						.insertByNamedSql(
								"com.sunline.sundp.mybatis.exchangeratedata.insertrate",
								txbExrt);
				if (nextday!=null) {
					txbExrt.put("trandt", nextday);
					commonDao
							.insertByNamedSql(
									"com.sunline.sundp.mybatis.exchangeratedata.insertrate",
									txbExrt);
				}
			}
			commonDao.commitTransaction();
			log.debug("end GenerateExchangeRateExecuter.generateExchangeRate......");
			return "success";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			commonDao.rollBack();
			log.error("���ɻ������ݱ�����" + e.getMessage());
			log.debug("end GenerateExchangeRateExecuter.generateExchangeRate......");
			return "fail";
		}
	}

	/*
	 * ��һ����������м�һ����¼,���ظ��ľͲ�������
	 */
	private void insertDataToGloImdt(String stacid, String sourst,
			String sourdt, String acctbr, String bathid, String usercd,
			String brchcd, String status, String nextdt, String currdt,
			String switdt, String plancd, String datach) throws BimisException {
		Connection conn = getConnection();
		if (conn == null) {
			return;
		}

		PreparedStatement pst = null;

		try {
			pst = conn.prepareStatement(INSERT_GLO_IMDT);

			pst.setBigDecimal(1, BigDecimal.valueOf(Integer.valueOf(stacid)));
			pst.setString(2, sourst);
			pst.setString(3, sourdt);
			pst.setString(4, acctbr);
			pst.setString(5, bathid);
			pst.setString(6, usercd);
			pst.setString(7, brchcd);
			pst.setString(8, status);
			pst.setString(9, nextdt);
			pst.setString(10, currdt);
			pst.setString(11, switdt);
			pst.setString(12, plancd);
			pst.setString(13, datach);
			pst.setString(14, "1");

			pst.execute();
		} catch (Exception ex) {
			log.error("��glo_imdt���в��������쳣:" + ex.getMessage());
		} finally {
			try {
				if (pst != null) {
					pst.close();
				}
				// closeConnection();
			} catch (Exception ex) {
				log.error(ex.getMessage());
			}
		}
	}

	/**
	 * ����glo_imdt״̬
	 */
	private void updateGloImdtStatus(String stacid, String bathid,
			String status, String plancd, String datach) throws BimisException {
		Connection conn = getConnection();
		if (conn == null) {
			return;
		}

		PreparedStatement pst = null;
		try {
			pst = conn.prepareStatement(UPDATE_GLO_IMDT_STATUS);
			pst.setString(1, status);
			pst.setBigDecimal(2, BigDecimal.valueOf(Integer.valueOf(stacid)));
			pst.setString(3, bathid);
			pst.setString(4, plancd);
			pst.setString(5, datach);

			pst.execute();
		} catch (Exception ex) {
			log.error("����glo_imdt״̬������" + ex.getMessage());
		} finally {
			try {
				if (pst != null) {
					pst.close();
				}
				// closeConnection();
			} catch (Exception ex) {
				log.error(ex.getMessage());
			}
		}
	}

	@Override
	public Comparator<Object> getComparator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> selectTasks(String taskParameter, String ownSign,
			int taskItemNum, List<TaskItemDefine> taskItemList,
			int eachFetchDataNum) throws Exception {
		// TODO Auto-generated method stub
		log.debug("start GenerateExchangeRateExecuter.selectTasks......");
		String stacid = "";
		String plancd = "";
		String systid = "";
		HashMap<String, String> map = StringUtils.String2Map(taskParameter);
		stacid = map.get("stacid");
		plancd = map.get("plancd");
		systid = map.get("systid");
		isGenNextDayRate = map.get("isGenNextDayRate") == null ? false
				: "true".equals(map.get("isGenNextDayRate"));
		log.debug("����������л�ȡ����Ϊ��" + stacid + " �������� = " + plancd + " ϵͳID = "
				+ systid);

		String trandt = getBsnsdt(stacid);
		log.debug("����ҵ�����ڣ�" + trandt);

		GloImdtBean gloImdtInfo = getGloImdtInfo(stacid, plancd, trandt);
		List<Object> list = new ArrayList<Object>();
		ReturnData rd = new ReturnData();
		rd.setStacid(stacid);
		rd.setPlancd(plancd);// ��Ҫ���ҵı�����
		rd.setBatchId(trandt);// ���κ�
		rd.setGloImdtInfo(gloImdtInfo);
		rd.setSystid(systid);
		rd.setCertno(DATACH);
		list.add(rd);
		log.debug("end GenerateExchangeRateExecuter.selectTasks......");
		return list;
	}

	@Override
	public boolean execute(Object task, String ownSign) throws Exception {
		// TODO Auto-generated method stub
		log.debug("start GenerateExchangeRateExecuter.execute......");
		ReturnData rd = (ReturnData) task;
		String stacid = rd.getStacid();
		String plancd = rd.getPlancd();
		String batchId = rd.getBatchId();
		GloImdtBean gloImdtInfo = rd.getGloImdtInfo();
		String systid = rd.getSystid();
		String certno = rd.getCertno();
		if (gloImdtInfo == null) {
			String usercd = "****";
			String brchcd = "****";
			String nextdt = "";
			String currdt = "";
			String switdt = "";
			String acctbr = "";
//			String sourdt = DatetimeUtil
//					.getCurDate(DatetimeUtil.DATE_FORMAT_YMD);
			String sourdt = batchId;
			String isGliImpSuccess = this.generateExchangeRate(stacid, systid,
					batchId);
			if ("null".equals(isGliImpSuccess)) {
				log.debug("����ҵ�����ڡ�" + batchId + "��û�л������ݣ���ȷ�ϣ�");
				return true;
			}
			String imdtStatus = "success".equals(isGliImpSuccess) ? IMPORT_COMPLETED
					: IMPORT_FAILED;
			// ����gloImdt��¼
			insertDataToGloImdt(stacid, systid, sourdt, acctbr, batchId,
					usercd, brchcd, imdtStatus, nextdt, currdt, switdt, plancd,
					certno);
		} else {
			if (IMPORT_FAILED.equals(gloImdtInfo.getStatus())) {// ����ʧ�ܵļ�¼
				String isGliImpSuccess = this.generateExchangeRate(stacid,
						systid, batchId);
				String imdtStatus = "success".equals(isGliImpSuccess) ? IMPORT_COMPLETED
						: IMPORT_FAILED;
				this.updateGloImdtStatus(stacid, batchId, imdtStatus, plancd,
						certno);
			} else if (IMPORT_COMPLETED.equals(gloImdtInfo.getStatus())) {
				log.debug("����ҵ�����ڡ�" + batchId + "�������ɻ������ݣ�");
			}
		}
		log.debug("end GenerateExchangeRateExecuter.execute......");
		return true;
	}

}
