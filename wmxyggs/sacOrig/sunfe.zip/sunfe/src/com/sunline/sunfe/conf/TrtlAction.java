package com.sunline.sunfe.conf;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.sunfe.base.PrtpAction;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.util.StringUtils;

public class TrtlAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.trtl.";
	private final String TAX_SEP_RULE = "pf_price_tx_separated";
	private final String TAX_SEP_COMMAND = "pf_price_tx_separarule";
	 

 
	private final static String PROFID_STANDARD = "T001";
	Log log = new Log(PrtpAction.class);
	/**
	 * ��ѯ�������ӽ��� & queryTrtlListPage
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	public void queryTrtlListPage() throws BimisException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			String tranna = StringUtils.repalceCharecter(hashmap.get("tranna"));
			String prcsna = StringUtils.repalceCharecter(hashmap.get("prcsna"));
			hashmap.put("prcsna", prcsna);
			hashmap.put("tranna", tranna);
			hashmap.put("vermod", "0");
			hashmap.put("stacid", SessionParaUtils.getStacid());
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryTrtllistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			log.logError(e);
		}
	}
	
	/**
	 * ���ݴ�������ӽ��״������ϵͳ���׷�����Ϣ
	 */
	@SuppressWarnings("unchecked")
	public void queryTrtlInfo(){
		try 
		{
			HashMap<String, String> hashmap =  (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("vermod", "0");
			Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryTrtlInfo", hashmap);	
            req.addRspData(e.removeContent());        //���ؽ����װ	
            Element templateEle = commonDao.queryByNamedSql(MYBATIS_NS+"queryTmapTranByPrcscdlistPage",hashmap);
            req.addRspData("Results2",templateEle.removeContent());   //���ؽ����װ
		} catch (Exception e) {
			log.logError(e);
		}
	 }	
	
	/**
	 *  ϵͳ���׷�����Ϣ¼��
	 * @throws JDOMException 
	 */
	@SuppressWarnings("rawtypes")
	public void addTrtl() throws JDOMException{
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			HashMap<String, String> hashmap2 = new HashMap<String, String>();
			commonDao.beginTransaction();
			String prcscd = req.getReqDataStr("prcscd");
			String sortno = req.getReqDataStr("sortno");
			String trancd = req.getReqDataStr("trancd");
			String maintg = req.getReqDataStr("maintg");
			String trgpid = req.getReqDataStr("trgpid");
			String condcd = req.getReqDataStr("condcd");
			String trcond = req.getReqDataStr("trcond");
			String chrgtg = req.getReqDataStr("chrgtg");
			String vermod = req.getReqDataStr("vermod");
			String projcd = req.getReqDataStr("projcd");
			String module = req.getReqDataStr("module");
			String stacid = req.getReqDataStr("stacid");
			
			List<String> tsortno_list = req.getReqDataTexts("tsortno");//����˳��
			List<String> fildcd_list = req.getReqDataTexts("fildcd");//�����ֶ���
			List<String> mpcdin_list = req.getReqDataTexts("mpcdin");//����ӳ������
			List<String> mpcdot_list = req.getReqDataTexts("mpcdot");//����ӳ�����
			List<String> rowNo_list = req.getReqDataTexts("rowNo");//
			
			hashmap.put("prcscd", prcscd);
			hashmap.put("stacid", stacid);
			hashmap.put("sortno", sortno);
			hashmap.put("trancd", trancd);
			hashmap.put("maintg", maintg);
			hashmap.put("trgpid", trgpid);
			hashmap.put("condcd", condcd);
			hashmap.put("trcond", trcond);
			hashmap.put("chrgtg", chrgtg);
			hashmap.put("vermod", vermod);
			hashmap.put("projcd", projcd);
			hashmap.put("module", module);
			
			//���׽��׳����ӽ����Ƿ��Ѵ���
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTrtl", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "�ý��׽��׳����ӽ����Ѵ��ڣ�");
					return;
				}
			}
			commonDao.insertByNamedSql(MYBATIS_NS+"addTrtl", hashmap);
			  if(tsortno_list.size()>0&&tsortno_list!=null){
			    	for(int i=0;i<tsortno_list.size();i++){
		    		    String proftp = req.getReqDataStr("proftp"+rowNo_list.get(i));//��������
					    String profid = req.getReqDataStr("profid"+rowNo_list.get(i));//����id
					    String tcondcd = req.getReqDataStr("tcondcd"+rowNo_list.get(i));//������
					    String nulflg = req.getReqDataStr("nulflg"+rowNo_list.get(i));//�ǿձ�ʶ
					    hashmap2.clear();
					    String tsortno = tsortno_list.get(i);
					    if(!"".equals(tsortno)&&tsortno!=null){
					       hashmap2.put("stacid", stacid);//����
						   hashmap2.put("tsortno", tsortno);//����˳��
						   hashmap2.put("vermod", vermod);//�汾ģʽ
						   hashmap2.put("dttrcd", trancd);//�ӽ���������
						   hashmap2.put("trtlno", sortno);//�ӽ���˳���
						   hashmap2.put("module", module);//ģ��
						   hashmap2.put("vermod", "0");
						   hashmap2.put("projcd", projcd);//��Ŀ���
						   hashmap2.put("prcscd", prcscd);//������
						   hashmap2.put("fildcd", fildcd_list.get(i));//�����ֶ���
						   hashmap2.put("proftp", proftp);//��������
						   hashmap2.put("profid", profid);//����Id
						   hashmap2.put("tcondcd", tcondcd);//������
						   hashmap2.put("nulflg", nulflg);//�����ǿձ�־
						   hashmap2.put("mpcdin", mpcdin_list.get(i));//��������ӳ����봮
						   hashmap2.put("mpcdot", mpcdot_list.get(i));//�������ӳ����봮
						   //�ж��Ƿ����д��ڵĽ��׷�������
							List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTmapTran", hashmap2);
							if(sumList!=null && sumList.size()>0) {
								Map sumMap = (HashMap)sumList.get(0);
								int sum = Integer.valueOf(sumMap.get("CC").toString());
								if(sum > 0) {
									commonDao.rollBack();
									req.addRspData("retCode", "300");
									req.addRspData("retMessage", "��"+(i+1)+"���׷��������Ѵ��ڣ�");
									return;
								}
							}
						  commonDao.insertByNamedSql(MYBATIS_NS+"insertTmapTran", hashmap2);//�������׷�������
					   }
				   }
			   }
			  	ResultUtils.setRspData(req, "200",  "�����ɹ�", "trtl_main", "closeCurrent", "");
				commonDao.commitTransaction();
			} catch (BimisException e) {
				commonDao.rollBack();
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
				log.logError(e);
		  }
	}
	/**
	 *  ά��ϵͳ���׷�����Ϣ
	 * @throws JDOMException 
	 */
	@SuppressWarnings("rawtypes")
	public void updateTrtl() throws JDOMException{
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			HashMap<String, String> hashmap2 = new HashMap<String, String>();
			HashMap<String, String> hashmap3 = new HashMap<String, String>();
			commonDao.beginTransaction();
			
			String prcscd = req.getReqDataStr("prcscd");
			String sortno = req.getReqDataStr("sortno");
			String trancd = req.getReqDataStr("trancd");
			String maintg = req.getReqDataStr("maintg");
			String trgpid = req.getReqDataStr("trgpid");
			String condcd = req.getReqDataStr("condcd");
			String trcond = req.getReqDataStr("trcond");
			String chrgtg = req.getReqDataStr("chrgtg");
			String projcd = req.getReqDataStr("projcd");
			String module = req.getReqDataStr("module");
			String stacid = req.getReqDataStr("stacid");
			
			List<String> tsortno_list = req.getReqDataTexts("tsortno");
			List<String> fildcd_list = req.getReqDataTexts("fildcd");
			List<String> mpcdin_list = req.getReqDataTexts("mpcdin");
			List<String> mpcdot_list = req.getReqDataTexts("mpcdot");
			List<String> rowNo_list = req.getReqDataTexts("rowNo");//
			
			hashmap.put("prcscd", prcscd);
			hashmap.put("stacid", stacid);
			hashmap.put("sortno", sortno);
			hashmap.put("trancd", trancd);
			hashmap.put("maintg", maintg);
			hashmap.put("trgpid", trgpid);
			hashmap.put("condcd", condcd);
			hashmap.put("trcond", trcond);
			hashmap.put("chrgtg", chrgtg);
			hashmap.put("projcd", projcd);
			hashmap.put("module", module);
			
			
			commonDao.updateByNamedSql(MYBATIS_NS+"updateTrtl", hashmap);
			hashmap.put("vermod", "0");
			commonDao.insertByNamedSql(MYBATIS_NS+"addTrtl", hashmap);
			
			commonDao.updateByNamedSql(MYBATIS_NS+"updateTran", hashmap);
			
			hashmap3.put("sortno", sortno);
			hashmap3.put("prcscd", prcscd);
			if(tsortno_list.size()>0&&tsortno_list!=null){
			    	for(int i=0;i<tsortno_list.size();i++){
		    		    String proftp = req.getReqDataStr("proftp"+rowNo_list.get(i));
					    String profid = req.getReqDataStr("profid"+rowNo_list.get(i));
					    String tcondcd = req.getReqDataStr("tcondcd"+rowNo_list.get(i));
					    String nulflg = req.getReqDataStr("nulflg"+rowNo_list.get(i));
					    hashmap2.clear();
					    String tsortno = tsortno_list.get(i);
					    if(!"".equals(tsortno)&&tsortno!=null){
						   hashmap2.put("tsortno", tsortno);//����˳��
						   hashmap2.put("vermod", "0");//�汾ģʽ
						   hashmap2.put("stacid", stacid);//�汾ģʽ
						   hashmap2.put("dttrcd", trancd);//�ӽ���������
						   hashmap2.put("trtlno", sortno);//�ӽ���˳���
						   hashmap2.put("module", module);//ģ��
						   hashmap2.put("projcd", projcd);//��Ŀ���
						   hashmap2.put("prcscd", prcscd);//������
						   hashmap2.put("fildcd", fildcd_list.get(i));//�����ֶ���
						   hashmap2.put("proftp", proftp);//��������
						   hashmap2.put("profid", profid);//����Id
						   hashmap2.put("tcondcd",tcondcd);//������
						   hashmap2.put("nulflg", nulflg);//�����ǿձ�־
						   hashmap2.put("mpcdin", mpcdin_list.get(i));//��������ӳ����봮
						   hashmap2.put("mpcdot", mpcdot_list.get(i));//�������ӳ����봮
						   //�ж�,�Ƿ����д��ڵĽ��׷�������
							List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTmapTran", hashmap2);
							if(sumList!=null && sumList.size()>0) {
								Map sumMap = (HashMap)sumList.get(0);
								int sum = Integer.valueOf(sumMap.get("CC").toString());
								if(sum > 0) {
									req.addRspData("retCode", "300");
									req.addRspData("retMessage", "���׷��������Ѵ��ڣ�");
									return;
								}
							}
						  commonDao.insertByNamedSql(MYBATIS_NS+"insertTmapTran", hashmap2);//�������׷�������
					   }
				   }
			   }
			ResultUtils.setRspData(req, "200",  "�����ɹ�", "trtl_main", "closeCurrent", "");
			commonDao.commitTransaction();
		} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
	  }
	}
	
	/**
	 * �������ɾ��ϵͳ���׷�����Ϣ
	 * @throws JDOMException 
	 */
	 public void deleteManyTrtl() throws JDOMException {
	        try {
	        	HashMap<String, String> param = new HashMap<String, String>();
	            List<String> prcscdsortnoList = req.getReqDataTexts("prcscdsortno");
	            commonDao.beginTransaction();
	            for (int i=0;i<prcscdsortnoList.size();i++) {
	            	param.clear();
	                String [] array = prcscdsortnoList.get(i).split("-");
                    param.put("prcscd", array[0]);
                    param.put("trancd", array[1]);
                    param.put("projcd", array[2]);
                    param.put("stacid", array[3]);
                   //ɾ��ϵͳ���׷�����Ϣʱ��ɾ����Ӧ�Ĵӱ�SYS_TMAP_TRAN�µ�����
                    commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTmapTran", param);
                    commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTrtl", param);
                    param.put("proftp", TAX_SEP_COMMAND);
                    commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTmap", param);
	            }
	            commonDao.commitTransaction();
				ResultUtils.setRspData(req, "200",  "�����ɹ�", "trtl_main", "", "");
	        } catch (BimisException e) {
				commonDao.rollBack();
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
				log.logError(e);
		}		
		}	

	/**
	 * ����ɾ��ϵͳ���׷�����Ϣ & deleteTrtl
	 * @throws JDOMException 
	 */
	public void deleteTrtl() throws JDOMException{
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			commonDao.beginTransaction();
				String prcscd = req.getReqDataStr("prcscd");
				String trancd = req.getReqDataStr("trancd");
				String projcd = req.getReqDataStr("projcd");
				
				hashmap.put("prcscd", prcscd);
				hashmap.put("projcd", projcd);
				hashmap.put("trancd", trancd);
				hashmap.put("stacid", req.getReqDataStr("stacid"));
				//ɾ��ϵͳ���׷�����Ϣʱ��ɾ����Ӧ�Ĵӱ�SYS_TMAP_TRAN�µ�����
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTmapTran", hashmap);
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTrtl", hashmap);
				hashmap.put("proftp", TAX_SEP_COMMAND);
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTmap", hashmap);
				commonDao.commitTransaction();
				ResultUtils.setRspData(req, "200",  "�����ɹ�", "trtl_main", "", "");
	        } catch (BimisException e) {
				commonDao.rollBack();
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
				log.logError(e);
		}		
	  }	 
	
	
	/**
	 * �������׳����ӽ��ף������汾��
	 * @return
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "unchecked"})
	public void addSysTrtl() throws JDOMException{
		try {
			commonDao.beginTransaction();
			//��������
			HashMap<String, Object> hashmap = (HashMap<String, Object>) req.getReqDataMap();
			List<HashMap<String,String>> e = (List<HashMap<String, String>>) 
					commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkPrcscd", hashmap);
			if(e.size() > 0 ){
				ResultUtils.setRspData(req, "300",  "���׳����Ѵ���", "", "", "");
				return;
			}
			insertData(hashmap);
			ResultUtils.setRspData(req, "200",  "�����ɹ�", "trtl_main", "closeCurrent", "");
			commonDao.commitTransaction();
	        } catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
		}		
	}
	
	/**
     * ��ȡ��ϸ������Ϣ
     * @param hashmap
     * @param trancd
     * @param sortno 
     * @return
     */
    @SuppressWarnings("unchecked")
	private ArrayList<HashMap<String, String>> getTmapTran(HashMap<String, Object> hashmap, String trancd ) {
	    	 ArrayList<HashMap<String,String>> tmapTranList = new ArrayList<HashMap<String,String>>(); 
	    	 ArrayList<String> indexList  =  (ArrayList<String>) hashmap.get("index_"+trancd);
    	 	 for (int i = 1; i < indexList.size(); i++) {
    	 		HashMap<String, String>   tmapTran = new HashMap<String, String>();
    			   tmapTran.put("stacid",  hashmap.get("stacid").toString());//����
    			   tmapTran.put("tsortno", String.valueOf(i) );//����˳��
    			   tmapTran.put("vermod", "0");//�汾ģʽ
    			   tmapTran.put("dttrcd", trancd);//�ӽ���������
//    			   tmapTran.put("trtlno", String.valueOf(sortno));//�ӽ���˳���
    			   tmapTran.put("module", hashmap.get("module").toString());//ģ��
    			   tmapTran.put("vermod", "0");
    			   tmapTran.put("projcd", ".");//��Ŀ���
    			   tmapTran.put("prcscd", hashmap.get("prcscd").toString());//������
    			   tmapTran.put("fildcd", hashmap.get("fildcd_"+trancd+"_"+indexList.get(i)).toString());//�����ֶ���
    			   tmapTran.put("proftp", hashmap.get("proftp_"+trancd+"_"+indexList.get(i)).toString());//��������
    			   tmapTran.put("profid", hashmap.get("profid_"+trancd+"_"+indexList.get(i)).toString());//����Id
    			   tmapTran.put("tcondcd",hashmap.get("tcondcd_"+trancd+"_"+indexList.get(i)).toString());//������
    			   tmapTranList.add(tmapTran);
		    }
    	 	String taxsep = hashmap.get("taxsep").toString();
    	 	if(taxsep.equals("1")){
    	 	   HashMap<String, String>   tmapTran = new HashMap<String, String>();
 			   tmapTran.put("stacid",  hashmap.get("stacid").toString());//����
 			   tmapTran.put("tsortno", String.valueOf(tmapTranList.size()+1));//����˳��
 			   tmapTran.put("vermod", "0");//�汾ģʽ
 			   tmapTran.put("dttrcd", trancd);//�ӽ���������
 			   tmapTran.put("module", hashmap.get("module").toString());//ģ��
 			   tmapTran.put("vermod", "0");
 			   tmapTran.put("projcd", ".");//��Ŀ���
 			   tmapTran.put("prcscd", hashmap.get("prcscd").toString());//������
 			   tmapTran.put("fildcd", "temp");//�����ֶ���
 			   tmapTran.put("proftp",TAX_SEP_RULE);//��������
 			   tmapTran.put("profid", "temp");//����Id
 			   tmapTran.put("tcondcd","");//������
 			   tmapTranList.add(tmapTran);
    	 	}
		return tmapTranList;
	}
    
    
    
    
   /**
    * ��ȡ���׳����ӽ�����ϸ
    */
    @SuppressWarnings("unchecked")
	public void getTrtlDetl(){
	   try 
		{
		   commonDao.beginTransaction();
		   HashMap<String, String> hashmap =  (HashMap<String, String>) req.getReqDataMap();
		   hashmap.put("vermod", "0");
		   Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryTrtlInfo", hashmap);
//		   //���¼��ý��׳����¶�Ӧ���ӽ�����Ϣ���Ƿ��ѷ����޸ģ���������޸������¼��ط����޸Ĳ��ֵ���Ϣ��
//		   updateTmapByTrcd(e);
           req.addRspData(e.removeContent()); 
           Element trancds = commonDao.queryByNamedSql(MYBATIS_NS+"getTrancds", hashmap);	
           req.addRspData("Results1",trancds.removeContent()); 
           hashmap.put("proftp", TAX_SEP_RULE);
           Element templateEle = commonDao.queryByNamedSql(MYBATIS_NS+"queryTmapTranByPrcscdlistPage",hashmap);
           req.addRspData("Results2",templateEle.removeContent());   //���ؽ����װ
           commonDao.commitTransaction();
		} catch (Exception e) {
		   commonDao.rollBack();
		   log.logError(e);
		}
   }
  
/**
    * �޸Ľ��׳����ӽ��ף������汾��
 * @throws JDOMException 
    */
    @SuppressWarnings({ "unchecked"})
	public void updateSysTrtl() throws JDOMException{
			try {
				commonDao.beginTransaction();
				//��������
				HashMap<String, Object> hashmap = (HashMap<String, Object>) req.getReqDataMap();
				//map���sys_trtl������Ϣ
				HashMap<String,String> trtl = new HashMap<String,String>();
					trtl.put("prcscd", hashmap.get("prcscd").toString());//���׳���
					trtl.put("trancd", hashmap.get("trancd").toString());//���׳���
					trtl.put("stacid", hashmap.get("stacid").toString());//����
					trtl.put("proftp", TAX_SEP_COMMAND);
				commonDao.updateByNamedSql(MYBATIS_NS+"updateTrtl", trtl);
				commonDao.updateByNamedSql(MYBATIS_NS+"updateTran", trtl);
				commonDao.updateByNamedSql(MYBATIS_NS+"updateTmap", trtl);
				insertData(hashmap);
				commonDao.commitTransaction();
				ResultUtils.setRspData(req, "200",  "�����ɹ�", "trtl_main", "closeCurrent", "");
			} catch (BimisException e) {
				commonDao.rollBack();
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
				log.logError(e);
			}
			
    }
    
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public void insertData(HashMap<String, Object> hashmap) throws JDOMException, BimisException{
			//map���sys_trtl������Ϣ
			HashMap<String,String> trtl = new HashMap<String,String>();
			    String taxsep = hashmap.get("taxsep").toString();
				trtl.put("prcscd", hashmap.get("prcscd").toString());//���׳���
				trtl.put("stacid", hashmap.get("stacid").toString());//����
				trtl.put("vermod", "0");//�汾
				trtl.put("projcd", ".");//��Ŀ���
				trtl.put("maintg", "1");//�����ױ�־
				trtl.put("module", hashmap.get("module").toString());//�����ױ�־
				trtl.put("desctx", hashmap.get("desctx").toString());//˵��
				trtl.put("taxsep", taxsep);//˵��
			ArrayList<String> trancds = new ArrayList<>();
			//hashmap.get("trancd")ΪString ���� �ӽ���ֻ��һ���������ж��hashmap.get("trancd")Ϊ����
			Object trancd_object = hashmap.get("trancd");
			if(trancd_object instanceof String){
				trancds.add(trancd_object.toString());
			}else{
				trancds = (ArrayList<String>) hashmap.get("trancd");
			}
//			int sortno = 1;
			for (Iterator iterator = trancds.iterator(); iterator.hasNext();) {
				  String trancd = ( String) iterator.next();
				  trtl.put("trancd", trancd);//�ӽ���
//				  trtl.put("sortno", String.valueOf(sortno));//�ӽ���
				//���׽��׳����ӽ����Ƿ��Ѵ���
					List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTrtl", trtl);
					if(countList!=null && countList.size()>0) {
						Map countMap = (HashMap)countList.get(0);
						int count = Integer.valueOf(countMap.get("CC").toString());
						if(count > 0) {
							throw new BimisException("-1","�ý��׽��׳����Ѵ���!");
						}
					 }
				  commonDao.insertByNamedSql(MYBATIS_NS+"addTrtl", trtl);
				  //��ȡ��ϸ����Ϣ
				  ArrayList<HashMap<String,String>> tmapTranList = getTmapTran(hashmap,trancd);
				  for (int j = 0; j < tmapTranList.size(); j++) {
					    HashMap<String, String> hashMap2 = tmapTranList.get(j);
					    //�ж��Ƿ����д��ڵĽ��׷�������
						List sumList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTmapTran", hashMap2);
						if(sumList!=null && sumList.size()>0) {
							Map sumMap = (HashMap)sumList.get(0);
							int sum = Integer.valueOf(sumMap.get("CC").toString());
							if(sum > 0) {
								throw new BimisException("-1", "�ӽ���"+trancd+"�ĵ�"+(j+1)+"�����׷��������Ѵ��ڣ�");
							}
						}
					  commonDao.insertByNamedSql(MYBATIS_NS+"insertTmapTran", hashMap2);//�������׷�������
				  }
				  
				  //���׳�����Ҫ��˰����ʱ�����Ӽ�˰����ָ��
				  if(taxsep.equals("1")){
					  List<HashMap<String,String>> syspmap = (List<HashMap<String, String>>) 
							  					commonDao.queryByNamedSqlForList(MYBATIS_NS+"getPmapBytrancd", trancd);
					  for (Iterator iterator2 = syspmap.iterator(); iterator2.hasNext();) {
						HashMap<String, String> pmap = (HashMap<String, String>) iterator2.next();
						pmap.put("proftp", TAX_SEP_COMMAND);
						pmap.put("profid", PROFID_STANDARD);
						pmap.put("vermod", "0");
						commonDao.updateByNamedSql(MYBATIS_NS+"updateTmapByPmap", pmap);
						commonDao.insertByNamedSql(MYBATIS_NS+"insetTmapByPmap", pmap);
					}
				  }
				  
			 }
		}		
    
    /**
     * ��Դ��Ϊ���ֵʱ����ѯ��Դ��
     */
	public void getFilnaMulit(){
    	 try {
    		HashMap<String,String> param = new HashMap<String,String>();
			String fildcd = req.getReqDataStr("fildcd");
			String module = req.getReqDataStr("module");
			param.put("module", module);
			String[] fildcds = fildcd.split(",");
			String fildnas = "";
			for (int i = 0; i < fildcds.length; i++) {
				param.put("fildcd", fildcds[i]);
				String fildna = commonDao.getSqlSession().selectOne(MYBATIS_NS+"getFilnaMulit", param);
				fildnas +=fildna + ",";
			}
			fildnas = fildnas.substring(0, fildnas.length()-1);
			req.addRspData("flinas", fildnas);
		} catch (JDOMException e) {
			log.logError(e);
		}
     }
   
}
