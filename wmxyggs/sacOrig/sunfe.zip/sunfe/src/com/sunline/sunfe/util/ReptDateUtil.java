package com.sunline.sunfe.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.sunline.jraf.util.DatetimeUtil;

/**
 * Ƶ�����ڻ�ȡ ������
 * @author zhangdq
 *
 */
public class ReptDateUtil {
	/**
	 * @Descrirption:���ݱ���Ƶ�Ⱥ͵�ǰ����,��ȡ���ڽ�������
	 * @param acctdt
	 * @param reptfq
	 */	
	public static String getEndDayByReptfq(Date acctdt,String reptfq){
		String endDate = null;
		//�걨
		if("Y".equals(reptfq)){
			endDate=DatetimeUtil.formatDate(acctdt,"yyyy")+"1231";
		}
	    //�±�
		else if("M".equals(reptfq)){
			endDate=DatetimeUtil.getEndDayOfMonth(acctdt,"yyyyMMdd");
		}
		//����
		else if("Q".equals(reptfq)){
			int month = acctdt.getMonth();
			String year=DatetimeUtil.formatDate(acctdt,"yyyy");
			if(0<=month && month<=2){
				endDate=year+"0331";
			}
			else if(3<=month && month<=5){
				endDate=year+"0630";
			}
			else if(6<=month && month<=8){
				endDate=year+"0930";
			}
			else if(9<=month && month<=11){
				endDate=year+"1231";
			}
		}
		//�ձ�
		else if("D".equals(reptfq)){
			endDate=DatetimeUtil.formatDate(acctdt,"yyyyMMdd");	
		}
		return endDate;		
	}
	
	/**
	 * @Descrirption:���ݱ���Ƶ�Ⱥ͵�ǰ����,��ȡ���ڿ�ʼ����
	 * @param acctdt
	 * @param reptfq
	 */	
	public static String getFirstDayByReptfq(Date acctdt,String reptfq){
		String firstDate = null;
		//�걨
		if("Y".equals(reptfq)){
			firstDate=DatetimeUtil.formatDate(acctdt,"yyyy")+"0101";
		}
	    //�±�
		else if("M".equals(reptfq)){
			firstDate=DatetimeUtil.getFirstDayOfCurrentMonthForString(acctdt).replace("-", "");
		}
		//����
		else if("Q".equals(reptfq)){
			int month = acctdt.getMonth();
			String year=DatetimeUtil.formatDate(acctdt,"yyyy");
			if(0<=month && month<=2){
				firstDate=year+"0101";
			}
			else if(3<=month && month<=5){
				firstDate=year+"0401";
			}
			else if(6<=month && month<=8){
				firstDate=year+"0701";
			}
			else if(9<=month && month<=11){
				firstDate=year+"1001";
			}
		}
		//�ձ�
		else if("D".equals(reptfq)){
			firstDate=DatetimeUtil.formatDate(acctdt,"yyyyMMdd");	
		}
		return firstDate;		
	}
	
	/**
	 * @Descrirption:���ݱ���Ƶ�Ⱥ͵�ǰ����,��ȡ���ڽ�������
	 * @param acctdt
	 * @param reptfq
	 */	
	public static String getLastDayByReptfq(Date acctdt,String reptfq){
		String lastDate = null;
		//�걨
		if("Y".equals(reptfq)){
			lastDate=DatetimeUtil.getLastYearLastDay(acctdt,"yyyyMMdd");
		}
	    //�±�
		else if("M".equals(reptfq)){
			lastDate=DatetimeUtil.getLastMonthLastDay(acctdt);
		}
		//����
		else if("Q".equals(reptfq)){
			lastDate=DatetimeUtil.getEndDayOfSeason(DatetimeUtil.formatDate(acctdt,"yyyy-MM-dd")).replace("-", "");
		}
		//�ձ�
		else if("D".equals(reptfq)){
			lastDate=DatetimeUtil.getYesterdayOfOneDay(acctdt).replace("-", "");	
		}
		return lastDate;		
	}
	
	public static void main(String[] args) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");		
		try {
			Date dateNow=sdf.parse("20150203");
			System.out.println(getEndDayByReptfq(dateNow,"D"));
			System.out.println(getEndDayByReptfq(dateNow,"M"));
			System.out.println(getEndDayByReptfq(dateNow,"Q"));
			System.out.println(getEndDayByReptfq(dateNow,"Y"));
						
			System.out.println(getFirstDayByReptfq(dateNow,"D"));
			System.out.println(getFirstDayByReptfq(dateNow,"M"));
			System.out.println(getFirstDayByReptfq(dateNow,"Q"));
			System.out.println(getFirstDayByReptfq(dateNow,"Y"));
			
			System.out.println(getLastDayByReptfq(dateNow,"D"));
			System.out.println(getLastDayByReptfq(dateNow,"M"));
			System.out.println(getLastDayByReptfq(dateNow,"Q"));
			System.out.println(getLastDayByReptfq(dateNow,"Y"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
