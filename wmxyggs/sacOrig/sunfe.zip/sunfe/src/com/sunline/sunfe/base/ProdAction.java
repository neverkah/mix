package com.sunline.sunfe.base;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.util.StringUtils;

public class ProdAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.prod.";
	Log log = new Log("ProdAction");
	
	private final static String TMPLTP_STANDARD = "tl_loan_cain";
	private final static String PROFTP_STANDARD = "pf_loan_cain";
	private final static String PROFID_STANDARD = "T001";
	private final static String PROJCD_STANDARD = ".";
	private final static String VERMOD_0 = "0";
	/**
	 * ��ѯ��Ʒ�嵥 & queryProdListPage
	 */
	@SuppressWarnings("unchecked")
	public void queryProdListPage(){
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("prodcd", StringUtils.repalceCharecter(hashmap.get("prodcd")));
			hashmap.put("vermod","0");
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryProdlistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			log.logError(e);
		}
		
	}
	/**
	 * ����ϵͳ��Ʒ & addProd
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addProd() throws JDOMException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistProd", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "��Ʒ�����Ѵ��ڣ�");
					return;
				}
			}
			
			commonDao.insertByNamedSql(MYBATIS_NS+"addProd",hashmap);
			//����ģ���µ��ӽ���
			updateTrancdBymodule(hashmap);
			ResultUtils.setRspData(req, "200",  "�����ɹ�", "prod_main", "closeCurrent", "");
			commonDao.commitTransaction();
		} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��", "", "", "");
			log.logError(e);
		}
	}
	
	/**
	 * 
	 * @Title: updateTrancdBymodule 
	 * @date: 2018��3��27�� ����3:56:58 
	 * @Description: ���²�Ʒ����ģ���µ��ӽ�������
	 * @param hashmap
	 * @return: void
	 * @throws BimisException 
	 */
	@SuppressWarnings("unchecked")
	private void updateTrancdBymodule(HashMap<String, String> hashmap) throws BimisException {
		    List<String> trancds = (List<String>) commonDao.queryByNamedSqlForList(MYBATIS_NS+"getTrancdBymodule", hashmap);
			if(trancds.size() > 0){
				String stacid = SessionParaUtils.getStacid();
				hashmap.put("stacid", stacid);
				//����ԭ���������µ��ӽ��ײ�Ʒ����
				for(String trancd : trancds){
					 hashmap.put("trancd", trancd);
					 List<HashMap<String, String>> pmapList =
							 (List<HashMap<String, String>>)commonDao.queryByNamedSqlForList(MYBATIS_NS+"getPmap", hashmap);
					 if(pmapList.size() > 0){
						 int index = pmapList.size() + 1;
						 HashMap<String, String> pmap = pmapList.get(0);
						 String [] tmplidArray = pmap.get("tmplid").split("_");
						 StringBuffer tmplid = new StringBuffer();
						 for (int i = 0; i < tmplidArray.length-1; i++) {
							 tmplid.append(tmplidArray[i]).append("_") ;
						 }
						 tmplid.append(String.valueOf(index));
						 pmap.put("new_tmplid", tmplid.toString());
						 pmap.put("new_prodcd", hashmap.get("prodcd"));
						 commonDao.insertByNamedSql(MYBATIS_NS+"insetPmapByTmplid", pmap);
						 commonDao.insertByNamedSql(MYBATIS_NS+"insetTmapByTmplid", pmap);
						 commonDao.insertByNamedSql(MYBATIS_NS+"insetTmplByTmplid", pmap);
					 }
				}
			}
	}
	/**
	 * �޸�ϵͳ��Ʒ��Ϣ & updateProd
	 * @throws JDOMException 
	 * 
	 */
	@SuppressWarnings("unchecked")
	public void updateProd() throws JDOMException{
	try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			commonDao.updateByNamedSql(MYBATIS_NS+"updateProd", hashmap);
			hashmap.put("vermod", "0");
			commonDao.insertByNamedSql(MYBATIS_NS+"addProd",hashmap);
			commonDao.commitTransaction();
			ResultUtils.setRspData(req, "200",  "�����ɹ�", "prod_main", "closeCurrent", "");
	} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
	  }
	}
	
	/**
	 * ɾ��ϵͳ��Ʒ��Ϣ & deleteProd
	 * @throws JDOMException 
	 */
	public void deleteProd() throws JDOMException{
		try {
			List<String> prodcdList = req.getReqDataTexts("prodcds");
			if (prodcdList != null && prodcdList.size() > 0) {
				commonDao.beginTransaction();
				HashMap<String, List<String>> hashmap = new HashMap<String, List<String>>();
				hashmap.put("prodcdList", prodcdList);
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteProd", hashmap);
				}
				commonDao.commitTransaction();
				ResultUtils.setRspData(req, "200",  "�����ɹ�", "prod_main", "", "");
		} catch (BimisException e) {
				commonDao.rollBack();
				ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
				log.logError(e);
		}
	}
}
