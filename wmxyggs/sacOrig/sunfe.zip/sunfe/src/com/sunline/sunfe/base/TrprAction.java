package com.sunline.sunfe.base;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.sunfe.util.StringUtils;
public class TrprAction extends Actor {

	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.trpr.";
	Log log = new Log("TrprAction");
	/**
	 * ��ѯ��������嵥 & queryTrprListPage
	 */
	@SuppressWarnings("unchecked")
	public void queryTrprListPage(){
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("trprcd",  StringUtils.repalceCharecter(hashmap.get("trprcd")));
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryTrprlistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (Exception e) {
			log.logError(e);
		}
		
	}
	/**
	 * ��ѯ����������� & queryTrprById
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void queryTrprById() throws JDOMException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			Element ement =commonDao.queryByNamedSql(MYBATIS_NS+"queryTrprById", hashmap);
			req.addRspData(ement.removeContent());
		} catch (BimisException e) {
			log.logError(e);
		}
		
	}
	
	/**
	 *  ����������� & addTrpr
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addTrpr() throws JDOMException{
		
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTrpr", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "������ʹ����Ѵ��ڣ�");
					return;
				}
			}
			commonDao.insertByNamedSql(MYBATIS_NS+"addTrpr", hashmap);
		    ResultUtils.setRspData(req, "200", "�����ɹ�", "trpr_main","closeCurrent","");
			commonDao.commitTransaction();
		} catch (BimisException e) {
			commonDao.rollBack();
			log.logError(e);
		}	
	}
	/**
	 *  �޸�������� & updateTrpr
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void updateTrpr() throws JDOMException{
		
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			//�޸�ģ����Ϣʱ����Ψһ��У��
			if(!hashmap.get("module").equals(hashmap.get("module_old"))){
				List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTrpr", hashmap);
				if(countList!=null && countList.size()>0) {
					Map countMap = (HashMap)countList.get(0);
					int count = Integer.valueOf(countMap.get("CC").toString());
					if(count > 0) {
						req.addRspData("retCode", "300");
						req.addRspData("retMessage", "������ʹ����Ѵ��ڣ�");
						return;
					}
				}
			}
			commonDao.beginTransaction();
			
//			if(hashmap.get("usedtp").equals("0")){
//				hashmap.put("usedtp", "1");
//				commonDao.updateByNamedSql(MYBATIS_NS+"updateTrprStatus", hashmap);
//			}
			
			commonDao.insertByNamedSql(MYBATIS_NS+"updateTrpr", hashmap);
			commonDao.commitTransaction();
		    ResultUtils.setRspData(req, "200", "�����ɹ�", "trpr_main","closeCurrent","");
		} catch (BimisException e) {
			commonDao.rollBack();
			log.logError(e);
		    ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "trpr_main","");
		  }
	 }	
	
	/**
	 * ɾ�����������Ϣ & deleteTrpr
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void deleteTrpr() throws JDOMException{
			 try {
				    HashMap<String,String> hashmap = (HashMap<String, String>) req.getReqDataMap();
				    commonDao.beginTransaction();
				    if (hashmap.get("usedtp").equals("1")) {
						ResultUtils.setRspData(req, "300", "��ʹ�õ�������Ͳ���ɾ��",
								"trpr_main", "closeCurren");
						return;
					}
					commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTrpr", hashmap);
					commonDao.commitTransaction();
				    ResultUtils.setRspData(req, "200", "�����ɹ�", "trpr_main","","");
			} catch (BimisException e) {
					commonDao.rollBack();
					log.logError(e);
				    ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "trpr_main","");
			}
	}	
	/**
	 * ����ɾ�����������Ϣ & deleteManyTrpr
	 * @throws JDOMException 
	 */
	public void deleteManyTrpr() throws JDOMException{
		try {
			List<String> trprcdList = req.getReqDataTexts("trprcds");
			commonDao.beginTransaction();
			HashMap<String,String> param = new HashMap<String, String>();
			for (int i=0;i<trprcdList.size();i++) {
				param.clear();
				String [] array = trprcdList.get(i).split("-");
				param.put("trprcd", array[0]);
				param.put("module", array[1]);
				param.put("usedtp", array[2]);
				 if (param.get("usedtp").equals("1")) {
						ResultUtils.setRspData(req, "300", "��ʹ�õ�������Ͳ���ɾ��","trpr_main", "closeCurren");
						return;
					}
				commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTrpr", param);
			}
			commonDao.commitTransaction();
		    ResultUtils.setRspData(req, "200", "�����ɹ�", "trpr_main","","");
		} catch (BimisException e) {
			commonDao.rollBack();
			log.logError(e);
		    ResultUtils.setRspData(req, "300", "����ʧ��"+e.getErrmsg(), "trpr_main","");

		}
	}
	
	
	
	/**
	 * 
	 * @Title: updateTrprStatus 
	 * @date: 2018��3��26�� ����2:49:19 
	 * @Description: ���½�����͵�ʹ��״̬
	 * @return: void
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void updateTrprStatus() throws JDOMException{
		HashMap<String,String> param = (HashMap<String, String>) req.getReqDataMap();
		try {
			commonDao.beginTransaction();
			commonDao.updateByNamedSql(MYBATIS_NS+"updateTrprStatus", param);
			commonDao.commitTransaction();
			ResultUtils.setRspData(req, "200", "�����ɹ�", "trpr_main","","");
		} catch (BimisException e) {
			ResultUtils.setRspData(req, "300", "����ʧ��" ,"","");
			commonDao.rollBack();
			log.logError(e);
		}
	
	}
}
