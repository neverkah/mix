package com.sunline.sunfe.base;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.sunline.jraf.BimisException;
import com.sunline.jraf.services.Actor;
import com.sunline.jraf.util.Log;
import com.sunline.jraf.util.StringUtil;
import com.sunline.suncm.util.PubUtil;
import com.sunline.suncm.util.ResultUtils;
import com.sunline.suncm.util.SessionParaUtils;
import com.sunline.sunfe.util.StringUtils;
public class TrcdAction extends Actor {
	private final static String MYBATIS_NS = "com.sunline.sunfe.mybatis.trcd.";
	
	private final static String PROJCD_STANDARD = ".";
	private final static String VERMOD_0 = "0";
	private final static String AMNTCD_NULL = "N";
	private final static String TMPLTP_STANDARD = "tl_loan_cain";
	private final static String PROFTP_STANDARD = "pf_loan_cain";
	private final static String PROFID_STANDARD = "T001";
	private final static String VARITP_DATA = "1";
	private final static String VARITP_TRPR = "2";
	private final static String VARITP_PROD = "3";
	private final static String IOMPTP_VARIABLE = "1";
	private final static String IOMPTP_CONSTANT = "2";
	private final static String IOMPTP_MULTIL = "3";
	
	
	Log log = new Log(TrcdAction.class);
	/**
	 * ��ѯϵͳ�ӽ��������嵥 & queryTrcdListPage
	 */
	@SuppressWarnings("unchecked")
	public void queryTrcdListPage(){
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("trancd", StringUtils.repalceCharecter(hashmap.get("trancd")));
			hashmap.put("vermod", "0");
			Element ement =commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"queryTrcdlistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			log.logError(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void queryTrcds() throws BimisException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			hashmap.put("trancd", StringUtils.repalceCharecter(hashmap.get("trancd")));
			hashmap.put("vermod", "0");
			Element ement =commonDao.queryByNamedSql(MYBATIS_NS+"queryTrcdlistPage", hashmap);
			req.addRspData(ement.removeContent());
		} catch (JDOMException e) {
			log.logError(e);
		}
	}
	/**
	 * ��ѯϵͳ�ӽ����������� & queryTrcdById
	 * @throws JDOMException 
	 */
	public void queryTrcdById() throws JDOMException{
		try {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			String trancd = req.getReqDataStr("trancd");
			String module = req.getReqDataStr("module");
			hashmap.put("vermod", "0");
			hashmap.put("trancd", trancd);
			hashmap.put("module", module);
			hashmap.put("stacid", SessionParaUtils.getStacid());
			
			//�ӽ��׺�������ϸ��Ϣ
			Element ement =commonDao.queryByNamedSql(MYBATIS_NS+"queryTrcdDetl", hashmap);
			if(ement.getChild("Record")!= null){
				req.addRspData(ement.removeContent());
			}else{
			  Element e =  commonDao.queryByNamedSql(MYBATIS_NS+"queryTrcdById", hashmap);
			  req.addRspData(e.removeContent());
			}
			//��ѯģ�����ݽṹ
			Element dict =  commonDao.queryByNamedSql(MYBATIS_NS+"getModuleDictByModule", hashmap);
			req.addRspData("Results1",dict.removeContent());
			//��ѯ�������
			Element trpr =  commonDao.queryByNamedSql(MYBATIS_NS+"getTrprByModule", hashmap);
			req.addRspData("Results2",trpr.removeContent());
			//��ѯ��¼ģ��
			Element tmpl =  commonDao.queryByNamedSql(MYBATIS_NS+"getTmpl", hashmap);
			req.addRspData("Results3",tmpl.removeContent());
			//��ѯӳ��
			Element sysIomp =  commonDao.queryByNamedSql(MYBATIS_NS+"getSysIomp", hashmap);
			req.addRspData("Results4",sysIomp.removeContent());
			//��ѯӳ��Ԥ����
			Element iomp =  commonDao.queryByNamedSql(MYBATIS_NS+"getIompByModule", hashmap);
			req.addRspData("Results5",iomp.removeContent());
			
		} catch (BimisException e) {
			log.logError(e);
		}
		
	}
	
	/**
	 * ��ѯ�ӽ��׹�ѡ�����ݽṹ
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void queryTrcdDetlVaritp1() throws JDOMException{
		try {
			
		HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
		//�ӽ��׺�������ϸ��Ϣ
		List<HashMap<String,String>> detlList =(List<HashMap<String, String>>) commonDao.
				queryByNamedSqlForList(MYBATIS_NS+"queryTrcdDetlVaritp1", hashmap);
		JSONArray jsonArray = new JSONArray();
		for (Iterator iterator = detlList.iterator(); iterator.hasNext();) {
			HashMap<String, String> hashMap = (HashMap<String, String>) iterator.next();
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("varicd", hashMap.get("varicd"));
			jsonObject.put("varina", hashMap.get("varina"));
			jsonObject.put("varitp", hashMap.get("varitp"));
			jsonArray.add(jsonObject);
		}
		req.addRspData("jsonArray", jsonArray.toString());
		Element e = commonDao.queryByNamedSql(MYBATIS_NS+"queryTrcdDetlVaritp1", hashmap);
		req.addRspData(e.removeContent());
		} catch (BimisException e) {
			log.logError(e);
		}
	}
	
	/**
	 * �첽�年ѡ��ģ�����ݽṹ��Ϣ
	 * @throws JDOMException
	 */
	public void insertModuldict() throws JDOMException{
		try {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		JSONArray jsonArray = JSONArray.fromObject(req.getReqDataStr("moduleDict"));
		String trancd = req.getReqDataStr("trancd");
		hashmap.put("trancd", trancd);
		hashmap.put("varitp", VARITP_DATA);
		commonDao.beginTransaction();
		commonDao.deleteByNamedSql(MYBATIS_NS+"delSysTrcdDetlVaritp", hashmap);	
		if(jsonArray != null){
		for (int i = 0; i < jsonArray.size(); i++) {
				hashmap.put("varicd", jsonArray.getJSONObject(i).getString("code"));
				hashmap.put("varina", jsonArray.getJSONObject(i).getString("name"));
				hashmap.put("varitp", VARITP_DATA);
				hashmap.put("vermod", VERMOD_0);
				commonDao.insertByNamedSql(MYBATIS_NS+"addSysTrcdDetl", hashmap);
		     }
		   }
		 commonDao.commitTransaction();
		} catch (BimisException e) {
			commonDao.rollBack();
			log.logError(e);
		}
	}
	
	 /**
	    * 
	    * @param trancd2 
	    * @param jsonArray 
	    * @Title: updateTrcdByTrtl 
	    * @date: 2018��3��30�� ����10:25:41 
	    * @Description: �ӽ���ģ�����ݻ����޸ĺ�ͬ���޸Ľ��׳�������
	    * @return: void
	    * @throws BimisException 
	    */
	   @SuppressWarnings({ "unchecked", "rawtypes" })
	private void updateTmapByTrcd( ArrayList<HashMap<String, Object>> trcddetllist ) throws BimisException {
		     List<String> varicdList = new ArrayList<String>();
		     for (Iterator iterator = trcddetllist.iterator(); iterator.hasNext();) {
			    HashMap<String, Object> trcddetl = (HashMap<String, Object>) iterator.next();
			    if(trcddetl.get("varitp").equals(VARITP_DATA)){
			    	 varicdList.add(trcddetl.get("varicd").toString());
			    }
		     }
		     String trancd = (String) trcddetllist.get(0).get("trancd");
		     String stacid = SessionParaUtils.getStacid();
		     HashMap<String,Object> param = new HashMap<String, Object>();
		     param.put("stacid", stacid);
		     param.put("trancd", trancd);
		     HashMap<String,String> tmapTran = new HashMap<String, String>();
		     tmapTran.put("stacid",  stacid);//����
		     tmapTran.put("vermod", "0");//�汾ģʽ
		     tmapTran.put("dttrcd", trancd);//�ӽ���������
		     tmapTran.put("projcd", ".");//��Ŀ���
		     tmapTran.put("proftp", "pf_tr_get_field");//��������
		     List<HashMap<String,String>> trtl = (List<HashMap<String,String>>) 
		    		 		commonDao.queryByNamedSqlForList(MYBATIS_NS+"getTrtlByTrancd", param);
		     param.put("varicdList", varicdList);
		     //���������Ľ��׳�����������
		     for (Iterator iterator = trtl.iterator(); iterator.hasNext();) {
		    	   HashMap<String,String> trtlmap = (HashMap<String,String>) iterator.next();
		    	   String prcscd = trtlmap.get("prcscd");
		    	   String module = trtlmap.get("module");
				   tmapTran.put("prcscd", prcscd);//������
				   tmapTran.put("module", module);//ģ��
				   param.put("prcscd", prcscd);
				   //ɾ��Ŀ���������Ŀǰ�ӽ��׵�ģ�����ݽṹ�еĽ��׳����������
				   commonDao.deleteByNamedSql(MYBATIS_NS+"delTmapTranByVaricd", param);
				   //��ѯĿǰ�ӽ��׹����Ľ��׳�����Ŀ����
				   List<String> profidList = (List<String>) 
		    		 		commonDao.queryByNamedSqlForList(MYBATIS_NS+"getprofidByTrancd", param);
				   //���е��ӽ������ݽṹ�����ݿ��д��ڵ�Ŀ����Ĳ
				   varicdList.removeAll(profidList);
				   for (Iterator iterator2 = varicdList.iterator(); iterator2.hasNext();) {
					   	String varicd = (String) iterator2.next();
					   	tmapTran.put("fildcd",varicd);//�����ֶ���
					   	tmapTran.put("profid",varicd);//����Id
					   	commonDao.insertByNamedSql("com.sunline.sunfe.mybatis.trtl.insertTmapTran", tmapTran);
				}
				
			}
	    }

	//��ѯ�ɹ�ѡ����ӽ������ݽṹ
	@SuppressWarnings("unchecked")
	public void getModuldictForSelect() throws JDOMException{
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			Element e = commonDao.queryByNamedSqlWithPage(MYBATIS_NS+"getModuldictForSelectlistPage",req.getReqPageInfo(), hashmap);
			req.addRspData(e.removeContent());
		} catch (Exception e) {
			log.logError(e);
		}
	}
	/**
	 *  �����ӽ������� & addTrcd
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addTrcd() throws JDOMException{
		
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTrcd", hashmap);
			if(countList!=null && countList.size()>0) {
				Map countMap = (HashMap)countList.get(0);
				int count = Integer.valueOf(countMap.get("CC").toString());
				if(count > 0) {
					req.addRspData("retCode", "300");
					req.addRspData("retMessage", "�ӽ������ʹ����Ѵ��ڣ�");
					return;
				}
			}
			
			commonDao.insertByNamedSql(MYBATIS_NS+"addTrcd", hashmap);
			ResultUtils.setRspData(req, "200",  "�����ɹ�", "trcd_main", "closeCurrent", "");
			commonDao.commitTransaction();
		} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
		}	
	}
	/**
	 *  �޸�ϵͳ�ӽ������� & updateTrcd
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void updateTrcd() throws JDOMException{
		
		try {
			HashMap<String, String> hashmap = (HashMap<String, String>) req.getReqDataMap();
			commonDao.beginTransaction();
			commonDao.insertByNamedSql(MYBATIS_NS+"updateTrcd", hashmap);
			hashmap.put("vermod", "0");
			commonDao.insertByNamedSql(MYBATIS_NS+"addTrcd", hashmap);
			commonDao.commitTransaction();
			ResultUtils.setRspData(req, "200",  "�����ɹ�", "trcd_main", "closeCurrent", "");
		} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
		  }
	 }	
	
	/**
	 * ɾ��ϵͳ�ӽ���������Ϣ & deleteTrcd
	 * @throws JDOMException 
	 */
	@SuppressWarnings("rawtypes")
	public void deleteTrcd() throws JDOMException{
		try {
			List<String> trancdList = req.getReqDataTexts("trancds");
			if (trancdList != null && trancdList.size() > 0) {
				commonDao.beginTransaction();
				for (Iterator iterator = trancdList.iterator(); iterator.hasNext();) {
					HashMap<String,String> hashmap = new HashMap<String,String>();
					String trancd = (String) iterator.next();
					hashmap.put("trancd", trancd);
					hashmap.put("stacid", SessionParaUtils.getStacid());
				  List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkUserTrtl", hashmap);
					if(countList!=null && countList.size()>0) {
						Map countMap = (HashMap)countList.get(0);
						int count = Integer.valueOf(countMap.get("CC").toString());
						if(count > 0) {
							req.addRspData("retCode", "300");
							req.addRspData("retMessage", "�ӽ����ѱ�ʹ��,������ɾ����");
							return;
						}
					 }
					commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTrcd", hashmap);
					commonDao.deleteByNamedSql(MYBATIS_NS+"deleteTrcdDetl", hashmap);
					commonDao.deleteByNamedSql(MYBATIS_NS+"deleteSysTmap", hashmap);
					commonDao.deleteByNamedSql(MYBATIS_NS+"deleteSysTmpl", hashmap);
					commonDao.deleteByNamedSql(MYBATIS_NS+"deleteSysPmap", hashmap);
					commonDao.deleteByNamedSql(MYBATIS_NS+"deleteSysIomp", hashmap);
					}
				}
			commonDao.commitTransaction();
			ResultUtils.setRspData(req, "200",  "�����ɹ�", "trcd_main", "", "");
		} catch (BimisException e) {
			commonDao.rollBack();
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
		}
	}	
	
	
	
	
	
	/**
	 * ��ѯ ģ���µ��ӽ���������ϸ��Ϣ
	 * @throws JDOMException 
	 */
	@SuppressWarnings("unchecked")
	public void getTrcdDetl() throws JDOMException{
		try {
			HashMap<String, String> param = (HashMap<String, String>) req.getReqDataMap();
			param.put("stacid", SessionParaUtils.getStacid());
			param.put("varitp", VARITP_DATA);
//			commonDao.deleteByNamedSql(MYBATIS_NS+"delSysTrcdDetlVaritp", param);
			//��ѯģ�����ݽṹ
			Element dict =  commonDao.queryByNamedSql(MYBATIS_NS+"getModuleDictByModule", param);
			req.addRspData(dict.removeContent());
			//��ѯ�������
			Element trpr =  commonDao.queryByNamedSql(MYBATIS_NS+"getTrprByModule", param);
			req.addRspData("Results1",trpr.removeContent());
			//��ѯ��¼ģ��
			Element tmpl =  commonDao.queryByNamedSql(MYBATIS_NS+"getTmpl", param);
			req.addRspData("Results2",tmpl.removeContent());
			//��ѯ��Ʒ
			Element prod =  commonDao.queryByNamedSql(MYBATIS_NS+"getProdByModule", param);
			req.addRspData("Results3",prod.removeContent());
			//��ѯӳ��Ԥ����
			Element iomp =  commonDao.queryByNamedSql(MYBATIS_NS+"getIompByModule", param);
			req.addRspData("Results4",iomp.removeContent());
			req.addRspData("module",param.get("module"));
		} catch (BimisException e) {
			ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
			log.logError(e);
		}
	}
	
	/**
	 * �����ӽ�������(�����汾)
	 * @throws JDOMException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void addSysTrcd() throws JDOMException{
		  try {
			 HashMap<String, Object> data = (HashMap<String, Object>) req.getReqDataMap();
			 //��ȡ�ӽ��ױ�����
			 HashMap<String, Object>  sysTrcd  = getsysTrcd(data);
			 //��ȡ�ӽ�����������
		     ArrayList<HashMap<String, Object>>  sysTrcdDetl  = getsysTrcdDetl(data);
			 //��ȡ��Ʒ�ӽ���ģ������\ҵ��ģ���������
		     ArrayList<HashMap<String, Object>>  sysPmap  = getsysPmap(data);
		     //��ȡ��¼ӳ���ϵ
		     ArrayList<HashMap<String, Object>>  sysIomp  = getsysIomp(data);
		     //ҵ��ģ���������
		     ArrayList<HashMap<String, Object>>  sysTmap  = getsysTmap(sysPmap,data);
		     //ģ��
		     ArrayList<HashMap<String, Object>>  sysTmpl  = getsysTmpl(sysPmap,data);
		     //�ӽ��׽���������ɺ󣬵�����棬ϵͳӦ���ģ����ʹ�õ��ֶ��Ƿ������ݽṹ+���������
		     checkValid(sysTrcdDetl,sysIomp);
		     commonDao.beginTransaction();
		     //���½������״̬
		     updateTrprStatus(sysTrcdDetl,data.get("module").toString());
		     //������
		     //���ӽ��ױ�����
		     List countList = commonDao.queryByNamedSqlForList(MYBATIS_NS+"checkExistTrcd", sysTrcd);
				if(countList!=null && countList.size()>0) {
					Map countMap = (HashMap)countList.get(0);
					int count = Integer.valueOf(countMap.get("CC").toString());
					if(count > 0) {
						req.addRspData("retCode", "300");
						req.addRspData("retMessage", "�ӽ����Ѵ��ڣ�");
						return;
					}
			 }
		     commonDao.insertByNamedSql(MYBATIS_NS+"addSysTrcd", sysTrcd);
		     sysTrcd.put("trancd", req.getReqDataStr("trancd_old"));
		     commonDao.deleteByNamedSql(MYBATIS_NS+"delSysTrcdDetlVaritp", sysTrcd);
		     //���ӽ�����������
		     for (Iterator iterator = sysTrcdDetl.iterator(); iterator.hasNext();) {
					HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
					commonDao.insertByNamedSql(MYBATIS_NS+"addSysTrcdDetl", hashMap);
			 }
		     //�۲�Ʒ�ӽ���ģ������
         	 for (Iterator iterator = sysPmap.iterator(); iterator.hasNext();) {
				HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
				commonDao.insertByNamedSql(MYBATIS_NS+"addSysPmap", hashMap);
			 }
		     //�ܷ�¼ӳ���ϵ
		     for (Iterator iterator = sysIomp.iterator(); iterator.hasNext();) {
					HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
					commonDao.insertByNamedSql(MYBATIS_NS+"addSysIomp", hashMap);
			 }
		     //��ҵ��ģ���������
		     for (Iterator iterator = sysTmap.iterator(); iterator.hasNext();) {
					HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
					commonDao.insertByNamedSql(MYBATIS_NS+"addSysTmap", hashMap);
				 }
		     //��ģ��
		     for (Iterator iterator = sysTmpl.iterator(); iterator.hasNext();) {
					HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
					commonDao.insertByNamedSql(MYBATIS_NS+"addSysTmpl", hashMap);
				 }
		     commonDao.commitTransaction();
		     ResultUtils.setRspData(req, "200",  "�����ɹ�", "trcd_main", "closeCurrent", "");
		   }catch (BimisException e) {
			  commonDao.rollBack();
		      ResultUtils.setRspData(req, "300",  "����ʧ��:"+e.getErrmsg(), "", "", "");
		      log.logError(e);
		}
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void checkValid(ArrayList<HashMap<String, Object>> sysTrcdDetl,
			ArrayList<HashMap<String, Object>> sysIomp) throws BimisException {
		 //ʹ�õ�����ӳ���ֶ�
		  List<String>  iomplist = new ArrayList<String>();
		  HashMap iompmap = new HashMap<String, String>();
		  for (Iterator iterator = sysIomp.iterator(); iterator.hasNext();) {
			HashMap<String, Object> iomp = (HashMap<String, Object>) iterator.next();
			if(!iomp.get("iomptp").toString().equals(IOMPTP_MULTIL) && 
					!iomp.get("ftokey").toString().equals("amntcd")){
				 iomplist.add(iomp.get("mapkey").toString());
				 iompmap.put(iomp.get("mapkey").toString(), iomp.get("smrytx").toString());
			}
		  }
		  
		  //ѡ������е����ݽṹ�ͽ������
		  List<String>  trcddetllist = new ArrayList<String>();
		  for (Iterator iterator1 = sysTrcdDetl.iterator(); iterator1.hasNext();) {
			HashMap<String, Object> trcddetl = (HashMap<String, Object>) iterator1.next();
			    trcddetllist.add(trcddetl.get("varicd").toString());
		  }
		  
		  if(!trcddetllist.containsAll(iomplist)){
			  //ѡ��ĺ�ʹ���ֶεĲ�ֵ
			  iomplist.removeAll(trcddetllist);
			  StringBuffer msg =  new StringBuffer();
			  for (Iterator iterator2 = iomplist.iterator(); iterator2.hasNext();) {
				   String varicd = (String) iterator2.next();
				   msg.append("��"+varicd+"��"+iompmap.get(varicd)+"��");
			}
			  throw new BimisException("-1", "ʹ�õ��ֶ�"+msg+"�Ƿ���");
		  }
	}

	/**
	 * @Title: updateTrprStatus 
	 * @date: 2018��4��9�� ����2:33:22 
	 * @Description: ���½������
	 * @param sysTrcdDetl
	 * @param module
	 * @throws JDOMException
	 * @throws BimisException
	 * @return: void
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void updateTrprStatus(ArrayList<HashMap<String, Object>> sysTrcdDetl, String module) throws JDOMException, BimisException{
			for (Iterator iterator = sysTrcdDetl.iterator(); iterator.hasNext();) {
				HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
				if(hashMap.get("varitp").toString().equals(VARITP_TRPR)){
					hashMap.put("module", module);
					hashMap.put("usedtp", "1");
					hashMap.put("trprcd", hashMap.get("varicd"));
					commonDao.updateByNamedSql(MYBATIS_NS+"updateTrprStatus", hashMap);
				}
			}
	}
	/**
	 * ��ȡģ���
	 * @param sysTmap
	 * @param data
	 * @return
	 * @throws BimisException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private ArrayList<HashMap<String, Object>> getsysTmpl(
			ArrayList<HashMap<String, Object>> sysPmap,
			HashMap<String, Object> data) throws BimisException {
		ArrayList<HashMap<String, Object>> sysTmplList = new ArrayList<HashMap<String, Object>>();
		String stacid = SessionParaUtils.getStacid();
		for (Iterator iterator = sysPmap.iterator(); iterator.hasNext();) {
			HashMap<String, Object> pmap = (HashMap<String, Object>) iterator.next();
				HashMap<String, Object> sysTmpl = new HashMap<String, Object>();
				sysTmpl.put("tmpltp", pmap.get("tmpltp"));//ģ������
				sysTmpl.put("tmplid", pmap.get("tmplid"));//ģ��id
				sysTmpl.put("tmplna", data.get("tranna").toString());//ģ������
				sysTmpl.put("efctdt", PubUtil.getGlisdt(Integer.parseInt(stacid)));//��Ч����
				sysTmpl.put("module", data.get("module").toString());//ģ��
				sysTmpl.put("vermod", VERMOD_0);
				sysTmpl.put("projcd", PROJCD_STANDARD);
				sysTmplList.add(sysTmpl);
		}
		return sysTmplList;
	}

	/**
	 * ҵ��ģ���������
	 * @param sysPmap ��Ʒ�ӽ���
	 * @param sysIomp	����ӳ��
	 * @param data 
	 * @return
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private ArrayList<HashMap<String, Object>> getsysTmap(ArrayList<HashMap<String, Object>> sysPmap, HashMap<String, Object> data) throws BimisException {
		ArrayList<HashMap<String, Object>> sysTmapList = new ArrayList<HashMap<String, Object>>();
		ArrayList<String> indexList  =  (ArrayList<String>) data.get("index");
		String stacid = SessionParaUtils.getStacid();
		int index=1;
		for (Iterator iterator = sysPmap.iterator(); iterator.hasNext();) {
			HashMap<String, Object> pmap = (HashMap<String, Object>) iterator.next();
			for (int i=1; i<indexList.size(); i++) {
				HashMap<String, Object> sysTmap = new HashMap<String, Object>();
				sysTmap.put("tmpltp", pmap.get("tmpltp"));//ģ������
				sysTmap.put("tmplid", pmap.get("tmplid"));//ģ��id
				sysTmap.put("sortno", data.get("sortno_"+indexList.get(i)).toString());//����˳��
				sysTmap.put("proftp", PROFTP_STANDARD);//��������
				sysTmap.put("profid", PROFID_STANDARD);//����id
				sysTmap.put("mpcdin", data.get("trancd").toString()+"_"+stacid+"_"+i);//��������ӳ����봮
				sysTmap.put("module", data.get("module").toString());//ģ��
				sysTmap.put("vermod", VERMOD_0);
				sysTmap.put("projcd", PROJCD_STANDARD);
				sysTmap.put("condcd", data.get("tcondcd_"+indexList.get(i)).toString());
				sysTmapList.add(sysTmap);
			}
			index = index + 1;
		}
		return sysTmapList;
	}
	/**
	 * //��ȡ�ӽ�����������
	 * @param data ǰ̨form�ύ������
	 * @return �ӽ����������ݼ���
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private ArrayList<HashMap<String, Object>> getsysTrcdDetl(HashMap<String, Object> data) throws BimisException {
		ArrayList<HashMap<String,Object>> sysTrcdDetlList = new ArrayList<HashMap<String, Object>>();
		//�ӽ������ݽṹ���������
		String [] param= {"varicd","trprcd"};
		String [] varitp= {VARITP_DATA,VARITP_TRPR};
		for (int i = 0; i < param.length; i++) {
			Object object = data.get(param[i]);
			if(object instanceof String){
				HashMap<String, Object> sysTrcdDetl = new HashMap<String, Object>();
				sysTrcdDetl.put("trancd", data.get("trancd").toString());//�ӽ���
				sysTrcdDetl.put("tranna", data.get("tranna").toString());//�ӽ�������
				sysTrcdDetl.put("varicd", object.toString());
				sysTrcdDetl.put("varina", data.get(param[i]+"_"+object.toString()));
				sysTrcdDetl.put("varitp", varitp[i]);
				sysTrcdDetlList.add(sysTrcdDetl);
			}else{
				List<String> varicds = (List<String>) object;
				for (Iterator iterator = varicds.iterator(); iterator.hasNext();) {
					HashMap<String, Object> sysTrcdDetl = new HashMap<String, Object>();
					sysTrcdDetl.put("trancd", data.get("trancd").toString());//�ӽ���
					sysTrcdDetl.put("tranna", data.get("tranna").toString());//�ӽ�������
					String varicd = (String) iterator.next();
					sysTrcdDetl.put("varicd", varicd.toString());
					sysTrcdDetl.put("varina", data.get(param[i]+"_"+varicd));
					sysTrcdDetl.put("varitp", varitp[i]);
					sysTrcdDetlList.add(sysTrcdDetl);
				}
			}
		}
		return sysTrcdDetlList;
	}
	/**
	 * ��ȡ��¼ӳ������
	 * @param data ǰ̨form�ύ������
	 * @return
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private ArrayList<HashMap<String, Object>> getsysIomp(HashMap<String, Object> data) throws BimisException {
		ArrayList<HashMap<String,Object>> sysIompList = new ArrayList<HashMap<String, Object>>();
		String stacid = SessionParaUtils.getStacid();
		//��ѯ��¼ģ��
		 HashMap<String, Object> param = new HashMap<String, Object>();
		 param.put("stacid", SessionParaUtils.getStacid());
		ArrayList<HashMap<String,String>> tmpl =  (ArrayList<HashMap<String, String>>) commonDao.
			    queryByNamedSqlForList(MYBATIS_NS+"getTmpl", param);
   	 	ArrayList<String> indexList  =  (ArrayList<String>) data.get("index");
   	 	List<String> exclude =  Arrays.asList("prodcd","loanp0","loanp1","loanp2",
   	 			"loanp3","fmvacd_trprcd","tcondcd","sortno","amntcd");
   	 	 //	������ϸ�����ݵ���ţ���Ŵӵڶ�����ʼ����һ��Ϊģ�����ţ�Ϊ��
   	 	for (int i = 1; i < indexList.size(); i++) {
   	 		String index = (String) indexList.get(i);//��ϸ�����ݵ����
   	 		//������ǰ��ϸ�����ݵ�����������
   	 		for (Iterator iterator = tmpl.iterator(); iterator.hasNext();) {
   	 				//��¼ģ�����
				  HashMap<String,Object>  tmplmap = ( HashMap<String,Object>) iterator.next();
				  String varicd = tmplmap.get("varicd").toString();
				  if(!exclude.contains(varicd)){
					  HashMap<String, Object> sysIomp = new HashMap<String, Object>();
	   	 			  //����ӳ��id���ӽ��״�����Ϊӳ��id
	   	 			  sysIomp.put("ruleid", data.get("trancd").toString()+"_"+stacid+"_"+i);
	   	 			  sysIomp.put("trancd", data.get("trancd").toString());
					  //�ӽ���ӳ��������ǰ̨�Ĵ���
					  String fmvacode = "fmvacd_"+varicd+"_"+index;
					  //�ӽ���ӳ��������ǰ̨�Ĵ���
					  String varina = "varina_"+varicd+"_"+index;
					  //�ӽ���ӳ��������ǰ̨ѡ��Ĵ���
					  String fmvacd = (String) data.get(fmvacode);
					  String fmvana = (String) data.get(varina); 
					  if(!StringUtil.isNullOrEmpty(fmvacd)){
						  sysIomp.put("ftokey", varicd);//Ŀ��
						  sysIomp.put("iomptp", IOMPTP_VARIABLE);//ӳ������
						  sysIomp.put("mapkey", fmvacd);//��Դ
						  sysIomp.put("smrytx", fmvana);//��Դ����
						  sysIompList.add(sysIomp);
					  }
				  }
   	 		   }
   	 		for (int j=0;j < exclude.size(); j++) {
				 String string = exclude.get(j);
				 HashMap<String, Object> sysIomp = new HashMap<String, Object>();
		 		    sysIomp.put("ruleid", data.get("trancd").toString()+"_"+stacid+"_"+i);
		 		    sysIomp.put("trancd", data.get("trancd").toString());
		 		    if(string.equals("fmvacd_trprcd")){
		 		    	sysIomp.put("ftokey", "lnbltp");//Ŀ��
		 		    }else{
		 		    	sysIomp.put("ftokey", string);//Ŀ��
		 		    }
				    sysIomp.put("mapkey", data.get(string+"_"+index).toString());//��Դ
				    if(string.equals("fmvacd_trprcd")||string.equals("amntcd")){
				       sysIomp.put("iomptp", IOMPTP_CONSTANT);//ӳ������
				    }else if(string.equals("loanp0")||string.equals("loanp1")||
				    		string.equals("loanp2")||string.equals("loanp3")||string.equals("prodcd")){
				       sysIomp.put("iomptp", IOMPTP_VARIABLE);//ӳ������
				    }else{
				       sysIomp.put("iomptp", IOMPTP_MULTIL);//ӳ������
				    }
				    if(string.equals("amntcd")){
				    	sysIomp.put("smrytx", "�������");
				    }else if(string.equals("sortno")){
				    	sysIomp.put("smrytx", "���");
				    }else if(string.equals("fmvacd_trprcd")){
				    	sysIomp.put("smrytx", "�������");
				    }else{
				    	sysIomp.put("smrytx", data.get("name_"+string+"_"+index).toString());
				    }
				    if(!StringUtil.isNullOrEmpty(data.get(string+"_"+index).toString())){
				    	sysIompList.add(sysIomp);
				    }
			}
	 		  
		}
		return sysIompList;
	}
	/**
	 * ��ȡ�ӽ��ױ�����
	 * @param data ǰ̨form�ύ������
	 * @return ��Ҫ������ӽ�������
	 */
	private HashMap<String, Object> getsysTrcd(HashMap<String, Object> data) {
		HashMap<String, Object> sysTrcd = new HashMap<String, Object>();
		sysTrcd.put("trancd", data.get("trancd").toString());//�ӽ���
		sysTrcd.put("tranna", data.get("tranna").toString());//�ӽ�������
		sysTrcd.put("desctx", data.get("desctx").toString());//˵��
		sysTrcd.put("module", data.get("module").toString());//ģ��
		sysTrcd.put("enname", data.get("trancd").toString());//Ӣ������
		sysTrcd.put("vermod", VERMOD_0);//�汾
		sysTrcd.put("tramcd", AMNTCD_NULL);//�������
		sysTrcd.put("intfcd", "*");//��������ӿڴ���
		sysTrcd.put("propif", "*");//���Խӿڴ���
		sysTrcd.put("projcd", PROJCD_STANDARD);//��Ŀ
		return sysTrcd;
	  }
	
	/**
	 * ��ȡ��Ʒ�ӽ���ģ������
	 * @param data ǰ̨form�ύ������
	 * @return ��Ҫ����Ĳ�Ʒ�ӽ���ģ������
	 * @throws BimisException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private  ArrayList<HashMap<String, Object>> getsysPmap(HashMap<String, Object> data) throws BimisException {
		ArrayList<HashMap<String, Object>> sysPmapList = new ArrayList<HashMap<String, Object>>();
		String stacid = SessionParaUtils.getStacid();
		//��ѯģ���µ����в�Ʒ,���ɲ�Ʒ�ӽ�������
		ArrayList<HashMap<String, Object>> prodList = (ArrayList<HashMap<String, Object>>) 
							commonDao.queryByNamedSqlForList(MYBATIS_NS+"getProdByModule", data);
			int index =1;
			for (Iterator iterator = prodList.iterator(); iterator.hasNext();) {
				HashMap<String, Object> prod = (HashMap<String, Object>) iterator.next();
				HashMap<String, Object> sysPmap = new HashMap<String, Object>();
				sysPmap.put("stacid", stacid);//����
				sysPmap.put("prodcd", prod.get("prodcd"));//��Ʒ
				sysPmap.put("trancd", data.get("trancd").toString());//�ӽ���
				sysPmap.put("tmpltp", TMPLTP_STANDARD);//ģ������
				sysPmap.put("tmplid", data.get("trancd").toString()+"_"+stacid+"_"+index);//ģ��id
				sysPmap.put("module", data.get("module").toString());//ģ��
				sysPmap.put("vermod", VERMOD_0);
				sysPmap.put("projcd", PROJCD_STANDARD);
				sysPmapList.add(sysPmap);
				index = index +1;
			}
		return sysPmapList;
	}
	
	
	
	
	
	@SuppressWarnings("unchecked")
	public void checkVaricdValid() throws JDOMException{
		try{
		HashMap<String, Object> data = (HashMap<String, Object>) req.getReqDataMap();
		 //��ȡ�ӽ�����������
	     ArrayList<HashMap<String, Object>>  sysTrcdDetl  = getsysTrcdDetl(data);
		 //��ȡ��¼ӳ���ϵ
	     ArrayList<HashMap<String, Object>>  sysIomp  = getsysIomp(data);
	     //�ӽ��׽����޸���ɺ󣬵�����棬ϵͳӦ���ģ����ʹ�õ��ֶ��Ƿ������ݽṹ+���������
	     checkValid(sysTrcdDetl,sysIomp);
	     ResultUtils.setRspData(req, "200",  "", "", "", "");
		}catch(BimisException e){
		 ResultUtils.setRspData(req, "300",  "����ʧ��:"+e.getErrmsg(), "", "", "");
		 log.logError(e);
		}
	}
	
	
	
	/**
	 * �����ӽ�������
	 * @throws JDOMException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void updateSysTrcd() throws JDOMException{
	     try {
	    	 HashMap<String, Object> data = (HashMap<String, Object>) req.getReqDataMap();
			 //��ȡ�ӽ��ױ�����
			 HashMap<String, Object>  sysTrcd  = getsysTrcd(data);
			 //��ȡ�ӽ�����������
		     ArrayList<HashMap<String, Object>>  sysTrcdDetl  = getsysTrcdDetl(data);
			 //��ȡ��Ʒ�ӽ���ģ������\ҵ��ģ���������
		     ArrayList<HashMap<String, Object>>  sysPmap  = getsysPmap(data);
			 //��ȡ��¼ӳ���ϵ
		     ArrayList<HashMap<String, Object>>  sysIomp  = getsysIomp(data);
		     //ҵ��ģ���������
		     ArrayList<HashMap<String, Object>>  sysTmap  = getsysTmap(sysPmap,data);
		     //ģ��
		     ArrayList<HashMap<String, Object>>  sysTmpl  = getsysTmpl(sysPmap,data);
		     //�ӽ��׽����޸���ɺ󣬵�����棬ϵͳӦ���ģ����ʹ�õ��ֶ��Ƿ������ݽṹ+���������
		     checkValid(sysTrcdDetl,sysIomp);
		     commonDao.beginTransaction();
		     //�ӽ������ݽṹ�޸ĺ�ͬ���޸Ľ��׳����������ù���
		     updateTmapByTrcd(sysTrcdDetl);
		     //���½������
		     updateTrprStatus(sysTrcdDetl, data.get("module").toString());
		     sysTrcd.put("stacid", SessionParaUtils.getStacid());
		     List<?> sysPmapList = commonDao.queryByNamedSqlForList("getsysPmapListByTrancd", sysTrcd);
		     //sysPmapList.size	()>0˵�����ڵ�ǰ�����µ��޸ģ�/sysPmapList.size()<0 �������������µ��޸ģ���ֱ���������ɡ�
		     int count = commonDao.updateByNamedSql(MYBATIS_NS+"updateTrcd", sysTrcd);
		     //count==0,˵���ӽ��ױ��޸�
		     if(count == 0){
		    	 //���°汾
		    	 commonDao.updateByNamedSql(MYBATIS_NS+"updateTrcdVermod", sysTrcd);
		    	 //����������
		    	 commonDao.insertByNamedSql(MYBATIS_NS+"addSysTrcd", sysTrcd);
		     }
		     if(sysPmapList.size()>0){
			     //���ӽ�����������
			     commonDao.deleteByNamedSql(MYBATIS_NS+"delSysTrcdDetlVaritp", sysTrcd);
			     for (Iterator iterator = sysTrcdDetl.iterator(); iterator.hasNext();) {
						HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
						commonDao.insertByNamedSql(MYBATIS_NS+"addSysTrcdDetl", hashMap);
				 }
			     //�۷�¼ӳ���ϵ
			     commonDao.deleteByNamedSql(MYBATIS_NS+"delSysIomp", sysTrcd);
			     for (Iterator iterator = sysIomp.iterator(); iterator.hasNext();) {
						HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
						commonDao.insertByNamedSql(MYBATIS_NS+"addSysIomp", hashMap);
				 }
			     //�ܲ�Ʒ�ӽ���ģ������
	         	for (Iterator iterator = sysPmap.iterator(); iterator.hasNext();) {
					HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
					int num = commonDao.updateByNamedSql(MYBATIS_NS+"updateSysPmap", hashMap);
					//count==0,˵�����޸�
					if(num == 0){
						commonDao.updateByNamedSql(MYBATIS_NS+"updateSysPmapVermod", hashMap);
						commonDao.insertByNamedSql(MYBATIS_NS+"addSysPmap", hashMap);
					}
				}
		       //��ҵ��ģ���������
	         	for (Iterator iterator = sysTmap.iterator(); iterator.hasNext();) {
					HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
					int num = commonDao.updateByNamedSql(MYBATIS_NS+"updateSysTmap", hashMap);
					//count==0,˵�����޸�
					if(num == 0){
						commonDao.updateByNamedSql(MYBATIS_NS+"updateSysTmapVermod", hashMap);
						commonDao.insertByNamedSql(MYBATIS_NS+"addSysTmap", hashMap);
					}
				}
	         	 //��ģ��
			     for (Iterator iterator = sysTmpl.iterator(); iterator.hasNext();) {
						HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
						commonDao.deleteByNamedSql(MYBATIS_NS+"delSysTmpl", hashMap);
						commonDao.insertByNamedSql(MYBATIS_NS+"addSysTmpl", hashMap);
					 }
		     }else{
			     //���ӽ�����������,ֵ�����Ʒ��Ϣ
		    	 commonDao.deleteByNamedSql(MYBATIS_NS+"delSysTrcdDetlVaritp", sysTrcd);
			     for (Iterator iterator = sysTrcdDetl.iterator(); iterator.hasNext();) {
						HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
						commonDao.insertByNamedSql(MYBATIS_NS+"addSysTrcdDetl", hashMap);
				 }
			     //�۷�¼ӳ���ϵ
			     for (Iterator iterator = sysIomp.iterator(); iterator.hasNext();) {
						HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
						commonDao.insertByNamedSql(MYBATIS_NS+"addSysIomp", hashMap);
				 }
			     //�ܲ�Ʒ�ӽ���ģ������
	         	for (Iterator iterator = sysPmap.iterator(); iterator.hasNext();) {
					HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
						commonDao.insertByNamedSql(MYBATIS_NS+"addSysPmap", hashMap);
					}
		       //��ҵ��ģ���������
	         	for (Iterator iterator = sysTmap.iterator(); iterator.hasNext();) {
					HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
						commonDao.insertByNamedSql(MYBATIS_NS+"addSysTmap", hashMap);
					}
	         	 //��ģ��
			     for (Iterator iterator = sysTmpl.iterator(); iterator.hasNext();) {
						HashMap<String, Object> hashMap = (HashMap<String, Object>) iterator.next();
						commonDao.insertByNamedSql(MYBATIS_NS+"addSysTmpl", hashMap);
					 }
		      }
		     commonDao.commitTransaction();
		     ResultUtils.setRspData(req, "200",  "�����ɹ�", "trcd_main", "closeCurrent", "");
		   }catch (BimisException e) {
			  commonDao.rollBack();
		      ResultUtils.setRspData(req, "300",  "����ʧ��:"+e.getErrmsg(), "", "", "");
		      log.logError(e);
		   	}
		}

	//��ѯģ�����ݽṹ
	@SuppressWarnings("unchecked")
	public void getModuDict() throws JDOMException{
		try {
			HashMap<String, String> param = (HashMap<String, String>) req.getReqDataMap();
			param.put("stacid", SessionParaUtils.getStacid());
			Element dict = commonDao.queryByNamedSql(MYBATIS_NS+"getModuleDictByModule", param);
			req.addRspData(dict.removeContent());
			//��ѯӳ��Ԥ����
			Element iomp =  commonDao.queryByNamedSql(MYBATIS_NS+"getIompByModule", param);
			req.addRspData("Results4",iomp.removeContent());
		} catch (BimisException e) {
			commonDao.rollBack();
		      ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
		      log.logError(e);
		}
	}
	
	 ////��ѯ��ѡ��������
	  @SuppressWarnings("unchecked")
	public void getTrpr() throws JDOMException{
		  try {
			//��ѯ�������
			 HashMap<String, String> param = (HashMap<String, String>) req.getReqDataMap();
			 Element trpr =  commonDao.queryByNamedSql(MYBATIS_NS+"getTrprByModule", param);
			 req.addRspData("Results1",trpr.removeContent());
			} catch (BimisException e) {
			  commonDao.rollBack();
		      ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
		      log.logError(e);
			}
	  }
	  
	  //��ѯ��ѡ��������
	  @SuppressWarnings("unchecked")
	public void getProd() throws JDOMException{
		  try {
			//��ѯ��Ʒ
			 HashMap<String, String> param = (HashMap<String, String>) req.getReqDataMap();
			 Element prod =  commonDao.queryByNamedSql(MYBATIS_NS+"getProdByModule", param);
			 req.addRspData("Results3",prod.removeContent());
			} catch (BimisException e) {
			  commonDao.rollBack();
		      ResultUtils.setRspData(req, "300",  "����ʧ��"+e.getErrmsg(), "", "", "");
		      log.logError(e);
			}
	  }
	  
	/**
	 * @Title: getTrtlByTrancd 
	 * @date: 2018��3��27�� ����2:50:58 
	 * @Description: ��ѯ�ӽ����漰�Ľ��׳���
	 * @throws JDOMException
	 * @return: void
	 */
	  @SuppressWarnings("unchecked")
	public void getTrtlByTrancd() throws JDOMException{
		    try {
				 HashMap<String, String> param = (HashMap<String, String>) req.getReqDataMap();
				 param.put("stacid", SessionParaUtils.getStacid());
				 Element trtl =  commonDao.queryByNamedSql(MYBATIS_NS+"getTrtlByTrancd", param);
				 req.addRspData(trtl.removeContent());
				} catch (BimisException e) {
			      ResultUtils.setRspData(req, "300",  "����ʧ��", "", "", "");
			      log.logError(e);
				}
	  }
	  
}

