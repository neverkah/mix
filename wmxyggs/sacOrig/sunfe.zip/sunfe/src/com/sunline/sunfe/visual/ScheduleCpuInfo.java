package com.sunline.sunfe.visual;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.sunline.jraf.util.JsonUtil;
/**
 * @desc �Ӽ������ж�ʱ��ȡCPU��Ϣ
 * @author Lanyq
 *@time 2017-11-29 16:09
 */
public class ScheduleCpuInfo extends CpuInfoListener{

	public void getSecondCpuInfo(){
		System.out.print(queue.size());
		//CPUʹ����
		String cpuUsedDegree=null;
		List<HashMap> list=new ArrayList<HashMap>();
		if(queue.size()>0){
		for(HashMap map:queue){
			list.add(map);
		}
		}
		try{
			cpuUsedDegree=JsonUtil.convertObject2Json(list);
			req.addRspData("cpu",cpuUsedDegree);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
