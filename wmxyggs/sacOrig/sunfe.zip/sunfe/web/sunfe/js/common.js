function convertStr2Json(str){
	return str.substring(1,str.length-1).split(',');
}