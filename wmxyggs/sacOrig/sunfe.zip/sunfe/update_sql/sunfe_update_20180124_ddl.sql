alter table gla_acct  modify systid varchar2(4);
alter table gla_tran  modify systid varchar2(4);
alter table GLA_AEUV  modify SOURST varchar2(4);
commit;

  
--����gla_vchr �� loan_busi ������
drop index IDX_GLS_VCHR_TRANSQ;
drop index IDX_GLS_VCHR_VCHRSQ;

alter table GLA_VCHR
  drop constraint PK_GLA_VCHR cascade;
alter table GLA_VCHR
  add constraint PK_GLA_VCHR primary key (STACID, SYSTID, TRANDT, TRANSQ, VCHRSQ, ACCTBR)
  using index ;

drop index IDX_LOAN_BUSI;
create index IDX_LOAN_BUSI on LOAN_BUSI (stacid, systid, trandt, tranbr, bathid);


alter table LOAN_BUSI modify bathid default '*';
alter table LOAN_BUSI modify bathid not null;
alter table LOAN_BUSI modify bathid default null;

alter table LOAN_BUSI
  drop constraint PK_LOAN_BUSI cascade;
alter table LOAN_BUSI
  add constraint PK_LOAN_BUSI primary key (STACID, SYSTID, TRANDT, TRANSQ, SERINO, BATHID)
  using index ;
  
  
  
drop table com_func;
create table COM_FUNC
(
  funcno VARCHAR2(12) not null,
  functx VARCHAR2(100) not null
)
;
-- Add comments to the table 
comment on table COM_FUNC
  is '��������Ϣ';
-- Add comments to the columns 
comment on column COM_FUNC.funcno
  is '������';
comment on column COM_FUNC.functx
  is '��������';
-- Create/Recreate primary, unique and foreign key constraints 
alter table COM_FUNC
  add constraint PK_COM_FUNC primary key (FUNCNO)
  using index ;
  
drop table fmp_item_config;  
create or replace view v_fmp_item_config as
select stacid,'C01' "FUNDTP",aebslv, lowrcr "ITEMCD" from fmp_cntr_aebs t where aebscd = '1A' union
select stacid,'C02' "FUNDTP",aebslv, upprdr "ITEMCD" from fmp_cntr_aebs t where aebscd = '1A' union
select stacid,'C05' "FUNDTP",aebslv, lowrdr "ITEMCD" from fmp_cntr_aebs t where aebscd = '1A' union
select stacid,'C06' "FUNDTP",aebslv, upprcr "ITEMCD" from fmp_cntr_aebs t where aebscd = '1A' order by
stacid,fundtp,aebslv;
comment on table V_FMP_ITEM_CONFIG is '�ڲ��ʽ��Ŀ����';
comment on column V_FMP_ITEM_CONFIG.STACID is '���ױ���';
comment on column V_FMP_ITEM_CONFIG.FUNDTP is '�ʽ����ͣ�C01��ű����� C02�ϴ汸���� C05��Ŷ��� C06�ϴ涨�ڣ�';
comment on column V_FMP_ITEM_CONFIG.AEBSLV is '�����㼶';
comment on column V_FMP_ITEM_CONFIG.ITEMCD is '��Ŀ';

