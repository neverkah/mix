-- Add columns
alter table GLI_IMP_COLM add stacid number(19) default 1;
comment on column GLI_IMP_COLM.STACID is '���ױ�ʶ';

alter table GLI_IMP_COLM add SYSTID VARCHAR2(4);
comment on column GLI_IMP_COLM.SYSTID is 'ϵͳ��ʶ';

-- Create table
create table GLI_PLAN
(
  plancd VARCHAR2(20) not null,
  planna VARCHAR2(40) not null,
  status CHAR(1) default '1' not null,
  certls VARCHAR2(1000) not null,
  smrytx VARCHAR2(255),
  stacid NUMBER(9) not null,
  systid VARCHAR2(1000) not null
);
-- Add comments to the columns 
comment on column GLI_PLAN.plancd
  is '��������';
comment on column GLI_PLAN.planna
  is '��������';
comment on column GLI_PLAN.status
  is '״̬(0�������ã�1������)';
comment on column GLI_PLAN.certls
  is '������ϸ(�ð�Ƕ��ŷָ�)';
comment on column GLI_PLAN.smrytx
  is '��ע';
comment on column GLI_PLAN.stacid
  is '����';
comment on column GLI_PLAN.systid
  is 'ϵͳ';
  
  --����һ������״̬
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'GL_TRANST', '8', 'DEFAULT', '����������', null, null, null, null, null, null, null, null, null, null, 'DEFAULT');

  
 --���н� ���ִ�����
  ALTER TABLE Glb_Exrt modify(tocrcy char(3));                                                   
update Glb_Exrt set crcycd = 'USD' where crcycd = '14';
update Glb_Exrt set crcycd = 'JPY' where crcycd = '27';
update Glb_Exrt set crcycd = 'EUR' where crcycd = '38';
update Glb_Exrt set crcycd = 'CNY' where crcycd = '01';
update Glb_Exrt set crcycd = 'GBP' where crcycd = '12';
update Glb_Exrt set crcycd = 'HKD' where crcycd = '13';
update Glb_Exrt set crcycd = 'CHF' where crcycd = '15';
update Glb_Exrt set crcycd = 'AUD' where crcycd = '29';
update Glb_Exrt set crcycd = 'CAD' where crcycd = '28';

update Glb_Exrt set tocrcy = substr(tocrcy,1,length(tocrcy)-1)||'C' ;


update com_exrt set crcycd = 'USD' where crcycd = '14';
update com_exrt set crcycd = 'JPY' where crcycd = '27';
update com_exrt set crcycd = 'EUR' where crcycd = '38';
update com_exrt set crcycd = 'CNY' where crcycd = '01';
update com_exrt set crcycd = 'GBP' where crcycd = '12';
update com_exrt set crcycd = 'HKD' where crcycd = '13';
update com_exrt set crcycd = 'CHF' where crcycd = '15';
update com_exrt set crcycd = 'AUD' where crcycd = '29';
update com_exrt set crcycd = 'CAD' where crcycd = '28';

update Com_Cvrt set crcycd = 'USD' where crcycd = '14';
update Com_Cvrt set crcycd = 'JPY' where crcycd = '27';
update Com_Cvrt set crcycd = 'EUR' where crcycd = '38';
update Com_Cvrt set crcycd = 'CNY' where crcycd = '01';
update Com_Cvrt set crcycd = 'GBP' where crcycd = '12';
update Com_Cvrt set crcycd = 'HKD' where crcycd = '13';
update Com_Cvrt set crcycd = 'CHF' where crcycd = '15';
update Com_Cvrt set crcycd = 'AUD' where crcycd = '29';
update Com_Cvrt set crcycd = 'CAD' where crcycd = '28';