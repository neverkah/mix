update pcmc_menu set linkurl ='/sunfe/glisfund/fmbcntr/fmbcntr_view.jsp' where menuname ='�ʽ��ͬ��ѯ';
update pcmc_menu set linkurl ='/sunfe/glisfund/fmpCntrAebs/fmpCntrAebs_view.jsp' where menuname ='�ϴ����¼����';
update pcmc_menu set linkurl ='/sunfe/glisfund/fmpInrtAjst/fmpInrtAjst_view.jsp' where menuname ='���ʵ���';
update pcmc_menu set linkurl ='/sunfe/glisfund/fmpInrt/fmpInrt_view.jsp' where menuname ='���ʲ�ѯ';
update pcmc_menu set linkurl ='/sunfe/glisfund/fmbDrrt/fmbDrrt_view.jsp' where menuname ='֧ȡ�黹��ѯ';
update pcmc_menu set linkurl ='/sunfe/glisfund/fmsInst/fmsInst_view.jsp' where menuname ='�ڲ��ʽ��Ϣ��ѯ';
update pcmc_menu set linkurl ='/sunfe/glisfund/fmpCntrAebs/fmpCntrAebs_query.jsp' where menuname ='�ϴ����¼��ѯ';
update pcmc_menu set linkurl ='/sunfe/glisfund/fmpItemConfig/fmpItemConfig_view.jsp' where menuname ='�ڲ��ʽ��Ŀ����';
update pcmc_menu set linkurl ='/sunfe/glisfund/fmpItemConfig/fmpItemConfig_query.jsp' where menuname ='�ڲ��ʽ��Ŀ��ѯ';
commit;


DELETE FROM PCMC_KNP_PARA WHERE PARATP='inrt_status';
insert into PCMC_KNP_PARA (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'inrt_status', '%', 'DEFAULT', '����״̬', 1, null, null, null, null, null, null, null, null, null, null);

insert into PCMC_KNP_PARA (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'inrt_status', '2', 'DEFAULT', '����', null, null, null, null, null, null, null, null, null, null, null);

insert into PCMC_KNP_PARA (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'inrt_status', '1', 'DEFAULT', '��Ч', null, null, null, null, null, null, null, null, null, null, null);

commit;