--glo_dep_busi  ������ ɾ����   TAģ�� �ڵ����������� ��DPTP02,DPTP03,DPTP04,DPTP05,DPTP06 ����Ϊ *
 DROP INDEX PK_GLO_DEP_BUSI;
alter table GLO_DEP_BUSI
  add constraint PK_GLO_DEP_BUSI primary key (STACID,TRANDT,ACCTBR,CRCYCD,DPTP01,DPTP02,DPTP03,DPTP04,DPTP05,DPTP06);
  
  
  commit;
  
  --ɾ������
  
 DROP INDEX PK_GLO_LOAN_BUSI;
  
 --��������
  alter table GLO_LOAN_BUSI
  add constraint PK_GLO_LOAN_BUSI primary key (STACID,TRANDT,ACCTBR,CRCYCD,DPTP01,DPTP02,DPTP03,DPTP04);
  commit;
  
  
  
  alter table loan_busi modify (loanp1 VARCHAR2(25),
  loanp2 VARCHAR2(25),
  loanp3 VARCHAR2(25),
  loanp4 VARCHAR2(25),
  loanp5 VARCHAR2(25),
  loanp6 VARCHAR2(25),
  loanp7 VARCHAR2(25),
  loanp8 VARCHAR2(25),
  loanp9 VARCHAR2(25),
  loanpa VARCHAR2(25));
  commit;
  
  
  insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('FE', 'FE_EDCTTP', '%', 'DEFAULT', '�������', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('FE', 'FE_EDCTTP', 'acen', 'DEFAULT', '�������', null, null, null, null, null, null, null, 1, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('FE', 'FE_EDCTTP', 'glis', 'DEFAULT', '������', null, null, null, null, null, null, null, 2, null, null, null);
commit;


alter table glb_dept_book add  bathid   VARCHAR2(35) not null;
commit;
  
  
  
  
  
 