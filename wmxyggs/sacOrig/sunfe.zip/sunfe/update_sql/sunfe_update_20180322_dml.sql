delete pcmc_knp_para t where t.subscd = 'fe' and t.paratp = 'aebscd';
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '%', 'DEFAULT', '�������', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '1A', 'DEFAULT', '�ϴ�', null, null, null, null, null, null, null, 1, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '1B', 'DEFAULT', '�ϴ�֧ȡ', null, null, null, null, null, null, null, 2, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '1D', 'DEFAULT', '�ϴ��Ϣ', null, null, null, null, null, null, null, 3, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '2A', 'DEFAULT', '�½�', null, null, null, null, null, null, null, 4, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '2B', 'DEFAULT', '�½�黹', null, null, null, null, null, null, null, 5, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '2D', 'DEFAULT', '�½��Ϣ', null, null, null, null, null, null, null, 6, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '3C', 'DEFAULT', '�ڲ��ʽ����', null, null, null, null, null, null, null, 7, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '3D', 'DEFAULT', '�ڲ��ʽ��Ϣ', null, null, null, null, null, null, null, 8, null, null, null);


insert into com_func (FUNCNO, FUNCTX)
values ('gls_reseca', '׼�������');

insert into com_para (STACID, PARANA, PARAVL, MODUCD, PARALV, PARATX)
values (1, 'resrit_freq', 'M', '0', '0', '�ڲ��ʽ��ϢƵ��');

commit;