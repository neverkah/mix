--zhangdq �˻�����������id  
alter table gla_acct add stacid number(19) default 1;
comment on column gla_acct.STACID is '���ױ�ʶ';

alter table gla_acct_h add stacid number(19) default 1;
comment on column gla_acct_h.STACID is '���ױ�ʶ';


--liuzengjɾ�������ֵ�  ����
delete pcmc_knp_para where  paratp like '%GL_CRCY%';
--�˻�״̬
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ACCTST', '0', 'DEFAULT', '�ر�', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ACCTST', '1', 'DEFAULT', '����', null, null, null, null, null, null, null, null, null, null);

--�˻����
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ACCTCL', '1', 'DEFAULT', '�ֹ��˻�', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ACCTCL', '2', 'DEFAULT', '��׼�˻�', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ACCTCL', '3', 'DEFAULT', 'ר���˻�', null, null, null, null, null, null, null, null, null, null);

--����

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_BLNCDN', 'D', 'DEFAULT', '�跽', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_BLNCDN', 'C', 'DEFAULT', '����', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_BLNCDN', 'P', 'DEFAULT', '����', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_BLNCDN', 'R', 'DEFAULT', '�շ�', null, null, null, null, null, null, null, null, null, null);


--�ֹ�����

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_HDBK', '0', 'DEFAULT', '������', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_HDBK', '1', 'DEFAULT', '��������', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_HDBK', '2', 'DEFAULT', '�������ϼ�����', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_HDBK', '3', 'DEFAULT', '�������¼�����', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_HDBK', '4', 'DEFAULT', '����������', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_HDBK', '5', 'DEFAULT', '����������', null, null, null, null, null, null, null, null, null, null);


---���������ֵ� ��������״̬

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_TRANST', '0', 'DEFAULT', '�Ǽ�', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_TRANST', '1', 'DEFAULT', '������', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_TRANST', '8', 'DEFAULT', '����������', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_TRANST', '9', 'DEFAULT', '������', null, null, null, null, null, null, null, null, null, null);

--�����������޸����ӵ�ַ
UPDATE PCMC_MENU SET "LINKURL"='/workflow/flow_todo_and_notify_list.jsp' where menuname like '%����������%';

commit;

