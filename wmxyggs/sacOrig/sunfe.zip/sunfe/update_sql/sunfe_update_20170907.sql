
-- Add/modify columns 
alter table GLA_ACCT_H modify openus VARCHAR2(20);
alter table GLA_ACCT_H modify closus VARCHAR2(20);

-- Create table
drop table busi_hang cascade constraints;
create table busi_hang
(
  STACID NUMBER(9) not null,
  SYSTID VARCHAR2(4) not null,
  TRANDT CHAR(8) not null,
  TRANSQ VARCHAR2(30) not null,
  tablcd VARCHAR2(120) not null,
  TRdata varchar2(4000) not null,
  STATUS CHAR(1) default 0 not null
);
-- Add comments to the table 
comment on table busi_hang
  is '������ˮ���˱�';
-- Add comments to the columns 
comment on column busi_hang.STACID
  is '����';
comment on column busi_hang.SYSTID
  is '����ϵͳ����';
comment on column busi_hang.TRANDT
  is '��������';
comment on column busi_hang.TRANSQ
  is '������ˮ';
comment on column busi_hang.tablcd
  is '�ӿڱ�����';
comment on column busi_hang.TRDATA
  is '������ˮ����json����';
comment on column busi_hang.STATUS
  is '����״̬��0δ���� 1�Ѵ���';
-- Create/Recreate primary, unique and foreign key constraints 
alter table busi_hang
  add constraint PK_busi_hang primary key (STACID, SYSTID, TRANDT, TRANSQ) ;


-- Create table
drop table busi_dict cascade constraints;
create table busi_dict
(
  tablcd VARCHAR2(120) not null,
  colucd VARCHAR2(120) not null,
  ordeid number(3) not null,
  coluna VARCHAR2(360) not null
);
-- Add comments to the table 
comment on table busi_dict
  is '�ӿڱ��ֶ��ֵ��';
-- Add comments to the columns 
comment on column busi_dict.tablcd
  is '�ӿڱ�����';
comment on column busi_dict.colucd
  is '�ӿ��б���';
comment on column busi_dict.ordeid
  is '�ӿ���˳��';  
comment on column busi_dict.coluna
  is '�ӿ�����������';
-- Create/Recreate primary, unique and foreign key constraints 
alter table busi_dict
  add constraint PK_busi_dict primary key (tablcd, colucd) ;

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (602, 'DEFAULT', 23, 577, 2, '�ռ佻����ˮ��������', null, '/sunfe/wrongaccount/wrongAccountHang/dayTimeHangUp.jsp', '0', null, 6, '1', '.577.602.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (601, 'DEFAULT', 23, 577, 2, '���к�����ˮ��������', null, '/sunfe/wrongaccount/wrongAccountHang/nightTimeHangUp.jsp', '0', null, 7, '1', '.577.601.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (600, 'DEFAULT', 23, 577, 2, '������ˮ��������', null, '/sunfe/wrongaccount/wrongAccountHang/loanBusiHangUp.jsp', '0', null, 5, '1', '.577.600.');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'stacid', 1, '����');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'systid', 2, 'ϵͳ');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'trandttrandt', 3, '��������');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'transq', 4, '������ˮ');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'trandt', 5, '���׻���');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'acctdt', 6, '�������');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'prcscd', 7, '���׳���');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'prodcd', 8, '��Ʒ');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'loanp1', 9, '����һ');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'loanp2', 10, '���Զ�');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'loanp3', 11, '������');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'loanp4', 12, '������');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'crcycd', 13, '����');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'trprcd', 14, '�������');

insert into busi_dict (TABLCD, COLUCD, ORDEID, COLUNA)
values ('loan_busi', 'tranam', 15, '���׽��');

---��ˮ��������״̬
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'GL_HANG_DEALST', '%', 'DEFAULT', '����״̬', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'GL_HANG_DEALST', '0', 'DEFAULT', 'δ����', null, null, null, null, null, null, null, 3, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'GL_HANG_DEALST', '1', 'DEFAULT', '�Ѵ���', null, null, null, null, null, null, null, 2, null, null, null);

commit;
