
--�޸�VERMOD�ֶ�

alter table SYS_BEAN add TMP_VERMOD number(19);
update SYS_BEAN set TMP_VERMOD = VERMOD;
alter table SYS_BEAN drop constraint PK_SYS_BEAN cascade;
alter table SYS_BEAN modify VERMOD null;
update SYS_BEAN set VERMOD = null; 
alter table SYS_BEAN modify (VERMOD number(19));
update SYS_BEAN set VERMOD =to_number(TMP_VERMOD);
alter table SYS_BEAN drop column TMP_VERMOD;
alter table SYS_BEAN modify VERMOD  not null;
alter table SYS_BEAN add constraint PK_SYS_BEAN primary key (BEANID, PROJCD, VERMOD) using index ;

alter table SYS_COND_DETL add TMP_VERMOD number(19);
update SYS_COND_DETL set TMP_VERMOD = VERMOD;
alter table SYS_COND_DETL drop constraint PK_SYS_COND_DETL cascade;
alter table SYS_COND_DETL modify VERMOD null;
update SYS_COND_DETL set VERMOD = null; 
alter table SYS_COND_DETL modify (VERMOD number(19));
update SYS_COND_DETL set VERMOD =to_number(TMP_VERMOD);
alter table SYS_COND_DETL drop column TMP_VERMOD;
alter table SYS_COND_DETL modify VERMOD not null;
alter table SYS_COND_DETL add constraint PK_SYS_COND_DETL primary key (CONDCD, SORTNO, PROJCD, VERMOD) using index ;

alter table SYS_COND add TMP_VERMOD number(19);
update SYS_COND set TMP_VERMOD = VERMOD;
alter table SYS_COND drop constraint PK_SYS_COND cascade;
alter table SYS_COND modify VERMOD null;
update SYS_COND set VERMOD = null; 
alter table SYS_COND modify (VERMOD number(19));
update SYS_COND set VERMOD =to_number(TMP_VERMOD);
alter table SYS_COND drop column TMP_VERMOD;
alter table SYS_COND modify VERMOD not null;
alter table SYS_COND add constraint PK_SYS_COND primary key (CONDCD, PROJCD, VERMOD) using index ;

alter table SYS_PRCS add TMP_VERMOD number(19);
update SYS_PRCS set TMP_VERMOD = VERMOD;
alter table SYS_PRCS  drop constraint PK_SYS_PRCS cascade;
alter table SYS_PRCS modify VERMOD null;
update SYS_PRCS set VERMOD = null; 
alter table SYS_PRCS modify (VERMOD number(19));
update SYS_PRCS set VERMOD =to_number(TMP_VERMOD);
alter table SYS_PRCS drop column TMP_VERMOD;
alter table SYS_PRCS modify VERMOD not null;
alter table SYS_PRCS add constraint PK_SYS_PRCS primary key (PRCSCD, PROJCD, VERMOD) using index ;

alter table SYS_TRCD add TMP_VERMOD number(19);
update SYS_TRCD set TMP_VERMOD = VERMOD;
alter table SYS_TRCD drop constraint PK_SYS_TRCD cascade;
alter table SYS_TRCD modify VERMOD null;
update SYS_TRCD set VERMOD = null; 
alter table SYS_TRCD modify (VERMOD number(19));
update SYS_TRCD set VERMOD =to_number(TMP_VERMOD);
alter table SYS_TRCD drop column TMP_VERMOD;
alter table SYS_TRCD modify VERMOD not null;
alter table SYS_TRCD add constraint PK_SYS_TRCD primary key (TRANCD, PROJCD, VERMOD) using index ;

alter table SYS_INTF add TMP_VERMOD number(19);
update SYS_INTF set TMP_VERMOD = VERMOD;
alter table SYS_INTF drop constraint PK_SYS_INTF cascade;
alter table SYS_INTF modify VERMOD null;
update SYS_INTF set VERMOD = null; 
alter table SYS_INTF modify (VERMOD number(19));
update SYS_INTF set VERMOD =to_number(TMP_VERMOD);
alter table SYS_INTF drop column TMP_VERMOD;
alter table SYS_INTF modify VERMOD not null;
alter table SYS_INTF add constraint PK_SYS_INTF primary key (INTFCD, PROJCD, VERMOD) using index ;

alter table SYS_INTF_DETL add TMP_VERMOD number(19);
update SYS_INTF_DETL set TMP_VERMOD = VERMOD;
alter table SYS_INTF_DETL drop constraint PK_SYS_INTF_DETL cascade;
alter table SYS_INTF_DETL modify VERMOD null;
update SYS_INTF_DETL set VERMOD = null; 
alter table SYS_INTF_DETL modify (VERMOD number(19));
update SYS_INTF_DETL set VERMOD =to_number(TMP_VERMOD);
alter table SYS_INTF_DETL drop column TMP_VERMOD;
alter table SYS_INTF_DETL modify VERMOD not null;
alter table SYS_INTF_DETL add constraint PK_SYS_INTF_DETL primary key (INTFCD, INOTTG, FILDLV, FILDCD, PROJCD, VERMOD) using index ;

alter table SYS_PROF add TMP_VERMOD number(19);
update SYS_PROF set TMP_VERMOD = VERMOD;
alter table SYS_PROF drop constraint PK_SYS_PROF cascade;
alter table SYS_PROF modify VERMOD null;
update SYS_PROF set VERMOD = null; 
alter table SYS_PROF modify (VERMOD number(19));
update SYS_PROF set VERMOD =to_number(TMP_VERMOD);
alter table SYS_PROF drop column TMP_VERMOD;
alter table SYS_PROF modify VERMOD not null;
alter table SYS_PROF add constraint PK_SYS_PROF primary key (PROFTP, PROJCD, PROFID, VERMOD) using index ;

alter table SYS_PFTP add TMP_VERMOD number(19);
update SYS_PFTP set TMP_VERMOD = VERMOD;
alter table SYS_PFTP drop constraint PK_SYS_PFTP cascade;
alter table SYS_PFTP modify VERMOD null;
update SYS_PFTP set VERMOD = null; 
alter table SYS_PFTP modify (VERMOD number(19));
update SYS_PFTP set VERMOD =to_number(TMP_VERMOD);
alter table SYS_PFTP drop column TMP_VERMOD;
alter table SYS_PFTP modify VERMOD not null;
alter table SYS_PFTP add constraint PK_SYS_PFTP primary key (PROFTP, PROJCD, VERMOD) using index ;

alter table SYS_PROD add TMP_VERMOD number(19);
update SYS_PROD set TMP_VERMOD = VERMOD;
alter table SYS_PROD drop constraint PK_SYS_PROD cascade;
alter table SYS_PROD modify VERMOD null;
update SYS_PROD set VERMOD = null; 
alter table SYS_PROD modify (VERMOD number(19));
update SYS_PROD set VERMOD =to_number(TMP_VERMOD);
alter table SYS_PROD drop column TMP_VERMOD;
alter table SYS_PROD modify VERMOD not null;
alter table SYS_PROD add constraint PK_SYS_PROD primary key (PRODCD, PROJCD, VERMOD) using index ;

alter table SYS_TMTP add TMP_VERMOD number(19);
update SYS_TMTP set TMP_VERMOD = VERMOD;
alter table SYS_TMTP drop constraint PK_SYS_TMTP cascade;
alter table SYS_TMTP modify VERMOD null;
update SYS_TMTP set VERMOD = null; 
alter table SYS_TMTP modify (VERMOD number(19));
update SYS_TMTP set VERMOD =to_number(TMP_VERMOD);
alter table SYS_TMTP drop column TMP_VERMOD;
alter table SYS_TMTP modify VERMOD not null;
alter table SYS_TMTP add constraint PK_SYS_TMTP primary key (TMPLTP, PROJCD, VERMOD) using index ;

alter table SYS_TMPL add TMP_VERMOD number(19);
update SYS_TMPL set TMP_VERMOD = VERMOD;
alter table SYS_TMPL drop constraint PK_SYS_TMPL cascade;
alter table SYS_TMPL modify VERMOD null;
update SYS_TMPL set VERMOD = null; 
alter table SYS_TMPL modify (VERMOD number(19));
update SYS_TMPL set VERMOD =to_number(TMP_VERMOD);
alter table SYS_TMPL drop column TMP_VERMOD;
alter table SYS_TMPL modify VERMOD not null;
alter table SYS_TMPL add constraint PK_SYS_TMPL primary key (TMPLTP, TMPLID, PROJCD, VERMOD) using index ;

alter table SYS_TMAP add TMP_VERMOD number(19);
update SYS_TMAP set TMP_VERMOD = VERMOD;
alter table SYS_TMAP drop constraint PK_SYS_TMAP cascade;
alter table SYS_TMAP modify VERMOD null;
update SYS_TMAP set VERMOD = null; 
alter table SYS_TMAP modify (VERMOD number(19));
update SYS_TMAP set VERMOD =to_number(TMP_VERMOD);
alter table SYS_TMAP drop column TMP_VERMOD;
alter table SYS_TMAP modify VERMOD not null;
alter table SYS_TMAP add constraint PK_SYS_TMAP primary key (TMPLTP, TMPLID, SORTNO, PROJCD, VERMOD) using index ;

alter table SYS_PRTP add TMP_VERMOD number(19);
update SYS_PRTP set TMP_VERMOD = VERMOD;
alter table SYS_PRTP drop constraint PK_SYS_PRTP cascade;
alter table SYS_PRTP modify VERMOD null;
update SYS_PRTP set VERMOD = null; 
alter table SYS_PRTP modify (VERMOD number(19));
update SYS_PRTP set VERMOD =to_number(TMP_VERMOD);
alter table SYS_PRTP drop column TMP_VERMOD;
alter table SYS_PRTP modify VERMOD not null;
alter table SYS_PRTP add constraint PK_SYS_PRTP primary key (PRGPTP, PROJCD, VERMOD) using index ;

alter table SYS_PRTP_DETL add TMP_VERMOD number(19);
update SYS_PRTP_DETL set TMP_VERMOD = VERMOD;
alter table SYS_PRTP_DETL drop constraint PK_SYS_PRTP_DETL cascade;
alter table SYS_PRTP_DETL modify VERMOD null;
update SYS_PRTP_DETL set VERMOD = null; 
alter table SYS_PRTP_DETL modify (VERMOD number(19));
update SYS_PRTP_DETL set VERMOD =to_number(TMP_VERMOD);
alter table SYS_PRTP_DETL drop column TMP_VERMOD;
alter table SYS_PRTP_DETL modify VERMOD not null;
alter table SYS_PRTP_DETL add constraint PK_SYS_PRTP_DETL primary key (PRGPTP, PROPCD, PROJCD, VERMOD) using index ;

alter table SYS_TMAP_TRAN add TMP_VERMOD number(19);
update SYS_TMAP_TRAN set TMP_VERMOD = VERMOD;
alter table SYS_TMAP_TRAN drop constraint PK_SYS_TMAP_TRAN cascade;
alter table SYS_TMAP_TRAN modify VERMOD null;
update SYS_TMAP_TRAN set VERMOD = null; 
alter table SYS_TMAP_TRAN modify (VERMOD number(19));
update SYS_TMAP_TRAN set VERMOD =to_number(TMP_VERMOD);
alter table SYS_TMAP_TRAN drop column TMP_VERMOD;
alter table SYS_TMAP_TRAN modify VERMOD not null;
alter table SYS_TMAP_TRAN add constraint PK_SYS_TMAP_TRAN primary key (PRCSCD, DTTRCD, TRTLNO, SORTNO, PROJCD, VERMOD) using index ;

alter table SYS_TRTL add TMP_VERMOD number(19);
update SYS_TRTL set TMP_VERMOD = VERMOD;
alter table SYS_TRTL drop constraint PK_SYS_TRTL cascade;
alter table SYS_TRTL modify VERMOD null;
update SYS_TRTL set VERMOD = null; 
alter table SYS_TRTL modify (VERMOD number(19));
update SYS_TRTL set VERMOD =to_number(TMP_VERMOD);
alter table SYS_TRTL drop column TMP_VERMOD;
alter table SYS_TRTL modify VERMOD not null;
alter table SYS_TRTL add constraint PK_SYS_TRTL primary key (PRCSCD, SORTNO, PROJCD, VERMOD) using index ;

alter table SYS_PMAP add TMP_VERMOD number(19);
update SYS_PMAP set TMP_VERMOD = VERMOD;
alter table SYS_PMAP drop constraint PK_SYS_PMAP cascade;
alter table SYS_PMAP modify VERMOD null;
update SYS_PMAP set VERMOD = null; 
alter table SYS_PMAP modify (VERMOD number(19));
update SYS_PMAP set VERMOD =to_number(TMP_VERMOD);
alter table SYS_PMAP drop column TMP_VERMOD;
alter table SYS_PMAP modify VERMOD not null;
alter table SYS_PMAP add constraint PK_SYS_PMAP primary key (PRODCD, TRANCD, CORRTG, TMPLTP, TMPLID, PROJCD, VERMOD) using index ;
commit;
