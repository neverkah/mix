--���������ӽ��ס��˵�ӦΪ�����׳����ӽ��ס�
update pcmc_menu set menuname = '���׳����ӽ���' where menuid= '134';


update pcmc_menu set menuname = '���׳����ӽ���ģ��' where menuid= '136';


--�����ֵ�-��Ŀ�������

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMDN', '%', 'DEFAULT', '��Ŀ����', 1, null, null, null, null, null, null, null, null,null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMDN', 'B', 'DEFAULT', '˫��', null, null, null, null, null, null, null, null, null,null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMDN', 'C', 'DEFAULT', '��', null, null, null, null, null, null, null, null, null,null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMDN', 'D', 'DEFAULT', '��', null, null, null, null, null, null, null, null, null,null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMDN', 'P', 'DEFAULT', '��', null, null, null, null, null, null, null, null, null,null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMDN', 'R', 'DEFAULT', '��', null, null, null, null, null, null, null, null, null,null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMDN', 'Z', 'DEFAULT', '����', null, null, null, null, null, null, null, null, null,null);





commit;