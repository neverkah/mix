---- 

alter table glo_dep_busi modify cainsq null;

alter table glo_dep_busi modify transq null; 

alter table glo_dep_busi modify tranbr null;

alter table glo_dep_busi modify dtitcd not null;

commit;


alter table glo_loan_busi modify transq null; 

alter table glo_loan_busi modify tranbr null;

alter table glo_loan_busi modify trantp null;

commit;

