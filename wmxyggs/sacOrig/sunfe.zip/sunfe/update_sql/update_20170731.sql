
--���������ֵ� ��ծȯ���
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'ivsttp', '%', 'DEFAULT', 'ծȯ���', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'ivsttp', '01', 'DEFAULT', '����ծȯ', null, null, null, null, null, null, null, 1, null, null, null);




commit;

-- Create table
create table GLI_MSLG
(
  stacid NUMBER(19),
  systid CHAR(2),
  recedt TIMESTAMP(6),
  respdt TIMESTAMP(6),
  recems CLOB,
  respms CLOB,
  prcscd VARCHAR2(16),
  mssize INTEGER,
  prtims INTEGER,
  prstau CHAR(1),
  errolg CLOB
);
-- Add comments to the columns 
comment on column GLI_MSLG.stacid
  is '����';
comment on column GLI_MSLG.systid
  is 'Դϵͳ';
comment on column GLI_MSLG.recedt
  is '���ձ���ʱ��';
comment on column GLI_MSLG.respdt
  is '���ر���ʱ��';
comment on column GLI_MSLG.recems
  is '���ձ���';
comment on column GLI_MSLG.respms
  is '��Ӧ����';
comment on column GLI_MSLG.prcscd
  is '���Ĵ�����';
comment on column GLI_MSLG.mssize
  is '���Ĵ�С';
comment on column GLI_MSLG.prtims
  is '��������';
comment on column GLI_MSLG.prstau
  is '����״̬';
comment on column GLI_MSLG.errolg
  is '������־';

--���ֵ���Ϊ��ʾ CNY�Ĺ��ʱ�׼�����ó�����01 ��׼   ��char(3)����Ϊ varchar2(3)
alter table ADB_CARD modify CRCYCD varchar2(3);
alter table AFE_BUSI modify CRCYCD varchar2(3);
alter table ASB_BUSI modify CRCYCD varchar2(3);
alter table ASI_CARD modify CRCYCD varchar2(3);
alter table BBK_BUSI modify CRCYCD varchar2(3);
alter table CMT_BSQR modify CRCYCD varchar2(3);
alter table COM_ACCT modify CRCYCD varchar2(3);
alter table COM_BOOK_CARD modify CRCYCD VARCHAR2(3);
alter table COM_CRCY modify CRCYCD varchar2(3);
alter table COM_CVRT modify CRCYCD varchar2(3);
alter table COM_EXRT modify CRCYCD varchar2(3);
alter table COM_EXRT1 modify CRCYCD varchar2(3);
alter table COM_FCPL modify CRCYCD varchar2(3);
alter table COM_JOUR_CARD modify CRCYCD VARCHAR2(3);
alter table COM_JOUR_DETL modify CRCYCD VARCHAR2(3);
alter table COM_LOOK modify CRCYCD varchar2(3);
alter table COM_PROFITREPORT modify CRCYCD varchar2(3);
alter table COM_PROFIT_ALL modify CRCYCD varchar2(3);
alter table COM_REPORT modify CRCYCD varchar2(3);
alter table COM_REPORT_ALL modify CRCYCD varchar2(3);
alter table COM_STAC modify CRCYCD VARCHAR2(3);
alter table COM_VTLV modify CRCYCD varchar2(3);
alter table COM_VTPL modify CRCYCD varchar2(3);
alter table CSA_BUSI modify CRCYCD varchar2(3);
alter table DEP_BUSI modify CRCYCD varchar2(3);
alter table FMB_CNTR modify CRCYCD varchar2(3);
alter table FMB_CNTR_BAK modify CRCYCD varchar2(3);
alter table FMB_CNTR_ZY modify CRCYCD varchar2(3);
alter table FMB_RESV modify CRCYCD varchar2(3);
alter table FMP_INRT modify CRCYCD varchar2(3);
alter table FMP_INRT_AJST modify CRCYCD varchar2(3);
alter table FMS_CAIT modify CRCYCD varchar2(3);
alter table FMS_INST modify CRCYCD varchar2(3);
alter table GAB_AEUV modify CRCYCD varchar2(3);
alter table GAB_GLIS modify CRCYCD varchar2(3);
alter table GAB_TRAN modify CRCYCD varchar2(3);
alter table GAB_UTDY modify CRCYCD varchar2(3);
alter table GCA_AEUV modify CRCYCD varchar2(3);
alter table GCA_GLIS modify CRCYCD varchar2(3);
alter table GCA_GLIS_H modify CRCYCD varchar2(3);
alter table GCA_TRAN modify CRCYCD varchar2(3);
alter table GCA_TRAN_H modify CRCYCD varchar2(3);
alter table GCA_VCHR modify CRCYCD varchar2(3);
alter table GCA_VCHR_H modify CRCYCD varchar2(3);
alter table GCB_VCHS modify CRCYCD varchar2(3);
alter table GCT_GLIS modify CRCYCD varchar2(3);
alter table GCT_SUMY modify CRCYCD varchar2(3);
alter table GLA_ACCT modify CRCYCD varchar2(3);
alter table GLA_ACCT_H modify CRCYCD varchar2(3);
alter table GLA_ADJT modify CRCYCD varchar2(3);
alter table GLA_AEUV_DETL modify CRCYCD varchar2(3);
alter table GLA_AEUV_H modify CRCYCD varchar2(3);
alter table GLA_CHK_SUBL modify CRCYCD VARCHAR2(3);
alter table GLA_CHK_SUBL_H modify CRCYCD VARCHAR2(3);
alter table GLA_CVCP modify CRCYCD varchar2(3);
alter table GLA_ENTR modify CRCYCD varchar2(3);
alter table GLA_ENTR_H modify CRCYCD varchar2(3);
alter table GLA_GLIS modify CRCYCD varchar2(3);
alter table GLA_GLIS_ADJU modify CRCYCD varchar2(3);
alter table GLA_GLIS_H modify CRCYCD varchar2(3);
alter table GLA_GLIS_H_S modify CRCYCD varchar2(3);
alter table GLA_GLIS_VITL_H modify CRCYCD varchar2(3);
alter table GLA_GLIS_ZY modify CRCYCD varchar2(3);
alter table GLA_GNMI modify CRCYCD varchar2(3);
alter table GLA_ITAJ modify CRCYCD varchar2(3);
alter table GLA_LPCL modify CRCYCD varchar2(3);
alter table GLA_MNTY modify CRCYCD varchar2(3);
alter table GLA_TRAN modify CRCYCD varchar2(3);
alter table GLA_TRVC modify CRCYCD VARCHAR2(3);
alter table GLA_VCHR modify CRCYCD varchar2(3);
alter table GLA_VCHR_H modify CRCYCD varchar2(3);
alter table GLB_ACCT modify CRCYCD varchar2(3);
alter table GLB_ACCT_BOOK modify CRCYCD varchar2(3);
alter table GLB_ACEX modify CRCYCD varchar2(3);
alter table GLB_AFEE_BOOK modify CRCYCD varchar2(3);
alter table GLB_AST_BOOK modify CRCYCD varchar2(3);
alter table GLB_BANK_BOOK modify CRCYCD varchar2(3);
alter table GLB_CASH_BOOK modify CRCYCD varchar2(3);
alter table GLB_CLER modify CRCYCD varchar2(3);
alter table GLB_CNBK_BOOK modify CRCYCD varchar2(3);
alter table GLB_CONV modify CRCYCD varchar2(3);
alter table GLB_CSER_BOOK modify CRCYCD varchar2(3);
alter table GLB_DEPT_BOOK modify CRCYCD varchar2(3);
alter table GLB_DIST_BOOK modify CRCYCD varchar2(3);
alter table GLB_EXHT modify CRCYCD varchar2(3);
alter table GLB_EXRT modify CRCYCD varchar2(3);
alter table GLB_GPLD_BOOK modify CRCYCD varchar2(3);
alter table GLB_INAC_BOOK modify CRCYCD varchar2(3);
alter table GLB_INVT_BOOK modify CRCYCD varchar2(3);
alter table GLB_LOAN_BOOK modify CRCYCD varchar2(3);
alter table GLB_LSBL modify CRCYCD VARCHAR2(3);
alter table GLB_PRVC_BOOK modify CRCYCD varchar2(3);
alter table GLB_RVPY_BOOK modify CRCYCD varchar2(3);
alter table GLB_UNDF modify CRCYCD varchar2(3);
alter table GLC_AEUV modify CRCYCD varchar2(3);
alter table GLC_ENTR modify CRCYCD varchar2(3);
alter table GLC_GLIS modify CRCYCD varchar2(3);
alter table GLC_GLIS_H modify CRCYCD varchar2(3);
alter table GLC_TRAN modify CRCYCD varchar2(3);
alter table GLC_UTDY modify CRCYCD varchar2(3);
alter table GLC_VCHR modify CRCYCD varchar2(3);
alter table GLI_ACCT modify CRCYCD VARCHAR2(3);
alter table GLI_LTTS modify CRCYCD varchar2(3);
alter table GLL_UTDY modify CRCYCD varchar2(3);
alter table GLO_ACCT modify CRCYCD VARCHAR2(3);
alter table GLO_CMDD_CAIN modify CRCYCD varchar2(3);
alter table GLO_CMDD_CHDT modify CRCYCD varchar2(3);
alter table GLO_CMDD_INAC modify CRCYCD varchar2(3);
alter table GLO_CMDD_PYIN modify CRCYCD varchar2(3);
alter table GLO_CMDD_RVPY modify CRCYCD varchar2(3);
alter table GLO_CMDD_TAX modify CRCYCD VARCHAR2(3);
alter table GLO_COM_EXRT modify CRCYCD varchar2(3);
alter table GLO_DEP_BUSI modify CRCYCD varchar2(3);
alter table GLO_EXTD modify CRCYCD varchar2(3);
alter table GLO_LOAN_BUSI modify CRCYCD varchar2(3);
alter table GLO_LOAN_TRAN modify CRCYCD varchar2(3);
alter table GLO_OTAS_CMDA modify CRCYCD VARCHAR2(3);
alter table GLO_TRAN modify CRCYCD VARCHAR2(3);
alter table GLO_TRCM_CSIO modify CRCYCD varchar2(3);
alter table GLR_GLIS modify CRCYCD varchar2(3);
alter table GLS_AFE_TRAN modify CRCYCD varchar2(3);
alter table GLS_ASB_DPRA modify CRCYCD varchar2(3);
alter table GLS_ASB_TRAN modify CRCYCD varchar2(3);
alter table GLS_CLS_CMDA modify CRCYCD VARCHAR2(3);
alter table GLS_CMDD_CAIN modify CRCYCD varchar2(3);
alter table GLS_CMDD_CHDT modify CRCYCD varchar2(3);
alter table GLS_CMDD_INAC modify CRCYCD varchar2(3);
alter table GLS_CMDD_PYIN modify CRCYCD varchar2(3);
alter table GLS_CMDD_RVCH modify CRCYCD VARCHAR2(3);
alter table GLS_CMDD_RVPY modify CRCYCD varchar2(3);
alter table GLS_CMDD_TAX modify CRCYCD VARCHAR2(3);
alter table GLS_EXTD modify CRCYCD varchar2(3);
alter table GLS_IVT_TRAN modify CRCYCD varchar2(3);
alter table GLS_LOAN_TRAN modify CRCYCD varchar2(3);
alter table GLS_MID_TRAN modify CRCYCD varchar2(3);
alter table GLS_OTAS_CMDA modify CRCYCD VARCHAR2(3);
alter table GLS_TRAN modify CRCYCD VARCHAR2(3);
alter table GLS_TRAN_BAK modify CRCYCD VARCHAR2(3);
alter table GLS_TRAN_HWY modify CRCYCD VARCHAR2(3);
alter table GLS_TRCM_CSIO modify CRCYCD varchar2(3);
alter table GLS_TRCM_CSMV modify CRCYCD VARCHAR2(3);
alter table GLT_CLEAR modify CRCYCD varchar2(3);
alter table GLT_CRCY modify CRCYCD varchar2(3);
alter table GLT_CRCY_SUMM modify CRCYCD varchar2(3);
alter table GLT_CVCP modify CRCYCD varchar2(3);
alter table GLT_DEPT modify CRCYCD varchar2(3);
alter table GLT_EXHT modify CRCYCD varchar2(3);
alter table GLT_GLIS modify CRCYCD varchar2(3);
alter table GLT_GLIS_H modify CRCYCD varchar2(3);
alter table GLT_GLIS_ZDQ modify CRCYCD varchar2(3);
alter table GLT_ITAJ modify CRCYCD varchar2(3);
alter table GLT_ITFV modify CRCYCD varchar2(3);
alter table GLT_LOAN modify CRCYCD varchar2(3);
alter table GLT_MNTY modify CRCYCD varchar2(3);
alter table GLT_MNTY_H modify CRCYCD varchar2(3);
alter table GLT_SUMY modify CRCYCD varchar2(3);
alter table GLT_SUMY_TIME modify CRCYCD varchar2(3);
alter table GLT_TEMP modify CRCYCD varchar2(3);
alter table GLT_UBOK modify CRCYCD varchar2(3);
alter table HX_CMDD_REPY modify CRCYCD varchar2(3);
alter table IBB_BOOK modify CRCYCD varchar2(3);
alter table IBI_BOOK modify CRCYCD VARCHAR2(3);
alter table ICB_BOOK modify CRCYCD varchar2(3);
alter table IMP_FMB_CNTR modify CRCYCD varchar2(3);
alter table IMP_GLA_ACCT modify CRCYCD varchar2(3);
alter table IMP_GLA_GLIS modify CRCYCD varchar2(3);
alter table IMP_GLA_VCHR_H modify CRCYCD varchar2(3);
alter table IMP_GLB_DEPT_BOOK modify CRCYCD varchar2(3);
alter table IOB_BOOK modify CRCYCD varchar2(3);
alter table IOI_BOOK modify CRCYCD VARCHAR2(3);
alter table IOT_ENTR modify CRCYCD varchar2(3);
alter table IRB_BOOK modify CRCYCD varchar2(3);
alter table IRI_BOOK modify CRCYCD VARCHAR2(3);
alter table IVT_BUSI modify CRCYCD varchar2(3);
alter table KTP_RESV modify CRCYCD varchar2(3);
alter table LOAN_BUSI modify CRCYCD varchar2(3);
alter table RPB_DATA modify CRCYCD varchar2(3);
alter table RPB_IDDV_CALC modify CRCYCD varchar2(3);
alter table RPB_IDGL modify CRCYCD varchar2(3);
alter table RPB_MANU_RECD modify CRCYCD VARCHAR2(3);
alter table RPT_IDGL_CALC modify CRCYCD varchar2(3);
alter table SYS_ACCT_OPEN modify CRCYCD varchar2(3);
alter table TXB_DFIC modify CRCYCD varchar2(3);
alter table ZHH_RESV modify CRCYCD varchar2(3);


---ɾ����Ŀ��Ӧ�˵������滻���ӿڹ��� - ��Ŀӳ��
delete from pcmc_menu where menuname = '��Ŀ��Ӧ' ;
commit;


---������˳��������ֵ������µ�����

delete from pcmc_knp_para where subscd ='COMM' and paratp = 'clersq'; 
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'clersq', '%', 'DEFAULT', '����˳��', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'clersq', '1', 'DEFAULT', '1.֧��-����', null, null, null, null, null, null, null, 1, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'clersq', '2', 'DEFAULT', '2.����-����', null, null, null, null, null, null, null, 2, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'clersq', '3', 'DEFAULT', '3.����-����', null, null, null, null, null, null, null, 3, null, null, null);

commit;


---��Ƽ����������ֵ�����

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'acctsy', 'CA', 'DEFAULT', 'ͳ����', null, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'acctsy', '%', 'DEFAULT', '��Ƽ�����', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'acctsy', 'IA', 'DEFAULT', '������', null, null, null, null, null, null, null, null, null, null, null);

commit;
