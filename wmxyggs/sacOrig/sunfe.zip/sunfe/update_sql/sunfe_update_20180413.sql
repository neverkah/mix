-- Create table
drop table VCHR_IOMP;
create table VCHR_IOMP
(
  module VARCHAR2(20) not null,
  desctx VARCHAR2(255) not null,
  stacid NUMBER(19) not null
);
-- Add comments to the table 
comment on table VCHR_IOMP
  is '��¼����ӳ������';
-- Add comments to the columns 
comment on column VCHR_IOMP.module
  is 'ģ��';
comment on column VCHR_IOMP.desctx
  is '��¼����ӳ��';
comment on column VCHR_IOMP.stacid
  is '���ױ��';
  
alter table VCHR_IOMP
  add constraint PK_VCHR_IOMP primary key (MODULE,STACID)
  using index ;
-- Create table
drop table VCHR_IOMP_DETL;
create table VCHR_IOMP_DETL
(
  module VARCHAR2(20) not null,
  tovacd VARCHAR2(120) not null,
  tovana VARCHAR2(360) not null,
  ordeid NUMBER(3) not null,
  varitp CHAR(1) not null,
  fmvacd VARCHAR2(120),
  fmvana VARCHAR2(360),
  desctx VARCHAR2(255) not null,
  updati DATE,
  updaid VARCHAR2(20),
  creati DATE,
  creaid VARCHAR2(20),
  stacid NUMBER(19) not null
);
-- Add comments to the table 
comment on table VCHR_IOMP_DETL
  is '��¼����ӳ��ӱ�';
-- Add comments to the columns 
comment on column VCHR_IOMP_DETL.module
  is 'ģ��';
comment on column VCHR_IOMP_DETL.tovacd
  is 'Ŀ���������';
comment on column VCHR_IOMP_DETL.tovana
  is 'Ŀ���������';
comment on column VCHR_IOMP_DETL.ordeid
  is '���';
comment on column VCHR_IOMP_DETL.varitp
  is 'Ŀ������  1 �̶�����  2 ��չ����';
comment on column VCHR_IOMP_DETL.fmvacd
  is '��Դ��������';
comment on column VCHR_IOMP_DETL.fmvana
  is '��Դ��������';
comment on column VCHR_IOMP_DETL.desctx
  is '��ע˵��';
comment on column VCHR_IOMP_DETL.stacid
  is '���ױ��';
-- Create/Recreate primary, unique and foreign key constraints 
alter table VCHR_IOMP_DETL
  add constraint PK_VCHR_IOMP_DETL primary key (MODULE, TOVACD, STACID)
  using index ;

-- Create table
drop table VCHR_TMPL;
create table VCHR_TMPL
(
  varicd VARCHAR2(120) not null,
  varitp CHAR(1) default '1' not null,
  ordeid NUMBER(3) not null,
  busina VARCHAR2(360) not null,
  desctx VARCHAR2(255) not null,
  updati DATE,
  updaid VARCHAR2(20),
  creati DATE,
  creaid VARCHAR2(20),
  stacid NUMBER(19) not null,
  detner VARCHAR2(20)
);
-- Add comments to the table 
comment on table VCHR_TMPL
  is '��ά��¼ģ��ṹ';
-- Add comments to the columns 
comment on column VCHR_TMPL.varicd
  is '��������';
comment on column VCHR_TMPL.varitp
  is '�������� 1 �̶����� 2 ��ά����';
comment on column VCHR_TMPL.ordeid
  is '���';
comment on column VCHR_TMPL.busina
  is 'ҵ������';
comment on column VCHR_TMPL.desctx
  is '�ֶ�˵��';
comment on column VCHR_TMPL.stacid
  is '���ױ��';
comment on column VCHR_TMPL.detner
  is '�����޶���';
-- Create/Recreate primary, unique and foreign key constraints 
alter table VCHR_TMPL
  add constraint PK_VCHR_TMPL primary key (VARICD, STACID)
  using index;

-- Create table
drop table MODU_DICT;
create table MODU_DICT
(
  module VARCHAR2(20) not null,
  tablcd VARCHAR2(120) not null,
  desctx VARCHAR2(255) not null,
  status CHAR(1) default '0' not null
);
-- Add comments to the table 
comment on table MODU_DICT
  is 'ģ�����ݽṹ����';
-- Add comments to the columns 
comment on column MODU_DICT.module
  is 'ģ�����';
comment on column MODU_DICT.tablcd
  is '��Ӧ�Ľӿڱ���';
comment on column MODU_DICT.desctx
  is '˵��';
comment on column MODU_DICT.status
  is 'ģ������״̬ 1 ���� 9 ͣ��';
-- Create/Recreate primary, unique and foreign key constraints 
alter table MODU_DICT
  add constraint PK_MODU_DICT primary key (MODULE, TABLCD)
  using index ;
-- Create table
drop table MODU_DICT_DETL;
create table MODU_DICT_DETL
(
  module VARCHAR2(20) not null,
  varitp CHAR(1) default '1' not null,
  ordeid NUMBER(3) not null,
  varicd VARCHAR2(120) not null,
  busina VARCHAR2(360) not null,
  desctx VARCHAR2(255) not null,
  status CHAR(1) default '0' not null,
  updati DATE,
  updaid VARCHAR2(20),
  creati DATE,
  creaid VARCHAR2(20)
);
-- Add comments to the table 
comment on table MODU_DICT_DETL
  is 'ģ�����ݽṹ�ӱ�';
-- Add comments to the columns 
comment on column MODU_DICT_DETL.module
  is 'ģ�����';
comment on column MODU_DICT_DETL.varitp
  is '�������� 1 �������� 2 ��������';
comment on column MODU_DICT_DETL.ordeid
  is '���';
comment on column MODU_DICT_DETL.varicd
  is '��������';
comment on column MODU_DICT_DETL.busina
  is 'ҵ������';
comment on column MODU_DICT_DETL.desctx
  is '�ֶ�˵��';
comment on column MODU_DICT_DETL.status
  is '�ӽ����Ƿ�ɼ��У�0����1�ǣ�';
-- Create/Recreate primary, unique and foreign key constraints 
alter table MODU_DICT_DETL
  add constraint PK_MODU_DICT_DETL primary key (MODULE, VARICD)
  using index ;

-- Create table
drop table SYS_TRCD_DETL;
create table SYS_TRCD_DETL
(
  trancd VARCHAR2(20) not null,
  tranna VARCHAR2(50),
  varicd VARCHAR2(20) not null,
  varina VARCHAR2(50),
  varitp VARCHAR2(40) not null
);
-- Add comments to the table 
comment on table SYS_TRCD_DETL
  is '�ӽ���������ϸ��';
-- Add comments to the columns 
comment on column SYS_TRCD_DETL.trancd
  is '�ӽ���������';
comment on column SYS_TRCD_DETL.tranna
  is '�ӽ����������';
comment on column SYS_TRCD_DETL.varicd
  is '�ֶδ���';
comment on column SYS_TRCD_DETL.varina
  is '�ֶ�����';
comment on column SYS_TRCD_DETL.varitp
  is '�ֶ�����(1:�ӽ������ݽṹ2:�������3����Ʒ)';
-- Create/Recreate primary, unique and foreign key constraints 
alter table SYS_TRCD_DETL
  add constraint PK_SYS_TRCD_DETL primary key (TRANCD, VARICD, VARITP)
  using index;



-- Add/modify columns 
alter table SYS_TRTL add desctx varchar2(255);
-- Add comments to the columns 
comment on column SYS_TRTL.desctx
  is '˵��';
  
  
-- Add/modify columns 
alter table LOAN_BUSI add numex0 NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numex0
  is '���1';
-- Add/modify columns 
alter table LOAN_BUSI add numex1 NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numex1
  is '���2';
  -- Add/modify columns 
alter table LOAN_BUSI add numex2 NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numex2
  is '���3';
  -- Add/modify columns 
alter table LOAN_BUSI add numex3 NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numex3
  is '���4';
  -- Add/modify columns 
alter table LOAN_BUSI add numex4 NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numex4
  is '���5';
  -- Add/modify columns 
alter table LOAN_BUSI add numex5 NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numex5
  is '���6';
  -- Add/modify columns 
alter table LOAN_BUSI add numex6 NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numex6
  is '���7';
  -- Add/modify columns 
alter table LOAN_BUSI add numex7 NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numex7
  is '���8';
alter table LOAN_BUSI add numex8 NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numex8
  is '���9';
alter table LOAN_BUSI add numex9 NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numex9
  is '���10';
alter table LOAN_BUSI add numexa NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numexa
  is '���11';
alter table LOAN_BUSI add numexb NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numexb
  is '���12';
alter table LOAN_BUSI add numexc NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numexc
  is '���13';
alter table LOAN_BUSI add numexd NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numexd
  is '���14';
alter table LOAN_BUSI add numexe NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numexe
  is '���15';
alter table LOAN_BUSI add numexf NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numexf
  is '���16';
alter table LOAN_BUSI add numexg NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numexg
  is '���17';
alter table LOAN_BUSI add numexh NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numexh
  is '���18';
alter table LOAN_BUSI add numexi NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numexi
  is '���19';
alter table LOAN_BUSI add numexj NUMBER(18,2) default 0;
-- Add comments to the columns 
comment on column LOAN_BUSI.numexj
  is '���20';
  
alter table LOAN_BUSI add chrex0 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrex0
  is '�ַ���1';
alter table LOAN_BUSI add chrex1 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrex1
  is '�ַ���2';
alter table LOAN_BUSI add chrex2 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrex2
  is '�ַ���3';
alter table LOAN_BUSI add chrex3 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrex3
  is '�ַ���4';
alter table LOAN_BUSI add chrex4 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrex4
  is '�ַ���5';
alter table LOAN_BUSI add chrex5 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrex5
  is '�ַ���6';
alter table LOAN_BUSI add chrex6 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrex6
  is '�ַ���7';
alter table LOAN_BUSI add chrex7 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrex7
  is '�ַ���8';
alter table LOAN_BUSI add chrex8 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrex8
  is '�ַ���9';
alter table LOAN_BUSI add chrex9 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrex9
  is '�ַ���10';
alter table LOAN_BUSI add chrexa varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrexa
  is '�ַ���11';
alter table LOAN_BUSI add chrexb varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrexb
  is '�ַ���12';
alter table LOAN_BUSI add chrexc varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrexc
  is '�ַ���13';
alter table LOAN_BUSI add chrexd varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrexd
  is '�ַ���14';
alter table LOAN_BUSI add chrexe varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrexe
  is '�ַ���15';
alter table LOAN_BUSI add chrexf varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrexf
  is '�ַ���16';
alter table LOAN_BUSI add chrexg varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrexg
  is '�ַ���17';
alter table LOAN_BUSI add chrexh varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrexh
  is '�ַ���18';
alter table LOAN_BUSI add chrexi varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrexi
  is '�ַ���19';
alter table LOAN_BUSI add chrexj varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.chrexj
  is '�ַ���20';
  
alter table LOAN_BUSI add datex0 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.datex0
  is '����1';
  alter table LOAN_BUSI add datex1 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.datex1
  is '����2';
alter table LOAN_BUSI add datex2 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.datex2
  is '����3';
alter table LOAN_BUSI add datex3 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.datex3
  is '����4';
alter table LOAN_BUSI add datex4 varchar2(30);
-- Add comments to the columns 
comment on column LOAN_BUSI.datex4
  is '����5';
	
	
-- Add comments to the columns 
comment on column LOAN_BUSI.loanp8
  is '��Ʒ����8';
comment on column LOAN_BUSI.loanp9
  is '��Ʒ����9';
comment on column LOAN_BUSI.loanpa
  is '��Ʒ����10';
comment on column LOAN_BUSI.bathid
  is '���κ�';


-- Add/modify columns 
alter table SYS_IOMP add iomptp char(1) default 1 not null;
-- Add comments to the columns 
comment on column SYS_IOMP.iomptp
  is '1������ӳ�� 2������ӳ��';
-- Add/modify columns 
alter table SYS_IOMP modify ruleid VARCHAR2(50);

alter table SYS_IOMP add trancd VARCHAR2(20);
-- Add comments to the columns 
comment on column SYS_IOMP.trancd
  is '�ӽ��״���';
  
 -- Add/modify columns 
alter table COM_ITEX add ordeid number(3);
-- Add comments to the columns 
comment on column COM_ITEX.ordeid
  is '���';
 
alter table com_itex add desctx VARCHAR2(20) ;
comment on column com_itex.desctx is '����˵��';


DELETE FROM  pcmc_knp_para where subscd='GL' and paratp = 'GL_OPRCOD';

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'GL_OPRCOD', '%', 'DEFAULT', '�߼���������', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'GL_OPRCOD', 'AND', 'DEFAULT', '����', null, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'GL_OPRCOD', 'OR', 'DEFAULT', '����', null, null, null, null, null, null, null, null, null, null, null);

commit;
-- Add/modify columns 
alter table SYS_COND_DETL modify oprcod null;


-- Add/modify columns 
alter table SYS_TRTL add taxsep CHAR(1) default '0';
-- Add comments to the columns 
comment on column SYS_TRTL.taxsep
  is '�Ƿ��˰����';
  
  
 update pcmc_menu
   set menuname = '������ˮ��ѯ' where menuname = 'ͨ�ý���';
   
 commit;
 
 -- Add/modify columns 
alter table SYS_PRTP_DETL add smrytx VARCHAR2(255) ;
-- Add comments to the columns 
comment on column SYS_PRTP_DETL.smrytx
  is '����˵��';
comment on column SYS_PRTP_DETL.desctx
  is '��������';

  
  --���ӹ���������ֵ
insert into sys_pftp (PROFTP, PFTPNA, PROCCD, DESCTX, ENNAME, VERMOD, MODULE, PROJCD)
values ('get_NumberAbs', 'ȡ����ֵ', 'getNumbreAbs', null, null, 0, 'CM', '.');

insert into sys_prof (PROFTP, PROFID, PROFNA, EFCTDT, INEFDT, DESCTX, ENNAME, VERMOD, MODULE, PROJCD)
values ('get_NumberAbs', 'T001', 'ȡ����ֵ', '20100101', '20991001', null, null, 0, 'CM', '.');

commit;

-- Add/modify columns 
alter table SYS_DTIT add module VARCHAR2(20)  null;
-- Add comments to the columns 
comment on column SYS_DTIT.module
  is 'ģ��';
  
  -- Add/modify columns 
alter table LOAN_BUSI modify trantp default 'TR' null;

update pcmc_menu a set a.menuname = '������Ͷ���' where a.menuname = '������Ͷ���';

commit;
