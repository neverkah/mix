--��������֧�ּ�Ⱥ������

-- Create table
create table SYS_AYNC_NODE
(
  aynccd VARCHAR2(10) not null,
  nodeid VARCHAR2(10) not null,
  stacid NUMBER(19) not null,
  trandt CHAR(8) not null,
  sourst VARCHAR2(4) not null,
  brchcd VARCHAR2(20) not null,
  pitncd VARCHAR2(4) not null,
  regiti VARCHAR2(25) not null
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table SYS_AYNC_NODE
  add constraint PK_SYS_AYNC_NODE primary key (AYNCCD, STACID, TRANDT, SOURST, BRCHCD, PITNCD);

 drop  table SYS_ACCT_OPEN;
  -- Create table
 create table SYS_ACCT_OPEN
(
  stacid NUMBER(9) not null,
  systid VARCHAR2(4) not null,
  brchcd VARCHAR2(20) not null,
  crcycd CHAR(3) not null,
  itemcd VARCHAR2(20) not null,
  aorder INTEGER default 1
);
comment on column SYS_ACCT_OPEN.stacid
  is '���ױ�ʶ';
comment on column SYS_ACCT_OPEN.systid
  is '����';
comment on column SYS_ACCT_OPEN.brchcd
  is '��֯����';
comment on column SYS_ACCT_OPEN.crcycd
  is 'Դϵͳ����';
comment on column SYS_ACCT_OPEN.itemcd
  is '���˿�Ŀ';
--��ʼ����SYS_ACCT_OPEN����
   insert into sys_acct_open(stacid,systid,brchcd,itemcd,crcycd,aorder)
    select stacid,systid,brchno,itemcd,crcycd,max(AORDER) from (    
     select stacid,systid,brchno,rpad(itemcd,6,'0') as itemcd,crcycd,To_Number(Substr(Acctno,-5,5)) as AORDER from gla_acct
     ) group by stacid,systid,brchno,itemcd,crcycd;
     
 commit;