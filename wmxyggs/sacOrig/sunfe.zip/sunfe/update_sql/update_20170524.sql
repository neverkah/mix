--�������ɣ�ϵͳ��Ʒ���� ����
alter table SYS_COND
  drop constraint PK_SYS_COND cascade;
drop index PK_SYS_COND ;	
alter table SYS_COND
  add constraint PK_SYS_COND primary key (CONDCD, PROJCD,VERMOD)
  using index ;
	
alter table SYS_COND_DETL
  drop constraint PK_SYS_COND_DETL cascade;
drop index PK_SYS_COND_DETL ;	
alter table SYS_COND_DETL
  add constraint PK_SYS_COND_DETL primary key (CONDCD, SORTNO, PROJCD,VERMOD)
  using index ;