insert into fmp_item_config (STACID, BRCHTP, FUNDTP, ITEMCD)
values (1, '2', 'C06', '30010105');

insert into fmp_item_config (STACID, BRCHTP, FUNDTP, ITEMCD)
values (1, '1', 'C06', '30010708');

insert into fmp_item_config (STACID, BRCHTP, FUNDTP, ITEMCD)
values (1, '2', 'C05', '30010106');

insert into fmp_item_config (STACID, BRCHTP, FUNDTP, ITEMCD)
values (1, '1', 'C05', '30010709');


delete pcmc_knp_para  t where t.subscd = 'fe' and t.paratp ='fundtp';
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'fundtp', '%', 'DEFAULT', '�ʽ�����', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'fundtp', 'C01', 'DEFAULT', '��ű�����', null, null, null, null, null, null, null, 1, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'fundtp', 'C02', 'DEFAULT', '�ϴ汸����', null, null, null, null, null, null, null, 2, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'fundtp', 'C03', 'DEFAULT', '�ϴ�׼����', null, null, null, null, null, null, null, 3, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'fundtp', 'C05', 'DEFAULT', '��Ŷ���', null, null, null, null, null, null, null, 5, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'fundtp', 'C06', 'DEFAULT', '�ϴ涨��', null, null, null, null, null, null, null, 6, null, null, null);
commit;