--�޸����ݱ����������ֶ�
alter table vch_busi add stacid number(19) default 1;
comment on column vch_busi.stacid is '���ױ�ʶ';
  alter table gpv_busi add stacid number(19) default 1;
  comment on column gpv_busi.stacid is '���ױ�ʶ';
   alter table dep_busi add stacid number(19) default 1;
   comment on column dep_busi.stacid is '���ױ�ʶ';
    alter table csa_busi add stacid number(19) default 1;
    comment on column csa_busi.stacid is '���ױ�ʶ';
     alter table cmb_busi add stacid number(19) default 1;
     comment on column cmb_busi.stacid is '���ױ�ʶ';
      alter table bbk_busi add stacid number(19) default 1;
      comment on column bbk_busi.stacid is '���ױ�ʶ';
       alter table asb_busi add stacid number(19) default 1;
       comment on column asb_busi.stacid is '���ױ�ʶ';
        alter table afe_busi add stacid number(19) default 1;
        comment on column afe_busi.stacid is '���ױ�ʶ';

--�����ֵ� ģ�������״̬��������
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_MODULE', 'DC', 'DEFAULT', '�����Ϣ', null, null, null, null, null, null, null, 14, null, null);

commit;

--���²˵�
insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (498, 'DEFAULT', 23, null, 1, '���ݽӿ�', null, null, '0', null, 5, '0', '.498.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (499, 'DEFAULT', 23, 498, 2, '�����', null, '/sunfe/busidata/loanBusi.jsp', '0', null, 1, '1', '.498.499.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (500, 'DEFAULT', 23, 498, 2, 'ƾ֤����', null, '/sunfe/busidata/vchBusi.jsp', '0', null, 2, '1', '.498.500.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (501, 'DEFAULT', 23, 498, 2, 'Ͷ��ҵ��', null, '/sunfe/busidata/ivtBusi.jsp', '0', null, 3, '1', '.498.501.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (502, 'DEFAULT', 23, 498, 2, '�ڲ��ʻ�', null, '/sunfe/busidata/gpvBusi.jsp', '0', null, 4, '1', '.498.502.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (503, 'DEFAULT', 23, 498, 2, '�����ҵ��', null, '/sunfe/busidata/depBusi.jsp', '0', null, 5, '1', '.498.503.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (504, 'DEFAULT', 23, 498, 2, '�ֽ����ҵ��', null, '/sunfe/busidata/csaBusi.jsp', '0', null, 6, '1', '.498.504.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (505, 'DEFAULT', 23, 498, 2, 'ͨ��ҵ��', null, '/sunfe/busidata/cmbBusi.jsp', '0', null, 7, '1', '.498.505.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (506, 'DEFAULT', 23, 498, 2, '�ع�ҵ��', null, '/sunfe/busidata/bbkBusi.jsp', '0', null, 8, '1', '.498.506.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (507, 'DEFAULT', 23, 498, 2, '�ʲ�ҵ��', null, '/sunfe/busidata/asbBusi.jsp', '0', null, 9, '1', '.498.507.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (508, 'DEFAULT', 23, 498, 2, 'Ӧ��Ӧ������ҵ��', null, '/sunfe/busidata/afeBusi.jsp', '0', null, 10, '1', '.498.508.');

--ƾ֤��ӡ�˵�

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (509, 'DEFAULT', 23, null, 1, '���ݴ�ӡ', null, null, '0', null, 6, '0', '.509.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (510, 'DEFAULT', 23, 509, 2, '����ƾ֤��ӡ', null, '/sungl/reporter/printVchrData.jsp', '0', null, 1, '1', '.509.510.');

commit;

--�˲������˵�

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (536, 'DEFAULT', 23, 477, 2, '�˲�����', null, null, '0', null, 2, '0', '.477.536.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (537, 'DEFAULT', 23, 536, 3, '�����ѯ', null, '/sungl/books/glaVchr.jsp', '0', null, 1, '1', '.477.536.537.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (538, 'DEFAULT', 23, 536, 3, '���˲�ѯ', null, '/sungl/books/glaGlis.jsp', '0', null, 2, '1', '.477.536.538.');

--�������������ֵ�

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_GELDTP', '%', 'DEFAULT', '��������', 1, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_GELDTP', 'D', 'DEFAULT', '������', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_GELDTP', 'H', 'DEFAULT', '��������', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_GELDTP', 'M', 'DEFAULT', '������', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_GELDTP', 'Q', 'DEFAULT', '������', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_GELDTP', 'Y', 'DEFAULT', '������', null, null, null, null, null, null, null, null, null, null);

commit;
