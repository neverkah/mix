delete pcmc_knp_para t where    t.paratp = 'aebscd' and t.subscd = 'fe';
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '%', 'DEFAULT', '�������', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '1A', 'DEFAULT', '�ϴ�', null, null, null, null, null, null, null, 1, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '1B', 'DEFAULT', '�ϴ�֧ȡ', null, null, null, null, null, null, null, 2, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '1D', 'DEFAULT', '�ϴ��Ϣ', null, null, null, null, null, null, null, 3, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '2A', 'DEFAULT', '�½�', null, null, null, null, null, null, null, 4, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '2B', 'DEFAULT', '�½�黹', null, null, null, null, null, null, null, 5, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebscd', '2D', 'DEFAULT', '�½��Ϣ', null, null, null, null, null, null, null, 6, null, null, null);
commit;

delete pcmc_knp_para t where    t.paratp = 'aebslv' and t.subscd = 'fe';
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebslv', '%', 'DEFAULT', '�ϴ��½�㼶', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebslv', '21', 'DEFAULT', '����', null, null, null, null, null, null, null, 2, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'aebslv', '31', 'DEFAULT', '֧��', null, null, null, null, null, null, null, 1, null, null, null);

 delete COM_SQDF where SQNOCD = 'aplysq';
insert into COM_SQDF (SQNOCD, SQNONA, SQNOLT, INITNO, MAXINO, RPTMTP, SQNORG, PRFXTP, SQNOTP, ISLKAC)
values ('aplysq', '������ˮ', 5, 1, 99999, 'Y', '1', '0', 'S', '1');
commit;