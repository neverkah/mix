insert into PCMC_MENU (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (572, 'DEFAULT', 23, null, 1, '���ݹ���ƽ̨', null, null, '0', null, 997, '0', '.572.');

insert into PCMC_MENU (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (573, 'DEFAULT', 23, 572, 2, '�����ļ�����', null, '/sunfe/sfdatamanager/dataBatchsManager.jsp', '0', null, 1, '1', '.572.573.');

insert into PCMC_MENU (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (574, 'DEFAULT', 23, 572, 2, '���Ĵ������', null, '/sunfe/sfdatamanager/msManager.jsp', '0', null, 2, '1', '.572.574.');
commit;