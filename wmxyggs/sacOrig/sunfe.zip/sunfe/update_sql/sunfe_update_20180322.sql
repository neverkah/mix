--����ͼ�������ֶ�

alter table CLP_CONF drop constraint pk_clp_conf;
 
alter table CLP_CONF modify CLERBR varchar2(20) null;

alter table CLP_CONF add CRCYCD varchar2(100);

comment on column CLP_CONF.crcycd
  is '���ִ���';
  
update CLP_CONF set crcycd='CNY';

alter table CLP_CONF modify CRCYCD not null;

alter table CLP_CONF add constraint pk_clp_conf primary key(STACID, BRCHCD, CRCYCD);

--���������ֵ�-����㼶
delete from PCMC_KNP_PARA where SUBSCD='COMM' and PARATP='clerty' and PARACD='CL30';

insert into PCMC_KNP_PARA (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'clerty', 'CL30', 'DEFAULT', '�㼶����', null, null, null, null, null, null, null, 8, null, null, null);

delete from PCMC_KNP_PARA where SUBSCD='COMM' and PARATP='clerty' and PARACD='CL40';

insert into PCMC_KNP_PARA (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'clerty', 'CL40', 'DEFAULT', 'һ������', null, null, null, null, null, null, null, 9, null, null, null);


commit;
