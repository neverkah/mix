--�޸�sys_dtit_conf��Ʒ�����ֶγ�����sys_prtp ���������ʹ���һ��
alter table  sys_dtit_conf  modify(p1tpkd varchar2(30));
alter table  sys_dtit_conf  modify(p2tpkd varchar2(30));
alter table  sys_dtit_conf  modify(p3tpkd varchar2(30));
alter table  sys_dtit_conf  modify(p4tpkd varchar2(30));
alter table  sys_dtit_conf  modify(p5tpkd varchar2(30));
alter table  sys_dtit_conf  modify(p6tpkd varchar2(30));
alter table  sys_dtit_conf  modify(p7tpkd varchar2(30));
alter table  sys_dtit_conf  modify(p8tpkd varchar2(30));
alter table  sys_dtit_conf  modify(p9tpkd varchar2(30));
alter table  sys_dtit_conf  modify(patpkd varchar2(30));