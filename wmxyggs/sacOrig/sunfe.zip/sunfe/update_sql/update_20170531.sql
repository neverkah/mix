alter table  SYS_DTIT modify (trprcd varchar2(10));

commit;