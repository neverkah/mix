drop table loan_busi_h;
create table loan_busi_h as select * from loan_busi where 1=2;
