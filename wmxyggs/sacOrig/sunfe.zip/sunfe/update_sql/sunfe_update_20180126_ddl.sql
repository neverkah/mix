create or replace view v_fmp_item_config as
select stacid,'C01' "FUNDTP",aebslv, lowrcr "ITEMCD" from fmp_cntr_aebs t where aebscd = '1A' union
select stacid,'C02' "FUNDTP",aebslv, upprdr "ITEMCD" from fmp_cntr_aebs t where aebscd = '1A' union
select stacid,'C01' "FUNDTP",aebslv, lowrdr "ITEMCD" from fmp_cntr_aebs t where aebscd = '2A' union
select stacid,'C02' "FUNDTP",aebslv, upprcr "ITEMCD" from fmp_cntr_aebs t where aebscd = '2A' union
select stacid,'C05' "FUNDTP",aebslv, lowrdr "ITEMCD" from fmp_cntr_aebs t where aebscd = '1A' union
select stacid,'C06' "FUNDTP",aebslv, upprcr "ITEMCD" from fmp_cntr_aebs t where aebscd = '1A' order by
stacid,fundtp,aebslv;
comment on table V_FMP_ITEM_CONFIG is '�ڲ��ʽ��Ŀ����';
comment on column V_FMP_ITEM_CONFIG.STACID is '���ױ���';
comment on column V_FMP_ITEM_CONFIG.FUNDTP is '�ʽ����ͣ�C01��ű����� C02�ϴ汸���� C05��Ŷ��� C06�ϴ涨�ڣ�';
comment on column V_FMP_ITEM_CONFIG.AEBSLV is '�����㼶';
comment on column V_FMP_ITEM_CONFIG.ITEMCD is '��Ŀ';