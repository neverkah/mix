-------liujianan
-----20170615����
--�����ת�˵�����
insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (541, 'DEFAULT', 1, 480, 3, '�����ת����', null, '/sungl/common/pfpconf/pfpConf.jsp', '0', null, 7, '1', '.479.480.541.');
--�����ת�������������ֵ�
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'TOTYPE', '%', 'DEFAULT', '�����ת��������', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'TOTYPE', '0', 'DEFAULT', '�����ϻ�', null, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'TOTYPE', '1', 'DEFAULT', '�����ת', null, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'TOTYPE', '2', 'DEFAULT', '��������תΪδ��������', null, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'TOTYPE', 'A', 'DEFAULT', '�����ϻ���ת', null, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'TOTYPE', 'B', 'DEFAULT', '���������ϻ�', null, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('GL', 'TOTYPE', 'C', 'DEFAULT', 'δ���������ϻ�', null, null, null, null, null, null, null, null, null, null, null);

ALTER TABLE  SYS_PRIV_ENTITY ADD DB_COLUMN_TITLE VARCHAR2(255) DEFAULT NULL;
COMMENT ON COLUMN SYS_PRIV_ENTITY.DB_COLUMN_TITLE IS '����ʵ�����';

commit;