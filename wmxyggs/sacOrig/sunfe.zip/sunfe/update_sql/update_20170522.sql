-- Create/Recreate primary, unique and foreign key constraints ���̶���
alter table SYS_BEAN
  drop constraint PK_SYS_BEAN cascade;
drop index PK_SYS_BEAN ;	
alter table SYS_BEAN
  add constraint PK_SYS_BEAN primary key (BEANID, PROJCD, VERMOD)
  using index ;
  

 -- Create/Recreate primary, unique and foreign key constraints  ������
alter table SYS_PRCS
  drop constraint PK_SYS_PRCS cascade;
drop index PK_SYS_PRCS ;	
alter table SYS_PRCS
  add constraint PK_SYS_PRCS primary key (PRCSCD, PROJCD, VERMOD)
  using index ;
  
  
  
alter table SYS_TRCD
  drop constraint PK_SYS_TRCD cascade;
drop index PK_SYS_TRCD ;	
alter table SYS_TRCD
  add constraint PK_SYS_TRCD primary key (TRANCD, PROJCD, VERMOD)
  using index ;
  
   --�ӿ� 
alter table SYS_INTF
  drop constraint PK_SYS_INTF ;	
drop index PK_SYS_INTF ;	
alter table SYS_INTF
  add constraint PK_SYS_INTF primary key (INTFCD, PROJCD, VERMOD)
  using index ;

alter table SYS_INTF_DETL
  drop constraint PK_SYS_INTF_DETL cascade;
drop index PK_SYS_INTF_DETL ;	
alter table SYS_INTF_DETL
  add constraint PK_SYS_INTF_DETL primary key (INTFCD, INOTTG, FILDLV, FILDCD, PROJCD, VERMOD)
  using index ;

  
 --ҵ����� 
alter table SYS_PROF
  drop constraint PK_SYS_PROF cascade;
drop index PK_SYS_PROF ;
alter table SYS_PROF
  add constraint PK_SYS_PROF primary key (PROFTP, PROJCD, PROFID, VERMOD);
  
alter table SYS_PFTP
  drop constraint PK_SYS_PFTP cascade;
drop index PK_SYS_PFTP ;
alter table SYS_PFTP
  add constraint PK_SYS_PFTP primary key (PROFTP, PROJCD,VERMOD)
  using index ;
  
  --��Ʒ
alter table SYS_PROD
  drop constraint PK_SYS_PROD cascade;	
drop index PK_SYS_PROD ;
alter table SYS_PROD
  add constraint PK_SYS_PROD primary key (PRODCD, PROJCD, VERMOD)
  using index ;
  
   
 --ģ������ 
alter table SYS_TMTP
  drop constraint PK_SYS_TMTP cascade;
alter table SYS_TMTP
  add constraint PK_SYS_TMTP primary key (TMPLTP, PROJCD, VERMOD)
  using index ;
 
alter table SYS_TMPL
  drop constraint PK_SYS_TMPL cascade;
drop index PK_SYS_TMPL ;
alter table SYS_TMPL
  add constraint PK_SYS_TMPL primary key (TMPLTP,TMPLID, PROJCD, VERMOD)
  using index ;
  
  --ҵ��ģ�����
alter table SYS_TMAP
  drop constraint PK_SYS_TMAP cascade;
drop index PK_SYS_TMAP ;	
alter table SYS_TMAP
  add constraint PK_SYS_TMAP primary key (TMPLTP, TMPLID, SORTNO, PROJCD, VERMOD)
  using index ;
  
  --����������
alter table SYS_PRTP
  drop constraint PK_SYS_PRTP cascade;
drop index PK_SYS_PRTP ;	
alter table SYS_PRTP
  add constraint PK_SYS_PRTP primary key (PRGPTP,PROJCD,VERMOD)
  using index ;
	
alter table SYS_PRTP_DETL
  drop constraint PK_SYS_PRTP_DETL cascade;
drop index PK_SYS_PRTP_DETL ;	
alter table SYS_PRTP_DETL
  add constraint PK_SYS_PRTP_DETL primary key (PRGPTP,PROPCD,PROJCD,VERMOD)
  
--�������ӽ���  
alter table SYS_TMAP_TRAN
  drop constraint PK_SYS_TMAP_TRAN cascade;
drop index PK_SYS_TMAP_TRAN ;	
alter table SYS_TMAP_TRAN
  add constraint PK_SYS_TMAP_TRAN primary key (PRCSCD, DTTRCD, TRTLNO, SORTNO, PROJCD,VERMOD)
  using index ;
	
alter table SYS_TRTL
  drop constraint PK_SYS_TRTL cascade;
drop index PK_SYS_TRTL ;	
alter table SYS_TRTL
  add constraint PK_SYS_TRTL primary key (PRCSCD, SORTNO, PROJCD,VERMOD)
  using index ;
  using index ;

  
  
  --��Ʒ�ӽ���ģ��	
alter table SYS_PMAP
  drop constraint PK_SYS_PMAP cascade;
drop index PK_SYS_PMAP ;	
alter table SYS_PMAP
  add constraint PK_SYS_PMAP primary key (PRODCD, TRANCD, CORRTG, TMPLTP, TMPLID,PROJCD,VERMOD)
  using index ;