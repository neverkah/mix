delete com_edct t where t.edcttp = 'sfe';
commit;