insert into sys_pub_para (PARA_CODE, PARA_NAME, VALUE_TYPE, PARA_VALUE, REMARK, PARA_TYPE, INPUT_TYPE, INPUT_CHECK, SELECT_DICTTYPE, SORTNO, I18N_CODE)
values ('homepath', 'imps�����ļ�·��', 'N', 'E:/kjyq/imps/web/WEB-INF/sunline/', null, null, null, null, null, null, null);
commit;

alter table gli_vchr add  bathid varchar2(64);