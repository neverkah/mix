drop table sys_trcr;
-- Create table
create table SYS_TRCR
(
  stacid NUMBER(19) not null,
  sourst VARCHAR2(4) not null,
  module VARCHAR2(20) not null,
  lstrpr VARCHAR2(20) not null,
  trprcd VARCHAR2(10) not null 
);
-- Add comments to the columns 
comment on column SYS_TRCR.module
  is 'ģ��';
comment on column SYS_TRCR.lstrpr
  is 'ҵ��ϵͳ�������';
comment on column SYS_TRCR.trprcd
  is '��������������';
comment on column SYS_TRCR.stacid
  is '���ױ�ʶ';
comment on column SYS_TRCR.sourst
  is 'ҵ��ϵͳ��ʶ';
alter table SYS_TRCR
  add constraint PK_SYS_TRCR primary key (MODULE, LSTRPR, STACID, SOURST) using index ;
  
  
insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (566, 'DEFAULT', 23, 120, 3, '�������ӳ��', null, '/sunfe/base/trcr/trcr_main.jsp', '1', null, 12, '1', '.120.566.');

commit;
