--
insert into sys_acct_conf (STACID, DBSOUR, TYPECO, TRPRCD, CRCYCO, BRCHCO, VALUCO, SMRYTX, SQLSTR, USEDTP)
values (2021, 'glb_dept_book', 'dptype', 'trprcd', 'crcycd', 'brchcd', 'captal', '����˻���', '               select stacid,systid,acctdt, brchcd as brchcd,itemcd,''*'',crcycd,abs(sum(case loanpa when ''0'' then captal when ''1'' then 0-captal else captal end)) as balanc from glb_dept_book where stacid = #stacid and acctdt = ''#acctdt'' group by stacid,systid,brchcd,itemcd,crcycd,acctdt', '1');

update pcmc_knp_para t set t.paracd = 'C03' where t.PARATP = 'inrt_inrttp' and t.SUBSCD = 'fe' and t.paracd = 'C02';
update pcmc_knp_para t set t.paracd = 'C02' where t.PARATP = 'inrt_inrttp' and t.SUBSCD = 'fe' and t.paracd = 'C01';

commit;