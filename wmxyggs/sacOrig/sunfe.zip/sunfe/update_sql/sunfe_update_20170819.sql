insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('data', 'status', '%', 'DEFAULT', '���ݹ���ƽ̨״̬', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('data', 'status', '0', 'DEFAULT', 'δ��ʼ', null, null, null, null, null, null, null, 0, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('data', 'status', '1', 'DEFAULT', '�ɹ�', null, null, null, null, null, null, null, 1, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('data', 'status', '2', 'DEFAULT', 'ʧ��', null, null, null, null, null, null, null, 2, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('data', 'status', '3', 'DEFAULT', '������', null, null, null, null, null, null, null, 3, null, null, null);
commit;
