﻿------增加菜单
insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (557, 'DEFAULT', 23, null, 1, '接口管理', null, null, '0', null, 4, '0', '.557.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (561, 'DEFAULT', 23, 557, 2, '交易方向映射', null, '/sunfe/intermanag/comtdcr/comtdcr_list.jsp', '0', null, 1, '1', '.557.561.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (562, 'DEFAULT', 23, 557, 2, '科目映射', null, '/sunfe/intermanag/comitcr/comitcr_list.jsp', '0', null, 2, '1', '.557.562.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (563, 'DEFAULT', 23, 557, 2, '机构映射', null, '/sunfe/intermanag/combrcr/combrcr_list.jsp', '0', null, 3, '1', '.557.563.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (564, 'DEFAULT', 23, 557, 2, '币种映射', null, '/sunfe/intermanag/comcrcr/comcrcr_list.jsp', '0', null, 4, '1', '.557.564.');


commit;
