--�˻��Ͳ�Ʒ��ͼ
-- Create view
create or replace view v_com_acct as
select distinct a.stacid,a.acctno,a.acctna,'000000' as sprrcd,'1' as detltg
from com_acct a
union all
select c.stacid,'*' as prodcd,'����' prodna, '000000'  as sprrcd,'1' as detltg from dual b,com_stac c
union all
select e.stacid,'000000' as prodcd,'����' prodna, ''  as sprrcd,'0' as detltg from dual d,com_stac e;

create or replace view v_sys_prod as
select distinct b.stacid as stacid,a.prodcd,a.prodna,'000000' as sprrcd,'1' as detltg
from sys_prod a,com_stac b where a.vermod ='0'
union all
select c.stacid as stacid,'*' as prodcd,'����' prodna, '000000'  as sprrcd,'1' as detltg from dual,com_stac c
union all
select d.stacid as stacid,'000000' as prodcd,'����' prodna, ''  as sprrcd,'0' as detltg from dual,com_stac d;