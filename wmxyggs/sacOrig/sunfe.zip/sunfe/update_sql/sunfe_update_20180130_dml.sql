DELETE FROM PCMC_KNP_PARA WHERE SUBSCD='fe' AND PARATP='inrt_status';
insert into PCMC_KNP_PARA (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'inrt_status', '%', 'DEFAULT', '����״̬', 1, null, null, null, null, null, null, null, null, null, null);

insert into PCMC_KNP_PARA (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'inrt_status', '1', 'DEFAULT', '��Ч', null, null, null, null, null, null, null, null, null, null, null);

insert into PCMC_KNP_PARA (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('fe', 'inrt_status', '0', 'DEFAULT', '����', null, null, null, null, null, null, null, null, null, null, null);

commit;
