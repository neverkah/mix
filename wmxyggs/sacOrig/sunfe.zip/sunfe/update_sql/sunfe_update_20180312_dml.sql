delete from pcmc_knp_para t where t.subscd = 'sungl' and t.paratp = 'fileType';

insert into PCMC_KNP_PARA (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('sungl', 'fileType', '%', 'DEFAULT', '�����ļ�����', 1, null, '', '', '', '', '', null, '', '', '');

insert into PCMC_KNP_PARA (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('sungl', 'fileType', 'pdf', 'DEFAULT', 'PDF', null, null, '', '', '', '', '', null, '', '', '');

insert into PCMC_KNP_PARA (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('sungl', 'fileType', 'xls', 'DEFAULT', 'EXCEL', null, null, '', '', '', '', '', null, '', '', '');

commit;