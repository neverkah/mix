
--sys_tmap_tran���������ֶ�
ALTER TABLE sys_tmap_tran add stacid NUMBER(9);
comment on column SYS_TMAP_TRAN.stacid
  is '����';
update sys_tmap_tran set stacid = 1;
ALTER TABLE sys_tmap_tran modify stacid not null;
ALTER TABLE sys_tmap_tran DROP CONSTRAINT PK_SYS_TMAP_TRAN;
ALTER TABLE sys_tmap_tran ADD (CONSTRAINT PK_SYS_TMAP_TRAN PRIMARY KEY(STACID, PRCSCD, DTTRCD, TRTLNO, SORTNO, PROJCD,VERMOD));


--sys_pmap���������ֶ�
ALTER TABLE sys_pmap add stacid NUMBER(9);
update sys_pmap set stacid = 1;
ALTER TABLE sys_pmap modify stacid not null;
ALTER TABLE sys_pmap DROP CONSTRAINT PK_SYS_PMAP;
ALTER TABLE sys_pmap ADD (CONSTRAINT PK_SYS_PMAP PRIMARY KEY(STACID, PRODCD, TRANCD, CORRTG, TMPLTP, TMPLID, PROJCD,VERMOD));

--sys_trtl���������ֶ�
ALTER TABLE sys_trtl add stacid NUMBER(9);
update sys_trtl set stacid = 1;
ALTER TABLE sys_trtl modify stacid not null;
ALTER TABLE sys_trtl DROP CONSTRAINT PK_SYS_TRTL;
ALTER TABLE sys_trtl ADD (CONSTRAINT PK_SYS_TRTL PRIMARY KEY(STACID, PRCSCD, SORTNO, PROJCD,VERMOD));


--gla_vchr
ALTER TABLE gla_vchr add sourac NUMBER(9);
comment on column gla_vchr.sourac
  is 'Դ����';
update gla_vchr set sourac = 1;
ALTER TABLE gla_vchr modify sourac not null;
ALTER TABLE gla_vchr DROP CONSTRAINT UNI_GLA_VCHR;
alter table GLA_VCHR
  add constraint UNI_GLA_VCHR unique (stacid,sourac, SOURDT, SOURSQ, SOURST, SRVCSQ);


--gla_vchr_h
ALTER TABLE gla_vchr_h add sourac NUMBER(9);
comment on column gla_vchr_h.sourac
  is 'Դ����';
update gla_vchr_h set sourac = 1;
ALTER TABLE gla_vchr_h modify sourac not null;
