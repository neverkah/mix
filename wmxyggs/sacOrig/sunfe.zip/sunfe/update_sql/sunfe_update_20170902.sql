delete from pcmc_menu where menuid in ('517','518','523','524','557','561','562','563','564','586');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (587, 'DEFAULT', 1, 511, 2, '�����˻�', null, null, '0', null, 3, '0', '.511.587.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (588, 'DEFAULT', 1, 587, 3, '���˿���', null, '/sungl/bigledger/glaacct/glaacct_open.jsp', '0', null, 1, '1', '.511.587.588.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (589, 'DEFAULT', 1, 587, 3, '�˻����ά����ѯ', null, '/sungl/bigledger/glaacct/glaacct_updt.jsp', '0', null, 2, '1', '.511.587.589.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (590, 'DEFAULT', 1, 587, 3, '�����˻���ѯ', null, '/sungl/bigledger/glaacct/glaacct.jsp', '0', null, 3, '1', '.511.587.590.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (591, 'DEFAULT', 1, 587, 3, '�ֹ��˻��ر�', null, '/sungl/bigledger/glaacct/glaacctClose.jsp', '0', null, 4, '1', '.511.587.591.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (592, 'DEFAULT', 1, 479, 2, '�ӿڹ���', null, null, '0', null, 6, '0', '.479.592.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (593, 'DEFAULT', 1, 592, 3, '���׷���ӳ��', null, '/sunfe/intermanag/comtdcr/comtdcr_list.jsp', '0', null, 1, '1', '.479.592.593.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (594, 'DEFAULT', 1, 592, 3, '��Ŀӳ��', null, '/sunfe/intermanag/comitcr/comitcr_list.jsp', '0', null, 2, '1', '.479.592.594.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (595, 'DEFAULT', 1, 592, 3, '����ӳ��', null, '/sunfe/intermanag/combrcr/combrcr_list.jsp', '0', null, 3, '1', '.479.592.595.');

insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (596, 'DEFAULT', 1, 592, 3, '����ӳ��', null, '/sunfe/intermanag/comcrcr/comcrcr_list.jsp', '0', null, 4, '1', '.479.592.596.');

update seq_block t set t.idx = '597' where t.name = 'pcmc_menu';

commit;

alter table sys_vchr_eror add stacid  NUMBER(19);
