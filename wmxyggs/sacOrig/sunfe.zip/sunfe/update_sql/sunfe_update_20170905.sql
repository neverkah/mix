--���˵Ǽǲ���������
-- Create table
-- Create table
drop table GLA_CHK_Book cascade constraints;
create table GLA_CHK_Book
(
  STACID NUMBER(10) not null,
  ACCTDT CHAR(8) not null,
  BRCHCD VARCHAR2(20) not null,
  ITEMCD VARCHAR2(20) not null,
  hgitem VARCHAR2(20) not null,
  SYSTID VARCHAR2(4) not null,
  CRCYCD VARCHAR2(3) not null,
  amntcd VARCHAR2(9) not null,
  tranam NUMBER(19,2) default 0 not null,
  dealam NUMBER(19,2) default 0 not null, 
  STATUS CHAR(1) default '0'
);
-- Add comments to the table 
comment on table GLA_CHK_Book
  is '���˽��Ǽǲ�';
-- Add comments to the columns 
comment on column GLA_CHK_Book.STACID
  is '���ױ�ʶ';
comment on column GLA_CHK_Book.ACCTDT
  is '����ʱ��';
comment on column GLA_CHK_Book.BRCHCD
  is '��������';
comment on column GLA_CHK_Book.ITEMCD
  is '���˿�Ŀ';
comment on column GLA_CHK_Book.hgitem
  is '���˿�Ŀ';  
comment on column GLA_CHK_Book.SYSTID
  is 'ϵͳά��';
comment on column GLA_CHK_Book.CRCYCD
  is '����';
comment on column GLA_CHK_Book.amntcd
  is '���˽���';  
comment on column GLA_CHK_Book.tranam
  is '���˽��';
comment on column GLA_CHK_Book.dealam
  is '�Ѵ������';
comment on column GLA_CHK_Book.STATUS
  is '����״̬��0��δ������1���Ѵ�����2 ���ִ�����';
-- Create/Recreate primary, unique and foreign key constraints 
alter table GLA_CHK_Book
  add constraint PK_GLA_CHK_Book primary key (STACID, ACCTDT, BRCHCD, ITEMCD, SYSTID, CRCYCD);
  
  
  -- ���Ӳ˵� ���˵Ǽǲ�
insert into pcmc_menu (MENUID, CORPCODE, SUBSYSID, PMENUID, LEVELP, MENUNAME, IMGURL, LINKURL, ISINTERNET, REMARK, SORTNO, IS_LEAF, MENUSEQ)
values (599, 'DEFAULT', 23, 577, 2, '���˵Ǽǲ�', null, '/sunfe/glachk/glaChkBook.jsp', '1', null, 8, '1', '.577.599.');


--�����ֵ� ���˵Ǽǲ�״̬
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'glaChk_status', '%', 'DEFAULT', '���˵Ǽǲ�״̬', 1, null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'glaChk_status', '0', 'DEFAULT', 'δ����', null, null, null, null, null, null, null, 1, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'glaChk_status', '1', 'DEFAULT', '�Ѵ���', null, null, null, null, null, null, null, 2, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE, CORPCODE_TEMP)
values ('COMM', 'glaChk_status', '2', 'DEFAULT', '���ִ���', null, null, null, null, null, null, null, 3, null, null, null);


commit;
