update pcmc_menu set linkurl='/sungl/glis/glis_balence.jsp' where menuid = '478' ;

commit;