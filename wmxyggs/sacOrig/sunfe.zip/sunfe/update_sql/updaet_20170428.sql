--���������ֵ� ��Ŀ����
insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMTP', '%', 'DEFAULT', '��Ŀ����', 1, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMTP', '1', 'DEFAULT', '�ʲ���', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMTP', '2', 'DEFAULT', '��ծ��', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMTP', '3', 'DEFAULT', '������Ȩ����', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMTP', '4', 'DEFAULT', 'ϵͳ������', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMTP', '5', 'DEFAULT', '������', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMTP', '6', 'DEFAULT', '����', null, null, null, null, null, null, null, null, null, null);

insert into pcmc_knp_para (SUBSCD, PARATP, PARACD, CORPCODE, PARANA, PARAAM, PARADT, PARACH, PARBCH, PARCCH, PARDCH, PARECH, SORTNO, AREA_NO_STR, I18N_CODE)
values ('GL', 'GL_ITEMTP', '7', 'DEFAULT', '����', null, null, null, null, null, null, null, null, null, null);

--�޸ı�sys_dtit�ĺ�������ֶγ���Ϊ30����sys_dtit_map ������һ��
alter   table sys_dtit  modify ( typecd varchar2(30));

commit;
